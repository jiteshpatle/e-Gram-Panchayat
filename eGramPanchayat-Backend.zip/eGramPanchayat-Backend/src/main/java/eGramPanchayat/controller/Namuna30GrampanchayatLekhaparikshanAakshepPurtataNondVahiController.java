package eGramPanchayat.controller;

import java.util.*;
import java.util.stream.Collectors;

import eGramPanchayat.service.impl.TransactionLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import eGramPanchayat.dto.Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO;
import eGramPanchayat.service.Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiService;
import eGramPanchayat.util.ResponseWrapper;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/lekhaparikshan")
@CrossOrigin(origins = "http://localhost:3000")
public class Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiController {
	@Autowired
	private Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiService service;

	@Autowired
	private TransactionLogService transactionLogService;

	// Create a new record
	@PostMapping("/create")
	public ResponseEntity<?> create(
			@Valid @RequestBody Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO dto,
			BindingResult bindingResult) {
		Map<String, Object> response = new LinkedHashMap<>();

		// Handle validation errors
		if (bindingResult.hasErrors()) {
			// Collect validation error messages into a list of ErrorMessage objects
			List<ErrorMessage> errors = bindingResult.getFieldErrors().stream()
					.map(fieldError -> new ErrorMessage(fieldError.getDefaultMessage()))
					.collect(Collectors.toList());

			response.put("code", "01");
			response.put("message", "Validation Error");
			response.put("errormessage", errors);
			return ResponseEntity.badRequest().body(response);
		}

		try {
			// Call the service layer to save the data
			Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO created = service.create(dto);

			// Log the transaction for audit purposes
			transactionLogService.logTransaction(
					"CREATE",
					"Data created successfully for Namuna30 with ID " + created.getId(),
					null, // Username is fetched automatically in the service
					created.getEmployeeId(),
					created.getEmployeeName(),
					created.getGramPanchayatId(),
					created.getGramPanchayatName());

			// Return a success response
			return ResponseEntity.status(HttpStatus.CREATED)
					.body(new ResponseWrapper<>("00", "Data Saved Successfully", null, ""));
		} catch (IllegalArgumentException e) {
			// Handle validation errors from the service layer
			List<String> errorList = new ArrayList<>();
			errorList.add(e.getMessage());

			// Log the failed attempt
			transactionLogService.logTransaction(
					"CREATE",

					"Validation error during data creation for Namuna30: ",
					null,
					null, null, null, null);

			return ResponseEntity.badRequest().body(new ResponseWrapper<>("01", "Validation Error", null, errorList));
		} catch (Exception e) {
			// Handle general exceptions
			List<String> errorList = new ArrayList<>();
			errorList.add("Error Creating Data");

			// Log the exception
			transactionLogService.logTransaction(
					"CREATE",

					"Error occurred during data creation for Namuna30: " + e.getMessage(),
					null, null, null, null, null);

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new ResponseWrapper<>("01", "Data Not Saved", null, errorList));
		}
	}

	// Update an existing record
	@PostMapping("/update/{id}")
	public ResponseEntity<?> update(
			@PathVariable Long id,
			@Valid @RequestBody Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO dto,
			BindingResult bindingResult) {

		Map<String, Object> response = new LinkedHashMap<>();

		// Handle validation errors
		if (bindingResult.hasErrors()) {
			List<ErrorMessage> errors = bindingResult.getFieldErrors()
					.stream()
					.map(fieldError -> new ErrorMessage(fieldError.getDefaultMessage()))
					.collect(Collectors.toList());

			response.put("code", "01");
			response.put("message", "Validation Error");
			response.put("errormessage", errors);
			return ResponseEntity.badRequest().body(response);
		}

		try {
			Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO updated = service.update(id, dto);

			if (updated != null) {
				// Log successful update transaction
				transactionLogService.logTransaction(
						"UPDATE",

						"Data updated successfully for Namuna30 with ID " + id,
						null // Fetch username automatically in the service,
						, updated.getEmployeeId(), updated.getEmployeeName(), updated.getGramPanchayatId(),
						updated.getGramPanchayatName());

				response.put("code", "00");
				response.put("message", "Data Updated Successfully");
				response.put("errormessage", "");
				return ResponseEntity.ok(response); // 200 OK
			} else {
				// Log not found scenario
				transactionLogService.logTransaction(
						"UPDATE",

						"Update failed. Data not found for Namuna30 with ID " + id,
						null, null, null, null, null);

				response.put("code", "01");
				response.put("message", "Error Updating Data");
				response.put("errormessage", "Data Not Found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response); // 404 Not Found
			}
		} catch (Exception e) {
			// Log the exception
			transactionLogService.logTransaction(
					"UPDATE",

					"Error occurred while updating data for Namuna30 with ID " + id + ": " + e.getMessage(),
					null, null, null, null, null);

			response.put("code", "01");
			response.put("message", "Error Updating Data");
			response.put("errormessage", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response); // 500 Internal Server Error
		}
	}

	// Get all records
	@PostMapping("/getAll")
	public ResponseEntity<?> getAllRecords() {
		Map<String, Object> response = new LinkedHashMap<>();
		try {
			List<Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO> allData = service.findAll();
			if (allData.isEmpty()) {
				response.put("code", "01");
				response.put("message", "Error retrieving Data");
				response.put("errormessage", "Data Not Found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}
			response.put("code", "00");
			response.put("message", "Data Retrieved Successfully");
			response.put("data", allData);
			response.put("errormessage", "");

			return ResponseEntity.status(HttpStatus.OK).body(response);
		} catch (Exception e) {
			response.put("code", "01");
			response.put("message", "Error retrieving Data");
			response.put("errormessage", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}

	// Get a record by ID
	@PostMapping("/getById/{id}")
	public ResponseEntity<?> getRecordById(@PathVariable Long id) {
		Map<String, Object> response = new LinkedHashMap<>();
		try {
			Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO record = service.findById(id);
			if (record != null) {
				// If the record is found, return the record as the response body
				response.put("code", "00");
				response.put("message", "Data Retrieved Successfully");
				response.put("data", record);

				response.put("errormessage", "");

				return ResponseEntity.ok(response);
			} else {
				// If no record is found, return a message
				response.put("code", "01");
				response.put("message", "Error retrieving Data");
				response.put("errormessage", "Data Not Found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}
		} catch (Exception e) {
			// Handle any exceptions and return a 500 Internal Server Error
			response.put("code", "01");
			response.put("message", "Error retrieving Data");
			response.put("errormessage", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}

	}

	@PostMapping("/delete/{id}")
	public ResponseEntity<?> deleteRecord(
			@PathVariable Long id,
			@RequestBody(required = false) Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO deleteRequest) {
		Map<String, Object> response = new LinkedHashMap<>();

		try {
			// Validate if JSON body is provided
			if (deleteRequest == null) {
				response.put("code", "01");
				response.put("message", "Error Deleting Data");
				response.put("errormessage", "Request body is missing.");
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
			}

			// Fetch the record by ID
			Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO record = service.findById(id);
			if (record == null) {
				response.put("code", "01");
				response.put("message", "Error Deleting Data");
				response.put("errormessage", "Data Not Found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}

			// Validate required fields in deleteRequest
			if (deleteRequest.getEmployeeId() == null ||
					deleteRequest.getEmployeeName() == null ||
					deleteRequest.getGramPanchayatId() == null ||
					deleteRequest.getGramPanchayatName() == null) {
				response.put("code", "01");
				response.put("message", "Error Deleting Data");
				response.put("errormessage", "All required fields in the request body must be provided.");
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
			}

			// Attempt to delete the record
			boolean isDeleted = service.delete(id);
			if (isDeleted) {
				// Log successful deletion
				transactionLogService.logTransaction(
						"DELETE",
						"Deleted record of Namuna 30 with ID: " + id,
						null, // Username (optional)
						deleteRequest.getEmployeeId(),
						deleteRequest.getEmployeeName(),
						deleteRequest.getGramPanchayatId(),
						deleteRequest.getGramPanchayatName());

				// Prepare success response
				response.put("code", "00");
				response.put("message", "Data Deleted Successfully");
				response.put("errormessage", "");
				return ResponseEntity.ok(response);
			} else {
				// Prepare not found response
				response.put("code", "01");
				response.put("message", "Error Deleting Data");
				response.put("errormessage", "Data Not Found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}
		} catch (Exception e) {
			// Handle any unexpected exceptions
			response.put("code", "01");
			response.put("message", "Error Deleting Data");
			response.put("errormessage", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}

	static class ErrorMessage {
		private String description;

		public ErrorMessage(String description) {
			this.description = description;
		}

		// Getter
		public String getDescription() {
			return description;
		}
	}
}
