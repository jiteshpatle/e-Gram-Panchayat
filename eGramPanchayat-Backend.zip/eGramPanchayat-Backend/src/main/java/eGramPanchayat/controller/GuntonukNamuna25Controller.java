package eGramPanchayat.controller;

import eGramPanchayat.service.impl.TransactionLogService;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;
import eGramPanchayat.dto.GuntonukNamuna25Dto;
import eGramPanchayat.dto.Namuna32RakkamPartavyaSathiChaAdeshDTO;
import eGramPanchayat.service.GuntonukNamun25Service;
import eGramPanchayat.util.ResponseWrapper;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/guntonukNamuna25")
public class GuntonukNamuna25Controller {

    @Autowired
    private GuntonukNamun25Service guntonukService;
    @Autowired
    private TransactionLogService transactionLogService;

    /*
     * @PostMapping("/add")
     * public ResponseEntity<GuntonukEntity1> createGuntonuk(@Valid @RequestBody
     * GuntonukDTO1 guntonukDTO1) {
     * GuntonukEntity1 savedEntity = guntonukService.save(guntonukDTO1);
     * return new ResponseEntity<>(savedEntity, HttpStatus.CREATED);
     * }
     */
    @PostMapping("/add")
    public HttpEntity<ResponseWrapper<Long>> createGuntonuk(
            @Valid @RequestBody GuntonukNamuna25Dto guntonukDTO,
            BindingResult bindingResult) {
        // Check for validation errors from JSR-303
        if (bindingResult.hasErrors()) {
            List<Map<String, String>> errorMessages = new ArrayList<>();
            int errorCount = 1; // Counter for numbering error messages

            for (FieldError fieldError : bindingResult.getFieldErrors()) {
                Map<String, String> errorMap = new HashMap<>();
                String formattedMessage = errorCount + ". " + fieldError.getDefaultMessage(); // Format with numbering
                errorMap.put(fieldError.getField(), formattedMessage);
                errorMessages.add(errorMap);
                errorCount++; // Increment the counter
            }

            // // Log the validation errors
            // transactionLogService.logTransaction(
            // "CREATE-FAILED",

            // "Validation failed for Guntonuk creation",
            // null, null, null, null, null);

            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseWrapper<>("01", "Validation Failed", null, errorMessages));
        }

        // Custom validation
        try {
            // validateFields(guntonukDTO); // Uncomment this to call your custom validation
            // method
        } catch (IllegalArgumentException e) {
            // // Log the custom validation failure
            // transactionLogService.logTransaction(
            // "CREATE-FAILED",

            // "Custom validation failed for Guntonuk creation",
            // null, null, null, null, null);

            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseWrapper<>("01", "Custom validation failed", null,
                            Collections.singletonList(e.getMessage())));
        }

        // Try to save the Guntonuk DTO
        try {
            // Save the Guntonuk data and get the generated ID (assuming the service returns
            // the saved entity with ID)
            GuntonukNamuna25Dto savedGuntonuk = guntonukService.save(guntonukDTO);

            // Log the successful creation
            transactionLogService.logTransaction(
                    "CREATE", // ID is available after saving
                    "Data saved successfully for Namuna25",
                    null,
                    savedGuntonuk.getEmployeeId(),
                    savedGuntonuk.getEmployeeName(),
                    savedGuntonuk.getGrampanchyatId(),
                    savedGuntonuk.getGrampanchyatName());

            // Return response with the generated ID
            return ResponseEntity.ok()
                    .body(new ResponseWrapper<>("00", "Data Saved Successfully", savedGuntonuk.getId(), ""));
        } catch (Exception e) {
            // // Log the exception during save
            // transactionLogService.logTransaction(
            // "CREATE-ERROR",

            // "Error occurred during Guntonuk creation",
            // null, null, null, null, null);

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "Error occurred", null,
                            Collections.singletonList(e.getMessage())));
        }
    }

    @PostMapping("/getAll")
    public ResponseEntity<ResponseWrapper<List<GuntonukNamuna25Dto>>> getAllGuntonuk() {
        try {
            List<GuntonukNamuna25Dto> kmlist = guntonukService.findAll();
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieve Successfully", kmlist, ""));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "Error Occurred", null,
                            Collections.singletonList(e.getMessage())));
        }
    }

    @PostMapping("/getById/{id}")
    public ResponseEntity<?> getDetailsById(@PathVariable Long id) {
        if (id == null) {
            return ResponseEntity.badRequest()
                    .body(new ResponseWrapper<>("01", "ID must not be null", null, null));
        }

        try {
            GuntonukNamuna25Dto details = guntonukService.findById(id);
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", details, ""));

        } catch (EntityNotFoundException e) {
            // Return specific message when data is not found
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, "Data Not Found")); // Use
                                                                                                         // ResponseWrapper
                                                                                                         // for
                                                                                                         // consistency
        } catch (Exception e) {
            // Handle any other exceptions
            System.err.println("Error retrieving data for ID: " + id + " - " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", null, null, "Error Occurred")); // Use ResponseWrapper for
                                                                                      // consistency
        }
    }

    @PostMapping("/update/{id}")
    public ResponseEntity<ResponseWrapper<GuntonukNamuna25Dto>> updateGuntonuks(
            @PathVariable Long id,
            @Valid @RequestBody GuntonukNamuna25Dto guntonukDTO1,
            BindingResult bindingResult) {

        // Handle validation errors
        if (bindingResult.hasErrors()) {
            List<Map<String, String>> errorMessages = new ArrayList<>();
            int errorCount = 1; // Counter for numbering error messages

            for (FieldError fieldError : bindingResult.getFieldErrors()) {
                Map<String, String> errorMap = new HashMap<>();
                String formattedMessage = errorCount + ". " + fieldError.getDefaultMessage(); // Format with numbering
                errorMap.put(fieldError.getField(), formattedMessage);
                errorMessages.add(errorMap);
                errorCount++; // Increment the counter
            }

            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseWrapper<>("01", "Validation Failed", null, errorMessages));
        }

        try {
            GuntonukNamuna25Dto updated = guntonukService.update(id, guntonukDTO1);

            // Log the successful update action
            transactionLogService.logTransaction("UPDATE", "Data updated successfully for Namuna25 with ID " + id, null,
                    updated.getEmployeeId(),
                    updated.getEmployeeName(),
                    updated.getGrampanchyatId(), updated.getGrampanchyatName()

            );

            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Updated Successfully", null, ""));
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseWrapper<>("01", "Error Updating Data", null, "Data Not Found"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "Error Updating Data", null, "Error Occurred"));
        }
    }

    // Delete record by ID
    @PostMapping("/deleteById/{id}")
    public ResponseEntity<?> delete(@PathVariable long id,
            @RequestBody GuntonukNamuna25Dto deleteRequest) {
        Map<String, Object> response = new LinkedHashMap<>();
        try {
            // Find the record by ID

            if (deleteRequest.getEmployeeId() == null ||
                    deleteRequest.getEmployeeName() == null ||
                    deleteRequest.getGrampanchyatId() == null ||
                    deleteRequest.getGrampanchyatName() == null) {

                // // Log the not-found case with null values
                // transactionLogService.logTransaction(
                // "DELETE",
                // "Deletion failed. Data not found for ID " + id,
                // null, employeeId, employeeName, gramPanchayatId, gramPanchayatName);

                // Prepare a not-found response
                response.put("code", "01");
                response.put("message", "Error Deleting Data");
                response.put("errormessage", "Data Not Found");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }

            // Proceed with deletion
            boolean isDeleted = guntonukService.deleteById(id);
            if (isDeleted) {
                // Log the deletion action with field values (or null if they are missing)
                transactionLogService.logTransaction(
                        "DELETE",
                        "Data deleted successfully for Namuna25 with ID " + id,
                        null, deleteRequest.getEmployeeId(),
                        deleteRequest.getEmployeeName(),
                        deleteRequest.getGrampanchyatId(),
                        deleteRequest.getGrampanchyatName());

                // Prepare a successful response
                response.put("code", "00");
                response.put("message", "Data Deleted Successfully");
                response.put("errormessage", "");
                return ResponseEntity.ok(response);
            } else {
                // // Log the deletion failure with field values (or null if they are missing)
                // transactionLogService.logTransaction(
                // "DELETE",
                // "Deletion operation failed for Namuna32 with ID " + id,
                // null, employeeId, employeeName, gramPanchayatId, gramPanchayatName);

                response.put("code", "01");
                response.put("message", "Error Deleting Data");
                response.put("errormessage", "Deletion operation failed");
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
            }
        } catch (Exception e) {
            // // Log the exception with null values for fields
            // transactionLogService.logTransaction(
            // "DELETE",
            // "Error occurred while deleting data for ID " + id,
            // null, null, null, null, null);

            // Prepare an error response
            response.put("code", "01");
            response.put("message", "Error Deleting Data");
            response.put("errormessage", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }
    // public void validateFields(GuntonukNamuna25Dto dto) {
    // String regex = "^[a-zA-Z0-9 ]*$"; // Adjust the regex pattern as necessary
    //
    // // Validate guntonukiciTapisila
    // if (!dto.getGuntonukiciTapisila().matches(regex)) {
    // throw new IllegalArgumentException("Guntonukici Q Tapisila contains invalid
    // characters.");
    // }
    //
    // // Validate guntonukichiRakamDarsaniMulya
    // if (!dto.getGuntonukichiRakamDarsaniMulya().matches(regex)) {
    // throw new IllegalArgumentException("Guntonukichi Rakam Darsani Mulya contains
    // invalid characters.");
    // }
    //
    // // Validate guntonukichiRakamKharēdīKimata
    // if (!dto.getGuntonukichiRakamKharēdīKimata().matches(regex)) {
    // throw new IllegalArgumentException("Guntonukichi Rakam Kharēdī Kimata
    // contains invalid characters.");
    // }
    //
    // // Validate nivalDyaRakam
    // if (!dto.getNivalDyaRakam().matches(regex)) {
    // throw new IllegalArgumentException("Nival Dya Rakam contains invalid
    // characters.");
    // }
    //
    // // Validate dainikRokadBahithilJamaRakam
    // if (!dto.getDainikRokadBahithilJamaRakam().matches(regex)) {
    // throw new IllegalArgumentException("Dainik Rokad Bahithil Jama Rakam contains
    // invalid characters.");
    // }
    //
    // // Validate prakritischiTapasni
    // if (!dto.getPrakritischiTapasni().matches(regex)) {
    // throw new IllegalArgumentException("Prakritischi Tapasni contains invalid
    // characters.");
    // }
    //
    // // Validate employeeName
    // if (!dto.getEmployeeName().matches(regex)) {
    // throw new IllegalArgumentException("Employee Name contains invalid
    // characters.");
    // }
    //
    // // Validate grampanchyatName
    // if (!dto.getGrampanchyatName().matches(regex)) {
    // throw new IllegalArgumentException("Grampanchyat Name contains invalid
    // characters.");
    // }
    //
    // // Validate remark
    // if (!dto.getRemark().matches(regex)) {
    // throw new IllegalArgumentException("Remark contains invalid characters.");
    // }
    //
    // // Validate Year
    // if (!dto.getYear().matches("^[0-9]+$")) {
    // throw new IllegalArgumentException("Year must contain only digits.");
    // }
    // }

}
