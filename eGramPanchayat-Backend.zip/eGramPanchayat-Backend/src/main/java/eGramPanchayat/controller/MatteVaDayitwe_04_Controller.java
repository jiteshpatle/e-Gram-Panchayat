package eGramPanchayat.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import eGramPanchayat.dto.MatteVaDayitwe_04_Dto;
import eGramPanchayat.service.MatteVaDayitwe_04_Service;
import eGramPanchayat.util.ResponseWrapper;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/matteVaDayitwe")
public class MatteVaDayitwe_04_Controller {

    @Autowired
    private MatteVaDayitwe_04_Service service;

    // Create endpoint
    @PostMapping("/create")
    public ResponseEntity<?> create(@Valid @RequestBody MatteVaDayitwe_04_Dto dto, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            List<String> errors = bindingResult.getFieldErrors().stream()
                .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ResponseWrapper<>("01", "Validation Failed", null, errors));
        }
        try {
            validateInput(dto);
            service.create(dto);
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Saved Successfully", null, ""));
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ResponseWrapper<>("01", "Validation Failed", null, Collections.singletonList(ex.getMessage())));
        } catch (DataIntegrityViolationException ex) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(new ResponseWrapper<>("01", "Data Integrity Violation", null, Collections.singletonList(ex.getMessage())));
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "Failed To Save Data", null, ex.getMessage()));
        }
    }

    // Update endpoint
    @PostMapping("/updateById/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @Valid @RequestBody MatteVaDayitwe_04_Dto dto, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            List<String> errors = bindingResult.getFieldErrors().stream()
                .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ResponseWrapper<>("01", "Validation Failed", null, errors));
        }
        try {
            MatteVaDayitwe_04_Dto updatedEntity = service.update(id, dto);
            if (updatedEntity != null) {
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Updated Successfully", null, ""));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseWrapper<>("01", null, null, "Data Not Found"));
            }
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "Error Updating Data", null, ex.getMessage()));
        }
    }

    // Get specific record by ID
    @PostMapping("/getById/{id}")
    public ResponseEntity<?> getById(@PathVariable Long id) {
        try {
            Optional<MatteVaDayitwe_04_Dto> details = service.getById(id);
            if (details.isPresent()) {
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", details.get(), ""));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseWrapper<>("01", null, null, "Data Not Found"));
            }
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, ex.getMessage()));
        }
    }

    @PostMapping("/getAll")
    public ResponseEntity<?> getAll() {
        try {
            List<MatteVaDayitwe_04_Dto> detailsList = service.getAll();
            if (detailsList.isEmpty()) {
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", new ArrayList<>(), ""));
            }
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", detailsList, ""));
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "An Error Occurred", null, ex.getMessage()));
        }
    }

    // Delete record by ID
    @PostMapping("/deleteById/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        try {
            boolean deleted = service.delete(id);
            if (deleted) {
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Deleted Successfully", null, ""));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseWrapper<>("01", null, null, "Data Not Found"));
            }
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "Error Deleting Data", null, ex.getMessage()));
        }
    }

    private List<String> validateInput(MatteVaDayitwe_04_Dto dto) {
        List<String> errors = new ArrayList<>();
        String regex = "^[\\u0900-\\u097F\\sa-zA-Z0-9-]*$";

        // Validate common fields
        if (dto.getCommonFields() != null) {
            if (dto.getCommonFields().getEmployeeName() == null || !dto.getCommonFields().getEmployeeName().matches(regex)) {
                errors.add("Employee Name contains invalid characters.");
            }

            if (dto.getCommonFields().getGrampanchayatName() == null || !dto.getCommonFields().getGrampanchayatName().matches(regex)) {
                errors.add("Grampanchayat Name contains invalid characters.");
            }

            // Validate employeeId
            if (dto.getCommonFields().getEmployeeId() == null || !dto.getCommonFields().getEmployeeId().matches(regex)) {
                errors.add("Employee ID contains invalid characters.");
            }

            // Validate grampanchayatId
            if (dto.getCommonFields().getGrampanchayatId() == null || !dto.getCommonFields().getGrampanchayatId().matches(regex)) {
                errors.add("Grampanchayat ID contains invalid characters.");
            }

            // Validate remark
            if (dto.getCommonFields().getRemark() == null || !dto.getCommonFields().getRemark().matches(regex)) {
                errors.add("Remark contains invalid characters.");
            }

            // Validate year
            if (dto.getCommonFields().getYear() == null || !dto.getCommonFields().getYear().matches(regex)) {
                errors.add("Year contains invalid characters.");
            }
        }

        // Validate matte fields
        if (dto.getMatteFields() != null) {
            // Validate mattaId
            if (dto.getMatteFields().getMattaId() == null || !dto.getMatteFields().getMattaId().matches(regex)) {
                errors.add("Matta ID contains invalid characters.");
            }

            // Validate each matte field
            validateField(dto.getMatteFields().getEmaratKar(), "Emarat Kar", errors, regex);
            validateField(dto.getMatteFields().getJameenKar(), "Jameen Kar", errors, regex);
            validateField(dto.getMatteFields().getAarogyaKar(), "Aarogya Kar", errors, regex);
            validateField(dto.getMatteFields().getDiwabattiKar(), "Diwabatti Kar", errors, regex);
            validateField(dto.getMatteFields().getPaniPatti(), "Pani Patti", errors, regex);
            validateField(dto.getMatteFields().getKarettar(), "Karettar", errors, regex);
            validateField(dto.getMatteFields().getDukanGaleBhade(), "Dukan Gale Bhade", errors, regex);
            validateField(dto.getMatteFields().getNuksanAnudan(), "Nuksan Anudan", errors, regex);
            validateField(dto.getMatteFields().getSahayyakAnudan(), "Sahayyak Anudan", errors, regex);
            validateField(dto.getMatteFields().getEkunNuksanAnudanSahayyakAnudan(), "Ekun Nuksan Anudan Sahayyak Anudan", errors, regex);
            validateField(dto.getMatteFields().getEtarJamaRakama(), "Etar Jama Rakama", errors, regex);
            validateField(dto.getMatteFields().getAgrimWasuliBaki(), "Agrim Wasuli Baki", errors, regex);
            validateField(dto.getMatteFields().getPanchayatichiSthavarMalmatta(), "Panchayatichi Sthavar Malmatta", errors, regex);
        }

        // Validate dayitwe fields
        if (dto.getDayitweFields() != null) {
            validateField(dto.getDayitweFields().getDayitweId(), "Dayitwe ID", errors, regex);
            validateField(dto.getDayitweFields().getThakitDeyak(), "Thakit Deyak", errors, regex);
            validateField(dto.getDayitweFields().getWetan(), "Wetan", errors, regex);
            validateField(dto.getDayitweFields().getWetanWyatiriktaEtarAasthapana(), "Wetan Wyatirikta Etar Aasthapana", errors, regex);
            validateField(dto.getDayitweFields().getSadhanSamagri(), "Sadhan Samagri", errors, regex);
            validateField(dto.getDayitweFields().getBandhkaam(), "Bandhkaam", errors, regex);
            validateField(dto.getDayitweFields().getEtar(), "Etar", errors, regex);
            validateField(dto.getDayitweFields().getGrampanchayatiKadunDeneAslelyaThakitRakma(), "Grampanchayati Kadun Dene Aslelya Thakit Rakma", errors, regex);
            validateField(dto.getDayitweFields().getKarjHaftaWaKarjawarilWyajHafta(), "Karj Hafta Wa Karjawaril Wyaj Hafta", errors, regex);
            validateField(dto.getDayitweFields().getEtarDeyaRakkam(), "Etar Deya Rakkam", errors, regex);
            validateField(dto.getDayitweFields().getTheviPartachaBaki(), "Thevi Partacha Baki", errors, regex);
            validateField(dto.getDayitweFields().getSamajKalyanBaki(), "Samaj Kalyan Baki", errors, regex);
            validateField(dto.getDayitweFields().getMahilaWaBalkalyanAnushesh(), "Mahila Wa Balkalyan Anushesh", errors, regex);
        }

        return errors;
    }

    // Helper method for field validation
    private void validateField(String fieldValue, String fieldName, List<String> errors, String regex) {
        if (fieldValue == null || !fieldValue.matches(regex)) {
            errors.add(fieldName + " contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }
    }

}
