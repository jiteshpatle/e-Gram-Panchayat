package eGramPanchayat.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import eGramPanchayat.dto.AakasmikKharchachePramanak_12_Dto;
import eGramPanchayat.service.AakasmikKharchachePramanak_12_Service;
import eGramPanchayat.util.ResponseWrapper;
import jakarta.validation.Valid;
@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/aakasmikKharchachePramanak")
public class AakasmikKharchachePramanak_12_Controller {

    @Autowired
    private AakasmikKharchachePramanak_12_Service service;

    @PostMapping("/create")
    public ResponseEntity<?> saveDetails(@Valid @RequestBody AakasmikKharchachePramanak_12_Dto dto, BindingResult bindingResult) {
        // Check for validation errors from BindingResult
        if (bindingResult.hasErrors()) {
            List<String> errors = bindingResult.getFieldErrors().stream()
                .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ResponseWrapper<List<String>>("01", "Validation Failed", null, errors));
        }

        // Validate the input using custom validation method
        List<Map<String, String>> validationErrors = validateInput(dto);
        if (!validationErrors.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ResponseWrapper<List<Map<String, String>>>("01", "Validation Failed", null, validationErrors));
        }

        try {
            // Create the record
            service.create(dto);
            // Return success response
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Saved Successfully!", null, ""));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<String>("01", "An Error Occurred", null, e.getMessage()));
        }
    }

 // Update endpoint
    @PostMapping("/updateById/{id}")
    public ResponseEntity<?> updateDetails(@PathVariable Long id, @Valid @RequestBody AakasmikKharchachePramanak_12_Dto dto, BindingResult bindingResult) {
        // Check for validation errors from BindingResult
        if (bindingResult.hasErrors()) {
            List<String> errors = bindingResult.getFieldErrors().stream()
                .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ResponseWrapper<List<String>>("01", "Validation Failed", null, errors));
        }

        // Validate the input using custom validation method
        List<Map<String, String>> validationErrors = validateInput(dto);
        if (!validationErrors.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ResponseWrapper<List<Map<String, String>>>("01", "Validation Failed", null, validationErrors));
        }

        try {
            AakasmikKharchachePramanak_12_Dto updatedEntity = service.update(id, dto);
            if (updatedEntity != null) {
                // Return success response
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Updated Successfully!", null, ""));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseWrapper<>("01", "Error Updating Data", null, "Data Not Found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<String>("01", "Error Updating Data", null, e.getMessage()));
        }
    }


    // Get all records
    @PostMapping("/getAll")
    public ResponseEntity<?> getAllDetails() {
        try {
            List<AakasmikKharchachePramanak_12_Dto> detailsList = service.getAll();
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", detailsList, ""));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "An Error Occurred", null, e.getMessage()));
        }
    }

    // Get specific record by ID
    @PostMapping("/getById/{id}")
    public ResponseEntity<?> getDetailsById(@PathVariable Long id) {
        try {
            Optional<AakasmikKharchachePramanak_12_Dto> details = service.getById(id);
            if (details.isPresent()) {
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", details.get(), ""));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, "Data Not Found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, e.getMessage()));
        }
    }

    // Delete record by ID
    @PostMapping("/deleteById/{id}")
    public ResponseEntity<?> deleteDetails(@PathVariable Long id) {
        try {
            boolean deleted = service.delete(id);
            if (deleted) {
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Deleted Successfully!", null, ""));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseWrapper<>("01", null, null, "Data Not Found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "Error Deleting Data", null, e.getMessage()));
        }
    }

    // Updated validation method
    public List<Map<String, String>> validateInput(AakasmikKharchachePramanak_12_Dto dto) {
        List<Map<String, String>> errorMessages = new ArrayList<>(); // List to store error messages
        String regex = "^[\\u0900-\\u097F\\sa-zA-Z0-9-]*$"; // Only allow alphanumeric characters and spaces

        // Helper method to add errors to the list
        Consumer<String> addError = message -> {
            Map<String, String> error = new HashMap<>();
            error.put("description", message);
            errorMessages.add(error);
        };

     // Validate employeeName
        if (dto.getEmployeeName() != null && !dto.getEmployeeName().matches(regex)) {
            addError.accept("Employee Name contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate grampanchayatName
        if (dto.getGrampanchayatName() != null && !dto.getGrampanchayatName().matches(regex)) {
            addError.accept("Grampanchayat Name contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate employeeId
        if (dto.getEmployeeId() != null && !dto.getEmployeeId().matches(regex)) {
            addError.accept("Employee ID contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate grampanchayatId
        if (dto.getGrampanchayatId() != null && !dto.getGrampanchayatId().matches(regex)) {
            addError.accept("Grampanchayat ID contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }



        // Validate deyakKramank
        if (!dto.getDeyakKramank().matches(regex)) {
            addError.accept("Deyak Kramank contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate pavtiLihunDenar
        if (!dto.getPavtiLihunDenar().matches(regex)) {
            addError.accept("Pavti Lihun Denar contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate kamacheKharediPavtiPramaneInNumbers
        if (!dto.getKamacheKharediPavtiPramaneInNumbers().matches(regex)) {
            addError.accept("Kamache Kharedi Pavti Pramane (in numbers) contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate kamacheKharediPavtiPramaneAkshari
        if (!dto.getKamacheKharediPavtiPramaneAkshari().matches(regex)) {
            addError.accept("Kamache Kharedi Pavti Pramane (in akshari) contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate matraRokhCheckNo
        if (!dto.getMatraRokhCheckNo().matches(regex)) {
            addError.accept("Matra Rokh Check No contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate nagKinwaWajan
        if (!dto.getNagKinwaWajan().matches(regex)) {
            addError.accept("Nag Kinwa Wajan contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate dar
        if (!dto.getDar().matches(regex)) {
            addError.accept("Dar contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate unit
        if (!dto.getUnit().matches(regex)) {
            addError.accept("Unit contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate rakkamRupaye
        if (!dto.getRakkamRupaye().matches(regex)) {
            addError.accept("Rakkam Rupaye contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate watnichiRakkamRupaye
        if (!dto.getWatnichiRakkamRupaye().matches(regex)) {
            addError.accept("Watnichi Rakkam Rupaye contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate purvichaKharchRupaye
        if (!dto.getPurvichaKharchRupaye().matches(regex)) {
            addError.accept("Purvicha Kharch Rupaye contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate dewakatDarshawilelaKharch
        if (!dto.getDewakatDarshawilelaKharch().matches(regex)) {
            addError.accept("Dewakat Darshawilela Kharch contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate ekunBerij2Plus2Rupaye
        if (!dto.getEkunBerij2Plus2Rupaye().matches(regex)) {
            addError.accept("Ekun Berij (2+2) Rupaye contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate uplabdhShillak
        if (!dto.getUplabdhShillak().matches(regex)) {
            addError.accept("Uplabdh Shillak contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate tharavKramank
        if (!dto.getTharavKramank().matches(regex)) {
            addError.accept("Tharav Kramank contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate dewakamadheDarshavileliRakkam
        if (!dto.getDewakamadheDarshavileliRakkam().matches(regex)) {
            addError.accept("Dewakamadhe Darshavileli Rakkam contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate maganiPurvichePurnRupayeInNumbers
        if (!dto.getMaganiPurvichePurnRupayeInNumbers().matches(regex)) {
            addError.accept("Magani Purviche Purn Rupaye (in numbers) contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate maganiPurvichePurnRupayeAkshari
        if (!dto.getMaganiPurvichePurnRupayeAkshari().matches(regex)) {
            addError.accept("Magani Purviche Purn Rupaye (in akshari) contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate pramanakKramank
        if (!dto.getPramanakKramank().matches(regex)) {
            addError.accept("Pramanak Kramank contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate rojwahitilPrusthKramank
        if (!dto.getRojwahitilPrusthKramank().matches(regex)) {
            addError.accept("Rojwahitil Prusth Kramank contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }


        return errorMessages; // Return the list of errors
    }
}
