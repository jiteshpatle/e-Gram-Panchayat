package eGramPanchayat.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import eGramPanchayat.dto.LekhaparikshanAaksheepanNamuna27DTO;
import eGramPanchayat.entity.Kirkolmagni_11;
import eGramPanchayat.service.Kirkolmagni11Service;
import eGramPanchayat.service.impl.Kirkolmagni11ServiceImpl;
import eGramPanchayat.service.impl.TransactionLogService;
import eGramPanchayat.util.ResponseWrapper;
import jakarta.validation.Valid;

@CrossOrigin("*")
@RestController
@RequestMapping("/kirkolmagni_11")
public class Kirkolmagni_11_Controller {

	
	@Autowired
	 private TransactionLogService transactionLogService;
	@Autowired
	Kirkolmagni11Service kirkolmagni11Service;
	
	@Autowired
	Kirkolmagni11ServiceImpl impl;

	@PostMapping("/create")
	public ResponseEntity<?> createEgram11(@Valid @RequestBody Kirkolmagni_11 entry, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
            List<String> errors = bindingResult.getFieldErrors().stream()
                .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ResponseWrapper<>("01", "Validation Failed", null, errors));
        }try {
        	Kirkolmagni_11 created =impl.saveEgram11(entry);            // Additional custom validation (e.g., regex or business logic)
            List<Map<String, String>> customErrors = validateInput(entry);
            if (!customErrors.isEmpty()) { 
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseWrapper<>("01", "Validation Failed", null, customErrors));
            }

            // Save entry through the service
           kirkolmagni11Service.saveEgram11(entry);
           
           transactionLogService.logTransaction(
					"SAVE", "Data saved successfully for Namuna11", null,
					created.getEmployeeId(),
					created.getEmployeeName(),
					created.getGrampanchayatId(),
					created.getGrampanchayatName());
           
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Saved Successfully", null, ""));
        } catch (IllegalArgumentException e) {
            // Return validation errors as response
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ResponseWrapper<>("01", "Validation Failed", null, e.getMessage()));
        } catch (Exception e) {
            // Catch any unexpected errors
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "An Error Occurred", null, "Data Not Found"));
        }
	}

	@PostMapping("/getBYID/{id}")
	public ResponseEntity<?> getEgram9ById(@PathVariable Long id)
	{
		try {
		Optional<Kirkolmagni_11> entry= kirkolmagni11Service.getEgram11_ById(id);
		 if (entry.isPresent()) {
             return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Found", entry.get(), ""));
         } else {
             return ResponseEntity.status(HttpStatus.NOT_FOUND)
                 .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, "Data Not Found"));
         }
     } catch (Exception e) {
         return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
             .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, e.getMessage()));
     }
	}

	@PostMapping("/getAll")
	public ResponseEntity<?> getAll() {
		try {
			List<Kirkolmagni_11> list = kirkolmagni11Service.getAllEgram11();

			return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", list, ""));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new ResponseWrapper<>("01", "An Error Occurred", null, e.getMessage()));
		}
	}
	
	 @PostMapping("/updateById/{id}")
	    public ResponseEntity<?>updateEgram11(@PathVariable Long id, @Valid @RequestBody Kirkolmagni_11 entry, BindingResult bindingResult) {
	        // Check for validation errors
	        if (bindingResult.hasErrors()) {
	            List<String> errors = bindingResult.getFieldErrors().stream()
	                .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
	                .collect(Collectors.toList());
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
	                .body(new ResponseWrapper<>("01", "Validation Failed", null, errors));
	        }

	        try {
	            // Additional custom validation (e.g., regex or business logic)
	            List<Map<String, String>> customErrors = validateInput(entry);
	            if (!customErrors.isEmpty()) {
	                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
	                    .body(new ResponseWrapper<>("01", "Validation Failed", null, customErrors));
	            }

	       
	            // Update entry through the service layer
	            Kirkolmagni_11 updatedEntry = kirkolmagni11Service.updateEgram11(id, entry);
	            if (updatedEntry != null) {
	            	
	            	transactionLogService.logTransaction(
		                    "UPDATE",
		                    "Successfully updated data for Namuna11 with ID: " + id,
		                    null,
		                    updatedEntry.getEmployeeId(),
		                    updatedEntry.getEmployeeName(),
		                    updatedEntry.getGrampanchayatId(),
		                    updatedEntry.getGrampanchayatName());
	                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Updated Successfully", null, ""));
	            } else {
	                // If entry not found, return a not found response
	                return ResponseEntity.status(HttpStatus.NOT_FOUND)
	                    .body(new ResponseWrapper<>("01", "Error Updating Data", null, "Data Not Found"));
	            }
	        } catch (Exception e) {
	            // Catch unexpected errors
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                .body(new ResponseWrapper<>("01", "Error Updating Data", null, "Data Not Found"));
	        }
	    }

@PostMapping("/deleteByID/{id}")
	public ResponseEntity<?> delete(@PathVariable long id,
                        @RequestBody Kirkolmagni_11 deleteRequest) {
                Map<String, Object> response = new LinkedHashMap<>();
                try {
                        // Find the record by ID

                        if (deleteRequest.getEmployeeId() == null ||
                                        deleteRequest.getEmployeeName() == null ||
                                        deleteRequest.getGrampanchayatId() == null ||
                                        deleteRequest.getGrampanchayatName() == null) {

                                // // Log the not-found case with null values
                                // transactionLogService.logTransaction(
                                // "DELETE",
                                // "Deletion failed. Data not found for ID " + id,
                                // null, employeeId, employeeName, gramPanchayatId, gramPanchayatName);

                                // Prepare a not-found response
                                response.put("code", "01");
                                response.put("message", "Error Deleting Data");
                                response.put("errormessage", "Data Not Found");
                                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
                        }

                        // Proceed with deletion
						boolean isDeleted = kirkolmagni11Service.deleteEgram11(id);
                        if (isDeleted) {
                                // Log the deletion action with field values (or null if they are missing)
                                transactionLogService.logTransaction(
                                                "DELETE",
                                                "Data deleted successfully for Namuna11 with ID " + id,
                                                null, deleteRequest.getEmployeeId(),
                                                deleteRequest.getEmployeeName(),
                                                deleteRequest.getGrampanchayatId(),
                                                deleteRequest.getGrampanchayatName());

                                // Prepare a successful response
                                response.put("code", "00");
                                response.put("message", "Data Deleted Successfully");
                                response.put("errormessage", "");
                                return ResponseEntity.ok(response);
                        } else {
                                // // Log the deletion failure with field values (or null if they are missing)
                                // transactionLogService.logTransaction(
                                // "DELETE",
                                // "Deletion operation failed for Namuna32 with ID " + id,
                                // null, employeeId, employeeName, gramPanchayatId, gramPanchayatName);

                                response.put("code", "01");
                                response.put("message", "Error Deleting Data");
                                response.put("errormessage", "Deletion operation failed");
                                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
                        }
                } catch (Exception e) {
                        // // Log the exception with null values for fields
                        // transactionLogService.logTransaction(
                        // "DELETE",
                        // "Error occurred while deleting data for ID " + id,
                        // null, null, null, null, null);

                        // Prepare an error response
                        response.put("code", "01");
                        response.put("message", "Error Deleting Data");
                        response.put("errormessage", e.getMessage());
                        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
                }
        }
private List<Map<String,String>> validateInput(Kirkolmagni_11 entry){
	
List<Map<String,String>> errorMessages=new ArrayList<>();
	String regex="^[//u0900-\\u097F\\sa-zA-Z0-9-]*$";
	
	//Helper method to add errors to the list
	Consumer<String> addError = message ->{
		Map<String,String> error=new HashMap<>();
	error.put("description",message);
	 errorMessages.add(error);
	};
    // Validate String fields for alphanumeric and space constraints
    if (entry.getYear() != null && !entry.getYear().matches(regex)) {
        addError.accept("Year contains invalid characters. Only alphanumeric characters, spaces, and dashes are allowed.");
    }

    if (entry.getEmployeeId() != null && !entry.getEmployeeId().matches(regex)) {
        addError.accept("Employee ID contains invalid characters. Only alphanumeric characters, spaces, and dashes are allowed.");
    }

    if (entry.getEmployeeName() != null && !entry.getEmployeeName().matches(regex)) {
        addError.accept("Employee Name contains invalid characters. Only alphanumeric characters, spaces, and dashes are allowed.");
    }

    if (entry.getGrampanchayatId() != null && !entry.getGrampanchayatId().matches(regex)) {
        addError.accept("Grampanchayat ID contains invalid characters. Only alphanumeric characters, spaces, and dashes are allowed.");
    }

    if (entry.getGrampanchayatName() != null && !entry.getGrampanchayatName().matches(regex)) {
        addError.accept("Grampanchayat Name contains invalid characters. Only alphanumeric characters, spaces, and dashes are allowed.");
    }

    if (entry.getRemark() != null && !entry.getRemark().matches(regex)) {
        addError.accept("Remark contains invalid characters. Only alphanumeric characters, spaces, and dashes are allowed.");
    }

    if (entry.getPropertyOwnerName() != null && !entry.getPropertyOwnerName().matches(regex)) {
        addError.accept("Property Owner Name contains invalid characters. Only alphanumeric characters, spaces, and dashes are allowed.");
    }

    if (entry.getDeyakramankOR_Date() != null && !entry.getDeyakramankOR_Date().matches(regex)) {
        addError.accept("Deyakramank OR Date contains invalid characters. Only alphanumeric characters, spaces, and dashes are allowed.");
    }

    if (entry.getVasuli_PavtiKramankOR_Date()!= null && !entry.getVasuli_PavtiKramankOR_Date().matches(regex)) {
        addError.accept("Vasuli Pavti Kramank OR Date contains invalid characters. Only alphanumeric characters, spaces, and dashes are allowed.");
    }

    if (entry.getSut_AadheshachaKramankOR_Date() != null && !entry.getSut_AadheshachaKramankOR_Date().matches(regex)) {
        addError.accept("Sut Aadheshacha Kramank OR Date contains invalid characters. Only alphanumeric characters, spaces, and dashes are allowed.");
    }

    if (entry.getShera() != null && !entry.getShera().matches(regex)) {
        addError.accept("Shera contains invalid characters. Only alphanumeric characters, spaces, and dashes are allowed.");
    }

    // Validate Long fields for non-null and non-negative values
    BiConsumer<Long, String> validateLongField = (value, fieldName) -> {
        if (value == null || value < 0) {
            addError.accept(fieldName + " must be a non-negative number and cannot be null.");
        }
    };

    validateLongField.accept(entry.getMagni_Happta(), "Magni Happta");
    validateLongField.accept(entry.getMagni_Rakam(), "Magni Rakam");
    validateLongField.accept(entry.getVasuli_Rakam(), "Vasuli Rakam");
    validateLongField.accept(entry.getSut_Rakam(), "Sut Rakam");
    validateLongField.accept(entry.getShillak(), "Shillak");
    
    return errorMessages; // Return all error messages
}

}

