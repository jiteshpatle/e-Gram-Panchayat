package eGramPanchayat.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import eGramPanchayat.dto.JaminichiNondWahi_24_Dto;
import eGramPanchayat.service.JaminichiNondWahi_24_Service;
import eGramPanchayat.util.ResponseWrapper;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/jaminichiNondWahi")
public class JaminichiNondWahi_24_Controller {

    @Autowired
    private JaminichiNondWahi_24_Service service;

 // Save endpoint
    @PostMapping("/create")
    public ResponseEntity<?> saveDetails(@Valid @RequestBody JaminichiNondWahi_24_Dto dto, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            List<String> errors = bindingResult.getFieldErrors().stream()
                .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ResponseWrapper<>("01", "Validation Failed", null, errors));
        }

        // Custom validation
//        List<Map<String, String>> validationErrors = validateInput(dto);
//        if (!validationErrors.isEmpty()) {
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                .body(new ResponseWrapper<>("01", "Validation Failed", null, validationErrors));
//        }

        try {
            service.createJaminichiNondWahi(dto);
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Saved Successfully!", null, ""));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "An Error Occurred", null, e.getMessage()));
        }
    }


 // Update endpoint
    @PostMapping("/updateById/{id}")
    public ResponseEntity<?> updateDetails(@PathVariable Long id, @Valid @RequestBody JaminichiNondWahi_24_Dto dto, BindingResult bindingResult) {
        // Check for standard validation errors
        if (bindingResult.hasErrors()) {
            List<String> errors = bindingResult.getFieldErrors().stream()
                .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ResponseWrapper<>("01", "Validation Failed", null, errors));
        }

        // Custom validation
//        List<Map<String, String>> validationErrors = validateInput(dto);
//        if (!validationErrors.isEmpty()) {
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                .body(new ResponseWrapper<>("01", "Validation Failed", null, validationErrors));
//        }

        try {
            JaminichiNondWahi_24_Dto updatedEntity = service.updateJaminichiNondWahi(id, dto);
            if (updatedEntity != null) {
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Updated Successfully!", null, ""));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseWrapper<>("01", null, null, "Data Not Found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "Error Updating Data", null, e.getMessage()));
        }
    }


    // Get all records
    @PostMapping("/getAll")
    public ResponseEntity<?> getAllDetails() {
        try {
            List<JaminichiNondWahi_24_Dto> detailsList = service.getAllJaminichiNondWahi();
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", detailsList, ""));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "An Error Occurred", null, e.getMessage()));
        }
    }

    // Get specific record by ID
    @PostMapping("/getById/{id}")
    public ResponseEntity<?> getDetailsById(@PathVariable Long id) {
        try {
            Optional<JaminichiNondWahi_24_Dto> details = service.getJaminichiNondWahiById(id);
            if (details.isPresent()) {
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Found", details.get(), ""));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseWrapper<>("01", null, null, "Data Not Found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, e.getMessage()));
        }
    }

    // Delete record by ID
    @PostMapping("/deleteById/{id}")
    public ResponseEntity<?> deleteDetails(@PathVariable Long id) {
        try {
            boolean deleted = service.deleteJaminichiNondWahi(id);
            if (deleted) {
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Deleted Successfully!", null, ""));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseWrapper<>("01", null, null, "Data Not Found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "Error Deleting Data", null, e.getMessage()));
        }
    }
}

//    private List<Map<String, String>> validateInput(JaminichiNondWahi_24_Dto dto) {
//        List<Map<String, String>> errorMessages = new ArrayList<>(); // List to store error messages
//        String regex = "[a-zA-Z0-9 ]+"; // Only allow alphanumeric characters and spaces
//
//        // Helper method to add errors to the list
//        Consumer<String> addError = message -> {
//            Map<String, String> error = new HashMap<>();
//            error.put("description", message);
//            errorMessages.add(error);
//        };
//
//        // Validate employeeName
//        if (!dto.getEmployeeName().matches(regex)) {
//            addError.accept("Employee Name contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }
//
//        // Validate grampanchayatName
//        if (!dto.getGrampanchayatName().matches(regex)) {
//            addError.accept("Grampanchayat Name contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }
//
//        // Validate employeeId
//        if (!dto.getEmployeeId().matches(regex)) {
//            addError.accept("Employee ID contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }
//
//        // Validate grampanchayatId
//        if (!dto.getGrampanchayatId().matches(regex)) {
//            addError.accept("Grampanchayat ID contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }
//
//        // Validate anukramank
//        if (!dto.getAnukramank().matches(regex)) {
//            addError.accept("Anukramank contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }
//
//        // Validate Year
//        if (!dto.getYear().matches(regex)) {
//            addError.accept("Year contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }
//
//        // Validate konatyaKarnasaathi
//        if (!dto.getKonatyaKarnasaathi().matches(regex)) {
//            addError.accept("Konatya Karnasaathi contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }
//
//        // Validate konakadun
//        if (!dto.getKonakadun().matches(regex)) {
//            addError.accept("Konakadun contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }
//
//        // Validate kararnamaNiwadaNirdeshank
//        if (!dto.getKararnamaNiwadaNirdeshank().matches(regex)) {
//            addError.accept("Kararnama Niwada Nirdeshank contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }
//
//        // Validate jaminicheKshetraphal
//        if (!dto.getJaminicheKshetraphal().matches(regex)) {
//            addError.accept("Jaminiche Kshetraphal contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }
//
//        // Validate bhumapanKramankEtyadi
//        if (!dto.getBhumapanKramankEtyadi().matches(regex)) {
//            addError.accept("Bhumapan Kramank Etyadi contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }
//
//        // Validate aakarni
//        if (!dto.getAakarni().matches(regex)) {
//            addError.accept("Aakarni contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }
//
//        // Validate jaminichyaSeema
//        if (!dto.getJaminichyaSeema().matches(regex)) {
//            addError.accept("Jaminichya Seema contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }
//
//        // Validate jaminisahKharediSampadanEmarati
//        if (!dto.getJaminisahKharediSampadanEmarati().matches(regex)) {
//            addError.accept("Jaminisah Kharedi Sampadan Emarati contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }
//
//        // Validate jaminichiWaEmartichiWilhewat
//        if (!dto.getJaminichiWaEmartichiWilhewat().matches(regex)) {
//            addError.accept("Jaminichi Wa Emartichi Wilhewat contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }
//
//        // Validate vikriPaasunMilaleliRakkam
//        if (!dto.getVikriPaasunMilaleliRakkam().matches(regex)) {
//            addError.accept("Vikri Paasun Milaleli Rakkam contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }
//
//        // Validate pramanakachaKramankWaDinank
//        if (!dto.getPramanakachaKramankWaDinank().matches(regex)) {
//            addError.accept("Pramanakacha Kramank Wa Dinank contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }
//
//        // Validate malmattechiWilhewatPanchayatichaTharav
//        if (!dto.getMalmattechiWilhewatPanchayatichaTharav().matches(regex)) {
//            addError.accept("Malmattechi Wilhewat Panchayaticha Tharav contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }
//
//        // Validate malmattechiWilhewatKalam55
//        if (!dto.getMalmattechiWilhewatKalam55().matches(regex)) {
//            addError.accept("Malmattechi Wilhewat Kalam 55 contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }
//
//        // Validate shera
//        if (!dto.getShera().matches(regex)) {
//            addError.accept("Shera contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }
//
//        return errorMessages; // Return the list of errors
//    }
//
//}