package eGramPanchayat.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import eGramPanchayat.entity.Egram26_K;

import eGramPanchayat.service.Egram_26K_Service;
import eGramPanchayat.service.impl.Egram_26K_ServiceImpl;
import eGramPanchayat.service.impl.TransactionLogService;
import eGramPanchayat.util.ResponseWrapper;

@RestController
@RequestMapping("/Egram26K")
@CrossOrigin("*")
public class Egram_26K_Controller {
	

	@Autowired
	private Egram_26K_Service egram26kService;
	
	@Autowired
	private Egram_26K_ServiceImpl impl;
	
	@Autowired
	 private TransactionLogService transactionLogService;
	
	
	
	@PostMapping("/create")
	public ResponseEntity<?> createEgram29K(@RequestBody Egram26_K entry, BindingResult bindingResult, @RequestHeader(value = "username", defaultValue = "unknown") String username)
	{
		if(bindingResult.hasErrors())
		{
			List<String> errors = bindingResult.getFieldErrors().stream()
					.map(FieldError -> FieldError.getField() +" : "+FieldError.getDefaultMessage())
					.collect(Collectors.toList());
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.body(new ResponseWrapper<>("01","Valiadtion Failed",null,errors));
		}
		try {
			
			Egram26_K created = impl.saveEgram26_K(entry);

			// Log the creation action
			transactionLogService.logTransaction(
					"SAVE", "Data saved successfully for Namuna26K", null,
					created.getEmployeeId(),
					created.getEmployeeName(),
					created.getGrampanchayatId(),
					created.getGrampanchayatName());
	
			

			
			
            // Additional custom validation (e.g., regex or business logic)
            List<Map<String, String>> customErrors = validateInput(entry);
            if (!customErrors.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseWrapper<>("01", "Validation Failed", null, customErrors));
            }

            // Save entry through the service
            egram26kService.saveEgram26_K(entry);
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Saved Successfully", null, ""));
        } catch (IllegalArgumentException e) {
            // Return validation errors as response
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ResponseWrapper<>("01", "Validation Failed", null, e.getMessage()));
        } catch (Exception e) {
            // Catch any unexpected errors
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "An Error Occurred", null, "Data Not Found"));
        }
		
	}
		@PostMapping("/getByID/{id}")
		public ResponseEntity<?> getByIDEgramg26K(@PathVariable Long id)
		{
			try {
				Optional<Egram26_K> entry = egram26kService.getEgram26KById(id);
				if(entry.isPresent())
				{
					return ResponseEntity.ok(new ResponseWrapper<>("00","Data Found",entry.get(),""));
				}else {
		             return ResponseEntity.status(HttpStatus.NOT_FOUND)
			                 .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, "Data Not Found"));
			         }
			   }
			   catch (Exception e) {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
						.body(new ResponseWrapper<>("01","Error Retrieving Data", null, e.getMessage()));
			}
			
		}
		
		@PostMapping("/getAll")
		public ResponseEntity<?> getAll()
		{
			try {
				List<Egram26_K> list =egram26kService.getAllEgram26_K();
				return ResponseEntity.ok(new ResponseWrapper<>("00","All Data Found Successfully",list,""));
			}catch (Exception e) {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseWrapper<>("01","An Error Occurred", null, e.getMessage()));
			}
		}
		
		@PostMapping("/updateByID/{id}")
		public ResponseEntity<?> updateEgram26K(@PathVariable Long id, @RequestBody Egram26_K entry,BindingResult bindingResult)
		{
			if (bindingResult.hasErrors()) {
		        List<String> errors = bindingResult.getFieldErrors().stream()
		            .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
		            .collect(Collectors.toList());
		        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
		            .body(new ResponseWrapper<>("01", "Validation Failed", null, errors));
		    }try {
		    	Egram26_K updatedEntity=egram26kService.updateEgram26KById(id, entry);
		        // Additional custom validation (e.g., regex or business logic)
		        List<Map<String, String>> customErrors = validateInput(entry);
		        if (!customErrors.isEmpty()) { 
		            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
		                .body(new ResponseWrapper<>("01", "Validation Failed", null, customErrors));
		        }

		        // Save entry through the service
		        egram26kService.updateEgram26KById(id, entry);
		        
		        
		        transactionLogService.logTransaction(
	                    "UPDATE",
	                    "Successfully updated data for Namuna with ID: " + id,
	                    null,
	                    updatedEntity.getEmployeeId(),
	                    updatedEntity.getEmployeeName(),
	                    updatedEntity.getGrampanchayatId(),
	                    updatedEntity.getGrampanchayatName());
		        return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Updated Successfully", null, ""));
		    } catch (IllegalArgumentException e) {
		        // Return validation errors as response
		        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
		            .body(new ResponseWrapper<>("01", "Validation Failed", null, e.getMessage()));
		    } catch (Exception e) {
		        // Catch any unexpected errors
		        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
		            .body(new ResponseWrapper<>("01", "An Error Occurred", null, "Data Not Found"));
		    }
		}

		@PostMapping("/deleteByID/{id}")
		 public ResponseEntity<?> deleteEgram26K(@PathVariable Long id, @RequestBody(required = false) Egram26_K deleteRequest)
		{
			try {
				boolean delete = egram26kService.deleteEgram26(id);
				if(delete)
				{
					 transactionLogService.logTransaction(
			                    "DELETE",
			                    "Successfully deleted Namuna26K data for ID: " + id,
			                    null,
			                    deleteRequest.getEmployeeId(),
			                    deleteRequest.getEmployeeName(),
			                    deleteRequest.getGrampanchayatId(),
			                    deleteRequest.getGrampanchayatName());

					return ResponseEntity.ok(new ResponseWrapper<>("00","Data Deleted Successfully",null,""));
				}else
				{
					return ResponseEntity.status(HttpStatus.BAD_REQUEST)
							.body(new ResponseWrapper<>("01",null,null,"Data not found"));
				}
			}
			catch (Exception e) {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
						.body(new ResponseWrapper<>("01","Error in Deleting process",null,e.getMessage()));
			
			}
			
		}
	
	 private List<Map<String, String>> validateInput(Egram26_K entry) {
	        List<Map<String, String>> errorMessages = new ArrayList<>(); // List to store error messages
	        String regex = "^[\\u0900-\\u097F\\sa-zA-Z0-9-]*$"; // Allow alphanumeric characters, spaces, and dashes

	        // Helper method to add errors to the list
	        Consumer<String> addError = message -> {
	            Map<String, String> error = new HashMap<>();
	            error.put("description", message);
	            errorMessages.add(error);
	        };

	        // Validate String fields for alphanumeric and space constraints
	        if (entry.getYear() != null && !entry.getYear().matches(regex)) {
	            addError.accept("Year contains invalid characters. Only alphanumeric characters and spaces are allowed.");
	        }

	        if (entry.getEmployeeId() != null && !entry.getEmployeeId().matches(regex)) {
	            addError.accept("Employee ID contains invalid characters. Only alphanumeric characters and spaces are allowed.");
	        }

	        if (entry.getEmployeeName() != null && !entry.getEmployeeName().matches(regex)) {
	            addError.accept("Employee Name contains invalid characters. Only alphanumeric characters and spaces are allowed.");
	        }

	        if (entry.getGrampanchayatId() != null && !entry.getGrampanchayatId().matches(regex)) {
	            addError.accept("Grampanchayat ID contains invalid characters. Only alphanumeric characters and spaces are allowed.");
	        }
	 
	        if (entry.getGrampanchayatName() != null && !entry.getGrampanchayatName().matches(regex)) {
	            addError.accept("Grampanchayat Name contains invalid characters. Only alphanumeric characters and spaces are allowed.");
	        }

	        if (entry.getRemark() != null && !entry.getRemark().matches(regex)) {
	            addError.accept("Remark contains invalid characters. Only alphanumeric characters and spaces are allowed.");
	        }
	        
	        BiConsumer<Long, String> validateLongField = (value, fieldName) -> {
	            if (value == null || value < 0) {
	                addError.accept(fieldName + " must be a non-negative number and cannot be null.");
	            }
	        };
	      

	        validateLongField.accept(entry.getJamaGramNidhiArthSankalpniyaTartud(), "Jama Gram Nidhi ArthSankalpniya Tartud");
	        validateLongField.accept(entry.getJamaGramNidhiChaluMahinyapurviJama(),"Jama Gram Nidhi Chalu Mahinyapurvi Jama");
	        validateLongField.accept(entry.getJamaGramNidhiChaluMahinyapurviJama(), "Jama Gram Nidhi Chalu Mahinyapurvi Jama");
	        validateLongField.accept(entry.getmalmattaKarArthSankalpniyaTartud(), "Malmatta Kar Arth Sankalpniya Tartud");
	        validateLongField.accept(entry.getmalmattaKarMagilMahinyapurviPratakshJama(), "Malmatta Kar Magil Mahinyapurvi Prataksh Jama");
	        validateLongField.accept(entry.getmalmattaKarChaluMahinyapurviJama(), "Malmatta Kar Chalu Mahinyapurvi Jama");
	        validateLongField.accept(entry.getdivabattiKarArthSankalpniyaTartud(), "Divabatti Kar Arth Sankalpniya Tartud");
	        validateLongField.accept(entry.getdivabattiKarMagilMahinyapurviPratakshJama(), "Divabatti Kar Magil Mahinyapurvi Prataksh Jama");
	        validateLongField.accept(entry.getdivabattiKarChaluMahinyapurviJama(), "Divabatti Kar Chalu Mahinyapurvi Jama");
	        validateLongField.accept(entry.getswachataKarArthSankalpniyaTartud(), "Swachata Kar Arth Sankalpniya Tartud");
	        validateLongField.accept(entry.getyatraKAarMagilMahinyapurviPratakshJama(), "Swachata Kar Magil Mahinyapurvi Prataksh Jama");
	        validateLongField.accept(entry.getswachataKarChaluMahinyapurviJama(), "Swachata Kar Chalu Mahinyapurvi Jama");
	        validateLongField.accept(entry.getdukaneHotelKarArthSankalpniyaTartud(), "Dukane Hotel Kar Arth Sankalpniya Tartud");
	        validateLongField.accept(entry.getdukaneHotelKarMagilMahinyapurviPratakshJama(), "Dukane Hotel Kar Magil Mahinyapurvi Prataksh Jama");
	        validateLongField.accept(entry.getdukaneHotelKarChaluMahinyapurviJama(), "Dukane Hotel Kar Chalu Mahinyapurvi Jama");
	        validateLongField.accept(entry.getyatraKAarArthSankalpniyaTartud(), "Yatra Kaar Arth Sankalpniya Tartud");
	        validateLongField.accept(entry.getyatraKAarMagilMahinyapurviPratakshJama(), "Yatra Kaar Magil Mahinyapurvi Prataksh Jama");
	        validateLongField.accept(entry.getyatraKAarChaluMahinyapurviJama(), "Yatra Kaar Chalu Mahinyapurvi Jama");
	        validateLongField.accept(entry.getjatraUttasavArthSankalpniyaTartud(), "Jatra Uttasav Arth Sankalpniya Tartud");
	        validateLongField.accept(entry.getjatraUttasavMagilMahinyapurviPratakshJama(), "Jatra Uttasav Magil Mahinyapurvi Prataksh Jama");
	        validateLongField.accept(entry.getjatraUttasavChaluMahinyapurviJama(), "Jatra Uttasav Chalu Mahinyapurvi Jama");
	        validateLongField.accept(entry.getcycleORVahnavarilKarArthSankalpniyaTartud(), "Cycle OR Vahnavaril Kar Arth Sankalpniya Tartud");
	        validateLongField.accept(entry.getcycleORVahnavarilKarMagilMahinyapurviPratakshJama(), "Cycle OR Vahnavaril Kar Magil Mahinyapurvi Prataksh Jama");
	        validateLongField.accept(entry.getcycleORVahnavarilKarChaluMahinyapurviJama(), "Cycle OR Vahnavaril Kar Chalu Mahinyapurvi Jama");
	        validateLongField.accept(entry.getJamakarTollTaxArthSankalpniyaTartud(), "Jamakar Toll Tax Arth Sankalpniya Tartud");
	        validateLongField.accept(entry.getJamakarTollTaxMagilMahinyapurviPratakshJama(), "Jamakar Toll Tax Magil Mahinyapurvi Prataksh Jama");
	        validateLongField.accept(entry.getJamakarTollTaxChaluMahinyapurviJama(), "Jamakar Toll Tax Chalu Mahinyapurvi Jama");
	        validateLongField.accept(entry.getGramNidhitunKharachArthSankalpniyaTartud(), "Gram Nidhitun Kharach Arth Sankalpniya Tartud");
	        validateLongField.accept(entry.getGramNidhitunKharachMagilMahinyapurviPratakshJama(), "Gram Nidhitun Kharach Magil Mahinyapurvi Prataksh Jama");
	        validateLongField.accept(entry.getGramNidhitunKharachChaluMahinyapurviJama(), "Gram Nidhitun Kharach Chalu Mahinyapurvi Jama");
	        validateLongField.accept(entry.getSarpanchMandhanArthSankalpniyaTartud(), "Sarpanch Mandhan Arth Sankalpniya Tartud");
	        validateLongField.accept(entry.getSarpanchMandhanMagilMahinyapurviPratakshJama(), "Sarpanch Mandhan Magil Mahinyapurvi Prataksh Jama");
	        validateLongField.accept(entry.getSarpanchMandhanChaluMahinyapurviJama(), "Sarpanch Mandhan Chalu Mahinyapurvi Jama");
	        validateLongField.accept(entry.getSadasyaBaithakBattaArthSankalpniyaTartud(), "Sadasya Baithak Batta Arth Sankalpniya Tartud");
	        validateLongField.accept(entry.getSadasyaBaithakBattaMagilMahinyapurviPratakshJama(), "Sadasya Baithak Batta Magil Mahinyapurvi Prataksh Jama");
	        validateLongField.accept(entry.getSadasyaBaithakBattaChaluMahinyapurviJama(), "Sadasya Baithak Batta Chalu Mahinyapurvi Jama");
	        validateLongField.accept(entry.getsarpanchPravasArthSankalpniyaTartud(), "Sarpanch Pravas Arth Sankalpniya Tartud");
	        validateLongField.accept(entry.getsarpanchPravasMagilMahinyapurviPratakshJama(), "Sarpanch Pravas Magil Mahinyapurvi Prataksh Jama");
	        validateLongField.accept(entry.getsarpanchPravasChaluMahinyapurviJama(), "Sarpanch Pravas Chalu Mahinyapurvi Jama");	     
	        validateLongField.accept(entry.getkarmchariVetanArthSankalpniyaTartud(), "Karmchari Vetan Arth Sankalpniya Tartud");
	        validateLongField.accept(entry.getkarmchariVetanMagilMahinyapurviPratakshJama(), "Karmchari Vetan Magil Mahinyapurvi Prataksh Jama");
	        validateLongField.accept(entry.getkarmchariVetanChaluMahinyapurviJama(), "Karmchari Vetan Chalu Mahinyapurvi Jama");
	        validateLongField.accept(entry.getkarmchariPravasArthSankalpniyaTartud(), "Karmchari Pravas Arth Sankalpniya Tartud");
	        validateLongField.accept(entry.getkarmchariPravasMagilMahinyapurviPratakshJama(), "Karmchari Pravas Magil Mahinyapurvi Prataksh Jama");
	        validateLongField.accept(entry.getkarmchariPravasChaluMahinyapurviJama(), "Karmchari Pravas Chalu Mahinyapurvi Jama");
	        validateLongField.accept(entry.getKaryalinKharachArthSankalpniyaTartud(), "Karyalin Kharach Arth Sankalpniya Tartud");
	        validateLongField.accept(entry.getKaryalinKharachMagilMahinyapurviPratakshJama(), "Karyalin Kharach Magil Mahinyapurvi Prataksh Jama");
	        validateLongField.accept(entry.getKaryalinKharachChaluMahinyapurviJama(), "Karyalin Kharach Chalu Mahinyapurvi Jama");
	        validateLongField.accept(entry.getsangnakKharchArthSankalpniyaTartud(), "Sangnak Kharch Arth Sankalpniya Tartud");
	        validateLongField.accept(entry.getsangnakKharchMagilMahinyapurviPratakshJama(), "Sangnak Kharch Magil Mahinyapurvi Prataksh Jama");
	        validateLongField.accept(entry.getsangnakKharchChaluMahinyapurviJama(), "Sangnak Kharch Chalu Mahinyapurvi Jama");
	        validateLongField.accept(entry.getjahiratKharchArthSankalpniyaTartud(), "Jahirat Kharch Arth Sankalpniya Tartud");
	        validateLongField.accept(entry.getjahiratKharchMagilMahinyapurviPratakshJama(), "Jahirat Kharch Magil Mahinyapurvi Prataksh Jama");
	        validateLongField.accept(entry.getjahiratKharchChaluMahinyapurviJama(), "Jahirat Kharch Chalu Mahinyapurvi Jama");
	        validateLongField.accept(entry.getPhogingORGhantagadisathiTelArthSankalpniyaTartud(), "Phoging OR Ghantagadisathi Tel Arth Sankalpniya Tartud");
	        validateLongField.accept(entry.getPhogingORGhantagadisathiTelMagilMahinyapurviPratakshJama(), "Phoging OR Ghantagadisathi Tel Magil Mahinyapurvi Prataksh Jama");
	        validateLongField.accept(entry.getPhogingORGhantagadisathiTelChaluMahinyapurviJama(), "Phoging OR Ghantagadisathi Tel Chalu Mahinyapurvi Jama");

	        
	         return errorMessages;
	   
	      

	        } 
}
