package eGramPanchayat.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import eGramPanchayat.dto.MojmaapWahi_21_Dto;
import eGramPanchayat.service.MojmaapWahi_21_Service;
import eGramPanchayat.util.ResponseWrapper;
import jakarta.validation.Valid;

@CrossOrigin(origins = "http://localhost:3002")
@RestController
@RequestMapping("/mojmaapWahi")
public class MojmaapWahi_21_Controller {

    @Autowired
    private MojmaapWahi_21_Service mojmaapWahiService;

 // Save endpoint
    @PostMapping("/create")
    public ResponseEntity<?> addMojmaapWahi(@Valid @RequestBody MojmaapWahi_21_Dto mojmaapWahiDto, BindingResult bindingResult) {
        // Handle validation errors from BindingResult
        if (bindingResult.hasErrors()) {
            List<String> errors = bindingResult.getFieldErrors().stream()
                .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ResponseWrapper<>("01", "Validation Failed", null, errors));
        }

        // Custom validation
        List<Map<String, String>> validationErrors = validateInput(mojmaapWahiDto);
        if (!validationErrors.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ResponseWrapper<>("01", "Validation Failed", null, validationErrors));
        }

        // Try saving the data
        try {
            mojmaapWahiService.addMojmaapWahi(mojmaapWahiDto);
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Saved Successfully!", null, ""));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "An Error Occurred", null, e.getMessage()));
        }
    }


    // Get all records
    @PostMapping("/getAll")
    public ResponseEntity<?> getAllMojmaapWahi() {
        try {
            List<MojmaapWahi_21_Dto> mojmaapWahiList = mojmaapWahiService.getAllMojmaapWahi();
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", mojmaapWahiList, ""));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "An Error Occurred", null, e.getMessage()));
        }
    }

    // Get specific record by ID
    @PostMapping("/getById/{id}")
    public ResponseEntity<?> getMojmaapWahiById(@PathVariable Long id) {
        try {
            Optional<MojmaapWahi_21_Dto> mojmaapWahi = mojmaapWahiService.getMojmaapWahiById(id);
            if (mojmaapWahi.isPresent()) {
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Found", mojmaapWahi.get(), ""));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new ResponseWrapper<>("01", "Error Updating Data", null, "Data Not Found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "Error Updating Data", null, e.getMessage()));
        }
    }



 // Update record by ID
    @PostMapping("/updateById/{id}")
    public ResponseEntity<?> updateMojmaapWahi(@PathVariable Long id, @Valid @RequestBody MojmaapWahi_21_Dto mojmaapWahiDto, BindingResult bindingResult) {
        // Handle validation errors from BindingResult
        if (bindingResult.hasErrors()) {
            List<String> errors = bindingResult.getFieldErrors().stream()
                .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ResponseWrapper<>("01", "Validation Failed", null, errors));
        }

        // Custom validation
        List<Map<String, String>> validationErrors = validateInput(mojmaapWahiDto);
        if (!validationErrors.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ResponseWrapper<>("01", "Validation Failed", null, validationErrors));
        }

        // Try updating the data
        try {
            boolean isUpdated = mojmaapWahiService.updateMojmaapWahi(id, mojmaapWahiDto);
            if (isUpdated) {
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Updated Successfully!", null, ""));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseWrapper<>("01", "Error Updating Data", null, "Data Not Found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "Error Updating Data", null, e.getMessage()));
        }
    }



    @PostMapping("/deleteById/{id}")
    public ResponseEntity<?> deleteMojmaapWahi(@PathVariable Long id) {
        try {
            boolean isDeleted = mojmaapWahiService.deleteMojmaapWahi(id);
            if (isDeleted) {
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Deleted Successfully!", null, ""));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new ResponseWrapper<>("01", "Error Deleting Data", null, "Data Not Found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "Error Deleting Data", null, e.getMessage()));
        }
    }

    private List<Map<String, String>> validateInput(MojmaapWahi_21_Dto mojmaapWahiDto) {
        List<Map<String, String>> errorMessages = new ArrayList<>();
        String regex = "^[\\u0900-\\u097F\\sa-zA-Z0-9-]*$"; // Only allow alphanumeric characters and spaces

        // Helper method to add errors to the list
        Consumer<String> addError = message -> {
            Map<String, String> error = new HashMap<>();
            error.put("description", message);
            errorMessages.add(error);
        };

        // Validate employeeName
        if (!mojmaapWahiDto.getEmployeeName().matches(regex)) {
            addError.accept("Employee Name contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate grampanchayatName
        if (!mojmaapWahiDto.getGrampanchayatName().matches(regex)) {
            addError.accept("Grampanchayat Name contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate employeeId
        if (!mojmaapWahiDto.getEmployeeId().matches(regex)) {
            addError.accept("Employee ID contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate grampanchayatId
        if (!mojmaapWahiDto.getGrampanchayatId().matches(regex)) {
            addError.accept("Grampanchayat ID contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

//        // Validate remark
//        if (!mojmaapWahiDto.getRemark().matches(regex)) {
//            addError.accept("Remark contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }

        // Validate kamachePratyakshaMojmap
        if (!mojmaapWahiDto.getKamachePratyakshaMojmap().matches(regex)) {
            addError.accept("Kamache Pratyaksha Mojmap contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate kamkarnayaAgencyAbhikanacheNaaw
        if (!mojmaapWahiDto.getKamkarnayaAgencyAbhikanacheNaaw().matches(regex)) {
            addError.accept("Kamkarnaya Agency Abhikanache Naaw contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate kamacheWarnan
        if (!mojmaapWahiDto.getKamacheWarnan().matches(regex)) {
            addError.accept("Kamache Warnan contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate mojmap
        if (!mojmaapWahiDto.getMojmap().matches(regex)) {
            addError.accept("Mojmap contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

//        // Validate Year
//        if (!mojmaapWahiDto.getYear().matches(regex)) {
//            addError.accept("Year contains invalid characters. Only alphanumeric characters and spaces are allowed.");
//        }

        // Validate kamacheWarnanKamacheUpashirshVaKshetracheAdhikari
        if (!mojmaapWahiDto.getKamacheWarnanKamacheUpashirshVaKshetracheAdhikari().matches(regex)) {
            addError.accept("Kamache Warnan Kamache Upashirsh Va Kshetrache Adhikari contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate mojmapachaTapshilPariman
        if (!mojmaapWahiDto.getMojmapachaTapshilPariman().matches(regex)) {
            addError.accept("Mojmapacha Tapshil Pariman contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate mojmapachaTapshilLaambi
        if (!mojmaapWahiDto.getMojmapachaTapshilLaambi().matches(regex)) {
            addError.accept("Mojmapacha Tapshil Laambi contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate mojmapachaTapshilRundi
        if (!mojmaapWahiDto.getMojmapachaTapshilRundi().matches(regex)) {
            addError.accept("Mojmapacha Tapshil Rundi contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate mojmapachaTapshilKholiUnchi
        if (!mojmaapWahiDto.getMojmapachaTapshilKholiUnchi().matches(regex)) {
            addError.accept("Mojmapacha Tapshil Kholi Unchi contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate mojmapachaTapshilEkun
        if (!mojmaapWahiDto.getMojmapachaTapshilEkun().matches(regex)) {
            addError.accept("Mojmapacha Tapshil Ekun contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate ekunParimanMaapPurvicheHajeriPramaneWarnanKarave
        if (!mojmaapWahiDto.getEkunParimanMaapPurvicheHajeriPramaneWarnanKarave().matches(regex)) {
            addError.accept("Ekun Pariman Maap Purviche Hajeri Pramane Warnan Karave contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate ekunMojmapachaTapshilEkunVaEkunParimanMaap
        if (!mojmaapWahiDto.getEkunMojmapachaTapshilEkunVaEkunParimanMaap().matches(regex)) {
            addError.accept("Ekun Mojmapacha Tapshil Ekun Va Ekun Pariman Maap contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate dar
        if (!mojmaapWahiDto.getDar().matches(regex)) {
            addError.accept("Dar contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate rakkam
        if (!mojmaapWahiDto.getRakkam().matches(regex)) {
            addError.accept("Rakkam contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        return errorMessages; // Return the list of errors
    }
}
