package eGramPanchayat.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import eGramPanchayat.dto.Namuna06JamaRakmanchiNondvahiDto;
import eGramPanchayat.service.Namuna06JamaRakmanchiNondvahiService;
import eGramPanchayat.util.ResponseWrapper;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/Namuna06JamaRakmanchiNondvahi")
@CrossOrigin(origins = "http://localhost:3000")
public class Namuna06JamaRakmanchiNondvahiController {

    @Autowired
    private Namuna06JamaRakmanchiNondvahiService service;

    // Save details with validation
    @PostMapping("/save")
    public ResponseEntity<?> create( @RequestBody Namuna06JamaRakmanchiNondvahiDto dto, BindingResult bindingResult) {
//        if (bindingResult.hasErrors()) {
//            List<String> errors = bindingResult.getFieldErrors().stream()
//                .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
//                .collect(Collectors.toList());
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                .body(new ResponseWrapper<>("01", "Validation Failed", null, errors));
//        }

//        try {
//            validateInput(dto);
            service.create(dto);
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data saved successfully!", null, ""));
//        } catch (IllegalArgumentException e) {
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                .body(new ResponseWrapper<>("01", "Validation Failed", null, (e.getMessage())));
//        } catch (Exception e) {
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                .body(new ResponseWrapper<>("01", "An Error Occurred", null, (e.getMessage())));
//        }
    }

    // Get by ID with validation for non-existent records
    @PostMapping("/get_by_id/{id}")
    public ResponseEntity<?> getById(@PathVariable Long id) {
        try {
            Optional<Namuna06JamaRakmanchiNondvahiDto> dto = service.getById(id);
            if (dto.isPresent()) {
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", dto.get(), ""));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseWrapper<>("01","Something Went Wrong", null, "Data Not Found "));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, (e.getMessage())));
        }
    }

    // Get all records
    @PostMapping("/getall")
    public ResponseEntity<?> getAll() {
        try {
            List<Namuna06JamaRakmanchiNondvahiDto> list = service.getAll();
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", list, ""));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "An Error Occurred", null, (e.getMessage())));
        }
    }

 // Update details with validation
    @PostMapping("/update/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @Valid @RequestBody Namuna06JamaRakmanchiNondvahiDto dto, BindingResult bindingResult) {
        // Check for validation errors
        if (bindingResult.hasErrors()) {
            List<String> errors = bindingResult.getFieldErrors().stream()
                .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ResponseWrapper<>("01", "Validation Failed", null, errors));
        }

//        try {
//            // Custom input validation
////            List<String> validationErrors = validateInput(dto);
//            if (!validationErrors.isEmpty()) {
//                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                    .body(new ResponseWrapper<>("01", "Validation Failed", null, validationErrors));
//            }

            // Attempt to update the details
            Optional<Namuna06JamaRakmanchiNondvahiDto> updatedEntity = service.update(id, dto);
            if (updatedEntity.isPresent()) {
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Updated Successfully!", null, ""));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseWrapper<>("01", "Something Went Wrong", null,"Data Not Found  "));
            }
//        } catch (IllegalArgumentException e) {
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                .body(new ResponseWrapper<>("01", "Validation Failed", null, (e.getMessage())));
//        } catch (Exception e) {
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                .body(new ResponseWrapper<>("01", "Error Updating Data", null, (e.getMessage())));
//        }
    }

    // Delete record by ID
    @PostMapping("/delete_by_id/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        try {
            boolean deleted = service.delete(id);
            if (deleted) {
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Deleted Successfully!", null, ""));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseWrapper<>("01", "Something Went Wrong", null, "Data Not Found "));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "Error Deleting Data", null, (e.getMessage())));
        }
    }
    
}  
    
    
//    
//
//    // Custom validation logic
//    private List<String> validateInput(Namuna06JamaRakmanchiNondvahiDto dto) {
//    	  List<String> errors = new ArrayList<>();
//    	  String regex = "^[\\u0900-\\u097F\\sa-zA-Z0-9-]*$";
//
//        if (!dto.getEmployeeName().matches(regex)) {
//            throw new IllegalArgumentException("Employee Name contains invalid characters.");
//        }
//
//        if (!dto.getGrampanchayatName().matches(regex)) {
//            throw new IllegalArgumentException("Grampanchayat Name contains invalid characters.");
//        }
//        
//        if (!dto.getYear().matches(regex)) {
//            throw new IllegalArgumentException("Year contains invalid characters.");
//        }
//        if (!dto.getShera().matches(regex)) {
//            throw new IllegalArgumentException("Shera contains invalid characters.");
//        }
//        if (!dto.getLekhaShirsh().matches(regex)) {
//            throw new IllegalArgumentException("LekhaShirsh contains invalid characters.");
//        }
//
//        if (!dto.getShera().matches(regex)) {
//            throw new IllegalArgumentException("Shera contains invalid characters.");
//        }
//
//        if (!dto.getArthsankalpiyaAnudan().matches(regex)) {
//            throw new IllegalArgumentException("ArthsankalpiyaAnudan contains invalid characters.");
//        }
//
//        if (!dto.getMahinyaBaddalchiEkunRakkam().matches(regex)) {
//            throw new IllegalArgumentException("MahinyaBaddalchiEkunRakkam contains invalid characters.");
//        }
//
//        if (!dto.getMaghilMahinyachaAkherparyantchiRakkam().matches(regex)) {
//            throw new IllegalArgumentException("MaghilMahinyachaAkherparyantchiRakkam contains invalid characters.");
//        }
//
//        if (!dto.getMaghePasunPudheChaluEkunRakkam().matches(regex)) {
//            throw new IllegalArgumentException("MaghePasunPudheChaluEkunRakkam contains invalid characters.");
//        }
//
//        if (!dto.getValue().matches(regex)) {
//            throw new IllegalArgumentException("Value contains invalid characters.");
//        }
//        return errors;
//    }
//}
