package eGramPanchayat.controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import eGramPanchayat.dto.Namuna15_UpbhogyaVastuSathaLekhaNondVahiDTO;
import eGramPanchayat.dto.Namuna5C_DainikRokadVahiDTO;
import eGramPanchayat.entity.Namuna15_UpbhogyaVastuSathaLekhaNondVahi;
import eGramPanchayat.service.Namuna15_UpbhogyaVastuSathaLekhaNondVahiService;
import eGramPanchayat.service.impl.Namuna15_UpbhogyaVastuSathaLekhaNondVahiServiceImpl;
import eGramPanchayat.service.impl.TransactionLogService;
import eGramPanchayat.util.ResponseWrapper;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/Namuna15_UpbhogyaVastuSathaLekhaNondVahi")
@CrossOrigin("*")
public class Namuna15_UpbhogyaVastuSathaLekhaNondVahiController {

	 @Autowired
	 private Namuna15_UpbhogyaVastuSathaLekhaNondVahiService service;
	 
	 @Autowired
	 private TransactionLogService transactionLogService;
	 
	 @Autowired
	 private Namuna15_UpbhogyaVastuSathaLekhaNondVahiServiceImpl impl;

	 	@PostMapping("/save")
	    public ResponseEntity<ResponseWrapper<Object>> save(
	            @Valid @RequestBody Namuna15_UpbhogyaVastuSathaLekhaNondVahiDTO dto,
	            BindingResult bindingResult,
	            @RequestHeader(value = "username", defaultValue = "unknown") String username) {

	        List<ErrorMessage> errors = new ArrayList<>();

	        // Field-level validation
	        if (bindingResult.hasErrors()) {
	            errors.addAll(bindingResult.getFieldErrors().stream()
	                    .map(fieldError -> new ErrorMessage(fieldError.getDefaultMessage()))
	                    .collect(Collectors.toList()));
	        }

	        // Return validation errors if any
	        if (!errors.isEmpty()) {
	            return ResponseEntity.badRequest()
	                    .body(new ResponseWrapper<>("01", "Validation Error", null, errors));
	        }

	        try {
	            // Save the data
	        	Namuna15_UpbhogyaVastuSathaLekhaNondVahi created = impl.savedata(dto);

	            // Log the transaction
	            transactionLogService.logTransaction(
	                    "SAVE",
	                    "Data saved successfully for Namuna15",
	                    null,
	                    created.getEmployeeId(),
	                    created.getEmployeeName(),
	                    created.getGrampanchayatId(),
	                    created.getGrampanchayatName());

	            // Return success response
	            return ResponseEntity.ok(
	                    new ResponseWrapper<>("00", "Data Saved Successfully", null, ""));
	        } catch (Exception e) {
	            // Log the error
	            transactionLogService.logTransaction(
	                    "SAVE_FAILED",
	                    "Error saving data",
	                    null,
	                    null,
	                    null,
	                    null,
	                    null);

	            // Return error response
	            List<ErrorMessage> errorList = List.of(new ErrorMessage("An unexpected error occurred: " + e.getMessage()));
	            return ResponseEntity.status(500)
	                    .body(new ResponseWrapper<>("01", "Data Not Saved", null, errorList));
	        }
	    }
	    
	 	@PostMapping("/getall")
	    public ResponseEntity<ResponseWrapper<List<Namuna15_UpbhogyaVastuSathaLekhaNondVahi>>> getAllDetails() {
	        try {
	            List<Namuna15_UpbhogyaVastuSathaLekhaNondVahi> details = service.getalldetails();
	            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", details, ""));
	        } catch (Exception e) {
	            return ResponseEntity.status(500).body(new ResponseWrapper<>("01", "Error Fetching Data", null, e.getMessage()));
	        }
	    }
	    
	 	@PostMapping("/get/{id}")
	    public ResponseEntity<ResponseWrapper<Namuna15_UpbhogyaVastuSathaLekhaNondVahi>> getDetailsById(@PathVariable Long id) {
	        try {
	        	Namuna15_UpbhogyaVastuSathaLekhaNondVahi result = service.getdetailsbyid(id);
	            if (result != null) {
	                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", result, ""));
	            } else {
	                return ResponseEntity.status(404).body(new ResponseWrapper<>("01", "Error Retrieving Data", null, "Data Not Found"));
	            }
	        } catch (Exception e) {
	            return ResponseEntity.status(500).body(new ResponseWrapper<>("01", "Error Fetching Data", null, e.getMessage()));
	        }
	    }
	    
	 	@PostMapping("/delete/{id}")
	    public ResponseEntity<?> delete(@PathVariable long id,
			@RequestBody Namuna15_UpbhogyaVastuSathaLekhaNondVahiDTO deleteRequest) {
		Map<String, Object> response = new LinkedHashMap<>();
		try {
			// Find the record by ID

			if (deleteRequest.getEmployeeId() == null ||
					deleteRequest.getEmployeeName() == null ||
					deleteRequest.getGrampanchayatId() == null ||
					deleteRequest.getGrampanchayatName() == null) {

				// // Log the not-found case with null values
				// transactionLogService.logTransaction(
				// "DELETE",
				// "Deletion failed. Data not found for ID " + id,
				// null, employeeId, employeeName, gramPanchayatId, gramPanchayatName);

				// Prepare a not-found response
				response.put("code", "01");
				response.put("message", "Error Deleting Data");
				response.put("errormessage", "Data Not Found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}

			// Proceed with deletion
			boolean isDeleted = service.deleteById(id);
			if (isDeleted) {
				// Log the deletion action with field values (or null if they are missing)
				transactionLogService.logTransaction(
						"DELETE",
						"Data deleted successfully for Namuna15 with ID " + id,
						null, deleteRequest.getEmployeeId(),
						deleteRequest.getEmployeeName(),
						deleteRequest.getGrampanchayatId(),
						deleteRequest.getGrampanchayatName());

				// Prepare a successful response
				response.put("code", "00");
				response.put("message", "Data Deleted Successfully");
				response.put("errormessage", "");
				return ResponseEntity.ok(response);
			} else {
				// // Log the deletion failure with field values (or null if they are missing)
				// transactionLogService.logTransaction(
				// "DELETE",
				// "Deletion operation failed for Namuna32 with ID " + id,
				// null, employeeId, employeeName, gramPanchayatId, gramPanchayatName);

				response.put("code", "01");
				response.put("message", "Error Deleting Data");
				response.put("errormessage", "Deletion operation failed");
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
			}
		} catch (Exception e) {
			// // Log the exception with null values for fields
			// transactionLogService.logTransaction(
			// "DELETE",
			// "Error occurred while deleting data for ID " + id,
			// null, null, null, null, null);

			// Prepare an error response
			response.put("code", "01");
			response.put("message", "Error Deleting Data");
			response.put("errormessage", e.getMessage());
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
	}

	 	@PostMapping("/update/{id}")
	    public ResponseEntity<ResponseWrapper<Object>> update(
	            @PathVariable Long id,
	            @Valid @RequestBody Namuna15_UpbhogyaVastuSathaLekhaNondVahiDTO dto,
	            BindingResult bindingResult,
	            @RequestHeader(value = "username", defaultValue = "unknown") String username) {

	        List<ErrorMessage> errors = new ArrayList<>();

	        // Field-level validation
	        if (bindingResult.hasErrors()) {
	            errors.addAll(bindingResult.getFieldErrors().stream()
	                    .map(fieldError -> new ErrorMessage(fieldError.getDefaultMessage()))
	                    .collect(Collectors.toList()));
	        }

	        // Return validation errors if any
	        if (!errors.isEmpty()) {
	            return ResponseEntity.badRequest()
	                    .body(new ResponseWrapper<>("01", "Validation Error", null, errors));
	        }

	        try {
	            // Update the data
	        	Namuna15_UpbhogyaVastuSathaLekhaNondVahi updated = impl.updateById(id, dto);

	            if (updated == null) {
	            	return ResponseEntity.status(404).body(
	                        new ResponseWrapper<>("01", "Error Retrieving Data", null,  "Data Not Found"));
	            }

	            // Log the transaction
	            transactionLogService.logTransaction(
	                    "UPDATE",
	                    "Data updated successfully for Namuna15",
	                    null,
	                    updated.getEmployeeId(),
	                    updated.getEmployeeName(),
	                    updated.getGrampanchayatId(),
	                    updated.getGrampanchayatName());

	            // Return success response
	            return ResponseEntity.ok(
	                    new ResponseWrapper<>("00", "Data Updated Successfully", null, ""));
	        } catch (Exception e) {
	            // Log the error
	            transactionLogService.logTransaction(
	                    "UPDATE_FAILED",
	                    "Error updating data",
	                    null,
	                    null,
	                    null,
	                    null,
	                    null);

	            // Return error response
	            List<ErrorMessage> errorList = List.of(new ErrorMessage("An unexpected error occurred: " + e.getMessage()));
	            return ResponseEntity.status(500)
	                    .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, errorList));
	        }
	    }

    public static class ErrorMessage {
        private String description;

        public ErrorMessage(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }

}
