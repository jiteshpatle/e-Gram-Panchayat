package eGramPanchayat.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import eGramPanchayat.dto.ErrorMessage;
import eGramPanchayat.dto.Namuna02PunarniyojanVaNiyatVatapDTO;
import eGramPanchayat.service.Namuna02PunarniyojanVaNiyatVatapService;

import eGramPanchayat.util.ResponseWrapper;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/Namuna02PunarniyojanVaNiyatVatap")
@CrossOrigin(origins = "http://localhost:3000")
public class Namuna02PunarniyojanVaNiyatVatapController {

    @Autowired
    private Namuna02PunarniyojanVaNiyatVatapService service;

    // @Autowired
    // private TransactionLogService transactionLogService;

    // Get the current authenticated user
    // private String getCurrentUser() {
    // Authentication authentication =
    // SecurityContextHolder.getContext().getAuthentication();
    // if (authentication != null && authentication.isAuthenticated()) {
    // return authentication.getName(); // Assuming the username is used as the
    // identifier
    // }
    // return "anonymous"; // Return a default value if not authenticated
    // }

    // Save endpoint
    @PostMapping("/save")
    public ResponseEntity<?> saveDetails(@Valid @RequestBody Namuna02PunarniyojanVaNiyatVatapDTO details,
            BindingResult bindingResult) {
        // String currentUser = getCurrentUser(); // Get the current user

        List<ErrorMessage> validationErrors = validateInput(details);
        if (!validationErrors.isEmpty()) {
            // Return validation errors in the desired format
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseWrapper<>("01", "Validation Failed", null, validationErrors));
        }

        try {
            service.saveDetails(details);
            // Log the save action with user information
            // transactionLogService.saveLog("SAVE", null, "Data Saved Successfully", "");
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Saved Successfully!", null, ""));
        } catch (DataIntegrityViolationException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(new ResponseWrapper<>("01", "Something Went Wrong", null, e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "An Error Occurred", null, e.getMessage()));
        }
    }

    // Update endpoint
    @PostMapping("/update/{id}")
    public ResponseEntity<?> updateDetails(@PathVariable Long id,
            @Valid @RequestBody Namuna02PunarniyojanVaNiyatVatapDTO details, BindingResult bindingResult) {
        // String currentUser = getCurrentUser(); // Get the current user

        List<ErrorMessage> validationErrors = validateInput(details);
        if (!validationErrors.isEmpty()) {
            // Return validation errors in the desired format
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseWrapper<>("01", "Validation Failed", null, validationErrors));
        }

        try {
            // Attempt to update the details
            Optional<Namuna02PunarniyojanVaNiyatVatapDTO> updatedEntity = Optional
                    .ofNullable(service.updateDetails(id, details));
            if (updatedEntity.isPresent()) {
                // Log the update action with user information
                // transactionLogService.saveLog("UPDATE", id, "Data Updated Successfully", "");
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Updated Successfully!", null, ""));
            } else {
                // transactionLogService.saveLog("UPDATE", id, "Data Not Found", "");
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new ResponseWrapper<>("01", "Data Not Found", null, "Data Not Found"));
            }
        } catch (DataIntegrityViolationException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(new ResponseWrapper<>("01", "Something Went Wrong", null, e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "Error Updating Data", null, e.getMessage()));
        }
    }

    // Get all records
    @PostMapping("/getall")
    public ResponseEntity<?> getAllDetails() {
        // String currentUser = getCurrentUser(); // Get the current user

        try {
            List<Namuna02PunarniyojanVaNiyatVatapDTO> detailsList = service.getAllDetails();
            // transactionLogService.saveLog("GET_ALL", null, "All Data Retrieved
            // Successfully", "");
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", detailsList, ""));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "An Error Occurred", null, e.getMessage()));
        }
    }

    @PostMapping("/get_by_id/{id}")
    public ResponseEntity<?> getDetailsById(@PathVariable Long id) {
        // String currentUser = getCurrentUser(); // Get the current user

        try {
            Optional<Namuna02PunarniyojanVaNiyatVatapDTO> details = service.getDetailsById(id);
            if (details.isPresent()) {
                // Log the get by ID action with user information
                // transactionLogService.saveLog("GET_BY_ID", id, "Data Retrieved Successfully",
                // "");
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", details.get(), ""));
            } else {
                // transactionLogService.saveLog("GET_BY_ID", id, "Data Not Found", "");
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new ResponseWrapper<>("01", "Data Not Found", null, "Data Not Found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, e.getMessage()));
        }
    }

    // Delete record by ID
    @PostMapping("/delete_by_id/{id}")
    public ResponseEntity<?> deleteDetails(@PathVariable Long id) {
        // String currentUser = getCurrentUser(); // Get the current user

        try {
            boolean deleted = service.deleteDetails(id);
            if (deleted) {
                // transactionLogService.saveLog("DELETE", id, "Data Deleted Successfully", "");
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Deleted Successfully!", null, ""));
            } else {
                // transactionLogService.saveLog("DELETE", id, "Data Not Found for Deletion",
                // "");
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new ResponseWrapper<>("01", "Data Not Found", null, "Data Not Found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "Error Deleting Data", null, e.getMessage()));
        }
    }

    // Custom input validation
    public List<ErrorMessage> validateInput(Namuna02PunarniyojanVaNiyatVatapDTO dto) {
        List<ErrorMessage> errorMessages = new ArrayList<>();
        String regex = "^[a-zA-Z0-9 ]+$";

        // Add error messages to the list based on validations
        if (!dto.getEmployeeName().matches(regex)) {
            errorMessages.add(new ErrorMessage("Employee Name contains invalid characters."));
        }
        if (!dto.getGrampanchayatName().matches(regex)) {
            errorMessages.add(new ErrorMessage("Grampanchayat Name contains invalid characters."));
        }
        if (!dto.getJamaRakmecheMukhyaShirshak().matches(regex)) {
            errorMessages.add(new ErrorMessage("Jama Rakmeche Mukhya Shirshak contains invalid characters."));
        }
        if (!dto.getManjurArthsankalp().matches(regex)) {
            errorMessages.add(new ErrorMessage("Manjur Arthsankalp contains invalid characters."));
        }
        if (!dto.getSudharitAndaz().matches(regex)) {
            errorMessages.add(new ErrorMessage("Sudharit Andaz contains invalid characters."));
        }
        if (!dto.getSudharitAdhikVaja().matches(regex)) {
            errorMessages.add(new ErrorMessage("Sudharit Adhik Vaja contains invalid characters."));
        }

        // Add more validation as required
        return errorMessages;
    }
}
