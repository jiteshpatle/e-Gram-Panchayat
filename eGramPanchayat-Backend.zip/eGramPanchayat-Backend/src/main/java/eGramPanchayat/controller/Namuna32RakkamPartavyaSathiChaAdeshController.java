package eGramPanchayat.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import eGramPanchayat.service.impl.Namuna32RakkamPartavyaSathiChaAdeshServiceImpl;
import eGramPanchayat.service.impl.TransactionLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import eGramPanchayat.dto.Namuna32RakkamPartavyaSathiChaAdeshDTO;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/rakkampartavya")
@CrossOrigin(origins = "http://localhost:3000")
public class Namuna32RakkamPartavyaSathiChaAdeshController {
	@Autowired
	Namuna32RakkamPartavyaSathiChaAdeshServiceImpl service;

	@Autowired
	private TransactionLogService transactionLogService;

	@PostMapping("/create")
	public ResponseEntity<?> create(@Valid @RequestBody Namuna32RakkamPartavyaSathiChaAdeshDTO dto,
			BindingResult bindingResult) {
		Map<String, Object> response = new LinkedHashMap<>();

		// Handle validation errors
		if (bindingResult.hasErrors()) {
			// Collect all validation error messages into a list of ErrorMessage objects
			List<ErrorMessage> errors = bindingResult.getFieldErrors().stream()
					.map(fieldError -> new ErrorMessage(fieldError.getDefaultMessage()))
					.collect(Collectors.toList());

			response.put("code", "01");
			response.put("message", "Validation Error");
			response.put("errormessage", errors); // List of ErrorMessage objects
			return ResponseEntity.badRequest().body(response);
		}

		try {
			// Save data
			Namuna32RakkamPartavyaSathiChaAdeshDTO created = service.create(dto);

			// Log the creation action
			transactionLogService.logTransaction(
					"SAVE", "Data saved successfully for Namuna32", null,
					created.getEmployeeId(),
					created.getEmployeeName(),
					created.getGramPanchayatId(),
					created.getGramPanchayatName());

			// Success response
			response.put("code", "00");
			response.put("message", "Data Saved Successfully");
			response.put("errormessage", "");
			return ResponseEntity.status(HttpStatus.CREATED).body(response);
		} catch (Exception e) {
			// // Log the error
			// transactionLogService.logTransaction(
			// "CREATE",
			// "Failed to create Namuna30 record. Error: ",
			// null, null, null, null, null);

			// Handle other exceptions
			response.put("code", "01");
			response.put("message", "Error Creating Data");
			response.put("errormessage", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}

	//

	@PostMapping("/update/{id}")
	public ResponseEntity<?> update(@PathVariable Long id,
			@Valid @RequestBody Namuna32RakkamPartavyaSathiChaAdeshDTO dto, BindingResult bindingResult) {
		Map<String, Object> response = new LinkedHashMap<>();

		// Handle validation errors
		if (bindingResult.hasErrors()) {
			// Collect all validation error messages into a list of ErrorMessage objects
			List<ErrorMessage> errors = bindingResult.getFieldErrors().stream()
					.map(fieldError -> new ErrorMessage(fieldError.getDefaultMessage()))
					.collect(Collectors.toList());

			response.put("code", "01");
			response.put("message", "Validation Error");
			response.put("errormessage", errors); // List of ErrorMessage objects
			return ResponseEntity.badRequest().body(response);
		}

		try {
			// Attempt to update the record
			Namuna32RakkamPartavyaSathiChaAdeshDTO updated = service.update(id, dto);
			if (updated != null) {
				// Log the successful update
				transactionLogService.logTransaction(
						"UPDATE",
						"Data updated successfully for Namuna32 with ID " + id,
						null, // Username is fetched automatically in the service
						updated.getEmployeeId(),
						updated.getEmployeeName(),
						updated.getGramPanchayatId(),
						updated.getGramPanchayatName());

				// Prepare a successful response
				response.put("code", "00");
				response.put("message", "Data Updated Successfully");
				response.put("errormessage", "");
				// response.put("data", updated); // Uncomment if you need to include the
				// updated data in the response
				return ResponseEntity.ok(response); // Return 200 OK with message and updated DTO
			} else {
				// // Log the failure due to data not found
				// transactionLogService.logTransaction(
				// "UPDATE",
				// "Failed to update Namuna32. Data not found with ID " + id,
				// null, null, null, null, null);

				// Handle case where the record is not found
				response.put("code", "01");
				response.put("message", "Error Updating Data");
				response.put("errormessage", "Data Not Found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response); // Return 404 Not Found
			}
		} catch (Exception e) {
			// // Log the exception
			// transactionLogService.logTransaction(
			// "UPDATE",

			// "Error occurred while updating Namuna32 with ID " + id + ". Error: " +
			// e.getMessage(),
			// null, null, null, null, null);

			// Handle general exceptions
			response.put("code", "01");
			response.put("message", "Error Updating Data");
			response.put("errormessage", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response); // Return 500 Internal Server
																							// Error
		}
	}

	@PostMapping("/delete/{id}")
	public ResponseEntity<?> delete(@PathVariable long id,
			@RequestBody Namuna32RakkamPartavyaSathiChaAdeshDTO deleteRequest) {
		Map<String, Object> response = new LinkedHashMap<>();
		try {
			// Find the record by ID

			if (deleteRequest.getEmployeeId() == null ||
					deleteRequest.getEmployeeName() == null ||
					deleteRequest.getGramPanchayatId() == null ||
					deleteRequest.getGramPanchayatName() == null) {

				// // Log the not-found case with null values
				// transactionLogService.logTransaction(
				// "DELETE",
				// "Deletion failed. Data not found for ID " + id,
				// null, employeeId, employeeName, gramPanchayatId, gramPanchayatName);

				// Prepare a not-found response
				response.put("code", "01");
				response.put("message", "Error Deleting Data");
				response.put("errormessage", "Data Not Found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}

			// Proceed with deletion
			boolean isDeleted = service.delete(id);
			if (isDeleted) {
				// Log the deletion action with field values (or null if they are missing)
				transactionLogService.logTransaction(
						"DELETE",
						"Data deleted successfully for Namuna32 with ID " + id,
						null, deleteRequest.getEmployeeId(),
						deleteRequest.getEmployeeName(),
						deleteRequest.getGramPanchayatId(),
						deleteRequest.getGramPanchayatName());

				// Prepare a successful response
				response.put("code", "00");
				response.put("message", "Data Deleted Successfully");
				response.put("errormessage", "");
				return ResponseEntity.ok(response);
			} else {
				// // Log the deletion failure with field values (or null if they are missing)
				// transactionLogService.logTransaction(
				// "DELETE",
				// "Deletion operation failed for Namuna32 with ID " + id,
				// null, employeeId, employeeName, gramPanchayatId, gramPanchayatName);

				response.put("code", "01");
				response.put("message", "Error Deleting Data");
				response.put("errormessage", "Deletion operation failed");
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
			}
		} catch (Exception e) {
			// // Log the exception with null values for fields
			// transactionLogService.logTransaction(
			// "DELETE",
			// "Error occurred while deleting data for ID " + id,
			// null, null, null, null, null);

			// Prepare an error response
			response.put("code", "01");
			response.put("message", "Error Deleting Data");
			response.put("errormessage", e.getMessage());
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
	}

	@PostMapping("getById/{id}")
	public ResponseEntity<?> findById(@PathVariable Long id) {
		Map<String, Object> response = new LinkedHashMap<>();
		try {
			Namuna32RakkamPartavyaSathiChaAdeshDTO record = service.findById(id);
			if (record != null) {
				// If the record is found, return the record as the response body
				response.put("code", "00");
				response.put("message", "Data Retrieved Successfully");
				response.put("data", record);

				response.put("errormessage", "");

				return ResponseEntity.ok(response);
			} else {
				// If no record is found, return a message
				response.put("code", "01");
				response.put("message", "Error retrieving Data");
				response.put("errormessage", "Data Not Found");

				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}
		} catch (Exception e) {
			// Handle any exceptions and return a 500 Internal Server Error
			response.put("code", "01");
			response.put("message", "Error retrieving Data");
			response.put("errormessage", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}

	@PostMapping("/getAll")
	public ResponseEntity<?> findAll() {
		Map<String, Object> response = new LinkedHashMap<>();
		try {
			List<Namuna32RakkamPartavyaSathiChaAdeshDTO> allData = service.findAll();
			if (allData.isEmpty()) {
				response.put("code", "01");
				response.put("message", "Error retrieving Data");
				response.put("errormessage", "Data Not Found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}
			response.put("code", "00");
			response.put("message", "Data Retrieved Successfully");
			response.put("data", allData);

			response.put("errormessage", "");

			return ResponseEntity.status(HttpStatus.OK).body(response);
		} catch (Exception e) {
			response.put("code", "01");
			response.put("message", "Error retrieving Data");
			response.put("errormessage", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}

	static class ErrorMessage {
		private String description;

		public ErrorMessage(String description) {
			this.description = description;
		}

		// Getter
		public String getDescription() {
			return description;
		}
	}
}
