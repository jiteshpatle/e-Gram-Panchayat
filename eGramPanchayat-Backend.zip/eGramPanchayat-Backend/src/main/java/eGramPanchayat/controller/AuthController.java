package eGramPanchayat.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import eGramPanchayat.dto.ForgotPasswordRequest;
import eGramPanchayat.dto.LoginRequest;
import eGramPanchayat.dto.RegisterRequest;
import eGramPanchayat.service.AuthService;
import eGramPanchayat.util.JwtUtil;
import eGramPanchayat.util.ResponseWrapper;
import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    @Qualifier("authServiceImpl")
    private AuthService authService;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/register")
    public ResponseWrapper<?> register(@RequestBody RegisterRequest request) {
        String result = authService.register(request);
        return result.equalsIgnoreCase("User Registered Successfully!") ?
                new ResponseWrapper<>("00", result, null, "") :
                new ResponseWrapper<>("01", "Registration Failed", null, result);
    }

    @PostMapping("/login")
    public ResponseWrapper<?> login(@RequestBody LoginRequest request) {
        String result = authService.login(request).trim();
        if (result.toLowerCase().startsWith("login successful!")) {
            String token = result.substring(18).trim();
            return new ResponseWrapper<>("00", "Login Successful!", token, "");
        }
        return new ResponseWrapper<>("01", "Login Failed", null, "Invalid Username or Password. Please try again.");
    }

    @PostMapping("/logout")
    public ResponseWrapper<?> logout(HttpServletRequest request) {
        String result = authService.logout(request);
        if (result.equalsIgnoreCase("Logout Successful!")) {
            return new ResponseWrapper<>("00", result, null, "");
        }
        return new ResponseWrapper<>("01", "Logout Failed", null, result);
    }

    @PostMapping("/forgotPassword")
    public ResponseWrapper<?> forgotPassword(@RequestBody ForgotPasswordRequest request) {
        String username = request.getUsername();
        if (username == null || username.trim().isEmpty()) {
            return new ResponseWrapper<>("01", "Invalid Request", null, "Username is required for password recovery.");
        }

        String result = authService.forgotPassword(username);
        return result.equals("OTP Sent Successfully!") ?
                new ResponseWrapper<>("00", result, null, "") :
                new ResponseWrapper<>("01", "Failed to Send OTP", null, result);
    }

    @PostMapping("/verifyOtp")
    public ResponseWrapper<?> verifyOtp(@RequestBody Map<String, String> request) {
        String username = request.get("username");
        String otp = request.get("otp");
        if (username == null || otp == null) {
            return new ResponseWrapper<>("01", "Invalid Request", null, "Username and OTP are required.");
        }

        boolean isVerified = authService.verifyOtp(username, otp);
        return isVerified ?
                new ResponseWrapper<>("00", "OTP Verified Successfully!", null, "") :
                new ResponseWrapper<>("01", "OTP Verification Failed", null, "Invalid or Expired OTP.");
    }

    @PostMapping("/resendOtp")
    public ResponseWrapper<?> resendOtp(@RequestBody Map<String, String> request) {
        String username = request.get("username");
        if (username == null || username.trim().isEmpty()) {
            return new ResponseWrapper<>("01", "Invalid Request", null, "Username is required to resend OTP.");
        }

        String result = authService.resendOtp(username);
        return result.equals("OTP Resent Successfully!") ?
                new ResponseWrapper<>("00", result, null, "") :
                new ResponseWrapper<>("01", "Failed to Resend OTP", null, result);
    }

    @PostMapping("/updatePassword")
    public ResponseWrapper<?> updatePassword(@RequestBody Map<String, String> request) {
        String username = request.get("username");
        String newPassword = request.get("newPassword");
        if (username == null || newPassword == null) {
            return new ResponseWrapper<>("01", "Invalid Request", null, "Username and New Password are required.");
        }

        String result = authService.updatePassword(username, newPassword);
        return result.equals("Password Updated Successfully!") ?
                new ResponseWrapper<>("00", result, null, "") :
                new ResponseWrapper<>("01", "Password Update Failed", null, result);
    }

    @PostMapping("/validateToken")
    public ResponseWrapper<?> validateToken(@RequestHeader("Authorization") String token) {
        if (token == null || !token.trim().startsWith("Bearer ")) {
            return new ResponseWrapper<>("01", "Invalid Token", null, "Authorization header is missing or malformed.");
        }

        String jwt = token.trim().substring(7);
        boolean isValid = jwtUtil.validateToken(jwt, jwtUtil.extractUsername(jwt));
        return isValid ?
                new ResponseWrapper<>("00", "Token is Valid!", null, "") :
                new ResponseWrapper<>("01", "Invalid Token", null, "Token validation failed.");
    }

    private ResponseWrapper<?> createResponse(String result, String successMessage, String failureMessage) {
        return result.equalsIgnoreCase(successMessage) ?
                new ResponseWrapper<>("00", result, null, "") :
                new ResponseWrapper<>("01", result, null, failureMessage);
    }
}