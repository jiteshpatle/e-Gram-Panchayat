package eGramPanchayat.controller;

import eGramPanchayat.service.impl.TransactionLogService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import eGramPanchayat.dto.Namuna32RakkamPartavyaSathiChaAdeshDTO;
import eGramPanchayat.entity.Egram9;
import eGramPanchayat.service.Egram9Service;
import eGramPanchayat.util.ResponseWrapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/egram9")
public class Egram9Controller {

    @Autowired
    private Egram9Service egram9Service;

    @Autowired
    private TransactionLogService transactionLogService;

    // save the data
    @PostMapping("/create")
    public ResponseEntity<?> createEgram9(@Valid @RequestBody Egram9 entry, BindingResult bindingResult) {
        // Check for validation errors
        if (bindingResult.hasErrors()) {
            List<String> errors = bindingResult.getFieldErrors().stream()
                    .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                    .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new eGramPanchayat.util.ResponseWrapper<>("01", "Validation Failed", null, errors));
        }

        try {
            // Additional custom validation (e.g., regex or business logic)
            List<Map<String, String>> customErrors = validateInput(entry);
            if (!customErrors.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(new ResponseWrapper<>("01", "Validation Failed", null, customErrors));
            }

            // Save entry through the service
            Egram9 created = egram9Service.saveEgram9(entry);
            transactionLogService.logTransaction(
                    "SAVE",
                    "Data saved successfully for Namuna09",
                    null,
                    created.getEmployeeId(),
                    created.getEmployeeName(),
                    created.getGrampanchayatId(),
                    created.getGrampanchayatName());

            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Saved Successfully", null, ""));
        } catch (IllegalArgumentException e) {
            // Return validation errors as response
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseWrapper<>("01", "Validation Failed", null, e.getMessage()));
        } catch (Exception e) {
            // Catch any unexpected errors
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "An Error Occurred", null, "Data Not Found"));
        }
    }

    // Get All Member of grampanchyat
    // Get all Egram9 records
    @PostMapping("/getAllRecord")
    public ResponseEntity<?> getAllEgram9() {
        try {
            List<Egram9> list = egram9Service.getAllEgram9();

            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", list, ""));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "An Error Occurred", null, e.getMessage()));
        }
    }

    // Get specific entry by ID
    @PostMapping("/getById/{id}")
    public ResponseEntity<?> getEntryById(@PathVariable Long id) {
        try {
            Optional<Egram9> entry = egram9Service.getEgram9ById(id);
            if (entry.isPresent()) {
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Found", entry.get(), ""));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, "Data Not Found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, e.getMessage()));
        }
    }

    // Update by field using Id
    @PostMapping("/updateById/{id}")
    public ResponseEntity<?> updateEgram9(@PathVariable Long id, @Valid @RequestBody Egram9 entry,
            BindingResult bindingResult) {
        // Check for validation errors
        if (bindingResult.hasErrors()) {
            List<String> errors = bindingResult.getFieldErrors().stream()
                    .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                    .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseWrapper<>("01", "Validation Failed", null, errors));
        }

        try {
            // Additional custom validation (e.g., regex or business logic)
            List<Map<String, String>> customErrors = validateInput(entry);
            if (!customErrors.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(new ResponseWrapper<>("01", "Validation Failed", null, customErrors));
            }

            // Update entry through the service layer
            Egram9 updatedEntry = egram9Service.updateEgram9(id, entry);
            if (updatedEntry != null) {

                transactionLogService.logTransaction(
                        "UPDATE",

                        "Data updated successfully for Namuna09 with ID " + id,
                        null, updatedEntry.getEmployeeId(), updatedEntry.getEmployeeName(),
                        updatedEntry.getEmployeeId(),
                        updatedEntry.getGrampanchayatName());
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Updated Successfully", null, ""));
            } else {
                // If entry not found, return a not found response
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new ResponseWrapper<>("01", "Error Updating Data", null, "Data Not Found"));
            }
        } catch (Exception e) {
            // Catch unexpected errors
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "Error Updating Data", null, "Data Not Found"));
        }
    }

    // Delete an Egram9 record by ID

    @PostMapping("/DeleteById/{id}")
    // public ResponseEntity<?> deleteEgram9(@PathVariable Long id) {
    // // egram9Service.deleteEgram9(id);
    // try {
    // boolean deleted = egram9Service.deleteEgram9(id);
    // if (deleted) {
    // transactionLogService.logTransaction(
    // "DELETE",

    // "Deleted Succesfully: ",
    // null, null, null, null
    // ,null);
    // return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Deleted
    // Successfully", null, ""));
    // } else {
    // return ResponseEntity.status(HttpStatus.NOT_FOUND)
    // .body(new ResponseWrapper<>("01", null, null, "Data Not Found"));
    // }
    // } catch (Exception e) {
    // return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
    // .body(new ResponseWrapper<>("01", "Error Deleting Data", null,
    // e.getMessage()));
    // }
    // }

    public ResponseEntity<?> delete(@PathVariable long id,
            @RequestBody Egram9 deleteRequest) {
        Map<String, Object> response = new LinkedHashMap<>();
        try {
            // Find the record by ID

            if (deleteRequest.getEmployeeId() == null ||
                    deleteRequest.getEmployeeName() == null ||
                    deleteRequest.getGrampanchayatId() == null ||
                    deleteRequest.getGrampanchayatName() == null) {

                // // Log the not-found case with null values
                // transactionLogService.logTransaction(
                // "DELETE",
                // "Deletion failed. Data not found for ID " + id,
                // null, employeeId, employeeName, gramPanchayatId, gramPanchayatName);

                // Prepare a not-found response
                response.put("code", "01");
                response.put("message", "Error Deleting Data");
                response.put("errormessage", "Data Not Found");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }

            // Proceed with deletion
            boolean isDeleted = egram9Service.deleteEgram9(id);
            if (isDeleted) {
                // Log the deletion action with field values (or null if they are missing)
                transactionLogService.logTransaction(
                        "DELETE",
                        "Data deleted successfully for Namuna32 with ID " + id,
                        null, deleteRequest.getEmployeeId(),
                        deleteRequest.getEmployeeName(),
                        deleteRequest.getGrampanchayatId(),
                        deleteRequest.getGrampanchayatName());

                // Prepare a successful response
                response.put("code", "00");
                response.put("message", "Data Deleted Successfully");
                response.put("errormessage", "");
                return ResponseEntity.ok(response);
            } else {
                // // Log the deletion failure with field values (or null if they are missing)
                // transactionLogService.logTransaction(
                // "DELETE",
                // "Deletion operation failed for Namuna32 with ID " + id,
                // null, employeeId, employeeName, gramPanchayatId, gramPanchayatName);

                response.put("code", "01");
                response.put("message", "Error Deleting Data");
                response.put("errormessage", "Deletion operation failed");
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
            }
        } catch (Exception e) {
            // // Log the exception with null values for fields
            // transactionLogService.logTransaction(
            // "DELETE",
            // "Error occurred while deleting data for ID " + id,
            // null, null, null, null, null);

            // Prepare an error response
            response.put("code", "01");
            response.put("message", "Error Deleting Data");
            response.put("errormessage", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }

    private List<Map<String, String>> validateInput(Egram9 entry) {
        List<Map<String, String>> errorMessages = new ArrayList<>(); // List to store error messages
        String regex = "^[\\u0900-\\u097F\\sa-zA-Z0-9-]*$"; // Allow alphanumeric characters, spaces, and dashes

        // Helper method to add errors to the list
        Consumer<String> addError = message -> {
            Map<String, String> error = new HashMap<>();
            error.put("description", message);
            errorMessages.add(error);
        };

        // Validate String fields for alphanumeric and space constraints
        if (entry.getYear() != null && !entry.getYear().matches(regex)) {
            addError.accept("Year contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        if (entry.getEmployeeId() != null && !entry.getEmployeeId().matches(regex)) {
            addError.accept(
                    "Employee ID contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        if (entry.getEmployeeName() != null && !entry.getEmployeeName().matches(regex)) {
            addError.accept(
                    "Employee Name contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        if (entry.getGrampanchayatId() != null && !entry.getGrampanchayatId().matches(regex)) {
            addError.accept(
                    "Grampanchayat ID contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        if (entry.getGrampanchayatName() != null && !entry.getGrampanchayatName().matches(regex)) {
            addError.accept(
                    "Grampanchayat Name contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        if (entry.getRemark() != null && !entry.getRemark().matches(regex)) {
            addError.accept("Remark contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        if (entry.getBookNo() != null && !entry.getBookNo().matches(regex)) {
            addError.accept(
                    "Book Number contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        if (entry.getBookNoOR_Date() != null && !entry.getBookNoOR_Date().matches(regex)) {
            addError.accept(
                    "Book Number OR Date contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        if (entry.getSutManjuriHukmacha_Shera() != null && !entry.getSutManjuriHukmacha_Shera().matches(regex)) {
            addError.accept(
                    "Sut Manjuri   Hukmacha Shera contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }
        if (entry.getSutManjuriHukmacha_Ullekh() != null && !entry.getSutManjuriHukmacha_Ullekh().matches(regex)) {
            addError.accept("Sut Manjuri hukmacha Ullekh contains invalid characters.");
        }

        // Validate Long fields for non-null and non-negative values
        BiConsumer<Long, String> validateLongField = (value, fieldName) -> {
            if (value == null || value < 0) {
                addError.accept(fieldName + " must be a non-negative number and cannot be null.");
            }
        };
        validateLongField.accept(entry.getMilkat_Number(), "Milkat Number");
        validateLongField.accept(entry.getNa_GharMagilBaki(), "Na Ghar Magil Baki");
        validateLongField.accept(entry.getNa_GharChaluKar(), "Na Ghar Chalu Kar");

        validateLongField.accept(entry.getNa_VijMagilBaki(), "Na Vij Magil Baki");
        validateLongField.accept(entry.getNa_VijChaluKar(), "Na Vij Chalu Kar");

        validateLongField.accept(entry.getNa_ArogyaMagilBaki(), "Na Arogya Magil Baki");
        validateLongField.accept(entry.getNa_ArogyaChaluKar(), "Na Arogya Chalu Kar");

        validateLongField.accept(entry.getNa_PaniMagilBaki(), "Na Pani Magil Baki");
        validateLongField.accept(entry.getNa_PaniChaluKar(), "Na Pani Chalu Kar");

        validateLongField.accept(entry.getVasuli_GharMagilBaki(), "Vasuli Ghar Magil Baki");
        validateLongField.accept(entry.getVasuli_GharChaluKar(), "Vasuli Ghar Chalu Kar");

        validateLongField.accept(entry.getVasuli_VijMagilBaki(), "Vasuli Vij Magil Baki");
        validateLongField.accept(entry.getVasuli_VijChaluKar(), "Vasuli Vij Chalu Kar");

        validateLongField.accept(entry.getVasuli_ArogyaMagilBaki(), "Vasuli Arogya Magil Baki");
        validateLongField.accept(entry.getVasuli_ArogyaChaluKar(), "Vasuli Arogya Chalu Kar");

        validateLongField.accept(entry.getVasuli_PaniMagilBaki(), "Vasuli Pani Magil Baki");
        validateLongField.accept(entry.getVasuli_PaniChaluKar(), "Vasuli Pani Chalu Kar");

        // Validate Integer fields
        if (entry.getSerialNo() == null || entry.getSerialNo() < 0) {
            addError.accept("Serial Number must be a non-negative integer and cannot be null.");
        }

        return errorMessages; // Return all error messages
    }

}
