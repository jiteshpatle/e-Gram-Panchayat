package eGramPanchayat.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import eGramPanchayat.service.impl.TransactionLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import eGramPanchayat.dto.Namuna32RakkamPartavyaSathiChaAdeshDTO;
import eGramPanchayat.dto.SthavarMalmattaNondWahi_22_Dto;
import eGramPanchayat.entity.SthavarMalmattaNondWahi_22;
import eGramPanchayat.service.SthavarMalmattaNondWahi_22_Service;
import eGramPanchayat.util.ResponseWrapper;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/sthavarMalmatta")
@CrossOrigin(origins = "http://localhost:3000")
public class SthavarMalmattaNondWahi_22_Controller {

    @Autowired
    private SthavarMalmattaNondWahi_22_Service service;

    @Autowired
    private TransactionLogService transactionLogService;

    // Save endpoint
    @PostMapping("/create")
    public ResponseEntity<?> addEntry(@Valid @RequestBody SthavarMalmattaNondWahi_22 entry,
            BindingResult bindingResult) {
        // Check for validation errors
        if (bindingResult.hasErrors()) {
            List<String> errors = bindingResult.getFieldErrors().stream()
                    .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                    .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseWrapper<>("01", "Validation Failed", null, errors));
        }

        try {
            // Additional custom validation (e.g., regex or business logic)
            List<Map<String, String>> customErrors = validateInput(entry);
            if (!customErrors.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(new ResponseWrapper<>("01", "Validation Failed", null, customErrors));
            }

            // Save entry through the service
            SthavarMalmattaNondWahi_22 created= service.addEntry(entry);

            // Log the transaction after successfully saving the entry
            transactionLogService.logTransaction("SAVE", "Data saved successfully for Namuna22", null,
                    created.getEmployeeId(),
                    created.getEmployeeName(),
                    created.getGrampanchayatId(),
                    created.getGrampanchayatName());

            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Saved Successfully", null, ""));
        } catch (IllegalArgumentException e) {
            // Return validation errors as response
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseWrapper<>("01", "Validation Failed", null, e.getMessage()));
        } catch (Exception e) {
            // Catch any unexpected errors
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "An Error Occurred", null, "Data Not Found"));
        }
    }

    // Update endpoint
    @PostMapping("/updateById/{id}")
    public ResponseEntity<?> updateEntry(@PathVariable Long id, @Valid @RequestBody SthavarMalmattaNondWahi_22 entry,
            BindingResult bindingResult) {
        // Check for validation errors
        if (bindingResult.hasErrors()) {
            List<String> errors = bindingResult.getFieldErrors().stream()
                    .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                    .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseWrapper<>("01", "Validation Failed", null, errors));
        }

        try {
            // Additional custom validation (e.g., regex or business logic)
            List<Map<String, String>> customErrors = validateInput(entry);
            if (!customErrors.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(new ResponseWrapper<>("01", "Validation Failed", null, customErrors));
            }

            // Update entry through the service layer
            SthavarMalmattaNondWahi_22 updated = service.updateEntry(id, entry);
            if (updated != null) {
                // Log the transaction after successfully updating the entry
                transactionLogService.logTransaction(
                    "UPDATE",
                        "Data updated successfully for Namuna22 with ID "+ id,
                    null,
                    updated.getEmployeeId(),
                    updated.getEmployeeName(),
                    updated.getGrampanchayatId(),
                    updated.getGrampanchayatName());

                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Updated Successfully", null, ""));
            } else {
                // If entry not found, return a not found response
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new ResponseWrapper<>("01", "Error Updating Data", null, "Data Not Found"));
            }
        } catch (Exception e) {
            // Catch unexpected errors
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "Error Updating Data", null, "Data Not Found"));
        }
    }

    // Get all entries
    @PostMapping("/getAll")
    public ResponseEntity<?> getAllEntries() {
        try {
            List<SthavarMalmattaNondWahi_22> entriesList = service.getAllEntries();
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", entriesList, ""));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "An Error Occurred", null, e.getMessage()));
        }
    }

    // Get specific entry by ID
    @PostMapping("/getById/{id}")
    public ResponseEntity<?> getEntryById(@PathVariable Long id) {
        try {
            Optional<SthavarMalmattaNondWahi_22> entry = service.getEntryById(id);
            if (entry.isPresent()) {
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieving Successfully", entry.get(), ""));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, "Data Not Found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, e.getMessage()));
        }
    }

    // Delete entry by ID
    @PostMapping("/deleteById/{id}")
    public ResponseEntity<?> delete(@PathVariable long id,
			@RequestBody SthavarMalmattaNondWahi_22_Dto deleteRequest) {
		Map<String, Object> response = new LinkedHashMap<>();
		try {
			// Find the record by ID

			if (deleteRequest.getEmployeeId() == null ||
					deleteRequest.getEmployeeName() == null ||
					deleteRequest.getGrampanchayatId() == null ||
					deleteRequest.getGrampanchayatName() == null) {

				// // Log the not-found case with null values
				// transactionLogService.logTransaction(
				// "DELETE",
				// "Deletion failed. Data not found for ID " + id,
				// null, employeeId, employeeName, gramPanchayatId, gramPanchayatName);

				// Prepare a not-found response
				response.put("code", "01");
				response.put("message", "Error Deleting Data");
				response.put("errormessage", "Data Not Found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}

			// Proceed with deletion
			boolean isDeleted = service.deleteEntry(id);
			if (isDeleted) {
				// Log the deletion action with field values (or null if they are missing)
				transactionLogService.logTransaction(
						"DELETE",
						"Data deleted successfully for Namuna22 with ID " + id,
						null, deleteRequest.getEmployeeId(),
						deleteRequest.getEmployeeName(),
						deleteRequest.getGrampanchayatId(),
						deleteRequest.getGrampanchayatName());

				// Prepare a successful response
				response.put("code", "00");
				response.put("message", "Data Deleted Successfully");
				response.put("errormessage", "");
				return ResponseEntity.ok(response);
			} else {
				// // Log the deletion failure with field values (or null if they are missing)
				// transactionLogService.logTransaction(
				// "DELETE",
				// "Deletion operation failed for Namuna32 with ID " + id,
				// null, employeeId, employeeName, gramPanchayatId, gramPanchayatName);

				response.put("code", "01");
				response.put("message", "Error Deleting Data");
				response.put("errormessage", "Deletion operation failed");
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
			}
		} catch (Exception e) {
			// // Log the exception with null values for fields
			// transactionLogService.logTransaction(
			// "DELETE",
			// "Error occurred while deleting data for ID " + id,
			// null, null, null, null, null);

			// Prepare an error response
			response.put("code", "01");
			response.put("message", "Error Deleting Data");
			response.put("errormessage", e.getMessage());
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
	}

    private List<Map<String, String>> validateInput(SthavarMalmattaNondWahi_22 entry) {
        List<Map<String, String>> errorMessages = new ArrayList<>(); // List to store error messages

        String str1 = "^[\\u0900-\\u097F\\sa-zA-Z\\p{Punct} ]*$";

        String int1 = "^[0-9\\u0966-\\u096F\\-\\.\\s]*$";

        // Helper method to add errors to the list
        Consumer<String> addError = message -> {
            Map<String, String> error = new HashMap<>();
            error.put("description", message);
            errorMessages.add(error);
        };

        // Validate employeeName
        // if (!entry.getEmployeeName().matches(regex)) {
        // addError.accept("Employee Name contains invalid characters. Only alphanumeric
        // characters and spaces are allowed.");
        // }
        //
        // // Validate grampanchayatName
        // if (!entry.getGrampanchayatName().matches(regex)) {
        // addError.accept("Grampanchayat Name contains invalid characters. Only
        // alphanumeric characters and spaces are allowed.");
        // }
        //
        // // Validate employeeId
        // if (!entry.getEmployeeId().matches(regex)) {
        // addError.accept("Employee ID contains invalid characters. Only alphanumeric
        // characters and spaces are allowed.");
        // }
        //
        // // Validate grampanchayatId
        // if (!entry.getGrampanchayatId().matches(regex)) {
        // addError.accept("Grampanchayat ID contains invalid characters. Only
        // alphanumeric characters and spaces are allowed.");
        // }

        // Validate anukramank
        //
        if (!entry.getSanpadanchiKharediKinwaUbharnichaDinank().matches(int1)) {
            addError.accept(
                    "Sanpadanchi Kharedi Kinwa Ubharnicha Dinank contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        if (!entry.getjAMSamKTyaadeshacheVPanchTharKramank().matches(int1)) {
            addError.accept(
                    "j A M Sam K Tya adeshache V Panch Thar Kramank contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        if (!entry.getjAMSamKTyaadeshacheVPanchTharDinak().matches(int1)) {
            addError.accept(
                    "j A M Sam K Tya adeshache V Panch Thar Dinank contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        if (!entry.getMalmattechaBhumapanKramank().matches(int1)) {
            addError.accept(
                    "Malmatte Cha Bhumapan Kramank contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }
        if (!entry.getMalmattechaBhumapanMalmattecheVarnan().matches(str1)) {
            addError.accept(
                    "Malmattecha Bhumapan Malmatteche Varnan contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        if (!entry.getKonatyaKarnaSaathiWaparKela().matches(str1)) {
            addError.accept(
                    "Konatya Karna Saathi Wapar Kela contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate ubharniKinwaSampadanachaKharch
        if (!entry.getUbharniKinwaSampadanachaKharch().matches(int1)) {
            addError.accept(
                    "Ubharni Kinwa Sampadanacha Kharch contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        if (!entry.getDurustyawarKinwaFerfaravarDinank().matches(int1)) {
            addError.accept("Durustyawar Kinwa Ferfaravar Dinank cannot be null.");
        }

        // Validate durustyawarKinwaFerfaravarChaluDurustyaRupaye
        if (!entry.getDurustyawarKinwaFerfaravarChaluDurustyaRupaye().matches(int1)) {
            addError.accept(
                    "Durustyawar Kinwa Ferfaravar Chalu Durustya Rupaye contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate durustyawarKinwaFerfaravarWisheshDurustyaRupaye
        if (!entry.getDurustyawarKinwaFerfaravarWisheshDurustyaRupaye().matches(int1)) {
            addError.accept(
                    "Durustyawar Kinwa Ferfaravar Wishesh Durustya Rupaye contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate durustyawarKinwaFerfaravarMulBandhKaamRupaye
        if (!entry.getDurustyawarKinwaFerfaravarMulBandhKaamRupaye().matches(int1)) {
            addError.accept(
                    "Durustyawar Kinwa Ferfaravar Mul Bandh Kaam Rupaye contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate durustyawarKinwaFerfaravarMulBandhkaamcheSwarup
        if (!entry.getDurustyawarKinwaFerfaravarMulBandhkaamcheSwarup().matches(str1)) {
            addError.accept(
                    "Durustyawar Kinwa Ferfaravar Mul Bandhkaamche Swarup contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate warshaAkherisGhatleliKinmat
        if (!entry.getWarshaAkherisGhatleliKinmat().matches(int1)) {
            addError.accept(
                    "Warsha Akheris Ghatleli Kinmat contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // // Validate sarpanchVaSachivYanchiAadhyakshari
        // if (!entry.getSarpanchVaSachivYanchiAadhyakshari().matches(regex)) {
        // addError.accept("Sarpanch Va Sachiv Yanchi Aadhyakshari contains invalid
        // characters. Only alphanumeric characters and spaces are allowed.");
        // }

        // Validate malmattechiVilhewatKramankVaDinank
        if (!entry.getMalmattechiVilhewatKramank().matches(int1)) {
            addError.accept(
                    "Malmattechi Vilhewat Kramank contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        if (!entry.getMalmattechiVilhewatDinank().matches(int1)) {
            addError.accept(
                    "Malmattechi Vilhewat Dinank contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate malmattechiVilhewatKalam55KramankVaDinank
        if (!entry.getMalmattechiVilhewatKalam55Dinank().matches(int1)) {
            addError.accept(
                    "Malmattechi Vilhewat Kalam 55 Dinank contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        if (!entry.getMalmattechiVilhewatKalam55Kramank().matches(int1)) {
            addError.accept(
                    "Malmattechi Vilhewat Kalam 55 Kramank contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate shera
        if (!entry.getShera().matches(str1)) {
            addError.accept("Shera contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        return errorMessages; // Return the list of errors
    }

}
