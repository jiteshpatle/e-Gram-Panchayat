package eGramPanchayat.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import eGramPanchayat.service.impl.TransactionLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import eGramPanchayat.dto.Namuna32RakkamPartavyaSathiChaAdeshDTO;
import eGramPanchayat.dto.TabyatilRastyanchiNondWahi_23_Dto;
import eGramPanchayat.service.TabyatilRastyanchiNondWahi_23_Service;
import eGramPanchayat.util.ResponseWrapper;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/tabyatilRastyanchiNondWahi")
@CrossOrigin(origins = "http://localhost:3000")
public class TabyatilRastyanchiNondWahi_23_Controller {

    @Autowired
    private TabyatilRastyanchiNondWahi_23_Service service;

    @Autowired
    private TransactionLogService transactionLogService;

    // Save endpoint
    @PostMapping("/create")
    public ResponseEntity<?> saveDetails(@Valid @RequestBody TabyatilRastyanchiNondWahi_23_Dto dto,
            BindingResult bindingResult) {
        // Check for validation errors
        if (bindingResult.hasErrors()) {
            List<String> errors = bindingResult.getFieldErrors().stream()
                    .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                    .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseWrapper<>("01", "Validation Failed", null, errors));
        }

        try {
            // Additional custom validation (e.g., regex or business logic)
            List<Map<String, String>> customErrors = validateInput(dto);
            if (!customErrors.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(new ResponseWrapper<>("01", "Validation Failed", null, customErrors));
            }

            // Create entry through the service
            TabyatilRastyanchiNondWahi_23_Dto created = service.create(dto);

            // Log the transaction after successfully saving the entity
            transactionLogService.logTransaction("SAVE", "Data saved successfully for Namuna23 ",
                    null, created.getEmployeeId(), created.getEmployeeName(), created.getGrampanchayatId(),
                            created.getGrampanchayatName());

            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Saved Successfully!", null, ""));
        } catch (IllegalArgumentException e) {
            // Return validation errors as response
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseWrapper<>("01", "Validation Failed", null, e.getMessage()));
        } catch (Exception e) {
            // Catch any unexpected errors
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "An Error Occurred", null, "Data Not Found"));
        }
    }

    // Update endpoint
    @PostMapping("/updateById/{id}")
    public ResponseEntity<?> updateDetails(@PathVariable Long id,
            @Valid @RequestBody TabyatilRastyanchiNondWahi_23_Dto dto, BindingResult bindingResult) {
        // Check for validation errors
        if (bindingResult.hasErrors()) {
            List<String> errors = bindingResult.getFieldErrors().stream()
                    .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                    .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseWrapper<>("01", "Validation Failed", null, errors));
        }

        try {
            // Additional custom validation
            List<Map<String, String>> customErrors = validateInput(dto);
            if (!customErrors.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(new ResponseWrapper<>("01", "Validation Failed", null, customErrors));
            }

            // Update entry through the service
            TabyatilRastyanchiNondWahi_23_Dto updated = service.update(id, dto);
            if (updated != null) {
                // Log the transaction after successfully updating the entity
                transactionLogService.logTransaction("UPDATE",
                        "Data updated successfully for Namuna23 with ID "
                        + id,
                        null, updated.getEmployeeId(), updated.getEmployeeName(), updated.getGrampanchayatId(),
                                updated.getGrampanchayatName());

                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Updated Successfully!", null, ""));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new ResponseWrapper<>("01", "Error Updating Data", null, "Data Not Found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "Error Updating Data", null, "Data Not Found"));
        }
    }

    // Get all records
    @PostMapping("/getAll")
    public ResponseEntity<?> getAllDetails() {
        try {
            List<TabyatilRastyanchiNondWahi_23_Dto> detailsList = service.getAll();
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", detailsList, ""));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "An Error Occurred", null, e.getMessage()));
        }
    }

    // Get specific record by ID
    @PostMapping("/getById/{id}")
    public ResponseEntity<?> getDetailsById(@PathVariable Long id) {
        try {
            Optional<TabyatilRastyanchiNondWahi_23_Dto> details = service.getById(id);
            if (details.isPresent()) {
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", details.get(), ""));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, "Data Not Found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, e.getMessage()));
        }
    }

    @PostMapping("/deleteById/{id}")
    public ResponseEntity<?> delete(@PathVariable long id,
			@RequestBody TabyatilRastyanchiNondWahi_23_Dto deleteRequest) {
		Map<String, Object> response = new LinkedHashMap<>();
		try {
			// Find the record by ID

			if (deleteRequest.getEmployeeId() == null ||
					deleteRequest.getEmployeeName() == null ||
					deleteRequest.getGrampanchayatId() == null ||
					deleteRequest.getGrampanchayatName() == null) {

				// // Log the not-found case with null values
				// transactionLogService.logTransaction(
				// "DELETE",
				// "Deletion failed. Data not found for ID " + id,
				// null, employeeId, employeeName, gramPanchayatId, gramPanchayatName);

				// Prepare a not-found response
				response.put("code", "01");
				response.put("message", "Error Deleting Data");
				response.put("errormessage", "Data Not Found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}

			// Proceed with deletion
			boolean isDeleted = service.delete(id);
			if (isDeleted) {
				// Log the deletion action with field values (or null if they are missing)
				transactionLogService.logTransaction(
						"DELETE",
						"Data deleted successfully for Namuna32 with ID " + id,
						null, deleteRequest.getEmployeeId(),
						deleteRequest.getEmployeeName(),
						deleteRequest.getGrampanchayatId(),
						deleteRequest.getGrampanchayatName());

				// Prepare a successful response
				response.put("code", "00");
				response.put("message", "Data Deleted Successfully");
				response.put("errormessage", "");
				return ResponseEntity.ok(response);
			} else {
				// // Log the deletion failure with field values (or null if they are missing)
				// transactionLogService.logTransaction(
				// "DELETE",
				// "Deletion operation failed for Namuna32 with ID " + id,
				// null, employeeId, employeeName, gramPanchayatId, gramPanchayatName);

				response.put("code", "01");
				response.put("message", "Error Deleting Data");
				response.put("errormessage", "Deletion operation failed");
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
			}
		} catch (Exception e) {
			// // Log the exception with null values for fields
			// transactionLogService.logTransaction(
			// "DELETE",
			// "Error occurred while deleting data for ID " + id,
			// null, null, null, null, null);

			// Prepare an error response
			response.put("code", "01");
			response.put("message", "Error Deleting Data");
			response.put("errormessage", e.getMessage());
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
	}

    private List<Map<String, String>> validateInput(TabyatilRastyanchiNondWahi_23_Dto dto) {
        List<Map<String, String>> errorMessages = new ArrayList<>();
        String regex = "^[\\u0900-\\u097F0-9a-zA-Z\\s]*$";
        String regex1 = "^[\\u0900-\\u097F0-9 .]*$";
        String regex2 = "^[\\u0900-\\u097F0-9 -]*$";

        // Helper method to add errors to the list
        Consumer<String> addError = message -> {
            Map<String, String> error = new HashMap<>();
            error.put("description", message);
            errorMessages.add(error);
        };

        // Validate employeeName
        // if (!dto.getEmployeeName().matches(regex)) {
        // addError.accept("Employee Name contains invalid characters. Only alphanumeric
        // characters and spaces are allowed.");
        // }
        //
        // // Validate grampanchayatName
        // if (!dto.getGrampanchayatName().matches(regex)) {
        // addError.accept("Grampanchayat Name contains invalid characters. Only
        // alphanumeric characters and spaces are allowed.");
        // }
        //
        // // Validate employeeId (since it's a Long, we check if it's null)
        // if (dto.getEmployeeId() == null) {
        // addError.accept("Employee ID cannot be null.");
        // }
        //
        // // Validate grampanchayatId (since it's a Long, we check if it's null)
        // if (dto.getGrampanchayatId() == null) {
        // addError.accept("Grampanchayat ID cannot be null.");
        // }
        if (dto.getLaambiKm() != null && !dto.getLaambiKm().matches(regex1)) {
            addError.accept("LaambiKm contains invalid characters.Only Numbers are allowed.");
        }
        if (dto.getRundiKm() != null && !dto.getRundiKm().matches(regex1)) {
            addError.accept("RundiKm contains invalid characters. Only Numbers are allowed.");
        }
        if (dto.getPratiKmRastaTayarKarnyasAalelaKharch() != null
                && !dto.getPratiKmRastaTayarKarnyasAalelaKharch().matches(regex1)) {
            addError.accept(
                    "Prati Km Rasta Tayar Karnyas Aalela Kharch contains invalid characters. Only Numbers are allowed.");
        }
        if (dto.getDurustyaChaluKharchRupaye() != null && !dto.getDurustyaChaluKharchRupaye().matches(regex1)) {
            addError.accept("Durustya Chalu Kharch Rupaye contains invalid characters. Only Numbers are allowed.");
        }
        if (dto.getDurustyaWisheshKharchRupaye() != null && !dto.getDurustyaWisheshKharchRupaye().matches(regex1)) {
            addError.accept("Durustya Wishesh Kharch Rupaye contains invalid characters. Only Numbers are allowed.");
        }
        if (dto.getDurustyaMulBandhkamKharchRupaye() != null
                && !dto.getDurustyaMulBandhkamKharchRupaye().matches(regex1)) {
            addError.accept(
                    "Durustya Mul Bandhkam Kharch Rupaye contains invalid characters. Only Numbers are allowed.");
        }

        // Validate Year (String field)
        if (dto.getYear() != null && !dto.getYear().matches(regex2)) {
            addError.accept("Year contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // // Validate anukramank (Integer field)
        // if (dto.getAnukramank() == null) {
        // addError.accept("Anukramank cannot be null.");
        // }

        // Validate rastyacheNaaw
        if (!dto.getRastyacheNaaw().matches(regex)) {
            addError.accept(
                    "Rastyache Naaw contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate gaawPaasun
        if (!dto.getGaawPaasun().matches(regex)) {
            addError.accept(
                    "Gaaw Paasun contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate gaawParyant
        if (!dto.getGaawParyant().matches(regex)) {
            addError.accept(
                    "Gaaw Paryant contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate laambiKm (Double field, just check if null)
        if (dto.getLaambiKm() == null) {
            addError.accept("Laambi (Km) cannot be null.");
        }

        // Validate rundiKm (Double field, just check if null)
        if (dto.getRundiKm() == null) {
            addError.accept("Rundi (Km) cannot be null.");
        }

        // Validate rastyachaPrakar
        if (!dto.getRastyachaPrakar().matches(regex)) {
            addError.accept(
                    "Rastyacha Prakar contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate purnKelyachiTarikh (LocalDate field)
        if (dto.getPurnKelyachiTarikh() == null) {
            addError.accept("Purn Kelyachi Tarikh cannot be null.");
        }

        // Validate pratiKmRastaTayarKarnyasAalelaKharch
        if (dto.getPratiKmRastaTayarKarnyasAalelaKharch() == null) {
            addError.accept("Prati Km Rasta Tayar Karnyas Aalela Kharch cannot be null.");
        }

        // Validate durustyaChaluKharchRupaye
        if (dto.getDurustyaChaluKharchRupaye() == null) {
            addError.accept("Durustya Chalu Kharch (Rupaye) cannot be null.");
        }

        // Validate durustyaChaluSwarup
        if (!dto.getDurustyaChaluSwarup().matches(regex)) {
            addError.accept(
                    "Durustya Chalu Swarup contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate durustyaWisheshKharchRupaye
        if (dto.getDurustyaWisheshKharchRupaye() == null) {
            addError.accept("Durustya Wishesh Kharch (Rupaye) cannot be null.");
        }

        // Validate durustyaWisheshSwarup
        if (!dto.getDurustyaWisheshSwarup().matches(regex)) {
            addError.accept(
                    "Durustya Wishesh Swarup contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate durustyaMulBandhkamKharchRupaye
        if (dto.getDurustyaMulBandhkamKharchRupaye() == null) {
            addError.accept("Durustya Mul Bandhkam Kharch (Rupaye) cannot be null.");
        }

        // Validate durustyaMulBandhkamSwarup
        if (!dto.getDurustyaMulBandhkamSwarup().matches(regex)) {
            addError.accept(
                    "Durustya Mul Bandhkam Swarup contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // Validate shera (String field)
        if (dto.getShera() != null && !dto.getShera().matches(regex)) {
            addError.accept("Shera contains invalid characters. Only alphanumeric characters and spaces are allowed.");
        }

        // // Validate malmattechiPadtalniSarpanchSachivSahya
        // if (!dto.getMalmattechiPadtalniSarpanchSachivSahya().matches(regex)) {
        // addError.accept("Malmattechi Padtalni Sarpanch Sachiv Sahya contains invalid
        // characters. Only alphanumeric characters and spaces are allowed.");
        // }

        return errorMessages; // Return the list of errors
    }

}
