package eGramPanchayat.controller;

import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import eGramPanchayat.dto.Namuna10DTO;
import eGramPanchayat.dto.Namuna32RakkamPartavyaSathiChaAdeshDTO;
import eGramPanchayat.dto.Namuna33VrukshNondVihaDTO;
import eGramPanchayat.entity.Namuna10Entity;
import eGramPanchayat.entity.Namuna33VrukshNondViha;
import eGramPanchayat.repository.Namuna10Repo;
import eGramPanchayat.service.Namuna10Service;
import eGramPanchayat.service.impl.TransactionLogService;
import eGramPanchayat.util.ResponseWrapper;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.ValidationException;

@RestController
@RequestMapping("/beed-namuna10")
@CrossOrigin(origins = "http://localhost:3000")
public class Namuna10Controller {

    @Autowired
    private TransactionLogService transactionLogService;

    @Autowired
    private Namuna10Service service;

    @PostMapping("/create")
    public ResponseEntity<ResponseWrapper> create(@RequestBody Namuna10DTO dto) {
        try {
            // Save the data
            Namuna10Entity created = service.save(dto);

            // Log the transaction
            transactionLogService.logTransaction(
                    "SAVE",
                    "Data saved successfully for Namuna10",
                    null,
                    created.getEmployeeId(),
                    created.getEmployeeName(),
                    created.getGramPanchayatId(),
                    created.getGramPanchayatName());

            // Success response
            return ResponseEntity.ok(new ResponseWrapper("00", "Data Created Successfully", null, ""));
        } catch (ValidationException ex) {
            // Validation error response
            return ResponseEntity.badRequest()
                    .body(new ResponseWrapper("01", "Validation Error", null, ex.getMessage()));
        } catch (Exception ex) {
            // Generic error response
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper("02", "Error Creating Data", null,
                            "An unexpected error occurred: " + ex.getMessage()));
        }
    }

    @PostMapping("/getAll")
    public ResponseEntity<List<Namuna10DTO>> getAll() {
        List<Namuna10DTO> dtos = service.getAll();
        return ResponseEntity.ok(dtos);
    }

    @PostMapping("getById/{id}")
    public ResponseEntity<Namuna10DTO> getById(@PathVariable Long id) {
        Namuna10DTO dto = service.getById(id);
        return dto != null ? ResponseEntity.ok(dto) : ResponseEntity.notFound().build();
    }

    // Controller
    @PostMapping("/update/{id}")
    public ResponseEntity<?> updateNamuna10Entity(
            @PathVariable Long id,
            @RequestBody Namuna10Entity updatedEntity) {
        try {
            Namuna10Entity updated = service.update(id, updatedEntity);

            transactionLogService.logTransaction(
                    "UPDATE",
                    "Successfully updated data for Namuna10 with ID: " + id,
                    null,
                    updated.getEmployeeId(),
                    updated.getEmployeeName(),
                    updated.getGramPanchayatId(),
                    updated.getGramPanchayatName());

            return ResponseEntity.ok().body(new ResponseWrapper("00", "Data updated successfully", null, ""));
        } catch (EntityNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseWrapper("01", "Error updating data", null, "Data not found for ID: " + id));
        }
    }

    @PostMapping("/delete/{id}")
     public ResponseEntity<?> delete(@PathVariable long id,
			@RequestBody Namuna10DTO deleteRequest) {
		Map<String, Object> response = new LinkedHashMap<>();
		try {
			// Find the record by ID

			if (deleteRequest.getEmployeeId() == null ||
					deleteRequest.getEmployeeName() == null ||
					deleteRequest.getGramPanchayatId() == null ||
					deleteRequest.getGramPanchayatName() == null) {

				// // Log the not-found case with null values
				// transactionLogService.logTransaction(
				// "DELETE",
				// "Deletion failed. Data not found for ID " + id,
				// null, employeeId, employeeName, gramPanchayatId, gramPanchayatName);

				// Prepare a not-found response
				response.put("code", "01");
				response.put("message", "Error Deleting Data");
				response.put("errormessage", "Data Not Found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}

			// Proceed with deletion
			boolean isDeleted = service.deleteById(id);
			if (isDeleted) {
				// Log the deletion action with field values (or null if they are missing)
				transactionLogService.logTransaction(
						"DELETE",
						"Data deleted successfully for Namuna10 with ID " + id,
						null, deleteRequest.getEmployeeId(),
						deleteRequest.getEmployeeName(),
						deleteRequest.getGramPanchayatId(),
						deleteRequest.getGramPanchayatName());

				// Prepare a successful response
				response.put("code", "00");
				response.put("message", "Data Deleted Successfully");
				response.put("errormessage", "");
				return ResponseEntity.ok(response);
			} else {
				// // Log the deletion failure with field values (or null if they are missing)
				// transactionLogService.logTransaction(
				// "DELETE",
				// "Deletion operation failed for Namuna32 with ID " + id,
				// null, employeeId, employeeName, gramPanchayatId, gramPanchayatName);

				response.put("code", "01");
				response.put("message", "Error Deleting Data");
				response.put("errormessage", "Deletion operation failed");
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
			}
		} catch (Exception e) {
			// // Log the exception with null values for fields
			// transactionLogService.logTransaction(
			// "DELETE",
			// "Error occurred while deleting data for ID " + id,
			// null, null, null, null, null);

			// Prepare an error response
			response.put("code", "01");
			response.put("message", "Error Deleting Data");
			response.put("errormessage", e.getMessage());
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		
	}    }  

    
    

    public static class ErrorMessage {
        private String description;

        public ErrorMessage(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }
}