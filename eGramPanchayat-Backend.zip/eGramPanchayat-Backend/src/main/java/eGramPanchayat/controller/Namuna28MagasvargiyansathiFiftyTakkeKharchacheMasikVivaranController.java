package eGramPanchayat.controller;

import java.util.*;

import eGramPanchayat.service.impl.TransactionLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import eGramPanchayat.dto.Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO;
import eGramPanchayat.service.Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranService;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/masikvivaran")
@CrossOrigin(origins = "http://localhost:3000")
public class Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranController {
	@Autowired
	private Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranService service;
	@Autowired
	private TransactionLogService transactionLogService;

	@PostMapping("/create")
	public ResponseEntity<?> create(
			@Valid @RequestBody Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO dto) {
		try {
			Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO created = service.create(dto);
			Map<String, Object> response = new LinkedHashMap<>();

			// Log successful creation
			transactionLogService.logTransaction(
			"SAVE",
			"Data saved successfully for Namuna28: ",
			null,
			created.getEmployeeId(),
			created.getEmployeeName(),
			created.getEmployeeId(),
			created.getEmployeeName());

			response.put("code", "00");
			response.put("message", "Data Saved Successfully");
			response.put("errormessage", "");
			return ResponseEntity.status(HttpStatus.CREATED).body(response);
		} catch (Exception e) {
			// // Log creation error
			// transactionLogService.logTransaction(
			// 		"CREATE-ERROR",
			// 		null,
			// 		"Error creating record: " + e.getMessage(),
			// 		null, null, null, null);

			Map<String, Object> error = new HashMap<>();
			error.put("code", "01");
			error.put("message", "Error Creating Data");
			error.put("errormessage", e.getMessage());
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
		}
	}

	@PostMapping("/update/{id}")
	public ResponseEntity<Map<String, Object>> update(
			@PathVariable Long id,
			@Valid @RequestBody Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO dto) {
		Map<String, Object> response = new LinkedHashMap<>();
		try {
			Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO updated = service.update(id, dto);

			if (updated != null) {
				// Log successful update
				transactionLogService.logTransaction(
						"UPDATE",

						"Successfully updated data for Namuna28 with ID: " + id,
						null,
						updated.getEmployeeId(),
						updated.getEmployeeName(),
						updated.getGramPanchayatId(),
						updated.getGramPanchayatName());

				response.put("code", "00");
				response.put("message", "Data Updated Successfully");
				response.put("errormessage", "");
				return ResponseEntity.ok(response); // Return 200 OK with updated DTO
			} else {
				// // Log update not found
				// transactionLogService.logTransaction(
				// 		"UPDATE-FAILED",

				// 		"Update failed: Record not found for ID: " + id,
				// 		null, null, null, null, null);

				response.put("code", "01");
				response.put("message", "Error Updating Data");
				response.put("errormessage", "Data Not Found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response); // Return 404 Not Found
			}
		} catch (EntityNotFoundException e) {
			// // Log specific not found error
			// transactionLogService.logTransaction(
			// 		"UPDATE-NOT-FOUND",

			// 		"Error updating record: Data not found for ID: " + id,
			// 		null, null, null, null, null);

			response.put("code", "01");
			response.put("message", "Error Updating Data");
			response.put("errormessage", "Data Not Found");
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response); // Return 404 Not Found
		} catch (Exception e) {
			// // Log general exception
			// transactionLogService.logTransaction(
			// 		"UPDATE-ERROR",

			// 		"Error occurred during update: ",
			// 		null, null, null, null, null);

			response.put("code", "01");
			response.put("message", "Error Updating Data");
			response.put("errormessage", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response); // Return 500 Internal Server
																							// Error
		}
	}

	@PostMapping("/getAll")
	public ResponseEntity<?> getAll() {
		Map<String, Object> response = new LinkedHashMap<>();
		try {
			List<Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO> allData = service.getAll();
			if (allData.isEmpty()) {
				response.put("code", "01");
				response.put("message", "Error Retrieving Data");
				response.put("errormessage", "Data Not Found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}
			response.put("code", "00");
			response.put("message", "Data Retrieved Successfully");
			response.put("data", allData);
			response.put("errormessage", "");
			return ResponseEntity.status(HttpStatus.OK).body(response);
		} catch (Exception e) {
			response.put("code", "01");
			response.put("message", "Error Retrieving Data");
			response.put("errormessage", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}

	@PostMapping("/getById/{id}")
	public ResponseEntity<?> getById(@PathVariable Long id) {
		Map<String, Object> response = new LinkedHashMap<>();
		try {
			Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO record = service.getById(id);
			if (record != null) {
				// If the record is found, return the record as the response body
				response.put("code", "00");
				response.put("message", "Data Retrieved Successfully");
				response.put("data", record);
				response.put("errormessage", "");
				return ResponseEntity.ok(response);
			} else {
				// If no record is found, return a message
				response.put("code", "01");
				response.put("message", "Error Retrieving Data");
				response.put("errormessage", "Data Not Found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}
		} catch (Exception e) {
			// Handle any exceptions and return a 500 Internal Server Error
			response.put("code", "01");
			response.put("message", "Error Retrieving Data");
			response.put("errormessage", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}

	@PostMapping("/delete/{id}")
	public ResponseEntity<?> delete(
			@PathVariable Long id,
			@RequestBody(required = false) Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO deleteRequest) {
		Map<String, Object> response = new LinkedHashMap<>();

		try {
			// Validate if JSON body is provided
			if (deleteRequest == null) {
				response.put("code", "01");
				response.put("message", "Error Deleting Data");
				response.put("errormessage", "Request body is missing.");
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
			}

			// Fetch the record by ID
			Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO record = service.getById(id);
			if (record == null) {
				response.put("code", "01");
				response.put("message", "Error Deleting Data");
				response.put("errormessage", "Data Not Found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}

			// Validate required fields in deleteRequest
			if (deleteRequest.getEmployeeId() == null ||
					deleteRequest.getEmployeeName() == null ||
					deleteRequest.getGramPanchayatId() == null ||
					deleteRequest.getGramPanchayatName() == null) {
				response.put("code", "01");
				response.put("message", "Error Deleting Data");
				response.put("errormessage", "All required fields in the request body must be provided.");
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
			}

			// Attempt to delete the record
			service.delete(id);

			// Log the successful deletion
			transactionLogService.logTransaction(
					"DELETE",
					"Successfully deleted Namuna28 data for ID: " + id,
					null,
					deleteRequest.getEmployeeId(),
					deleteRequest.getEmployeeName(),
					deleteRequest.getGramPanchayatId(),
					deleteRequest.getGramPanchayatName());

			// Prepare success response
			response.put("code", "00");
			response.put("message", "Data Deleted Successfully");
			response.put("errormessage", "");
			return ResponseEntity.ok(response);
		} catch (Exception e) {
			// Log the deletion error
			transactionLogService.logTransaction(
					"DELETE-ERROR",
					"Error occurred during deletion: " + e.getMessage(),
					null, null, null, null, null);

			// Prepare error response
			response.put("code", "01");
			response.put("message", "Error Deleting Data");
			response.put("errormessage", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}

	// private List<Map<String, String>>
	// validateInput(Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO
	// dto) {
	// List<Map<String, String>> errorMessages = new ArrayList<>();
	// String regex = "^[\\u0900-\\u097F0-9a-zA-Z\\s]*$";
	// String regex1 = "^[\\u0900-\\u097F0-9 .]*$";
	// String regex2 = "^[\\u0900-\\u097F0-9 -]*$";
	//
	// // Helper method to add errors to the list
	// Consumer<String> addError = message -> {
	// Map<String, String> error = new HashMap<>();
	// error.put("description", message);
	// errorMessages.add(error);
	// };
	//
	// // if(dto.getEmployeeId()!=null && !dto.getEmployeeId().matches(regex)){
	// // addError.accept("Employee Id contains invalid characters.Only Numbers are
	// // allowed.");
	// // }if(dto.getGramPanchayatId()!=null &&
	// // !dto.getGramPanchayatId().matches(regex1)){
	// // addError.accept("GramPanchayat Id contains invalid characters.Only Numbers
	// // are allowed.");
	// // }if(dto.getGramPanchayatName()!=null &&
	// // !dto.getGramPanchayatName().matches(regex1)){
	// // addError.accept("GramPanchayat Name contains invalid characters.Only
	// Numbers
	// // are allowed.");
	// // }if(dto.getEmployeeName()!=null &&
	// !dto.getEmployeeName().matches(regex1)){
	// // addError.accept("Employee Name contains invalid characters.Only Numbers
	// are
	// // allowed.");
	// // }
	// if (dto.getSanMadhemagasvargiyansathiKeleliTartud() != null
	// && !dto.getSanMadhemagasvargiyansathiKeleliTartud().matches(regex)) {
	// addError.accept(
	// "San Madhe magasvargiyansathi Keleli Tartud contains invalid characters.Only
	// Numbers are allowed.");
	// }
	// if (dto.getSan() != null && !dto.getSan().matches(regex2)) {
	// addError.accept("San contains invalid characters");
	// }
	// if (dto.getChaluMahinyatPraptaJhaleleUtpanna() != null
	// && !dto.getChaluMahinyatPraptaJhaleleUtpanna().matches(regex1)) {
	// addError.accept("Chalu Mahinyat Prapta Jhalele Utpanna contains invalid
	// characters.");
	// }
	// if (dto.getFiftyTakkeKharchaKarychiRakkam() != null
	// && !dto.getFiftyTakkeKharchaKarychiRakkam().matches(regex1)) {
	// addError.accept("Fifty Takke Kharcha Karychi Rakkam contains invalid
	// characters.");
	// }
	// if (dto.getKharchachyaBabiYojanavar() != null &&
	// !dto.getKharchachyaBabiYojanavar().matches(regex1)) {
	// addError.accept("Kharchachya Babi Yojanavar contains invalid characters.");
	// }
	// if (dto.getMagilMahinayatJhalelaKharcha() != null &&
	// !dto.getMagilMahinayatJhalelaKharcha().matches(regex1)) {
	// addError.accept("Magil Mahinayat Jhalela Kharcha contains invalid
	// characters.");
	// }
	// if (dto.getChaluMahinyatJhalelaKharcha() != null &&
	// !dto.getChaluMahinyatJhalelaKharcha().matches(regex1)) {
	// addError.accept("Chalu Mahinyat Jhalela Kharcha contains invalid
	// characters");
	// }
	// if (dto.getEkunKharch() != null && !dto.getEkunKharch().matches(regex1)) {
	// addError.accept("Ekun Kharch contains invalid characters.");
	// }
	// if (dto.getKharchachiTakkevari() != null &&
	// !dto.getKharchachiTakkevari().matches(regex1)) {
	// addError.accept("Kharchachi Takkevari contains invalid characters.");
	// }
	// if (dto.getYear() != null && !dto.getYear().matches(regex1)) {
	// addError.accept("Varsh contains invalid characters.");
	// }
	// if (dto.getMonth() != null && !dto.getMonth().matches(regex1)) {
	// addError.accept("Mahina contains invalid characters");
	// }
	// return errorMessages;
	// }
}
