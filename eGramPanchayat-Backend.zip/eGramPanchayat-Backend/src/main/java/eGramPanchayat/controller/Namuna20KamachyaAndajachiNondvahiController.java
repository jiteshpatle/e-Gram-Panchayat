package eGramPanchayat.controller;


import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import eGramPanchayat.dto.ErrorMessage;
import eGramPanchayat.dto.Namuna20KamachaAndajachiNondvahiDto;
import eGramPanchayat.service.Namuna20KamachyaAndajachiNondvahiService;
// import eGramPanchayat.service.impl.TransactionLogService;
import eGramPanchayat.util.ResponseWrapper;
import jakarta.validation.Valid;                                                    

@RestController
@RequestMapping("/Namuna20KamachyaAndajachiNondvahi")
public class Namuna20KamachyaAndajachiNondvahiController {

    @Autowired
    private Namuna20KamachyaAndajachiNondvahiService service;

    // @Autowired
    // private TransactionLogService transactionLogService;

    // Get the current authenticated user
//    private String getCurrentUser() {
////        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//        if (authentication != null && authentication.isAuthenticated()) {
//            return authentication.getName();  // Assuming the username is used as the identifier
//        }
//        return "anonymous";  // Return a default value if not authenticated
//    }

    // Save details with validation
    @PostMapping("/save")
    public ResponseEntity<?> saveDetails(
        @Valid @RequestBody Namuna20KamachaAndajachiNondvahiDto details,
        BindingResult bindingResult) {

//        String currentUser = getCurrentUser();  // Get the current user

        // Handle Spring's built-in validation errors
        if (bindingResult.hasErrors()) {
            List<ErrorMessage> validationErrors = bindingResult.getFieldErrors().stream()
                .map(fieldError -> new ErrorMessage(fieldError.getField() + ": " + fieldError.getDefaultMessage()))
                .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ResponseWrapper<>("01", "Validation Failed", null, validationErrors));
        }

        // Perform custom validation
//        List<String> customValidationErrors = validateInput(details);
//        if (!customValidationErrors.isEmpty()) {
//            List<ErrorMessage> validationErrors = customValidationErrors.stream()
//                .map(ErrorMessage::new)  // Wrapping each error in ErrorMessage DTO
//                .collect(Collectors.toList());
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                .body(new ResponseWrapper<>("01", "Validation Failed", null, validationErrors));
//        }

        // If all validations pass, proceed to save
        try {
            service.create(details);
//            transactionLogService.saveLog("SAVE", null, "Data Saved Successfully", currentUser);
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Saved Successfully!", null, ""));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ResponseWrapper<>("01", "Validation Failed", null, e.getMessage()));
        } catch (DataIntegrityViolationException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(new ResponseWrapper<>("01", "Something Went Wrong", null, e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "An Error Occurred", null, e.getMessage()));
        }
    }
    @PostMapping("/update/{id}")
    public ResponseEntity<?> updateDetails(
        @PathVariable Long id,
        @Valid @RequestBody Namuna20KamachaAndajachiNondvahiDto details,
        BindingResult bindingResult) {

//        String currentUser = getCurrentUser();  // Get the current user

        // Handle Spring's built-in validation errors
        if (bindingResult.hasErrors()) {
            List<ErrorMessage> validationErrors = bindingResult.getFieldErrors().stream()
                .map(fieldError -> new ErrorMessage(fieldError.getField() + ": " + fieldError.getDefaultMessage()))
                .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ResponseWrapper<>("01", "Validation Failed", null, validationErrors));
        }
//
//        try {
//            // Perform custom input validation
////            List<String> customValidationErrors = validateInput(details);
////            if (!customValidationErrors.isEmpty()) {
//                // Wrap the custom validation errors in ErrorMessage format
//                List<ErrorMessage> errorMessages = customValidationErrors.stream()
//                    .map(error -> new ErrorMessage(error))
//                    .collect(Collectors.toList());
//                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                    .body(new ResponseWrapper<>("01", "Validation Failed", null, errorMessages));
//            }

            // Attempt to update the entity
            Optional<Namuna20KamachaAndajachiNondvahiDto> updatedEntity = service.update(id, details);
            if (updatedEntity.isPresent()) {
//                transactionLogService.saveLog("UPDATE", id, "Data Updated Successfully", currentUser);
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Updated Successfully!", null, ""));
            } else {
//                transactionLogService.saveLog("UPDATE", id, "Data Not Found", currentUser);
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseWrapper<>("01", "Data Not Found", null, "Data Not Found"));
            }
//        } catch (IllegalArgumentException e) {
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                .body(new ResponseWrapper<>("01", "Validation Failed", null, e.getMessage()));
//        } catch (Exception e) {
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                .body(new ResponseWrapper<>("01", "Error Updating Data", null, e.getMessage()));
//        }
    }


    // Get all records
    @PostMapping("/getall")
    public ResponseEntity<?> getAllDetails() {
//        String currentUser = getCurrentUser();  // Get the current user

        try {
            List<Namuna20KamachaAndajachiNondvahiDto> list = service.getAll();
//            transactionLogService.saveLog("GET_ALL", null, "All Data Retrieved Successfully", currentUser);
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", list, ""));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "An Error Occurred", null, e.getMessage()));
        }
    }

    // Get by ID
    @PostMapping("/get_by_id/{id}")
    public ResponseEntity<?> getDetailsById(@PathVariable Long id) {
//        String currentUser = getCurrentUser();  // Get the current user

        try {
            Optional<Namuna20KamachaAndajachiNondvahiDto> details = service.getById(id);
            if (details.isPresent()) {
//                transactionLogService.saveLog("GET_BY_ID", id, "Data Retrieved Successfully", currentUser);
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", details.get(), ""));
            } else {
//                transactionLogService.saveLog("GET_BY_ID", id, "Data Not Found", currentUser);
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseWrapper<>("01", "Data Not Found", null, "Data Not Found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, e.getMessage()));
        }
    }

    // Delete data by ID
    @PostMapping("/delete_by_id/{id}")
    public ResponseEntity<?> deleteDetails(@PathVariable Long id) {
//        String currentUser = getCurrentUser();  // Get the current user

        try {
            boolean deleted = service.delete(id);
            if (deleted) {
//                transactionLogService.saveLog("DELETE", id, "Data Deleted Successfully", currentUser);
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Deleted Successfully!", null, ""));
            } else {
//                transactionLogService.saveLog("DELETE", id, "Data Not Found for Deletion", currentUser);
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseWrapper<>("01", "Data Not Found", null, "Data Not Found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseWrapper<>("01", "Error Deleting Data", null, e.getMessage()));
        }
    }

//    // Custom validation logic
//    private List<String> validateInput(Namuna20KamachaAndajachiNondvahiDto dto) {
//        List<String> errors = new ArrayList<>();
//        String regex = "^[a-zA-Z0-9 ]+$";
//
//        // Add your custom validation logic here
//        if (!dto.getEmployeeName().matches(regex)) {
//            errors.add("Employee Name contains invalid characters.");
//        }
//        if (!dto.getGrampanchayatName().matches(regex)) {
//            errors.add("Grampanchayat Name contains invalid characters.");
//        }
//        
//        if (!dto.getKramank().matches(regex)) {
//            errors.add("Kramank contains invalid characters.");
//        }
//        if (!dto.getNidhicheShirsh().matches(regex)) {
//            errors.add("NidhicheShirsh contains invalid characters.");
//        }
//        
//        if (!dto.getUpaShirsh().matches(regex)) {
//            errors.add("UpaShirsh contains invalid characters.");
//        }
//        
//        if (!dto.getMadheHonyachyaSambhavKharchach().matches(regex)) {
//            errors.add("MadheHonyachyaSambhavKharchach contains invalid characters.");
//        }
//        
//        if (!dto.getYanniKelelaAndaj().matches(regex)) {
//            errors.add("YanniKelelaAndaj contains invalid characters.");
//        }
//        
//        if (!dto.getSarvasadharanGoshwaraParinam().matches(regex)) {
//            errors.add("SarvasadharanGoshwaraParinam  contains invalid characters.");
//        }
//        
//        if (!dto.getSarvasadharanGoshwaraBaab().matches(regex)) {
//            errors.add("SarvasadharanGoshwaraBaab contains invalid characters.");
//        }
//        
//        if (!dto.getSarvasadharanGoshwaraDarRupaye().matches(regex)) {
//            errors.add("SarvasadharanGoshwaraDarRupaye contains invalid characters.");
//        }
//        if (!dto.getSarvasadharanGoshwaraPratteki().matches(regex)) {
//            errors.add("SarvasadharanGoshwaraPratteki contains invalid characters.");
//        }
//        if (!dto.getSarvasadharanGoshwaraRakkamDashanshat().matches(regex)) {
//            errors.add("SarvasadharanGoshwaraRakkamDashanshat contains invalid characters.");
//        }
//        if (!dto.getMojmapAndajpatraKramank().matches(regex)) {
//            errors.add("MojmapAndajpatraKramank contains invalid characters.");
//        }
//        if (!dto.getMojmapAndajpatraLaambi().matches(regex)) {
//            errors.add("MojmapAndajpatraLaambi contains invalid characters.");
//        }
//        // Add further validation checks for other fields...
//        if (!dto.getMojmapAndajpatraRundi().matches(regex)) {
//            errors.add("MojmapAndajpatraRundi contains invalid characters.");
//        }
//        if (!dto.getMojmapAndajpatraKholi().matches(regex)) {
//            errors.add("MojmapAndajpatraKholi contains invalid characters.");
//        }
//        if (!dto.getMojmapAndajpatraParimanDashanshat().matches(regex)) {
//            errors.add("MojmapAndajpatraParimanDashanshat contains invalid characters.");
//        }
//        if (!dto.getEkun().matches(regex)) {
//            errors.add("Ekun contains invalid characters.");
//        }
//        return errors;
//    }
}
