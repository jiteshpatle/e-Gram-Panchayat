package eGramPanchayat.controller;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import eGramPanchayat.service.impl.TransactionLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import eGramPanchayat.dto.LekhaparikshanAaksheepanNamuna27DTO;
import eGramPanchayat.dto.Namuna32RakkamPartavyaSathiChaAdeshDTO;
import eGramPanchayat.service.LekhaparikshanAaksheepanNamuna27Service;
import eGramPanchayat.util.ResponseWrapper;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/LekhaparikshanAaksheepanNamuna27")
@CrossOrigin(origins = "http://localhost:3000") // Replace with your frontend URL
public class LekhaparikshanAaksheepanNamuna27Controller {

        @Autowired
        private TransactionLogService transactionLogService;
        @Autowired
        private LekhaparikshanAaksheepanNamuna27Service lekhaparikshanAaksheepanService;

        @PostMapping("/add")
        public ResponseEntity<Map<String, Object>> saveDetails(
                        @Valid @RequestBody LekhaparikshanAaksheepanNamuna27DTO dto,
                        BindingResult bindingResult) {

                // Handle validation errors
                if (bindingResult.hasErrors()) {
                        List<ErrorMessage> errors = bindingResult.getFieldErrors().stream()
                                        .map(fieldError -> new ErrorMessage(fieldError.getDefaultMessage()))
                                        .collect(Collectors.toList());

                        // // Log the validation failure
                        // transactionLogService.logTransaction(
                        // "CREATE-FAILED",

                        // "Validation failed for entity: LekhaparikshanAaksheepanNamuna27DTO",
                        // null, null, null, null,
                        // null);

                        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                                        .body(createResponse("01", "Validation Failed", null, errors));
                }

                try {
                        // Call the service to save the record
                        LekhaparikshanAaksheepanNamuna27DTO created = lekhaparikshanAaksheepanService.save(dto);

                        // Log the successful creation
                        transactionLogService.logTransaction(
                                        "SAVE",

                                        "Successfully created record for Namuna27 ",
                                        null, created.getEmployeeId(), created.getEmployeeName(),
                                        created.getGrampanchyatId(), created.getGrampanchyatName());

                        return ResponseEntity.status(HttpStatus.CREATED)
                                        .body(createResponse("00", "Data Saved Successfully", null, ""));
                } catch (IllegalArgumentException e) {
                        // // Handle custom validation errors
                        // // Log the custom validation failure
                        // transactionLogService.logTransaction(
                        // "CREATE-FAILED",

                        // "Validation failed: " + e.getMessage(),
                        // null, null, null, null,
                        // null);

                        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                                        .body(createResponse("01", "Validation Failed", null,
                                                        Collections.singletonList(new ErrorMessage(e.getMessage()))));
                } catch (Exception e) {
                        // // Handle any other generic errors
                        // // Log the generic error
                        // transactionLogService.logTransaction(
                        // "CREATE-ERROR",

                        // "Error occurred during creation: " + e.getMessage(),
                        // null, null, null, null, null);

                        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                        .body(createResponse("01", "An Error Occurred: ", null, e.getMessage()));
                }
        }

        // Helper method to create a response
        private Map<String, Object> createResponse(String code, String message, Object data, Object errorsmessage) {
                Map<String, Object> response = new LinkedHashMap<>();
                response.put("code", code);
                response.put("message", message);

                if (data != null) {
                        response.put("data", data);
                }

                response.put("errorsmessage", errorsmessage != null ? errorsmessage : "");
                return response;
        }

        // Get all records
        @PostMapping("/getAll")
        public ResponseEntity<?> getAllDetails() {
                try {
                        List<LekhaparikshanAaksheepanNamuna27DTO> detailsList = lekhaparikshanAaksheepanService
                                        .getAll();
                        return ResponseEntity
                                        .ok(new ResponseWrapper<>("00", "Data Retrieve Successfully", detailsList, ""));
                } catch (Exception e) {
                        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                        .body(new ResponseWrapper<>("01", null, "Error Retrieving Data",
                                                        Collections.singletonList(e.getMessage())));
                }
        }

        @PostMapping("/getById/{id}")
        public ResponseEntity<?> getDetailsById(@PathVariable Long id) {
                if (id == null) {
                        return ResponseEntity.badRequest()
                                        .body(new ResponseWrapper<>("01", "ID must not be null", null,
                                                        "ID must not be null"));
                }

                try {
                        Optional<LekhaparikshanAaksheepanNamuna27DTO> detailsOpt = lekhaparikshanAaksheepanService
                                        .findById(id);

                        if (detailsOpt.isPresent()) {
                                return ResponseEntity
                                                .ok(new ResponseWrapper<>("00", "Data Retrieved Successfully",
                                                                detailsOpt.get(), ""));
                        } else {
                                // Return 404 status with "Data Not Found" message
                                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                                                .body(new ResponseWrapper<>("01", "Error Retrieving Data", null,
                                                                "Data Not Found"));
                        }
                } catch (Exception e) {
                        System.err.println("Error retrieving data for ID: " + id + " - " + e.getMessage());
                        // Return 500 status for any server error
                        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                        .body(new ResponseWrapper<>("01", "Error Retrieving Data", null,
                                                        "An internal server error occurred"));
                }
        }

        @PostMapping("/update/{id}")
        public ResponseEntity<Map<String, Object>> updateDetails(
                        @PathVariable Long id,
                        @Valid @RequestBody LekhaparikshanAaksheepanNamuna27DTO dto,
                        BindingResult bindingResult) {

                Map<String, Object> response = new LinkedHashMap<>();

                // Check if the entity exists
                if (!lekhaparikshanAaksheepanService.existsById(id)) {
                        response.put("code", "01");
                        response.put("message", "Error Retrieving Data");
                        response.put("errormessage", "Data Not Found");

                        // // Log the error for entity not found
                        // transactionLogService.logTransaction(
                        // "UPDATE-FAILED",

                        // "Entity not found for ID: " + id,
                        // null, null, null, null, null);

                        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
                }

                // Handle validation errors
                if (bindingResult.hasErrors()) {
                        List<ErrorMessage> errors = bindingResult.getFieldErrors().stream()
                                        .map(fieldError -> new ErrorMessage(fieldError.getDefaultMessage()))
                                        .collect(Collectors.toList());

                        // // Log the validation failure
                        // transactionLogService.logTransaction(
                        // "UPDATE-FAILED",

                        // "Validation failed for entity ID: " + id,
                        // null, null, null, null, null);

                        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                                        .body(createResponse("01", "Validation Failed", null, errors));
                }

                try {
                        // Call the service to update the entity
                        LekhaparikshanAaksheepanNamuna27DTO updated = lekhaparikshanAaksheepanService.updatee(id, dto);

                        // Log the successful update
                        transactionLogService.logTransaction(
                                        "UPDATE",

                                        "Successfully updated data for Namuna27 with ID: " + id,
                                        null, updated.getEmployeeId(), updated.getEmployeeName(),
                                        updated.getGrampanchyatId(), updated.getGrampanchyatName());

                        response.put("code", "00");
                        response.put("message", "Data Updated Successfully");
                        response.put("errormessage", "");
                        return ResponseEntity.ok(response);
                } catch (Exception e) {
                        response.put("code", "01");
                        response.put("message", "Error While Updating Data");
                        response.put("errormessage", e.getMessage());

                        // // Log the exception during the update
                        // transactionLogService.logTransaction(
                        // "UPDATE-ERROR",

                        // "Error occurred during update for ID: ",
                        // null, null, null, null,
                        // null);

                        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
                }
        }

        // Delete record by ID
        // Delete record by ID
        @PostMapping("/delete/{id}")
        public ResponseEntity<?> delete(@PathVariable long id,
                        @RequestBody LekhaparikshanAaksheepanNamuna27DTO deleteRequest) {
                Map<String, Object> response = new LinkedHashMap<>();
                try {
                        // Find the record by ID

                        if (deleteRequest.getEmployeeId() == null ||
                                        deleteRequest.getEmployeeName() == null ||
                                        deleteRequest.getGrampanchyatId() == null ||
                                        deleteRequest.getGrampanchyatName() == null) {

                                // // Log the not-found case with null values
                                // transactionLogService.logTransaction(
                                // "DELETE",
                                // "Deletion failed. Data not found for ID " + id,
                                // null, employeeId, employeeName, gramPanchayatId, gramPanchayatName);

                                // Prepare a not-found response
                                response.put("code", "01");
                                response.put("message", "Error Deleting Data");
                                response.put("errormessage", "Data Not Found");
                                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
                        }

                        // Proceed with deletion
                        boolean isDeleted = lekhaparikshanAaksheepanService.deleteById(id);
                        if (isDeleted) {
                                // Log the deletion action with field values (or null if they are missing)
                                transactionLogService.logTransaction(
                                                "DELETE",
                                                "Data deleted successfully for Namuna32 with ID " + id,
                                                null, deleteRequest.getEmployeeId(),
                                                deleteRequest.getEmployeeName(),
                                                deleteRequest.getGrampanchyatId(),
                                                deleteRequest.getGrampanchyatName());

                                // Prepare a successful response
                                response.put("code", "00");
                                response.put("message", "Data Deleted Successfully");
                                response.put("errormessage", "");
                                return ResponseEntity.ok(response);
                        } else {
                                // // Log the deletion failure with field values (or null if they are missing)
                                // transactionLogService.logTransaction(
                                // "DELETE",
                                // "Deletion operation failed for Namuna32 with ID " + id,
                                // null, employeeId, employeeName, gramPanchayatId, gramPanchayatName);

                                response.put("code", "01");
                                response.put("message", "Error Deleting Data");
                                response.put("errormessage", "Deletion operation failed");
                                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
                        }
                } catch (Exception e) {
                        // // Log the exception with null values for fields
                        // transactionLogService.logTransaction(
                        // "DELETE",
                        // "Error occurred while deleting data for ID " + id,
                        // null, null, null, null, null);

                        // Prepare an error response
                        response.put("code", "01");
                        response.put("message", "Error Deleting Data");
                        response.put("errormessage", e.getMessage());
                        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
                }
        }

        // public ResponseEntity<ResponseWrapper<Void>> deleteDetails(@PathVariable Long
        // id) {
        // try {
        // // Log the attempt to delete
        // transactionLogService.logTransaction(
        // "DELETE",

        // "Successfully deleted Namuna33 data for ID: "+ id,
        // null, null, null, null, null);

        // // Attempt to delete the record
        // lekhaparikshanAaksheepanService.deleteById(id);

        // // Log the successful deletion
        // transactionLogService.logTransaction(
        // "DELETE",

        // "Data deleted successfully for Namuna32 with ID "+ id,
        // null, null, null, null, null);

        // return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Deleted
        // Successfully", null, "")); // Message on
        // // success

        // } catch (EntityNotFoundException e) {
        // // // Log the error when data is not found
        // // transactionLogService.logTransaction(
        // // "DELETE-FAILED",

        // // "Data not found for deletion with ID: " + id,
        // // null, null, null, null,null);

        // return ResponseEntity.status(HttpStatus.NOT_FOUND)
        // .body(new ResponseWrapper<>("01", "Error Deleting data", null, "Data Not
        // Found"));
        // } catch (Exception e) {
        // // // Log the error when there's an exception during deletion
        // // transactionLogService.logTransaction(
        // // "DELETE-ERROR",

        // // "Error occurred during deletion for ID: " + id,
        // // null, null, null, null,null);

        // return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
        // .body(new ResponseWrapper<>("01", null, null,
        // List.of("Error While Deleting data: " + e.getMessage())));
        // }
        // }

        // Custom error message class
        static class ErrorMessage {
                private String description;

                public ErrorMessage(String description) {
                        this.description = description;
                }

                // Getter
                public String getDescription() {
                        return description;
                }
        }
}
