package eGramPanchayat.controller;

import eGramPanchayat.service.impl.TransactionLogService;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;
import eGramPanchayat.dto.GrampanchayatNamuna26KhaaDto;
import eGramPanchayat.dto.Namuna32RakkamPartavyaSathiChaAdeshDTO;
import eGramPanchayat.service.GrampanchayatNamuna26KhaaService;
import eGramPanchayat.util.ResponseWrapper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/grampanchayatKhaa26")
@CrossOrigin(origins = "http://localhost:3000")
public class GrampanchayatNamuna26KhaaController {

    @Autowired
    private GrampanchayatNamuna26KhaaService service;

    @Autowired
    private TransactionLogService transactionLogService;


    @PostMapping("/add")
    public ResponseEntity<ResponseWrapper<?>> createGrampanchayatNamuna26Khaa(
            @Valid @RequestBody GrampanchayatNamuna26KhaaDto dto,
            BindingResult bindingResult) {

        // // Log the incoming request
        // transactionLogService.logTransaction(
        //         "CREATE",

        //         "Data saved successfully for Namuna26",
        //         null, null, null, null, null);

        // Check for validation errors
        if (bindingResult.hasErrors()) {
            List<Map<String, String>> errorMessages = new ArrayList<>();

            for (FieldError fieldError : bindingResult.getFieldErrors()) {
                Map<String, String> errorMap = new HashMap<>();
                String formattedMessage = fieldError.getDefaultMessage(); // Format with numbering
                errorMap.put(fieldError.getField(), formattedMessage);
                errorMessages.add(errorMap);
            }

            // // Log the validation errors
            // transactionLogService.logTransaction(
            //         "CREATE-FAILED",

            //         "Validation errors occurred while creating GrampanchayatNamuna26Khaa",
            //         null, null, null, null, null);

            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseWrapper<>("01", "Validation Failed", null, errorMessages));
        }

        try {
            // Call to custom validation if needed (e.g., some business logic validation)
            // validateFields(dto);

            // Log the success of saving the data
            GrampanchayatNamuna26KhaaDto created = service.save(dto);
            transactionLogService.logTransaction(
                    "SAVE",
                    "Data saved successfully for Namuna26Kha",
                    null,
                    created.getEmployeeId(),
                    created.getEmployeeName(),
                    created.getGrampanchyatId(),
                    created.getGrampanchyatName());

            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(new ResponseWrapper<>("00", "Data Saved Successfully", null, ""));
        } catch (IllegalArgumentException e) {
            // // Log the custom validation error
            // transactionLogService.logTransaction(
            //         "CREATE-FAILED",
                    
            //         "Custom validation error during creation", null, null, null, null,
            //                 null
            //         );

            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseWrapper<>("01", "Custom validation error", null,
                            Collections.singletonList(e.getMessage())));
        } catch (Exception e) {
            // // Log the general error
            // transactionLogService.logTransaction(
            //         "CREATE-ERROR",
            //         null,
            //         "Error occurred during creation of GrampanchayatNamuna26Khaa",
            //         null, null, null, null);

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "An Error Occurred", null,
                            Collections.singletonList(e.getMessage())));
        }
    }

    // Get all records
    @PostMapping("/getAll")
    public ResponseEntity<?> getAllGrampanchayatNamuna26KhaNew() {
        try {
            List<GrampanchayatNamuna26KhaaDto> kmlist = service.findAll();
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieve Successfully", kmlist, ""));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "Error Retrieving Data", null,
                            Collections.singletonList(e.getMessage())));
        }
    }

    @PostMapping("/getById/{id}")
    public ResponseEntity<ResponseWrapper<GrampanchayatNamuna26KhaaDto>> getGrampanchayatNamuna26KhaaById(
            @PathVariable Long id) {
        try {
            // Fetch the record by ID
            Optional<GrampanchayatNamuna26KhaaDto> record = service.findById(id);

            if (record.isPresent()) {
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", record.get(), ""));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, "Data not found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", null, null, "Error Retrieving Data"));
        }
    }

    @PostMapping("/update/{id}")
    public ResponseEntity<ResponseWrapper<GrampanchayatNamuna26KhaaDto>> updateGrampanchayatNamuna26Khaa(
            @PathVariable Long id,
            @Valid @RequestBody GrampanchayatNamuna26KhaaDto dto,
            BindingResult bindingResult) {

       
        // Check for validation errors
        if (bindingResult.hasErrors()) {
            List<Map<String, String>> errorMessages = new ArrayList<>();
            int errorCount = 1; // Counter for numbering error messages

            for (FieldError fieldError : bindingResult.getFieldErrors()) {
                Map<String, String> errorMap = new HashMap<>();
                String formattedMessage = errorCount + ". " + fieldError.getDefaultMessage(); // Format with numbering
                errorMap.put(fieldError.getField(), formattedMessage);
                errorMessages.add(errorMap);
                errorCount++; // Increment the counter
            }

            // // Log the validation errors
            // transactionLogService.logTransaction(
            //         "UPDATE-FAILED",
                    
            //         "Validation errors occurred while updating GrampanchayatNamuna26Khaa with ID: " + id,
            //         null, null, null,
            //         null,null);

            return ResponseEntity.badRequest()
                    .body(new ResponseWrapper<>("01", "Validation Failed", null, errorMessages));
        }

        try {
            // Call the service to update the entity
            GrampanchayatNamuna26KhaaDto updated = service.update(id, dto);

            // Log the successful update
            transactionLogService.logTransaction(
                    "UPDATE",
                    "Data updated successfully for Namuna26Kha with ID " + id,
                    null, updated.getEmployeeId(), updated.getEmployeeName(), updated.getGrampanchyatId(),
                    updated.getGrampanchyatName());

            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Updated Successfully", null, ""));
        } catch (EntityNotFoundException e) {
            // // Log the EntityNotFoundException
            // transactionLogService.logTransaction(
            //         "UPDATE-FAILED",
                   
            //         "Data not found for update with ID: " + id,
            //         null, null, null,
            //         null,null);

            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseWrapper<>("01", "Error Updating Data", null, "Data not found")); // Using
                                                                                                       // errormessage
        } catch (Exception e) {
            // // Log the general exception
            // transactionLogService.logTransaction(
            //         "UPDATE-ERROR",
                    
            //         "Error occurred during update of GrampanchayatNamuna26Khaa with ID: " + id,
            //         null, null, null,
            //         null,null);

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "Error Updating Data", null, "Error: " + e.getMessage()));
        }
    }

    // Delete record by ID
    @PostMapping("/delete/{id}")
    public ResponseEntity<?> delete(@PathVariable long id,
			@RequestBody GrampanchayatNamuna26KhaaDto deleteRequest) {
		Map<String, Object> response = new LinkedHashMap<>();
		try {
			// Find the record by ID

			if (deleteRequest.getEmployeeId() == null ||
					deleteRequest.getEmployeeName() == null ||
					deleteRequest.getGrampanchyatId() == null ||
					deleteRequest.getGrampanchyatName() == null) {

				// // Log the not-found case with null values
				// transactionLogService.logTransaction(
				// "DELETE",
				// "Deletion failed. Data not found for ID " + id,
				// null, employeeId, employeeName, gramPanchayatId, gramPanchayatName);

				// Prepare a not-found response
				response.put("code", "01");
				response.put("message", "Error Deleting Data");
				response.put("errormessage", "Data Not Found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}

			// Proceed with deletion
			boolean isDeleted = service.deleteById(id);
			if (isDeleted) {
				// Log the deletion action with field values (or null if they are missing)
				transactionLogService.logTransaction(
						"DELETE",
						"Data deleted successfully for Namuna26Kha with ID " + id,
						null, deleteRequest.getEmployeeId(),
						deleteRequest.getEmployeeName(),
						deleteRequest.getGrampanchyatId(),
						deleteRequest.getGrampanchyatName());

				// Prepare a successful response
				response.put("code", "00");
				response.put("message", "Data Deleted Successfully");
				response.put("errormessage", "");
				return ResponseEntity.ok(response);
			} else {
				// // Log the deletion failure with field values (or null if they are missing)
				// transactionLogService.logTransaction(
				// "DELETE",
				// "Deletion operation failed for Namuna32 with ID " + id,
				// null, employeeId, employeeName, gramPanchayatId, gramPanchayatName);

				response.put("code", "01");
				response.put("message", "Error Deleting Data");
				response.put("errormessage", "Deletion operation failed");
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
			}
		} catch (Exception e) {
			// // Log the exception with null values for fields
			// transactionLogService.logTransaction(
			// "DELETE",
			// "Error occurred while deleting data for ID " + id,
			// null, null, null, null, null);

			// Prepare an error response
			response.put("code", "01");
			response.put("message", "Error Deleting Data");
			response.put("errormessage", e.getMessage());
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
	}

    public void validateFields(GrampanchayatNamuna26KhaaDto dto) {
        // String regex = "^[u0900-u097 . ]*$"; // Adjust the regex pattern as necessary
        String regex1 = "^[\\u0900-\\u097F0-9 .]*$";

        // if (!dto.getMahina().matches(regex1)) {
        // throw new IllegalArgumentException("Mahina contains invalid characters.");
        // }

        if (!dto.getPraarabhitShillak().matches(regex1)) {
            throw new IllegalArgumentException("Praarabhit Shillak contains invalid characters.");
        }

        if (!dto.getRakamJamaKileyachaMahina().matches(regex1)) {
            throw new IllegalArgumentException("Rakam Jama Kileyacha Mahina contains invalid characters.");
        }

        // if(dto.getMahinaAakhrichiShillakSachivakdila().matches(regex))
        // if (!dto.get().matches(regex)) {
        // throw new IllegalArgumentException("Cash contains invalid characters.");
        //// }

        if (!dto.getMahinaAakhrichiShillakBanketila().matches(regex1)) {
            throw new IllegalArgumentException("Mahina Aakhrichi Shillak Banketila contains invalid characters.");
        }

        // if (!dto.getMahinaAakhrichiShillakPostateil().matches(regex1)) {
        // throw new IllegalArgumentException("Mahina Aakhrichi Shillak Postateil
        // contains invalid characters.");
        // }

        if (!dto.getAlpabachatPramanapatrataGuntviloliRakam().matches(regex1)) {
            throw new IllegalArgumentException(
                    "Alpabachat Pramanapatrata Guntviloli Rakam contains invalid characters.");
        }

        if (!dto.getBanketaMudataThevitaGuntavililiRakam().matches(regex1)) {
            throw new IllegalArgumentException("Banketa Mudata Thevita Guntavilili Rakam contains invalid characters.");
        }

        if (!dto.getEkun().matches(regex1)) {
            throw new IllegalArgumentException("Ekun contains invalid characters.");
        }

        /*
         * if (!dto.getShoraNiyamapeshaJasataRakam().matches(regex)) {
         * throw new
         * IllegalArgumentException("Shora Niyamapesha Jasata Rakam contains invalid characters."
         * );
         * }
         */

        // if (dto.getEmployeeId() == null) {
        // throw new IllegalArgumentException("Employee ID cannot be null.");
        // }

        // if (dto.getCreateDate() == null) {
        // throw new IllegalArgumentException("Create Date cannot be null.");
        // }
        //
        // if (dto.getUpdatedDate() == null) {
        // throw new IllegalArgumentException("Updated Date cannot be null.");
        // }

        // if (dto.getGrampanchyatId() == null) {
        // throw new IllegalArgumentException("Grampanchyat ID cannot be null.");
        // }

        // if (!dto.getEmployeeName().matches(regex)) {
        // throw new IllegalArgumentException("Employee Name contains invalid
        // characters.");
        // }

        // if (!dto.getGrampanchyatName().matches(regex)) {
        // throw new IllegalArgumentException("Grampanchyat Name contains invalid
        // characters.");
        // }

        // if (!dto.get().matches("^[0-9]+$")) {
        // throw new IllegalArgumentException("Year must contain only digits.");
        // }
    }

}
