package eGramPanchayat.controller;


import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import eGramPanchayat.dto.ErrorMessage;
import eGramPanchayat.dto.Namuna18KirkolRokadVahiDto;
import eGramPanchayat.entity.Namuna18KirkolRokadVahi;
import eGramPanchayat.service.Namuna18KirkolRokadVahiService;

import eGramPanchayat.util.ResponseWrapper;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/Namuna18KirkolRokadVahi")
@CrossOrigin(origins = "http://localhost:3000")

public class Namuna18KirkolRokadVahiController {

    @Autowired
    private Namuna18KirkolRokadVahiService kirkolRokadVahiService;
//
//    @Autowired
//    private TransactionLogService transactionLogService;
////
//    // Get the current authenticated user
//    private String getCurrentUser() {
//        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//        return (authentication != null && authentication.isAuthenticated()) ? authentication.getName() : "anonymous";
//    }

    // Save details with validation
    @PostMapping("/save")
    public ResponseEntity<?> saveDetails(
            @Valid @RequestBody Namuna18KirkolRokadVahiDto kirkolRokadVahiDto,
            BindingResult bindingResult) {

//        String currentUser = getCurrentUser();  // Get the current user

        // Handle validation errors
        if (bindingResult.hasErrors()) {
            List<ErrorMessage> validationErrors = bindingResult.getFieldErrors().stream()
                .map(fieldError -> new ErrorMessage(fieldError.getField() + ": " + fieldError.getDefaultMessage()))
                .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseWrapper<>("01", "Validation Failed", null, validationErrors));
        }

        // Perform custom validation
//        List<ErrorMessage> customValidationErrors = validateInput(kirkolRokadVahiDto);
//        if (!customValidationErrors.isEmpty()) {
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                    .body(new ResponseWrapper<>("01", "Validation Failed", null, customValidationErrors));
//        }

        // If all validations pass, proceed to save
        try {
            kirkolRokadVahiService.save(kirkolRokadVahiDto);
//            transactionLogService.saveLog("SAVE", null, "Data Saved Successfully", "");
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data saved successfully!", null, ""));
        } catch (DataIntegrityViolationException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(new ResponseWrapper<>("01", "Data Integrity Violation", null, e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "An Error Occurred", null, e.getMessage()));
        }
    }

    // Update details with validation
    @PostMapping("/update/{id}")
    public ResponseEntity<?> update(
            @PathVariable Long id,
            @Valid @RequestBody Namuna18KirkolRokadVahiDto kirkolRokadVahiDto,
            BindingResult bindingResult) {

//        String currentUser = getCurrentUser();  // Get the current user

        // Handle validation errors
        if (bindingResult.hasErrors()) {
            List<ErrorMessage> validationErrors = bindingResult.getFieldErrors().stream()
                    .map(fieldError -> new ErrorMessage(fieldError.getField() + ": " + fieldError.getDefaultMessage()))
                    .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ResponseWrapper<>("01", "Validation Failed", null, validationErrors));
        }

//        // Validate input
//        List<ErrorMessage> customValidationErrors = validateInput(kirkolRokadVahiDto);
//        if (!customValidationErrors.isEmpty()) {
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                    .body(new ResponseWrapper<>("01", "Validation Failed", null, customValidationErrors));
//        }

        try {
            Optional<Namuna18KirkolRokadVahi> updatedEntity = kirkolRokadVahiService.update(id, kirkolRokadVahiDto);
            if (updatedEntity.isPresent()) {
//                transactionLogService.saveLog("UPDATE", id, "Data Updated Successfully", "");
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Updated Successfully!", null, ""));
            } else {
//                transactionLogService.saveLog("UPDATE", id, "Data Not Found", "");
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new ResponseWrapper<>("01", "Data Not Found", null, "Data Not Found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "Error Updating Data", null, e.getMessage()));
        }
    }

    // Get record by ID
    @PostMapping("/get_by_id/{id}")
    public ResponseEntity<?> findById(@PathVariable Long id) {
//        String currentUser = getCurrentUser();  // Get the current user

        try {
            Optional<Namuna18KirkolRokadVahi> entity = kirkolRokadVahiService.findById(id);
            if (entity.isPresent()) {
//                transactionLogService.saveLog("GET_BY_ID", id, "Data Retrieved Successfully", "");
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", entity.get(), ""));
            } else {
//                transactionLogService.saveLog("GET_BY_ID", id, "Data Not Found", "");
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new ResponseWrapper<>("01", "Data Not Found", null, "Data Not Found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, e.getMessage()));
        }
    }

    // Get all records
    @PostMapping("/getall")
    public ResponseEntity<?> findAll() {
//        String currentUser = getCurrentUser();  // Get the current user

        try {
            List<Namuna18KirkolRokadVahi> entities = kirkolRokadVahiService.findAll();
//            transactionLogService.saveLog("GET_ALL", null, "All Data Retrieved Successfully", "");
            return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Retrieved Successfully", entities, ""));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "Error Retrieving Data", null, e.getMessage()));
        }
    }

    // Delete record by ID
    @PostMapping("/delete_by_id/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
//        String currentUser = getCurrentUser();  // Get the current user

        try {
            boolean deleted = kirkolRokadVahiService.delete(id);
            if (deleted) {
//                transactionLogService.saveLog("DELETE", id, "Data Deleted Successfully", "");
                return ResponseEntity.ok(new ResponseWrapper<>("00", "Data Deleted Successfully!", null, ""));
            } else {
//                transactionLogService.saveLog("DELETE", id, "Data Not Found for Deletion", "");
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new ResponseWrapper<>("01", "Data Not Found", null, "Data Not Found"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseWrapper<>("01", "Error Deleting Data", null, e.getMessage()));
        }
    }

//    // Custom validation logic
//    private List<ErrorMessage> validateInput(Namuna18KirkolRokadVahiDto dto) {
//        List<ErrorMessage> errorMessages = new ArrayList<>();
//        String regex = "^[a-zA-Z0-9 ]+$";
//
//        // Add error messages based on the validation checks
//        if (!dto.getEmployeeName().matches(regex)) {
//            errorMessages.add(new ErrorMessage("Employee Name contains invalid characters."));
//        }
//        if (!dto.getGrampanchayatName().matches(regex)) {
//            errorMessages.add(new ErrorMessage("Grampanchayat Name contains invalid characters."));
//        }
//        if (!dto.getRemark().matches(regex)) {
//            errorMessages.add(new ErrorMessage("Remark contains invalid characters."));
//        }
//        if (!dto.getDhanadeshKramank().matches(regex)) {
//            errorMessages.add(new ErrorMessage("Dhanadesh Kramank contains invalid characters."));
//        }
//        if (!dto.getKonakadunPraptZala().matches(regex)) {
//            errorMessages.add(new ErrorMessage("Konakadun Prapt Zala contains invalid characters."));
//        }
//        if (!dto.getJamaTapshil().matches(regex)) {
//            errorMessages.add(new ErrorMessage("Jama Tapshil contains invalid characters."));
//        }
//        return errorMessages;
//    }
}
