package eGramPanchayat.controller;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import eGramPanchayat.dto.Namuna33VrukshNondVihaDTO;
import eGramPanchayat.entity.Namuna33VrukshNondViha;
import eGramPanchayat.repository.Namuna33VrukshNondVihaRepository;
import eGramPanchayat.service.Namuna33VrukshNondVihaService;
import eGramPanchayat.service.impl.Namuna33VrukshNondVihaIMPL;
import eGramPanchayat.service.impl.TransactionLogService;
import eGramPanchayat.util.ResponseWrapper;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/Namuna33VrukshNondViha")
@CrossOrigin("*")
public class Namuna33VrukshNondVihaController {

    @Autowired
    private Namuna33VrukshNondVihaIMPL impl;

    @Autowired
    private Namuna33VrukshNondVihaService service;

    @Autowired
    private Namuna33VrukshNondVihaRepository repo;

    @Autowired
    private TransactionLogService transactionLogService;

    @PostMapping("/save")
    public ResponseEntity<ResponseWrapper<Object>> save(
            @Valid @RequestBody Namuna33VrukshNondVihaDTO dto,
            BindingResult bindingResult,
            @RequestHeader(value = "username", defaultValue = "unknown") String username) {

        List<ErrorMessage> errors = new ArrayList<>();

        // Field-level validation
        if (bindingResult.hasErrors()) {
            errors.addAll(bindingResult.getFieldErrors().stream()
                    .map(fieldError -> new ErrorMessage(fieldError.getDefaultMessage()))
                    .collect(Collectors.toList()));
        }

        // Perform custom validations and collect errors
        try {
            validateDetails(dto, errors); // This may throw an IllegalArgumentException
        } catch (IllegalArgumentException e) {
            errors.add(new ErrorMessage(e.getMessage()));
        }

        // Return validation errors if any
        if (!errors.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(new ResponseWrapper<>("01", "Validation Error", null, errors));
        }

        try {
            // Save the data
            Namuna33VrukshNondViha created = impl.savedata(dto);

            // Log the transaction
            transactionLogService.logTransaction(
                    "SAVE",
                    "Data saved successfully for Namuna33",
                    null,
                    created.getEmployeeid(),
                    created.getEmployeename(),
                    created.getGrampanchayatid(),
                    created.getGrampanchayatname());

            // Return success response
            return ResponseEntity.ok(
                    new ResponseWrapper<>("00", "Data Saved Successfully", null, ""));
        } catch (Exception e) {
            // // Log the error
            // transactionLogService.logTransaction(
            //         "SAVE_FAILED",
            //         "Error saving data",
            //         null,
            //         null,
            //         null,
            //         null,
            //         null);

            // Return error response
            List<ErrorMessage> errorList = List.of(new ErrorMessage("An unexpected error occurred: " + e.getMessage()));
            return ResponseEntity.status(500)
                    .body(new ResponseWrapper<>("01", "Data Not Saved", null, errorList));
        }
    }

    @PostMapping("/getall")
    public ResponseEntity<ResponseWrapper<List<Namuna33VrukshNondViha>>> getAll() {
        List<Namuna33VrukshNondViha> records = impl.getalldetails();

        if (records.isEmpty()) {
            // No records found
            ResponseWrapper<List<Namuna33VrukshNondViha>> response = new ResponseWrapper<>(
                    "01",
                    "No Records Found",
                    null, // No data as there are no records
                    "No Data Available" // Set the error message
            );
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(response);
        } else {
            // Records found
            ResponseWrapper<List<Namuna33VrukshNondViha>> response = new ResponseWrapper<>(
                    "00",
                    "Data Retrieved Successfully",
                    records, // Pass the found records
                    "" // No error message
            );
            return ResponseEntity.ok(response);
        }
    }

    @PostMapping("/get_by_id/{id}")
    public ResponseEntity<ResponseWrapper<Namuna33VrukshNondViha>> getById(@PathVariable Long id) {
        Namuna33VrukshNondViha record = impl.getdetailsbyid(id);

        if (record == null) {
            // Record not found, return error message as list
            List<String> errorMessages = new ArrayList<>();
            errorMessages.add("Data Not Found");

            ResponseWrapper<Namuna33VrukshNondViha> response = new ResponseWrapper<>(
                    "01", // code
                    "Error Retrieving Data", // message
                    null, // no data
                    errorMessages // errorMessage as a list
            );
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        } else {
            // Record found, return success message with empty errorMessage
            ResponseWrapper<Namuna33VrukshNondViha> response = new ResponseWrapper<>(
                    "00", // code
                    "Data Retrieved Successfully", // message
                    record, // data
                    "" // errorMessage is empty for success
            );
            return ResponseEntity.ok(response);
        }
    }

    @PostMapping("/update_by_id/{id}")
    public ResponseEntity<?> update(
            @PathVariable Long id,
            @Valid @RequestBody Namuna33VrukshNondVihaDTO dto,
            BindingResult bindingResult) {

        Map<String, Object> response = new LinkedHashMap<>();
        List<ErrorMessage> errors = new ArrayList<>();

        // Check for binding validation errors
        if (bindingResult.hasErrors()) {
            errors.addAll(bindingResult.getFieldErrors().stream()
                    .map(fieldError -> new ErrorMessage(fieldError.getDefaultMessage()))
                    .collect(Collectors.toList()));
        }

        // Perform custom validations
        try {
            validateDetails(dto, errors);
        } catch (IllegalArgumentException e) {
            errors.add(new ErrorMessage(e.getMessage()));
        }

        // If there are validation errors, log the transaction and return response
        if (!errors.isEmpty()) {
            response.put("code", "01");
            response.put("message", "Validation Error");
            response.put("errormessage", errors);

            // transactionLogService.logTransaction(
            //         "UPDATE",
            //         "Validation failed for Namuna33 with errors.",
            //         null, null, null, null, null);

            return ResponseEntity.badRequest().body(response);
        }

        // Check if entity exists by ID
        if (!repo.existsById(id)) {
            response.put("code", "01");
            response.put("message", "Error Retrieving Data");
            response.put("errormessage", List.of(new ErrorMessage("Data Not Found")));

            // transactionLogService.logTransaction(
            //         "UPDATE",
            //         "Entity not found for ID: " + id,
            //         null, null, null, null, null);

            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }

        // Try to update the data
        try {
            Namuna33VrukshNondViha updatedEntity = service.updatedata(id, dto);

            if (updatedEntity == null) {
                response.put("code", "01");
                response.put("message", "Error Updating Data");
                response.put("errormessage", List.of(new ErrorMessage("Entity not updated for ID: " + id)));

                // transactionLogService.logTransaction(
                //         "UPDATE",
                //         "Failed to update entity for ID: " + id,
                //         null, null, null, null, null);

                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
            }
            
            // Success response
            response.put("code", "00");
            response.put("message", "Data Updated Successfully");
            response.put("errormessage", "");

            transactionLogService.logTransaction(
                    "UPDATE",
                    "Successfully updated data for Namuna33 with ID: " + id,
                    null,
                    updatedEntity.getEmployeeid(),
                    updatedEntity.getEmployeename(),
                    updatedEntity.getGrampanchayatid(),
                    updatedEntity.getGrampanchayatname());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            // Handle any unexpected error during the update process
            response.put("code", "01");
            response.put("message", "Data Not Updated Successfully");
            response.put("errormessage", List.of(new ErrorMessage("An unexpected error occurred: " + e.getMessage())));

            // transactionLogService.logTransaction(
            //         "UPDATE",
            //         "Unexpected error occurred while updating data for Namuna33 with ID: " + id,
            //         null, null, null, null, null);

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

   

    @PostMapping("/delete_by_id/{id}")
    public ResponseEntity<ResponseWrapper<Object>> deleteById(
            @PathVariable Long id,
            @RequestBody Namuna33VrukshNondVihaDTO deleteRequest) {

        // Validate the incoming JSON fields
        if (deleteRequest.getEmployeeid() == null ||
                deleteRequest.getEmployeename() == null ||
                deleteRequest.getGrampanchayatid() == null ||
                deleteRequest.getGrampanchayatname() == null) {

            ResponseWrapper<Object> response = new ResponseWrapper<>(
                    "01", // code
                    "Request data is missing", // message
                    null, // no data field
                    "Required fields are not provided" // error message
            );
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }

        // Check if the entity exists
        Namuna33VrukshNondViha entity = impl.getdetailsbyid(id);
        if (entity == null) {
            // // Log failure to delete (data not found)
            // transactionLogService.logTransaction(
            //         "DELETE",
            //         "Failed to delete Namuna33 data for ID: " + id,
            //         null,
            //         deleteRequest.getEmployeeId(),
            //         deleteRequest.getEmployeeName(),
            //         deleteRequest.getGrampanchayatId(),
            //         deleteRequest.getGrampanchayatName());

            // Return failure response
            ResponseWrapper<Object> response = new ResponseWrapper<>(
                    "01", // code
                    "Error Deleting Data", // message
                    null, // no data field
                    "Data Not Found" // error message
            );
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }

        // Attempt to delete the data
        boolean isDeleted = impl.deletebyid(id);
        if (isDeleted) {
            // Log successful deletion
            transactionLogService.logTransaction(
                    "DELETE",
                    "Successfully deleted Namuna33 data for ID: " + id,
                    null,
                    deleteRequest.getEmployeeid(),
                    deleteRequest.getEmployeename(),
                    deleteRequest.getGrampanchayatid(),
                    deleteRequest.getGrampanchayatname());

            // Return success response
            ResponseWrapper<Object> response = new ResponseWrapper<>(
                    "00", // code
                    "Data Deleted Successfully", // message
                    null, // no data field
                    "" // empty error message for success
            );
            return ResponseEntity.ok(response);
        } else {
            // // Log failure to delete (unexpected error)
            // transactionLogService.logTransaction(
            //         "DELETE",
            //         "Failed to delete Namuna33 data for ID: " + id,
            //         null,
            //         deleteRequest.getEmployeeId(),
            //         deleteRequest.getEmployeeName(),
            //         deleteRequest.getGrampanchayatId(),
            //         deleteRequest.getGrampanchayatName());

            // Return failure response
            ResponseWrapper<Object> response = new ResponseWrapper<>(
                    "01", // code
                    "Error Deleting Data", // message
                    null, // no data field
                    "Data could not be deleted" // error message
            );
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }  
    
    
    
    
    
    
    
    
    
    
    
    
    // public void validateDetails(Namuna33VrukshNondVihaDTO dto) {
    // String regx = "^[\u0900-\u097F a-zA-Z ]+$";
    // String regx1 = "^[\u0966-\u096F0-9 -]+$";
    //
    // if (!dto.getEmployeename().matches(regx)) {
    // throw new IllegalArgumentException("Employeename contains invalid
    // Characters");
    // }
    // if (!dto.getGrampanchayatname().matches(regx)) {
    // throw new IllegalArgumentException("GramPanchayatname contains invalid
    // Characters");
    // }
    // if (!dto.getNaav().matches(regx)) {
    // throw new IllegalArgumentException("Naav contains invalid Characters");
    // }
    // if (!dto.getVrukshprakar().matches(regx)) {
    // throw new IllegalArgumentException("Vrukshprakar contains invalid
    // Characters");
    // }
    // if (!dto.getVrukshjopasnechijababdari().matches(regx)) {
    // throw new IllegalArgumentException("Vrukshjopasnechijababdari contains
    // invalid Characters");
    // }
    //// if (!dto.getCurrentDate().matches(regx1)) {
    //// throw new IllegalArgumentException("CurrentDate contains invalid
    // Characters");
    //// }
    // if (!dto.getYear().matches(regx1)) {
    // throw new IllegalArgumentException("Year contains invalid Characters");
    // }
    //
    // }

    public void validateDetails(Namuna33VrukshNondVihaDTO dto, List<ErrorMessage> errors) {
        String regx = "^[\u0900-\u097F a-zA-Z ]+$"; // Allow Marathi and English letters with spaces
        String regx1 = "^[\u0966-\u096F  0-9 -]+$"; // Allow Marathi digits, English digits, and hyphens

        // if (!dto.getEmployeename().matches(regx)) {
        // errors.add(new ErrorMessage("Employeename contains invalid Characters"));
        // }
        // if (!dto.getGrampanchayatname().matches(regx)) {
        // errors.add(new ErrorMessage("GramPanchayatname contains invalid
        // Characters"));
        // }
        if (!dto.getNaav().matches(regx)) {
            errors.add(new ErrorMessage("Naav contains invalid Characters"));
        }
        if (!dto.getVrukshprakar().matches(regx)) {
            errors.add(new ErrorMessage("Vrukshprakar contains invalid Characters"));
        }
        if (!dto.getVrukshjopasnechijababdari().matches(regx)) {
            errors.add(new ErrorMessage("Vrukshjopasnechijababdari contains invalid Characters"));
        }
        // if (!dto.getDate().after(regx1)) {
        // errors.add(new ErrorMessage("Year contains invalid Characters"));
        // }
        if (!dto.getVrukshkrmank().matches(regx1)) {
            errors.add(new ErrorMessage("Vrukshkrmank contains invalid Characters"));
        }
        // if (!dto.getEmployeeid().matches(regx1)) {
        // errors.add(new ErrorMessage("Employee Id contains invalid Characters"));
        // }
        // if (!dto.getGrampanchayatid().matches(regx1)) {
        // errors.add(new ErrorMessage("Grampanchayat Id contains invalid Characters"));
        // }
    }

    // static class ErrorMessage {
    // private String description;
    //
    // public ErrorMessage(String description) {
    // this.description = description;
    // }
    //
    // // Getter
    // public String getDescription() {
    // return description;
    // }
    // }

    public static class ErrorMessage {
        private String description;

        public ErrorMessage(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }

}
