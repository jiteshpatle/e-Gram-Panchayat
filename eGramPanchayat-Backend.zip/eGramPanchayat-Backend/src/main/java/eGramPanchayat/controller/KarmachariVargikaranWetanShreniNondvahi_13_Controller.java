package eGramPanchayat.controller;

import eGramPanchayat.dto.KarmachariVargikaranWetanShreniNondvahi_13_Dto;
import eGramPanchayat.dto.Namuna33VrukshNondVihaDTO;
import eGramPanchayat.entity.KarmachariVargikaranWetanShreniNondvahi_13;
import eGramPanchayat.entity.Namuna33VrukshNondViha;
import eGramPanchayat.service.KarmachariVargikaranWetanShreniNondvahi_13_Service;

import eGramPanchayat.service.impl.TransactionLogService;
import eGramPanchayat.util.ResponseWrapper;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/karmachari-varg-wetan-shreni")
@CrossOrigin(origins = "http://localhost:3000")

public class KarmachariVargikaranWetanShreniNondvahi_13_Controller {

    @Autowired
    private KarmachariVargikaranWetanShreniNondvahi_13_Service service;

    @Autowired
    private TransactionLogService transactionLogService;

    // Create a new record
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createRecord(
            @Valid @RequestBody KarmachariVargikaranWetanShreniNondvahi_13_Dto dto) {
        Map<String, Object> response = new HashMap<>();
        try {
            // Create the record
            KarmachariVargikaranWetanShreniNondvahi_13_Dto created = service.create(dto);

            // Log the transaction (Add this if needed)
            transactionLogService.logTransaction(
                    "SAVE",
                    "Data saved successfully for Namuna13",
                    null, // No username needed if logged in user isn't specified
                    created.getEmployeeId(), created.getEmployeeName(), created.getGrampanchayatId(),
                    created.getGrampanchayatName());

            // Build response for successful creation
            response.put("code", "00");
            response.put("message", "Data saved successfully");
            response.put("errormessage", "");
            response.put("data", created);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception e) {
            // Log the error (Add this if needed)
            // transactionLogService.logTransaction(
            // "CREATE",
            // null, // No entity ID for creation
            // "Failed to create record. Error: " + e.getMessage(),
            // null);

            // Build response for error
            response.put("code", "01");
            response.put("message", "Error saving data");
            response.put("errormessage", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }

    // @PostMapping("/update_by_id/{id}") // Changed to PUT for update
    // public ResponseEntity<Map<String, Object>> updateRecord(
    //         @PathVariable Long id,
    //         @Valid @RequestBody KarmachariVargikaranWetanShreniNondvahi_13_Dto dto) {
    //     Map<String, Object> response = new HashMap<>();
    //     try {
    //         KarmachariVargikaranWetanShreniNondvahi_13_Dto updated = service.update(id, dto);
    //         if (updated != null) {
    //             response.put("code", "00");
    //             response.put("message", "Data updated successfully");
    //             response.put("errormessage", "");
    //             response.put("data", updated);

    //             // Log the transaction after successfully saving the entry
    //             transactionLogService.logTransaction("Update", "Updated record with ID:",
    //                     null, updated.getEmployeeId(), updated.getEmployeeName(), updated.getGrampanchayatId(),
    //                     updated.getGrampanchayatName());
    //             return ResponseEntity.ok(response);
    //         } else {
    //             response.put("code", "01");
    //             response.put("errormessage", "ID not found");
    //             return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
    //         }
    //     } catch (Exception e) {
    //         response.put("code", "01");
    //         response.put("errormessage", e.getMessage());
    //         // Log the transaction after successfully saving the entry
    //         // transactionLogService.logTransaction("Update Error", id,
    //         // "Error Occured While Updating the record with ID: ",
    //         // null);
    //         return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
    //     }
    // }

    @PostMapping("/update_by_id/{id}")
public ResponseEntity<Map<String, Object>> updateRecord(
        @PathVariable Long id,
        @Valid @RequestBody KarmachariVargikaranWetanShreniNondvahi_13_Dto dto) {
    Map<String, Object> response = new HashMap<>();
    try {
        // Call the service method to update the record
        KarmachariVargikaranWetanShreniNondvahi_13_Dto updated = service.update(id, dto);

        if (updated != null) {
            // Prepare a successful response
            response.put("code", "00");
            response.put("message", "Data updated successfully");
            response.put("errormessage", "");
            response.put("data", updated);

            // Log the successful transaction
            transactionLogService.logTransaction(
                    "Update",
                    "Successfully updated data for Namuna13 with ID: "
                            + id,
                    null,
                    updated.getEmployeeId(),
                    updated.getEmployeeName(),
                    updated.getGrampanchayatId(),
                    updated.getGrampanchayatName()
            );

            return ResponseEntity.ok(response);
        } else {
            // If the ID was not found
            response.put("code", "01");
            response.put("message", "Error updating data");
            response.put("errormessage", "ID not found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    } catch (EntityNotFoundException e) {
        // Handle specific case where the ID is invalid
        response.put("code", "01");
        response.put("message", "Error updating data");
        response.put("errormessage", e.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
    } catch (Exception e) {
        // Handle generic errors
        response.put("code", "01");
        response.put("message", "Error updating data");
        response.put("errormessage", e.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
    }
}

    
    
    
    
    
    // Fetch all records
    @PostMapping("/getall") // Changed to GET for fetching records
    public ResponseEntity<Map<String, Object>> getAllRecords() {
        Map<String, Object> response = new HashMap<>();
        try {
            List<KarmachariVargikaranWetanShreniNondvahi_13_Dto> allRecords = service.getAll();
            if (allRecords.isEmpty()) {
                response.put("code", "01");
                response.put("errormessage", "Data Not Found");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }
            response.put("code", "00");
            response.put("message", "Data retrieved successfully");
            response.put("errormessage", "");
            response.put("data", allRecords);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("code", "01");
            response.put("errormessage", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // Fetch record by ID
    @PostMapping("/get_by_id/{id}") // Changed to GET for fetching by ID
    public ResponseEntity<Map<String, Object>> getRecordById(
            @PathVariable @Min(value = 1, message = "ID must be a positive integer") Long id) {
        Map<String, Object> response = new HashMap<>();
        try {
            KarmachariVargikaranWetanShreniNondvahi_13_Dto record = service.getById(id);
            if (record != null) {
                response.put("code", "00");
                response.put("message", "Data retrieved successfully");
                response.put("errormessage", "");
                response.put("data", record);
                return ResponseEntity.ok(response);
            } else {
                response.put("code", "01");
                response.put("errormessage", "ID not found");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }
        } catch (Exception e) {
            response.put("code", "01");
            response.put("errormessage", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // Delete a record by ID
    @PostMapping("/delete_by_id/{id}") // Changed to DELETE for record deletion
    // public ResponseEntity<Map<String, Object>> deleteRecord(
    //         @PathVariable @Min(value = 1, message = "ID must be a positive integer") Long id) {
    //     Map<String, Object> response = new HashMap<>();
    //     try {
    //         KarmachariVargikaranWetanShreniNondvahi_13_Dto record = service.getById(id);
    //         if (record != null) {
    //             // Log the transaction before deleting
    //             transactionLogService.logTransaction(
    //                     "DELETE",
    //                     // Provide the entity ID for deletion
    //                     "Successfully deleted record with ID: ",
    //                     null, // No username if not needed
    //                     null, null, null, null);

    //             // Delete the record
    //             service.delete(id);

    //             // Build response for successful deletion
    //             response.put("code", "00");
    //             response.put("message", "Data deleted successfully");
    //             response.put("errormessage", "");
    //             return ResponseEntity.ok(response);
    //         } else {

    //             // Build response for ID not found
    //             response.put("code", "01");
    //             response.put("message", "Error deleting data");
    //             response.put("errormessage", "ID not found");
    //             return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
    //         }
    //     } catch (Exception e) {
    //         // Build response for any error
    //         response.put("code", "01");
    //         response.put("message", "Error deleting data");
    //         response.put("errormessage", e.getMessage());
    //         return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
    //     }
    // }

     public ResponseEntity<ResponseWrapper<Object>> deleteById(
            @PathVariable Long id,
            @RequestBody KarmachariVargikaranWetanShreniNondvahi_13_Dto deleteRequest) {

        // Validate the incoming JSON fields
        if (deleteRequest.getEmployeeId() == null ||
                deleteRequest.getEmployeeName() == null ||
                deleteRequest.getGrampanchayatId() == null ||
                deleteRequest.getGrampanchayatName() == null) {

            ResponseWrapper<Object> response = new ResponseWrapper<>(
                    "01", // code
                    "Request data is missing", // message
                    null, // no data field
                    "Required fields are not provided" // error message
            );
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }

        // Check if the entity exists
        KarmachariVargikaranWetanShreniNondvahi_13_Dto entity = service.getById(id);
        if (entity == null) {
            // // Log failure to delete (data not found)
            // transactionLogService.logTransaction(
            //         "DELETE",
            //         "Failed to delete Namuna33 data for ID: " + id,
            //         null,
            //         deleteRequest.getEmployeeId(),
            //         deleteRequest.getEmployeeName(),
            //         deleteRequest.getGrampanchayatId(),
            //         deleteRequest.getGrampanchayatName());

            // Return failure response
            ResponseWrapper<Object> response = new ResponseWrapper<>(
                    "01", // code
                    "Error Deleting Data", // message
                    null, // no data field
                    "Data Not Found" // error message
            );
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }

        // Attempt to delete the data
        boolean isDeleted = service.delete(id);
        if (isDeleted) {
            // Log successful deletion
            transactionLogService.logTransaction(
                    "DELETE",
                    "Successfully deleted Namuna13 data for ID: " + id,
                    null,
                    deleteRequest.getEmployeeId(),
                    deleteRequest.getEmployeeName(),
                    deleteRequest.getGrampanchayatId(),
                    deleteRequest.getGrampanchayatName());

            // Return success response
            ResponseWrapper<Object> response = new ResponseWrapper<>(
                    "00", // code
                    "Data Deleted Successfully", // message
                    null, // no data field
                    "" // empty error message for success
            );
            return ResponseEntity.ok(response);
        } else {
            // // Log failure to delete (unexpected error)
            // transactionLogService.logTransaction(
            //         "DELETE",
            //         "Failed to delete Namuna33 data for ID: " + id,
            //         null,
            //         deleteRequest.getEmployeeId(),
            //         deleteRequest.getEmployeeName(),
            //         deleteRequest.getGrampanchayatId(),
            //         deleteRequest.getGrampanchayatName());

            // Return failure response
            ResponseWrapper<Object> response = new ResponseWrapper<>(
                    "01", // code
                    "Error Deleting Data", // message
                    null, // no data field
                    "Data could not be deleted" // error message
            );
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }  
    


}
