package eGramPanchayat.service;

import java.util.List;
import java.util.Optional;

import eGramPanchayat.dto.MatteVaDayitwe_04_Dto;

public interface MatteVaDayitwe_04_Service {
    MatteVaDayitwe_04_Dto create(MatteVaDayitwe_04_Dto dto);
    MatteVaDayitwe_04_Dto update(Long id, MatteVaDayitwe_04_Dto dto);
    Optional<MatteVaDayitwe_04_Dto> getById(Long id);
    List<MatteVaDayitwe_04_Dto> getAll();
    boolean delete(Long id);
}
