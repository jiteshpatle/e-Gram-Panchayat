package eGramPanchayat.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eGramPanchayat.entity.Egram9;
import eGramPanchayat.repository.Egram9Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class Egram9ServiceImpl implements Egram9Service {

    @Autowired
    private Egram9Repository egram9Repository;

    // field calculation (** 'Akun' fields data automatic connected)
    @Override
    public Egram9 saveEgram9(Egram9 egram) {
        egram.setNa_GharTotal(egram.getNa_GharMagilBaki() + egram.getNa_GharChaluKar());
        egram.setNa_VijTotal(egram.getNa_VijMagilBaki() + egram.getNa_VijChaluKar());
        egram.setNa_ArogyaTotal(egram.getNa_ArogyaMagilBaki() + egram.getNa_ArogyaChaluKar());
        egram.setNa_PaniTotal(egram.getNa_PaniMagilBaki() + egram.getNa_PaniChaluKar());

        Long NA_khateYekunRakam = egram.getNa_GharTotal() + egram.getNa_VijTotal() + egram.getNa_ArogyaTotal()
                + egram.getNa_PaniTotal();
        egram.setNa_TotalKar(NA_khateYekunRakam);

        egram.setVasuli_GharTotal(egram.getVasuli_GharMagilBaki() + egram.getVasuli_GharChaluKar());
        egram.setVasuli_VijTotal(egram.getVasuli_VijMagilBaki() + egram.getVasuli_VijChaluKar());
        egram.setVasuli_ArogyaTotal(egram.getVasuli_ArogyaMagilBaki() + egram.getVasuli_ArogyaChaluKar());
        egram.setVasuli_PaniTotal(egram.getVasuli_PaniMagilBaki() + egram.getVasuli_PaniChaluKar());

        Long Vasuli_khateYekunRakam = egram.getVasuli_GharTotal() + egram.getVasuli_VijTotal()
                + egram.getVasuli_ArogyaTotal() + egram.getVasuli_PaniTotal();
        egram.setVasuli_TotalKar(Vasuli_khateYekunRakam);

        return egram9Repository.save(egram);
    }

    @Override
    public List<Egram9> getAllEgram9() {
        return egram9Repository.findAll();
    }

    @Override
    public Optional<Egram9> getEgram9ById(Long id) {
        Optional<Egram9> egram9 = egram9Repository.findById(id);
        if (egram9.isPresent()) {
            return egram9; // Simply return the Optional if the value is present
        } else {
            throw new RuntimeException("Egram9 record not found for ID: " + id);
        }
    }

    @Override
    public Egram9 updateEgram9(Long id, Egram9 updatedEgram9) {
        Optional<Egram9> entry = egram9Repository.findById(id);
        if (entry.isPresent()) {
            Egram9 existingEgram9 = entry.get();
            // Update all necessary fields
            existingEgram9.setCreatedDate(existingEgram9.getCreatedDate());
            existingEgram9.setUpdatedDate(LocalDateTime.now());
            // Check and retain existing values for specific fields
            existingEgram9.setGrampanchayatName(updatedEgram9.getGrampanchayatName());
            existingEgram9.setGrampanchayatName(updatedEgram9.getGrampanchayatName());
            existingEgram9.setEmployeeId(updatedEgram9.getEmployeeId());
            existingEgram9.setEmployeeName(updatedEgram9.getEmployeeName());
            existingEgram9.setRemark(updatedEgram9.getRemark());
            existingEgram9.setSerialNo(updatedEgram9.getSerialNo());
            existingEgram9.setMilkat_Number(updatedEgram9.getMilkat_Number());
            existingEgram9.setPropertyOwnerName(updatedEgram9.getPropertyOwnerName());
            existingEgram9.setNa_GharMagilBaki(updatedEgram9.getNa_GharMagilBaki());
            existingEgram9.setNa_GharChaluKar(updatedEgram9.getNa_GharChaluKar());
            existingEgram9.setNa_GharTotal(updatedEgram9.getNa_GharMagilBaki() + updatedEgram9.getNa_GharChaluKar());
            existingEgram9.setNa_VijMagilBaki(updatedEgram9.getNa_VijMagilBaki());
            existingEgram9.setNa_VijChaluKar(updatedEgram9.getNa_VijChaluKar());
            existingEgram9.setNa_VijTotal(updatedEgram9.getNa_VijMagilBaki() + updatedEgram9.getNa_VijChaluKar());
            existingEgram9.setNa_ArogyaMagilBaki(updatedEgram9.getNa_ArogyaMagilBaki());
            existingEgram9.setNa_ArogyaChaluKar(updatedEgram9.getNa_ArogyaChaluKar());
            existingEgram9
                    .setNa_ArogyaTotal(updatedEgram9.getNa_ArogyaMagilBaki() + updatedEgram9.getNa_ArogyaChaluKar());
            existingEgram9.setNa_PaniMagilBaki(updatedEgram9.getNa_PaniMagilBaki());
            existingEgram9.setNa_PaniChaluKar(updatedEgram9.getNa_PaniChaluKar());
            existingEgram9.setNa_PaniTotal(updatedEgram9.getNa_PaniMagilBaki() + updatedEgram9.getNa_PaniChaluKar());
            existingEgram9.setNa_TotalKar(existingEgram9.getNa_GharTotal() + existingEgram9.getNa_VijTotal()
                    + existingEgram9.getNa_ArogyaTotal() + existingEgram9.getNa_PaniTotal());
            existingEgram9.setBookNo(updatedEgram9.getBookNo());
            existingEgram9.setBookNoOR_Date(updatedEgram9.getBookNoOR_Date());
            existingEgram9.setPavti_Number(updatedEgram9.getPavti_Number());
            existingEgram9.setVasuli_GharMagilBaki(updatedEgram9.getVasuli_GharMagilBaki());
            existingEgram9.setVasuli_GharChaluKar(updatedEgram9.getVasuli_GharChaluKar());
            existingEgram9.setVasuli_GharTotal(
                    updatedEgram9.getVasuli_GharMagilBaki() + updatedEgram9.getVasuli_GharChaluKar());
            existingEgram9.setVasuli_VijMagilBaki(updatedEgram9.getVasuli_VijMagilBaki());
            existingEgram9.setVasuli_VijChaluKar(updatedEgram9.getVasuli_VijChaluKar());
            existingEgram9
                    .setVasuli_VijTotal(updatedEgram9.getVasuli_VijMagilBaki() + updatedEgram9.getVasuli_VijChaluKar());
            existingEgram9.setVasuli_ArogyaMagilBaki(updatedEgram9.getVasuli_ArogyaMagilBaki());
            existingEgram9.setVasuli_ArogyaChaluKar(updatedEgram9.getVasuli_ArogyaChaluKar());
            existingEgram9.setVasuli_ArogyaTotal(
                    updatedEgram9.getVasuli_ArogyaMagilBaki() + updatedEgram9.getVasuli_ArogyaChaluKar());
            existingEgram9.setVasuli_PaniMagilBaki(updatedEgram9.getVasuli_PaniMagilBaki());
            existingEgram9.setVasuli_PaniChaluKar(updatedEgram9.getVasuli_PaniChaluKar());
            existingEgram9.setVasuli_PaniTotal(
                    updatedEgram9.getVasuli_PaniMagilBaki() + updatedEgram9.getVasuli_PaniChaluKar());
            existingEgram9.setVasuli_TotalKar(existingEgram9.getVasuli_GharTotal() + existingEgram9.getVasuli_VijTotal()
                    + existingEgram9.getVasuli_ArogyaTotal() + existingEgram9.getVasuli_PaniTotal());
            existingEgram9.setSutManjuriHukmacha_Shera(updatedEgram9.getSutManjuriHukmacha_Shera());
            existingEgram9.setSutManjuriHukmacha_Ullekh(updatedEgram9.getSutManjuriHukmacha_Ullekh());

            return egram9Repository.save(existingEgram9);
        }
        return null;
    }

    @Override
    public boolean deleteEgram9(Long id) {
        if (egram9Repository.existsById(id)) {
            egram9Repository.deleteById(id);
            return true;
        }
        return false;

    }
}
