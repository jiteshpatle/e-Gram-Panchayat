package eGramPanchayat.service;

import java.util.List;
import java.util.Optional;

import eGramPanchayat.entity.Kirkolmagni_11;

public interface Kirkolmagni11Service {

	Kirkolmagni_11 saveEgram11(Kirkolmagni_11 egram11);

    List<Kirkolmagni_11> getAllEgram11();

  Optional<Kirkolmagni_11>getEgram11_ById(Long id);

  Kirkolmagni_11 updateEgram11(Long id, Kirkolmagni_11 updatedEgram11);

    boolean deleteEgram11(Long id);
	
}