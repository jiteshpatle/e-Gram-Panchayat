package eGramPanchayat.service;

import java.util.List;
import java.util.Optional;

import eGramPanchayat.dto.Namuna06JamaRakmanchiNondvahiDto;

public interface Namuna06JamaRakmanchiNondvahiService {
    Namuna06JamaRakmanchiNondvahiDto create(Namuna06JamaRakmanchiNondvahiDto dto);
    Optional<Namuna06JamaRakmanchiNondvahiDto> getById(Long id);
    List<Namuna06JamaRakmanchiNondvahiDto> getAll();
    Optional<Namuna06JamaRakmanchiNondvahiDto> update(Long id, Namuna06JamaRakmanchiNondvahiDto dto);
    boolean delete(Long id);
}

