package eGramPanchayat.service;

import java.util.List;

import eGramPanchayat.dto.Namuna29_KarjachiNondVahiDTO;
import eGramPanchayat.entity.Namuna29_KarjachiNondVahi;

public interface Namuna29_KarjachiNondVahiService {

	Namuna29_KarjachiNondVahi savedata(Namuna29_KarjachiNondVahiDTO dto);
    List<Namuna29_KarjachiNondVahi> getalldetails();
    Namuna29_KarjachiNondVahi getdetailsbyid(Long id);
    Namuna29_KarjachiNondVahi updateById(Long id, Namuna29_KarjachiNondVahiDTO dto);
    boolean deleteById(Long id);
}