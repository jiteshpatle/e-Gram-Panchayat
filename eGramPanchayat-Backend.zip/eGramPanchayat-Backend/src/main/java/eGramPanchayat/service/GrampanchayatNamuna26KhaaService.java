package eGramPanchayat.service;



import java.util.List;
import java.util.Optional;

import eGramPanchayat.dto.GrampanchayatNamuna26KhaaDto;


public interface GrampanchayatNamuna26KhaaService {
	GrampanchayatNamuna26KhaaDto save(GrampanchayatNamuna26KhaaDto dto);
    List<GrampanchayatNamuna26KhaaDto> findAll();
    Optional<GrampanchayatNamuna26KhaaDto> findById(Long id);
    GrampanchayatNamuna26KhaaDto update(Long id, GrampanchayatNamuna26KhaaDto dto);

    boolean deleteById(Long id);
}
