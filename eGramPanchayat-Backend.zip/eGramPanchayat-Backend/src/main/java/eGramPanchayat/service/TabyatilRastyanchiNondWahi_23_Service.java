package eGramPanchayat.service;

import java.util.List;
import java.util.Optional;

import eGramPanchayat.dto.TabyatilRastyanchiNondWahi_23_Dto;

public interface TabyatilRastyanchiNondWahi_23_Service {

    TabyatilRastyanchiNondWahi_23_Dto create(TabyatilRastyanchiNondWahi_23_Dto dto);

    TabyatilRastyanchiNondWahi_23_Dto update(Long id, TabyatilRastyanchiNondWahi_23_Dto dto);

    /**
     * Deletes the entity by its ID and returns a boolean indicating whether the deletion was successful.
     * 
     * @param id the ID of the entity to be deleted
     * @return true if the entity was deleted, false if the entity with the given ID was not found
     */
    boolean delete(Long id);

    Optional<TabyatilRastyanchiNondWahi_23_Dto> getById(Long id);

    List<TabyatilRastyanchiNondWahi_23_Dto> getAll();
}
