package eGramPanchayat.service;

import java.util.List;
import java.util.Optional;

import eGramPanchayat.dto.Namuna18KirkolRokadVahiDto;
import eGramPanchayat.entity.Namuna18KirkolRokadVahi;

public interface Namuna18KirkolRokadVahiService {
    Namuna18KirkolRokadVahi save(Namuna18KirkolRokadVahiDto kirkolRokadVahiDto);
    Optional<Namuna18KirkolRokadVahi> update(Long id, Namuna18KirkolRokadVahiDto kirkolRokadVahiDto);
    boolean delete(Long id);
    List<Namuna18KirkolRokadVahi> findAll();
    Optional<Namuna18KirkolRokadVahi> findById(Long id);
}
