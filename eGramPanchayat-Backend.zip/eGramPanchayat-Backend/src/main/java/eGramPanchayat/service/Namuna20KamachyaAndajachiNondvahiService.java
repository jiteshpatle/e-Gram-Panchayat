package eGramPanchayat.service;


import java.util.List;
import java.util.Optional;

import eGramPanchayat.dto.Namuna20KamachaAndajachiNondvahiDto;

public interface Namuna20KamachyaAndajachiNondvahiService {
	Namuna20KamachaAndajachiNondvahiDto create(Namuna20KamachaAndajachiNondvahiDto dto);
	Optional<Namuna20KamachaAndajachiNondvahiDto> update(Long id, Namuna20KamachaAndajachiNondvahiDto dto);
	Optional<Namuna20KamachaAndajachiNondvahiDto> getById(Long id);
    List<Namuna20KamachaAndajachiNondvahiDto> getAll();
	boolean delete(Long id);
}