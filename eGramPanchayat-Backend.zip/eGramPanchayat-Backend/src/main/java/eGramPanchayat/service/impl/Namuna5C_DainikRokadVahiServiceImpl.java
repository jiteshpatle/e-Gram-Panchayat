package eGramPanchayat.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import eGramPanchayat.dto.Namuna5C_DainikRokadVahiDTO;
import eGramPanchayat.entity.Namuna5C_DainikRokadVahi;
import eGramPanchayat.repository.Namuna5C_DainikRokadVahiRepository;
import eGramPanchayat.service.Namuna5C_DainikRokadVahiService;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Component
public class Namuna5C_DainikRokadVahiServiceImpl implements Namuna5C_DainikRokadVahiService {

    @Autowired
    Namuna5C_DainikRokadVahiRepository repo;

    @Override
    public Namuna5C_DainikRokadVahi savedata(Namuna5C_DainikRokadVahiDTO dto) {
        // Map DTO to entity
        Namuna5C_DainikRokadVahi entity = new Namuna5C_DainikRokadVahi();
        entity.setEmployeeId(dto.getEmployeeId());
        entity.setEmployeeName(dto.getEmployeeName());
        entity.setGrampanchayatId(dto.getGrampanchayatId());
        entity.setGrampanchayatName(dto.getGrampanchayatName());
        entity.setShera(dto.getShera());
        entity.setPavtiKramank(dto.getPavtiKramank());
        entity.setKonakdunMilali(dto.getKonakdunMilali());
        entity.setJamaRakkamTapshil(dto.getJamaRakkamTapshil());
        entity.setRokhRakkam(dto.getRokhRakkam());
        entity.setDhanadeshRakkam(dto.getDhanadeshRakkam());
        entity.setDhanadeshKinvaRakkamJamaDinank(dto.getDhanadeshKinvaRakkamJamaDinank());
        entity.setDhanadeshVatvilyachaDinank(dto.getDhanadeshVatvilyachaDinank());
        entity.setDate(dto.getDate());
        entity.setYear(dto.getYear());
        entity.setCreatedDate(dto.getCreatedDate());
        entity.setUpdatedDate(dto.getUpdatedDate());

        // Save to database
        return repo.save(entity);
    }

    @Override
    public List<Namuna5C_DainikRokadVahi> getalldetails() {
        return repo.findAll();
    }

    @Override
    public Namuna5C_DainikRokadVahi getdetailsbyid(Long id) {
        return repo.findById(id).orElse(null);
    }
    
    @Override
    public Namuna5C_DainikRokadVahi updateById(Long id, Namuna5C_DainikRokadVahiDTO dto) {
        // Check if the record exists in the database
        Optional<Namuna5C_DainikRokadVahi> existingEntityOpt = repo.findById(id);

        if (existingEntityOpt.isEmpty()) {
            return null;
        }

        Namuna5C_DainikRokadVahi existingEntity = existingEntityOpt.get();

        // Map fields from DTO to the entity
        existingEntity.setEmployeeId(dto.getEmployeeId());
        existingEntity.setEmployeeName(dto.getEmployeeName());
        existingEntity.setGrampanchayatId(dto.getGrampanchayatId());
        existingEntity.setGrampanchayatName(dto.getGrampanchayatName());
        existingEntity.setShera(dto.getShera());
        existingEntity.setPavtiKramank(dto.getPavtiKramank());
        existingEntity.setKonakdunMilali(dto.getKonakdunMilali());
        existingEntity.setJamaRakkamTapshil(dto.getJamaRakkamTapshil());
        existingEntity.setRokhRakkam(dto.getRokhRakkam());
        existingEntity.setDhanadeshRakkam(dto.getDhanadeshRakkam());
        existingEntity.setDhanadeshKinvaRakkamJamaDinank(dto.getDhanadeshKinvaRakkamJamaDinank());
        existingEntity.setDhanadeshVatvilyachaDinank(dto.getDhanadeshVatvilyachaDinank());
        existingEntity.setDate(dto.getDate());
        existingEntity.setYear(dto.getYear());
        existingEntity.setUpdatedDate(LocalDateTime.now());

        // Save the updated entity
        return repo.save(existingEntity);
    }

	@Override
	 public boolean deleteById(Long id) {
        if (repo.existsById(id)) {
            repo.deleteById(id);
            return true;
        }
        return false;
    }
}
