package eGramPanchayat.service.impl;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import eGramPanchayat.dto.Namuna16_DeadStockDTO;
import eGramPanchayat.entity.Namuna16_DeadStock;
import eGramPanchayat.repository.Namuna16_DeadStockRepository;
import eGramPanchayat.service.Namuna16_DeadStockService;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Component
public class Namuna16_DeadStockServiceImpl implements Namuna16_DeadStockService {

    @Autowired
    Namuna16_DeadStockRepository repo;

    @Override
    public Namuna16_DeadStock savedata(Namuna16_DeadStockDTO dto) {
        // Map DTO to entity
    	Namuna16_DeadStock entity = new Namuna16_DeadStock();
    	
    	 entity.setEmployeeId(dto.getEmployeeId());
         entity.setEmployeeName(dto.getEmployeeName());
         entity.setGrampanchayatId(dto.getGrampanchayatId());
         entity.setGrampanchayatName(dto.getGrampanchayatName());
         entity.setShera(dto.getShera());
         entity.setDate(dto.getDate());
         entity.setVastucheVarnan(dto.getVastucheVarnan());
         entity.setKharedibaddalPradhikar(dto.getKharedibaddalPradhikar());
         entity.setKharedichiTarikh(dto.getKharedichiTarikh());
         entity.setSankhyaKinvaPraman(dto.getSankhyaKinvaPraman());
         entity.setKimmat(dto.getKimmat());
         entity.setAntimVilhevatsathiSankhyaKinvaPariman(dto.getAntimVilhevatsathiSankhyaKinvaPariman());
         entity.setVilhevaticheSwarup(dto.getVilhevaticheSwarup());
         entity.setPradhikarPatraKinvaPramanak(dto.getPradhikarPatraKinvaPramanak());
         entity.setVasulKeleliRakkam(dto.getVasulKeleliRakkam());
         entity.setVasulRakkamKoshagaratBharnyachiTarikh(dto.getVasulRakkamKoshagaratBharnyachiTarikh());
         entity.setSathyatilShillak(dto.getSathyatilShillak());
         entity.setYear(dto.getYear());
         entity.setCreatedDate(dto.getCreatedDate());
         entity.setUpdatedDate(dto.getUpdatedDate());
        // Save to database
        return repo.save(entity);
    }

    @Override
    public List<Namuna16_DeadStock> getalldetails() {
        return repo.findAll();
    }

    @Override
    public Namuna16_DeadStock getdetailsbyid(Long id) {
        return repo.findById(id).orElse(null);
    }
    
    @Override
    public Namuna16_DeadStock updateById(Long id, Namuna16_DeadStockDTO dto) {
        // Check if the record exists in the database
        Optional<Namuna16_DeadStock> existingEntityOpt = repo.findById(id);

        if (existingEntityOpt.isEmpty()) {
            return null;
        }

        Namuna16_DeadStock existingEntity = existingEntityOpt.get();

        // Map fields from DTO to the entity
        existingEntity.setEmployeeId(dto.getEmployeeId());
        existingEntity.setEmployeeName(dto.getEmployeeName());
        existingEntity.setGrampanchayatId(dto.getGrampanchayatId());
        existingEntity.setGrampanchayatName(dto.getGrampanchayatName());
        existingEntity.setShera(dto.getShera());
        existingEntity.setDate(dto.getDate());
        existingEntity.setVastucheVarnan(dto.getVastucheVarnan());
        existingEntity.setKharedibaddalPradhikar(dto.getKharedibaddalPradhikar());
        existingEntity.setKharedichiTarikh(dto.getKharedichiTarikh());
        existingEntity.setSankhyaKinvaPraman(dto.getSankhyaKinvaPraman());
        existingEntity.setKimmat(dto.getKimmat());
        existingEntity.setAntimVilhevatsathiSankhyaKinvaPariman(dto.getAntimVilhevatsathiSankhyaKinvaPariman());
        existingEntity.setVilhevaticheSwarup(dto.getVilhevaticheSwarup());
        existingEntity.setPradhikarPatraKinvaPramanak(dto.getPradhikarPatraKinvaPramanak());
        existingEntity.setVasulKeleliRakkam(dto.getVasulKeleliRakkam());
        existingEntity.setVasulRakkamKoshagaratBharnyachiTarikh(dto.getVasulRakkamKoshagaratBharnyachiTarikh());
        existingEntity.setSathyatilShillak(dto.getSathyatilShillak());
        existingEntity.setYear(dto.getYear());
        existingEntity.setUpdatedDate(LocalDateTime.now());

        // Save the updated entity
        return repo.save(existingEntity);
    }

	@Override
	 public boolean deleteById(Long id) {
		if (repo.existsById(id)) {
            repo.deleteById(id);
            return true;
        }
        return false;
    }

}
