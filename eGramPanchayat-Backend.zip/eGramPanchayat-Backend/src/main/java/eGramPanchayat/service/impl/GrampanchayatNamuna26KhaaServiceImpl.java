package eGramPanchayat.service.impl;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import eGramPanchayat.dto.GrampanchayatNamuna26KhaaDto;
import eGramPanchayat.entity.GrampanchayatNamuna26Khaa;
import eGramPanchayat.repository.GrampanchayatNamuna26KhaaRepository;
import eGramPanchayat.service.GrampanchayatNamuna26KhaaService;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class GrampanchayatNamuna26KhaaServiceImpl implements GrampanchayatNamuna26KhaaService {

    @Autowired
    private GrampanchayatNamuna26KhaaRepository repository;

    @Override
    public GrampanchayatNamuna26KhaaDto save(@Valid GrampanchayatNamuna26KhaaDto dto) {
        GrampanchayatNamuna26Khaa entity = mapToEntity(dto);
        entity = repository.save(entity);
        return mapToDto(entity);
    }

    @Override
    public List<GrampanchayatNamuna26KhaaDto> findAll() {
        return repository.findAll().stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<GrampanchayatNamuna26KhaaDto> findById(Long id) {
        return repository.findById(id)
                .map(this::mapToDto);
    }

    @Override
    public GrampanchayatNamuna26KhaaDto update(Long id, GrampanchayatNamuna26KhaaDto dto) {
        // // Fetch the existing entity by ID
        // GrampanchayatNamuna26Khaa existingEntity = repository.findById(id)
        // .orElseThrow(() -> new EntityNotFoundException("GrampanchayatNamuna26Khaa not
        // found for ID: " + id));

        // // Update the existing entity with values from the DTO
        // updateEntityFromDto(existingEntity, dto);

        // // Save the updated entity and return the mapped DTO
        // return mapToDto(repository.save(existingEntity));

        GrampanchayatNamuna26Khaa update = repository.findById(id).orElse(null);

        if (update != null) {
            // // Update only non-null fields
            // Optional.ofNullable(dto.getGrampanchyatId()).ifPresent(update::setGrampanchyatId);
            // Optional.ofNullable(dto.getEmployeeName()).ifPresent(update::setEmployeeName);
            // Optional.ofNullable(dto.getEmployeeId()).ifPresent(update::setEmployeeId);
            // Optional.ofNullable(dto.getGrampanchyatName()).ifPresent(update::setGrampanchyatName);

            update.setGrampanchyatId(dto.getGrampanchyatId());
            update.setGrampanchyatName(dto.getGrampanchyatName());
            update.setEmployeeId(dto.getEmployeeId());
            update.setEmployeeName(dto.getEmployeeName());
            update.setMahina(dto.getMahina());
            update.setPraarabhitShillak(dto.getPraarabhitShillak());
            update.setRakamJamaKileyachaMahina(dto.getRakamJamaKileyachaMahina());
            update.setMahinaAakhrichiShillakSachivakdila(dto.getMahinaAakhrichiShillakSachivakdila());
            update.setMahinaAakhrichiShillakBanketila(dto.getMahinaAakhrichiShillakBanketila());
            update.setMahinaAakhrichiShillakPostateil(dto.getMahinaAakhrichiShillakPostateil());
            update.setAlpabachatPramanapatrataGuntviloliRakam(dto.getAlpabachatPramanapatrataGuntviloliRakam());
            update.setBanketaMudataThevitaGuntavililiRakam(dto.getBanketaMudataThevitaGuntavililiRakam());
            update.setEkun(dto.getEkun());
            // update.setCreateDate(dto.getCreateDate());
            update.setUpdatedDate(dto.getUpdatedDate());
            update.setDinank(dto.getDinank());
            update.setShera(dto.getShera());

            GrampanchayatNamuna26Khaa updatedEntity = repository.save(update);

            return mapToDto(updatedEntity);
        }

        return null;
    }

    @Override
    public boolean deleteById(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return true; // Deletion successful
        }
        return false; // Entity not found

    }

    // Mapping methods
    private GrampanchayatNamuna26Khaa mapToEntity(GrampanchayatNamuna26KhaaDto dto) {
        GrampanchayatNamuna26Khaa entity = new GrampanchayatNamuna26Khaa();
        entity.setId(dto.getId());
        entity.setMahina(dto.getMahina());
        entity.setPraarabhitShillak(dto.getPraarabhitShillak());
        entity.setRakamJamaKileyachaMahina(dto.getRakamJamaKileyachaMahina());
        entity.setMahinaAakhrichiShillakSachivakdila(dto.getMahinaAakhrichiShillakSachivakdila());
        entity.setMahinaAakhrichiShillakBanketila(dto.getMahinaAakhrichiShillakBanketila());
        entity.setMahinaAakhrichiShillakPostateil(dto.getMahinaAakhrichiShillakPostateil());
        entity.setAlpabachatPramanapatrataGuntviloliRakam(dto.getAlpabachatPramanapatrataGuntviloliRakam());
        entity.setBanketaMudataThevitaGuntavililiRakam(dto.getBanketaMudataThevitaGuntavililiRakam());
        entity.setEkun(dto.getEkun());
        // entity.setShoraNiyamapeshaJasataRakam(dto.getShoraNiyamapeshaJasataRakam());
        entity.setEmployeeId(dto.getEmployeeId());
        entity.setCreateDate(dto.getCreateDate());
        entity.setUpdatedDate(dto.getUpdatedDate());
        entity.setGrampanchyatId(dto.getGrampanchyatId());
        entity.setEmployeeName(dto.getEmployeeName());
        entity.setGrampanchyatName(dto.getGrampanchyatName());
        entity.setDinank(dto.getDinank());
        entity.setShera(dto.getShera());
        return entity;
    }

    private GrampanchayatNamuna26KhaaDto mapToDto(GrampanchayatNamuna26Khaa entity) {
        GrampanchayatNamuna26KhaaDto dto = new GrampanchayatNamuna26KhaaDto();
        dto.setId(entity.getId());
        dto.setMahina(entity.getMahina());
        dto.setPraarabhitShillak(entity.getPraarabhitShillak());
        dto.setRakamJamaKileyachaMahina(entity.getRakamJamaKileyachaMahina());
        dto.setMahinaAakhrichiShillakSachivakdila(entity.getMahinaAakhrichiShillakSachivakdila());
        dto.setMahinaAakhrichiShillakBanketila(entity.getMahinaAakhrichiShillakBanketila());
        dto.setMahinaAakhrichiShillakPostateil(entity.getMahinaAakhrichiShillakPostateil());
        dto.setAlpabachatPramanapatrataGuntviloliRakam(entity.getAlpabachatPramanapatrataGuntviloliRakam());
        dto.setBanketaMudataThevitaGuntavililiRakam(entity.getBanketaMudataThevitaGuntavililiRakam());
        dto.setEkun(entity.getEkun());
        // dto.setShoraNiyamapeshaJasataRakam(entity.getShoraNiyamapeshaJasataRakam());
        dto.setEmployeeId(entity.getEmployeeId());
        dto.setCreateDate(entity.getCreateDate());
        dto.setUpdatedDate(entity.getUpdatedDate());
        dto.setGrampanchyatId(entity.getGrampanchyatId());
        dto.setEmployeeName(entity.getEmployeeName());
        dto.setGrampanchyatName(entity.getGrampanchyatName());
        dto.setDinank(entity.getDinank());
        dto.setShera(entity.getShera());
        return dto;
    }

    private void updateEntityFromDto(GrampanchayatNamuna26Khaa entity, GrampanchayatNamuna26KhaaDto dto) {
        entity.setMahina(dto.getMahina());
        entity.setPraarabhitShillak(dto.getPraarabhitShillak());
        entity.setRakamJamaKileyachaMahina(dto.getRakamJamaKileyachaMahina());
        entity.setMahinaAakhrichiShillakSachivakdila(dto.getMahinaAakhrichiShillakSachivakdila());
        entity.setMahinaAakhrichiShillakBanketila(dto.getMahinaAakhrichiShillakBanketila());
        entity.setMahinaAakhrichiShillakPostateil(dto.getMahinaAakhrichiShillakPostateil());
        entity.setAlpabachatPramanapatrataGuntviloliRakam(dto.getAlpabachatPramanapatrataGuntviloliRakam());
        entity.setBanketaMudataThevitaGuntavililiRakam(dto.getBanketaMudataThevitaGuntavililiRakam());
        entity.setEkun(dto.getEkun());
        // entity.setShoraNiyamapeshaJasataRakam(dto.getShoraNiyamapeshaJasataRakam());
        entity.setEmployeeId(dto.getEmployeeId());
        entity.setUpdatedDate(dto.getUpdatedDate());
        entity.setGrampanchyatId(dto.getGrampanchyatId());
        entity.setEmployeeName(dto.getEmployeeName());
        entity.setGrampanchyatName(dto.getGrampanchyatName());
        entity.setDinank(dto.getDinank());
        entity.setShera(dto.getShera());
    }
}
