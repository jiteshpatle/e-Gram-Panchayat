package eGramPanchayat.service.impl;


import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eGramPanchayat.dto.Namuna20KamachaAndajachiNondvahiDto;
import eGramPanchayat.entity.Namuna20KamachyaAndajachiNondvahi;
import eGramPanchayat.repository.Namuna20KamachyaAndajachiNondvahiRepository;
import eGramPanchayat.service.Namuna20KamachyaAndajachiNondvahiService;
import jakarta.persistence.EntityNotFoundException;

@Service
public class Namuna20KamachyaAndajachiNondvahiServiceImpl implements Namuna20KamachyaAndajachiNondvahiService {

    @Autowired
    private Namuna20KamachyaAndajachiNondvahiRepository repository;
    @Override
    public Namuna20KamachaAndajachiNondvahiDto create(Namuna20KamachaAndajachiNondvahiDto dto) {
        Namuna20KamachyaAndajachiNondvahi entity = mapToEntity(dto); // Call the correct mapToEntity method
        entity = repository.save(entity);
        return mapToDto(entity);
    }


    @Override
    public Optional<Namuna20KamachaAndajachiNondvahiDto> update(Long id, Namuna20KamachaAndajachiNondvahiDto dto) {
        // Fetch the existing entity by ID
        Optional<Namuna20KamachyaAndajachiNondvahi> existingEntityOpt = repository.findById(id);

        if (existingEntityOpt.isPresent()) {
            Namuna20KamachyaAndajachiNondvahi existingEntity = existingEntityOpt.get();

            // Map the new DTO data into the existing entity without overriding specific fields
            Namuna20KamachyaAndajachiNondvahi updatedEntity = mapToEntity(dto);

            // Keep fields that shouldn't be overwritten, such as createdDate
            updatedEntity.setId(existingEntity.getId());
            updatedEntity.setCreatedDate(existingEntity.getCreatedDate());

            // Save updated entity
            updatedEntity = repository.save(updatedEntity);

            return Optional.ofNullable(mapToDto(updatedEntity));
        } else {
            return Optional.empty(); // Return empty if the entity was not found
        }
    }
    @Override
    public boolean delete(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return true;  // Return true to indicate successful deletion
        } else {
            throw new EntityNotFoundException("Data Not Found ");  // Throw exception if record doesn't exist
        }
    }


    @Override
    public Optional<Namuna20KamachaAndajachiNondvahiDto> getById(Long id) {
        Namuna20KamachyaAndajachiNondvahi entity = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Data Not Found"));
        return Optional.ofNullable(mapToDto(entity));
    }

    @Override
    public List<Namuna20KamachaAndajachiNondvahiDto> getAll() {
        return repository.findAll().stream().map(this::mapToDto).collect(Collectors.toList());
    }

    private Namuna20KamachyaAndajachiNondvahi mapToEntity(Namuna20KamachaAndajachiNondvahiDto dto) {
        Namuna20KamachyaAndajachiNondvahi entity = new Namuna20KamachyaAndajachiNondvahi();
        entity.setKramank(dto.getKramank());
        entity.setEmployeeId(dto.getEmployeeId());
        entity.setEmployeeName(dto.getEmployeeName());
        entity.setGrampanchayatId(dto.getGrampanchayatId());
        entity.setGrampanchayatName(dto.getGrampanchayatName());
        entity.setNidhicheShirsh(dto.getNidhicheShirsh());
        entity.setUpaShirsh(dto.getUpaShirsh());
        entity.setMadheHonyachyaSambhavKharchach(dto.getMadheHonyachyaSambhavKharchach());
        entity.setYanniKelelaAndaj(dto.getYanniKelelaAndaj());
        entity.setSarvasadharanGoshwaraParinam(dto.getSarvasadharanGoshwaraParinam());
        entity.setSarvasadharanGoshwaraBaab(dto.getSarvasadharanGoshwaraBaab());
        entity.setSarvasadharanGoshwaraDarRupaye(dto.getSarvasadharanGoshwaraDarRupaye());
        entity.setSarvasadharanGoshwaraPratteki(dto.getSarvasadharanGoshwaraPratteki());
        entity.setSarvasadharanGoshwaraRakkamDashanshat(dto.getSarvasadharanGoshwaraRakkamDashanshat());
        entity.setMojmapAndajpatraKramank(dto.getMojmapAndajpatraKramank());
        entity.setMojmapAndajpatraLaambi(dto.getMojmapAndajpatraLaambi());
        entity.setMojmapAndajpatraRundi(dto.getMojmapAndajpatraRundi());
        entity.setMojmapAndajpatraKholi(dto.getMojmapAndajpatraKholi());
        entity.setMojmapAndajpatraParimanDashanshat(dto.getMojmapAndajpatraParimanDashanshat());
        entity.setEkun(dto.getEkun());
        
        // Set createdDate to now during creation
        entity.setCreatedDate(LocalDateTime.now());
        entity.setUpdatedDate(LocalDateTime.now()); // Assuming you want to set it to now when creating

        entity.setYear(dto.getYear());
        
        return entity;
    }



    private Namuna20KamachaAndajachiNondvahiDto mapToDto(Namuna20KamachyaAndajachiNondvahi entity) {
        Namuna20KamachaAndajachiNondvahiDto dto = new Namuna20KamachaAndajachiNondvahiDto();
        dto.setId(entity.getId());
        dto.setKramank(entity.getKramank());
        dto.setEmployeeId(entity.getEmployeeId());
        dto.setEmployeeName(entity.getEmployeeName());
        dto.setGrampanchayatId(entity.getGrampanchayatId());
        dto.setGrampanchayatName(entity.getGrampanchayatName());
        dto.setNidhicheShirsh(entity.getNidhicheShirsh());
        dto.setUpaShirsh(entity.getUpaShirsh());
        dto.setMadheHonyachyaSambhavKharchach(entity.getMadheHonyachyaSambhavKharchach());
        dto.setYanniKelelaAndaj(entity.getYanniKelelaAndaj());
        dto.setSarvasadharanGoshwaraParinam(entity.getSarvasadharanGoshwaraParinam());
        dto.setSarvasadharanGoshwaraBaab(entity.getSarvasadharanGoshwaraBaab());
        dto.setSarvasadharanGoshwaraDarRupaye(entity.getSarvasadharanGoshwaraDarRupaye());
        dto.setSarvasadharanGoshwaraPratteki(entity.getSarvasadharanGoshwaraPratteki());
        dto.setSarvasadharanGoshwaraRakkamDashanshat(entity.getSarvasadharanGoshwaraRakkamDashanshat());
        dto.setMojmapAndajpatraKramank(entity.getMojmapAndajpatraKramank());
        dto.setMojmapAndajpatraLaambi(entity.getMojmapAndajpatraLaambi());
        dto.setMojmapAndajpatraRundi(entity.getMojmapAndajpatraRundi());
        dto.setMojmapAndajpatraKholi(entity.getMojmapAndajpatraKholi());
        dto.setMojmapAndajpatraParimanDashanshat(entity.getMojmapAndajpatraParimanDashanshat());
        dto.setEkun(entity.getEkun());
        
        // Correctly set createdDate and updatedDate from entity to DTO
        dto.setCreatedDate(entity.getCreatedDate());
        dto.setUpdatedDate(entity.getUpdatedDate());

        dto.setYear(entity.getYear());
        
        return dto;
    }

}
