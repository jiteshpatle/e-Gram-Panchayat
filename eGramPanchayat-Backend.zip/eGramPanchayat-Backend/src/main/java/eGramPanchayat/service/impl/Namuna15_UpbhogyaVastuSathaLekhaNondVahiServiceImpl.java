package eGramPanchayat.service.impl;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import eGramPanchayat.dto.Namuna15_UpbhogyaVastuSathaLekhaNondVahiDTO;
import eGramPanchayat.entity.Namuna15_UpbhogyaVastuSathaLekhaNondVahi;
import eGramPanchayat.repository.Namuna15_UpbhogyaVastuSathaLekhaNondVahiRepository;
import eGramPanchayat.service.Namuna15_UpbhogyaVastuSathaLekhaNondVahiService;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Component
public class Namuna15_UpbhogyaVastuSathaLekhaNondVahiServiceImpl implements Namuna15_UpbhogyaVastuSathaLekhaNondVahiService {

    @Autowired
    Namuna15_UpbhogyaVastuSathaLekhaNondVahiRepository repo;

    @Override
    public Namuna15_UpbhogyaVastuSathaLekhaNondVahi savedata(Namuna15_UpbhogyaVastuSathaLekhaNondVahiDTO dto) {
        // Map DTO to entity
    	Namuna15_UpbhogyaVastuSathaLekhaNondVahi entity = new Namuna15_UpbhogyaVastuSathaLekhaNondVahi();
    	
    	 entity.setEmployeeId(dto.getEmployeeId());
         entity.setEmployeeName(dto.getEmployeeName());
         entity.setGrampanchayatId(dto.getGrampanchayatId());
         entity.setGrampanchayatName(dto.getGrampanchayatName());
         entity.setShera(dto.getShera());
         entity.setDate(dto.getDate());
         entity.setTarikh(dto.getTarikh());
         entity.setAarambhichiShillak(dto.getAarambhichiShillak());
         entity.setMilaleliSankhyaKinvaPariman(dto.getMilaleliSankhyaKinvaPariman());
         entity.setEkun(dto.getEkun());
         entity.setKonasDile(dto.getKonasDile());
         entity.setKontyaKarnasathiDile(dto.getKontyaKarnasathiDile());
         entity.setDilelyaJinsachiSankhyaKinvaPariman(dto.getDilelyaJinsachiSankhyaKinvaPariman());
         entity.setShillak(dto.getShillak());
         entity.setVastuDenaryaAdhikaryacheNav(dto.getVastuDenaryaAdhikaryacheNav());
         entity.setYear(dto.getYear());
         entity.setCreatedDate(dto.getCreatedDate());
         entity.setUpdatedDate(dto.getUpdatedDate());
        // Save to database
        return repo.save(entity);
    }

    @Override
    public List<Namuna15_UpbhogyaVastuSathaLekhaNondVahi> getalldetails() {
        return repo.findAll();
    }

    @Override
    public Namuna15_UpbhogyaVastuSathaLekhaNondVahi getdetailsbyid(Long id) {
        return repo.findById(id).orElse(null);
    }
    
    @Override
    public Namuna15_UpbhogyaVastuSathaLekhaNondVahi updateById(Long id, Namuna15_UpbhogyaVastuSathaLekhaNondVahiDTO dto) {
        // Check if the record exists in the database
        Optional<Namuna15_UpbhogyaVastuSathaLekhaNondVahi> existingEntityOpt = repo.findById(id);

        if (existingEntityOpt.isEmpty()) {
            return null;
        }

        Namuna15_UpbhogyaVastuSathaLekhaNondVahi existingEntity = existingEntityOpt.get();

        // Map fields from DTO to the entity
        existingEntity.setEmployeeId(dto.getEmployeeId());
        existingEntity.setEmployeeName(dto.getEmployeeName());
        existingEntity.setGrampanchayatId(dto.getGrampanchayatId());
        existingEntity.setGrampanchayatName(dto.getGrampanchayatName());
        existingEntity.setShera(dto.getShera());
        existingEntity.setDate(dto.getDate());
        existingEntity.setTarikh(dto.getTarikh());
        existingEntity.setAarambhichiShillak(dto.getAarambhichiShillak());
        existingEntity.setMilaleliSankhyaKinvaPariman(dto.getMilaleliSankhyaKinvaPariman());
        existingEntity.setEkun(dto.getEkun());
        existingEntity.setKonasDile(dto.getKonasDile());
        existingEntity.setKontyaKarnasathiDile(dto.getKontyaKarnasathiDile());
        existingEntity.setDilelyaJinsachiSankhyaKinvaPariman(dto.getDilelyaJinsachiSankhyaKinvaPariman());
        existingEntity.setShillak(dto.getShillak());
        existingEntity.setVastuDenaryaAdhikaryacheNav(dto.getVastuDenaryaAdhikaryacheNav());
        existingEntity.setYear(dto.getYear());
        existingEntity.setUpdatedDate(LocalDateTime.now());

        // Save the updated entity
        return repo.save(existingEntity);
    }

	@Override
	 public boolean deleteById(Long id) {
		if (repo.existsById(id)) {
            repo.deleteById(id);
            return true;
        }
        return false;
    }

}
