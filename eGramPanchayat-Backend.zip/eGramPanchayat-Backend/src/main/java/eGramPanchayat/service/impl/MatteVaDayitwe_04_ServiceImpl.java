package eGramPanchayat.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eGramPanchayat.dto.MatteVaDayitwe_04_Dto;
import eGramPanchayat.dto.MatteVaDayitwe_04_Dto.CommonFieldsDto;
import eGramPanchayat.dto.MatteVaDayitwe_04_Dto.DayitweFieldsDto;
import eGramPanchayat.dto.MatteVaDayitwe_04_Dto.MatteFieldsDto;
import eGramPanchayat.entity.MatteVaDayitwe_04;
import eGramPanchayat.entity.MatteVaDayitwe_04.CommonFields;
import eGramPanchayat.entity.MatteVaDayitwe_04.DayitweFields;
import eGramPanchayat.entity.MatteVaDayitwe_04.MatteFields;
import eGramPanchayat.repository.MatteVaDayitwe_04_Repository;
import eGramPanchayat.service.MatteVaDayitwe_04_Service;

@Service
public class MatteVaDayitwe_04_ServiceImpl implements MatteVaDayitwe_04_Service {

    @Autowired
    private MatteVaDayitwe_04_Repository repository;

    @Override
    public MatteVaDayitwe_04_Dto create(MatteVaDayitwe_04_Dto dto) {
        MatteVaDayitwe_04 entity = convertToEntity(dto);
        entity.setUpdatedDate(null); // Ensure updatedDate is null during creation
        repository.save(entity);
        return convertToDto(entity);
    }

    @Override
    public MatteVaDayitwe_04_Dto update(Long id, MatteVaDayitwe_04_Dto dto) {
        MatteVaDayitwe_04 entity = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Data Not found"));

        // Update common fields
        entity.getCommonFields().setEmployeeId(dto.getCommonFields().getEmployeeId());
        entity.getCommonFields().setEmployeeName(dto.getCommonFields().getEmployeeName());
        entity.getCommonFields().setGrampanchayatId(dto.getCommonFields().getGrampanchayatId());
        entity.getCommonFields().setGrampanchayatName(dto.getCommonFields().getGrampanchayatName());
        entity.getCommonFields().setRemark(dto.getCommonFields().getRemark());
        entity.getCommonFields().setYear(dto.getCommonFields().getYear());
        entity.getCommonFields().setUpdatedDate(LocalDateTime.now()); // Set updatedDate to current timestamp

        // Update MatteFields
        if (dto.getMatteFields() != null) {
            updateMatteFields(entity.getMatteFields(), dto.getMatteFields());
        }

        // Update DayitweFields
        if (dto.getDayitweFields() != null) {
            updateDayitweFields(entity.getDayitweFields(), dto.getDayitweFields());
        }

        repository.save(entity);
        return convertToDto(entity);
    }

    // Helper method to convert DTO to entity
    private MatteVaDayitwe_04 convertToEntity(MatteVaDayitwe_04_Dto dto) {
        MatteVaDayitwe_04 entity = new MatteVaDayitwe_04();
        
        dto.setId(entity.getId());  // Make sure this line exists to copy the ID

        // Common Fields
        CommonFields commonFields = new CommonFields();
        commonFields.setEmployeeId(dto.getCommonFields().getEmployeeId());
        commonFields.setEmployeeName(dto.getCommonFields().getEmployeeName());
        commonFields.setGrampanchayatId(dto.getCommonFields().getGrampanchayatId());
        commonFields.setGrampanchayatName(dto.getCommonFields().getGrampanchayatName());
        commonFields.setCreatedDate(LocalDateTime.now()); // Set createdDate to current timestamp
        commonFields.setRemark(dto.getCommonFields().getRemark());
        commonFields.setYear(dto.getCommonFields().getYear());
        entity.setCommonFields(commonFields);

        // Matte Fields
        MatteFields matteFields = new MatteFields();
        updateMatteFields(matteFields, dto.getMatteFields());
        entity.setMatteFields(matteFields);

        // Dayitwe Fields
        DayitweFields dayitweFields = new DayitweFields();
        updateDayitweFields(dayitweFields, dto.getDayitweFields());
        entity.setDayitweFields(dayitweFields);

        return entity;
    }

    // Helper method to update MatteFields
    private void updateMatteFields(MatteFields entityFields, MatteFieldsDto dtoFields) {
        entityFields.setMattaId(dtoFields.getMattaId());
        entityFields.setKar(dtoFields.getKar());
        entityFields.setEmaratKar(dtoFields.getEmaratKar());
        entityFields.setJameenKar(dtoFields.getJameenKar());
        entityFields.setAarogyaKar(dtoFields.getAarogyaKar());
        entityFields.setDiwabattiKar(dtoFields.getDiwabattiKar());
        entityFields.setPaniPatti(dtoFields.getPaniPatti());
        entityFields.setKarettar(dtoFields.getKarettar());
        entityFields.setDukanGaleBhade(dtoFields.getDukanGaleBhade());
        entityFields.setNuksanAnudan(dtoFields.getNuksanAnudan());
        entityFields.setSahayyakAnudan(dtoFields.getSahayyakAnudan());
        entityFields.setShasanakadun(dtoFields.getShasanakadun());
        entityFields.setEkunNuksanAnudanSahayyakAnudan(dtoFields.getEkunNuksanAnudanSahayyakAnudan());
        entityFields.setEtarJamaRakama(dtoFields.getEtarJamaRakama());
        entityFields.setAgrimWasuliBaki(dtoFields.getAgrimWasuliBaki());
        entityFields.setPanchayatichiSthavarMalmatta(dtoFields.getPanchayatichiSthavarMalmatta());
        entityFields.setGrampanchayatikadunYeneAslelyaThakitRakama(dtoFields.getGrampanchayatikadunYeneAslelyaThakitRakama());
    }

    // Helper method to update DayitweFields
    private void updateDayitweFields(DayitweFields entityFields, DayitweFieldsDto dtoFields) {
        entityFields.setDayitweId(dtoFields.getDayitweId());
        entityFields.setThakitDeyak(dtoFields.getThakitDeyak());
        entityFields.setWetan(dtoFields.getWetan());
        entityFields.setWetanWyatiriktaEtarAasthapana(dtoFields.getWetanWyatiriktaEtarAasthapana());
        entityFields.setSadhanSamagri(dtoFields.getSadhanSamagri());
        entityFields.setBandhkaam(dtoFields.getBandhkaam());
        entityFields.setEtar(dtoFields.getEtar());
        entityFields.setGrampanchayatiKadunDeneAslelyaThakitRakma(dtoFields.getGrampanchayatiKadunDeneAslelyaThakitRakma());
        entityFields.setKarjHaftaWaKarjawarilWyajHafta(dtoFields.getKarjHaftaWaKarjawarilWyajHafta());
        entityFields.setEtarDeyaRakkam(dtoFields.getEtarDeyaRakkam());
        entityFields.setTheviPartachaBaki(dtoFields.getTheviPartachaBaki());
        entityFields.setSamajKalyanBaki(dtoFields.getSamajKalyanBaki());
        entityFields.setMahilaWaBalkalyanAnushesh(dtoFields.getMahilaWaBalkalyanAnushesh());
    }

    // Helper method to convert entity to DTO
    private MatteVaDayitwe_04_Dto convertToDto(MatteVaDayitwe_04 entity) {
        MatteVaDayitwe_04_Dto dto = new MatteVaDayitwe_04_Dto();
        
        dto.setId(entity.getId());  // Make sure this line exists to copy the ID
        
        // Common Fields
        CommonFieldsDto commonFieldsDto = new CommonFieldsDto();
        commonFieldsDto.setEmployeeId(entity.getCommonFields().getEmployeeId());
        commonFieldsDto.setEmployeeName(entity.getCommonFields().getEmployeeName());
        commonFieldsDto.setGrampanchayatId(entity.getCommonFields().getGrampanchayatId());
        commonFieldsDto.setGrampanchayatName(entity.getCommonFields().getGrampanchayatName());
        commonFieldsDto.setCreatedDate(entity.getCommonFields().getCreatedDate());
        commonFieldsDto.setUpdatedDate(entity.getCommonFields().getUpdatedDate());
        commonFieldsDto.setRemark(entity.getCommonFields().getRemark());
        commonFieldsDto.setYear(entity.getCommonFields().getYear());
        dto.setCommonFields(commonFieldsDto);

        // Matte Fields
        MatteFieldsDto matteFieldsDto = new MatteFieldsDto();
        matteFieldsDto.setMattaId(entity.getMatteFields().getMattaId());
        matteFieldsDto.setKar(entity.getMatteFields().getKar());
        matteFieldsDto.setEmaratKar(entity.getMatteFields().getEmaratKar());
        matteFieldsDto.setJameenKar(entity.getMatteFields().getJameenKar());
        matteFieldsDto.setAarogyaKar(entity.getMatteFields().getAarogyaKar());
        matteFieldsDto.setDiwabattiKar(entity.getMatteFields().getDiwabattiKar());
        matteFieldsDto.setPaniPatti(entity.getMatteFields().getPaniPatti());
        matteFieldsDto.setKarettar(entity.getMatteFields().getKarettar());
        matteFieldsDto.setDukanGaleBhade(entity.getMatteFields().getDukanGaleBhade());
        matteFieldsDto.setNuksanAnudan(entity.getMatteFields().getNuksanAnudan());
        matteFieldsDto.setSahayyakAnudan(entity.getMatteFields().getSahayyakAnudan());
        matteFieldsDto.setShasanakadun(entity.getMatteFields().getShasanakadun());
        matteFieldsDto.setEkunNuksanAnudanSahayyakAnudan(entity.getMatteFields().getEkunNuksanAnudanSahayyakAnudan());
        matteFieldsDto.setEtarJamaRakama(entity.getMatteFields().getEtarJamaRakama());
        matteFieldsDto.setAgrimWasuliBaki(entity.getMatteFields().getAgrimWasuliBaki());
        matteFieldsDto.setPanchayatichiSthavarMalmatta(entity.getMatteFields().getPanchayatichiSthavarMalmatta());
        matteFieldsDto.setGrampanchayatikadunYeneAslelyaThakitRakama(entity.getMatteFields().getGrampanchayatikadunYeneAslelyaThakitRakama());
        dto.setMatteFields(matteFieldsDto);

        // Dayitwe Fields
        DayitweFieldsDto dayitweFieldsDto = new DayitweFieldsDto();
        dayitweFieldsDto.setDayitweId(entity.getDayitweFields().getDayitweId());
        dayitweFieldsDto.setThakitDeyak(entity.getDayitweFields().getThakitDeyak());
        dayitweFieldsDto.setWetan(entity.getDayitweFields().getWetan());
        dayitweFieldsDto.setWetanWyatiriktaEtarAasthapana(entity.getDayitweFields().getWetanWyatiriktaEtarAasthapana());
        dayitweFieldsDto.setSadhanSamagri(entity.getDayitweFields().getSadhanSamagri());
        dayitweFieldsDto.setBandhkaam(entity.getDayitweFields().getBandhkaam());
        dayitweFieldsDto.setEtar(entity.getDayitweFields().getEtar());
        dayitweFieldsDto.setGrampanchayatiKadunDeneAslelyaThakitRakma(entity.getDayitweFields().getGrampanchayatiKadunDeneAslelyaThakitRakma());
        dayitweFieldsDto.setKarjHaftaWaKarjawarilWyajHafta(entity.getDayitweFields().getKarjHaftaWaKarjawarilWyajHafta());
        dayitweFieldsDto.setEtarDeyaRakkam(entity.getDayitweFields().getEtarDeyaRakkam());
        dayitweFieldsDto.setTheviPartachaBaki(entity.getDayitweFields().getTheviPartachaBaki());
        dayitweFieldsDto.setSamajKalyanBaki(entity.getDayitweFields().getSamajKalyanBaki());
        dayitweFieldsDto.setMahilaWaBalkalyanAnushesh(entity.getDayitweFields().getMahilaWaBalkalyanAnushesh());
        dto.setDayitweFields(dayitweFieldsDto);

        return dto;
    }

    @Override
    public Optional<MatteVaDayitwe_04_Dto> getById(Long id) {
        MatteVaDayitwe_04 entity = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Data Not found"));
        return Optional.ofNullable(convertToDto(entity));
    }

    @Override
    public List<MatteVaDayitwe_04_Dto> getAll() {
        return repository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    public boolean delete(Long id) {
        if (!repository.existsById(id)) {
            throw new RuntimeException("Data Not Found");
        }
        repository.deleteById(id);
        return true;
    }
}
