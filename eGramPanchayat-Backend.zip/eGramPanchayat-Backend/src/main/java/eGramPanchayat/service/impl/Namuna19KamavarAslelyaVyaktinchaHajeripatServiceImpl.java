package eGramPanchayat.service.impl;



import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eGramPanchayat.dto.Namuna19KamavarAslelyaVyaktinchaHajeripatDto;
import eGramPanchayat.entity.Namuna19KamavarAslelyaVyaktinchaHajeripat;
import eGramPanchayat.repository.Namuna19KamavarAslelyaVyaktinchaHajeripatRepository;
import eGramPanchayat.service.Namuna19KamavarAslelyaVyaktinchaHajeripatService;

@Service
public class Namuna19KamavarAslelyaVyaktinchaHajeripatServiceImpl implements Namuna19KamavarAslelyaVyaktinchaHajeripatService {

    @Autowired
    private Namuna19KamavarAslelyaVyaktinchaHajeripatRepository repository;

    @Override
    public Namuna19KamavarAslelyaVyaktinchaHajeripatDto create(Namuna19KamavarAslelyaVyaktinchaHajeripatDto dto) {
        Namuna19KamavarAslelyaVyaktinchaHajeripat entity = convertToEntity(dto);
        Namuna19KamavarAslelyaVyaktinchaHajeripat savedEntity = repository.save(entity);
        return convertToDto(savedEntity);
    }

    @Override
    public Optional<Namuna19KamavarAslelyaVyaktinchaHajeripatDto> update(Long id, Namuna19KamavarAslelyaVyaktinchaHajeripatDto dto) {
        Optional<Namuna19KamavarAslelyaVyaktinchaHajeripat> existingEntityOpt = repository.findById(id);

        if (existingEntityOpt.isPresent()) {
            Namuna19KamavarAslelyaVyaktinchaHajeripat existingEntity = existingEntityOpt.get();
            
            // Update entity with new data from the DTO
          
            existingEntity.setRemark(dto.getRemark());
            existingEntity.setEmployeeId(dto.getEmployeeId());
            existingEntity.setEmployeeName(dto.getEmployeeName());
            existingEntity.setGrampanchayatId(dto.getGrampanchayatId());
            existingEntity.setGrampanchayatName(dto.getGrampanchayatName());
            existingEntity.setSampurnaNaav(dto.getSampurnaNaav());
            existingEntity.setGaon(dto.getGaon());
            existingEntity.setHudda(dto.getHudda());
            existingEntity.setDar(dto.getDar());
            existingEntity.setEkun(dto.getEkun());
            existingEntity.setDileliRakkam(dto.getDileliRakkam());
            existingEntity.setYeneAsleliShillakRakkam(dto.getYeneAsleliShillakRakkam());
            existingEntity.setPaiseDenaryaAdhikaryaneKaravayachiTaNishaA(dto.getPaiseDenaryaAdhikaryaneKaravayachiTaNishaA());
            existingEntity.setAttendanceData(dto.getAttendanceData());
            existingEntity.setYear(dto.getYear());

            Namuna19KamavarAslelyaVyaktinchaHajeripat updatedEntity = repository.save(existingEntity);
            return Optional.ofNullable(convertToDto(updatedEntity));
        } else {
            throw new RuntimeException("Data Not Found");
        }
    }

    @Override
    public Optional<Namuna19KamavarAslelyaVyaktinchaHajeripatDto> getById(Long id) {
        Optional<Namuna19KamavarAslelyaVyaktinchaHajeripat> entityOpt = repository.findById(id);
        if (entityOpt.isPresent()) {
            return Optional.ofNullable(convertToDto(entityOpt.get()));
        } else {
            throw new RuntimeException("Data Not Found");
        }
    }

    @Override
    public List<Namuna19KamavarAslelyaVyaktinchaHajeripatDto> getAll() {
        List<Namuna19KamavarAslelyaVyaktinchaHajeripat> entities = repository.findAll();
        return entities.stream().map(this::convertToDto).collect(Collectors.toList());
    }

    @Override
    public boolean delete(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
        } else {
            throw new RuntimeException("Data Not Found");
        }
		return true;
    }

    private Namuna19KamavarAslelyaVyaktinchaHajeripatDto convertToDto(Namuna19KamavarAslelyaVyaktinchaHajeripat entity) {
        Namuna19KamavarAslelyaVyaktinchaHajeripatDto dto = new Namuna19KamavarAslelyaVyaktinchaHajeripatDto();
        dto.setId(entity.getId());
        dto.setCreatedDate(entity.getCreatedDate());
        dto.setUpdatedDate(entity.getUpdatedDate());
        dto.setRemark(entity.getRemark());
        dto.setEmployeeId(entity.getEmployeeId());
        dto.setEmployeeName(entity.getEmployeeName());
        dto.setGrampanchayatId(entity.getGrampanchayatId());
        dto.setGrampanchayatName(entity.getGrampanchayatName());
        dto.setSampurnaNaav(entity.getSampurnaNaav());
        dto.setGaon(entity.getGaon());
        dto.setHudda(entity.getHudda());
        dto.setDar(entity.getDar());
        dto.setEkun(entity.getEkun());
        dto.setDileliRakkam(entity.getDileliRakkam());
        dto.setYeneAsleliShillakRakkam(entity.getYeneAsleliShillakRakkam());
        dto.setPaiseDenaryaAdhikaryaneKaravayachiTaNishaA(entity.getPaiseDenaryaAdhikaryaneKaravayachiTaNishaA());
        dto.setAttendanceData(entity.getAttendanceData());
        dto.setYear(entity.getYear());
        return dto;
    }

    private Namuna19KamavarAslelyaVyaktinchaHajeripat convertToEntity(Namuna19KamavarAslelyaVyaktinchaHajeripatDto dto) {
        Namuna19KamavarAslelyaVyaktinchaHajeripat entity = new Namuna19KamavarAslelyaVyaktinchaHajeripat();
        entity.setCreatedDate(dto.getCreatedDate());
        entity.setUpdatedDate(dto.getUpdatedDate());
        entity.setRemark(dto.getRemark());
        entity.setEmployeeId(dto.getEmployeeId());
        entity.setEmployeeName(dto.getEmployeeName());
        entity.setGrampanchayatId(dto.getGrampanchayatId());
        entity.setGrampanchayatName(dto.getGrampanchayatName());
        entity.setSampurnaNaav(dto.getSampurnaNaav());
        entity.setGaon(dto.getGaon());
        entity.setHudda(dto.getHudda());
        entity.setDar(dto.getDar());
        entity.setEkun(dto.getEkun());
        entity.setDileliRakkam(dto.getDileliRakkam());
        entity.setYeneAsleliShillakRakkam(dto.getYeneAsleliShillakRakkam());
        entity.setPaiseDenaryaAdhikaryaneKaravayachiTaNishaA(dto.getPaiseDenaryaAdhikaryaneKaravayachiTaNishaA());
        entity.setAttendanceData(dto.getAttendanceData());
        entity.setYear(dto.getYear());
        return entity;
    }
}
