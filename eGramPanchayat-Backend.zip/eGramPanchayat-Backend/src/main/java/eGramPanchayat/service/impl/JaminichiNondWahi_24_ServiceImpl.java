package eGramPanchayat.service.impl;

import java.time.LocalDateTime;  // Import LocalDateTime
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eGramPanchayat.dto.JaminichiNondWahi_24_Dto;
import eGramPanchayat.entity.JaminichiNondWahi_24;
import eGramPanchayat.repository.JaminichiNondWahi_24_Repository;
import eGramPanchayat.service.JaminichiNondWahi_24_Service;

@Service("jaminichiNondWahi_24_ServiceImpl")
public class JaminichiNondWahi_24_ServiceImpl implements JaminichiNondWahi_24_Service {

    @Autowired
    private JaminichiNondWahi_24_Repository repository;

    @Override
    public JaminichiNondWahi_24_Dto createJaminichiNondWahi(JaminichiNondWahi_24_Dto dto) {
        JaminichiNondWahi_24 entity = convertToEntity(dto);
        entity.setCreatedDate(LocalDateTime.now());  // Set createdDate
        entity = repository.save(entity);
        return convertToDto(entity);
    }

    @Override
    public Optional<JaminichiNondWahi_24_Dto> getJaminichiNondWahiById(Long id) {
        return Optional.ofNullable(repository.findById(id)
            .map(this::convertToDto)
            .orElseThrow(() -> new IllegalArgumentException("Data Not Found")));
    }

    @Override
    public List<JaminichiNondWahi_24_Dto> getAllJaminichiNondWahi() {
        return repository.findAll()
            .stream()
            .map(this::convertToDto)
            .collect(Collectors.toList());
    }

    @Override
    public JaminichiNondWahi_24_Dto updateJaminichiNondWahi(Long id, JaminichiNondWahi_24_Dto dto) {
        JaminichiNondWahi_24 entity = repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Data Not Found"));
        // Update entity fields from DTO
        updateEntityFromDto(entity, dto);
        entity.setUpdatedDate(LocalDateTime.now());  // Set updatedDate on update
        entity = repository.save(entity);
        return convertToDto(entity);
    }

    @Override
    public boolean deleteJaminichiNondWahi(Long id) {
        JaminichiNondWahi_24 entity = repository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Data Not Found"));
        repository.delete(entity);
        return true;
    }


    // Conversion from Entity to DTO
    private JaminichiNondWahi_24_Dto convertToDto(JaminichiNondWahi_24 entity) {
        JaminichiNondWahi_24_Dto dto = new JaminichiNondWahi_24_Dto();
        dto.setId(entity.getId());
        dto.setEmployeeId(entity.getEmployeeId());
        dto.setEmployeeName(entity.getEmployeeName());
        dto.setGrampanchayatId(entity.getGrampanchayatId());
        dto.setGrampanchayatName(entity.getGrampanchayatName());
        dto.setCreatedDate(entity.getCreatedDate());
        dto.setUpdatedDate(entity.getUpdatedDate());
        dto.setAnukramank(entity.getAnukramank());
        dto.setHastantaritKharidiKinwaSampaditKelyachiTarikh(entity.getHastantaritKharidiKinwaSampaditKelyachiTarikh());
        dto.setKonatyaKarnasaathi(entity.getKonatyaKarnasaathi());
        dto.setKonakadun(entity.getKonakadun());
        dto.setKararnamaNiwadaNirdeshank(entity.getKararnamaNiwadaNirdeshank());
        dto.setJaminicheKshetraphal(entity.getJaminicheKshetraphal());
        dto.setBhumapanKramankEtyadi(entity.getBhumapanKramankEtyadi());
        dto.setAakarni(entity.getAakarni());
        dto.setJaminichyaSeema(entity.getJaminichyaSeema());
        dto.setJaminisahKharediSampadanEmarati(entity.getJaminisahKharediSampadanEmarati());
        dto.setJaminichiWaEmartichiWilhewat(entity.getJaminichiWaEmartichiWilhewat());
        dto.setVikriPaasunMilaleliRakkam(entity.getVikriPaasunMilaleliRakkam());
        dto.setPramanakachaKramankWaDinank(entity.getPramanakachaKramankWaDinank());
        dto.setMalmattechiWilhewatPanchayatichaTharav(entity.getMalmattechiWilhewatPanchayatichaTharav());
        dto.setMalmattechiWilhewatKalam55(entity.getMalmattechiWilhewatKalam55());
        dto.setShera(entity.getShera());
        dto.setYear(entity.getYear());
        return dto;
    }

    // Conversion from DTO to Entity
    private JaminichiNondWahi_24 convertToEntity(JaminichiNondWahi_24_Dto dto) {
        JaminichiNondWahi_24 entity = new JaminichiNondWahi_24();
        entity.setEmployeeId(dto.getEmployeeId());
        entity.setEmployeeName(dto.getEmployeeName());
        entity.setGrampanchayatId(dto.getGrampanchayatId());
        entity.setGrampanchayatName(dto.getGrampanchayatName());
        entity.setCreatedDate(dto.getCreatedDate());  // Use the value from DTO if it's provided
        entity.setUpdatedDate(dto.getUpdatedDate());  // Use the value from DTO if it's provided
        entity.setAnukramank(dto.getAnukramank());
        entity.setHastantaritKharidiKinwaSampaditKelyachiTarikh(dto.getHastantaritKharidiKinwaSampaditKelyachiTarikh());
        entity.setKonatyaKarnasaathi(dto.getKonatyaKarnasaathi());
        entity.setKonakadun(dto.getKonakadun());
        entity.setKararnamaNiwadaNirdeshank(dto.getKararnamaNiwadaNirdeshank());
        entity.setJaminicheKshetraphal(dto.getJaminicheKshetraphal());
        entity.setBhumapanKramankEtyadi(dto.getBhumapanKramankEtyadi());
        entity.setAakarni(dto.getAakarni());
        entity.setJaminichyaSeema(dto.getJaminichyaSeema());
        entity.setJaminisahKharediSampadanEmarati(dto.getJaminisahKharediSampadanEmarati());
        entity.setJaminichiWaEmartichiWilhewat(dto.getJaminichiWaEmartichiWilhewat());
        entity.setVikriPaasunMilaleliRakkam(dto.getVikriPaasunMilaleliRakkam());
        entity.setPramanakachaKramankWaDinank(dto.getPramanakachaKramankWaDinank());
        entity.setMalmattechiWilhewatPanchayatichaTharav(dto.getMalmattechiWilhewatPanchayatichaTharav());
        entity.setMalmattechiWilhewatKalam55(dto.getMalmattechiWilhewatKalam55());
        entity.setShera(dto.getShera());
        entity.setYear(dto.getYear());
        return entity;
    }

    // Update Entity fields from DTO
    private void updateEntityFromDto(JaminichiNondWahi_24 entity, JaminichiNondWahi_24_Dto dto) {
        entity.setEmployeeId(dto.getEmployeeId());
        entity.setEmployeeName(dto.getEmployeeName());
        entity.setGrampanchayatId(dto.getGrampanchayatId());
        entity.setGrampanchayatName(dto.getGrampanchayatName());
        entity.setUpdatedDate(LocalDateTime.now());  // Updated when editing
        entity.setAnukramank(dto.getAnukramank());
        entity.setHastantaritKharidiKinwaSampaditKelyachiTarikh(dto.getHastantaritKharidiKinwaSampaditKelyachiTarikh());
        entity.setKonatyaKarnasaathi(dto.getKonatyaKarnasaathi());
        entity.setKonakadun(dto.getKonakadun());
        entity.setKararnamaNiwadaNirdeshank(dto.getKararnamaNiwadaNirdeshank());
        entity.setJaminicheKshetraphal(dto.getJaminicheKshetraphal());
        entity.setBhumapanKramankEtyadi(dto.getBhumapanKramankEtyadi());
        entity.setAakarni(dto.getAakarni());
        entity.setJaminichyaSeema(dto.getJaminichyaSeema());
        entity.setJaminisahKharediSampadanEmarati(dto.getJaminisahKharediSampadanEmarati());
        entity.setJaminichiWaEmartichiWilhewat(dto.getJaminichiWaEmartichiWilhewat());
        entity.setVikriPaasunMilaleliRakkam(dto.getVikriPaasunMilaleliRakkam());
        entity.setPramanakachaKramankWaDinank(dto.getPramanakachaKramankWaDinank());
        entity.setMalmattechiWilhewatPanchayatichaTharav(dto.getMalmattechiWilhewatPanchayatichaTharav());
        entity.setMalmattechiWilhewatKalam55(dto.getMalmattechiWilhewatKalam55());
        entity.setShera(dto.getShera());
        entity.setYear(dto.getYear());
    }
}
