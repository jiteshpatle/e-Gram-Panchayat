package eGramPanchayat.service.impl;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import eGramPanchayat.dto.LoginRequest;
import eGramPanchayat.dto.RegisterRequest;
import eGramPanchayat.entity.Log;
import eGramPanchayat.entity.User;
import eGramPanchayat.repository.LogRepository;
import eGramPanchayat.repository.UserRepository;
import eGramPanchayat.service.AuthService;
import eGramPanchayat.util.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.MailSendException;
import org.springframework.mail.SimpleMailMessage;


@Service
@Primary
public class AuthServiceImpl implements AuthService, UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private LogRepository logRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;
    
    // Add this field to AuthServiceImpl
    @Autowired
    private JavaMailSender mailSender;

    // In-memory store for invalidated tokens
    private final Set<String> invalidatedTokens = ConcurrentHashMap.newKeySet();
    
    // Add this in AuthServiceImpl
    private final Map<String, Boolean> verifiedUsers = new ConcurrentHashMap<>();

    
    // Add a temporary OTP store (use a cache like Redis in production)
    private final Map<String, String> otpStore = new ConcurrentHashMap<>();
    private final Map<String, LocalDateTime> otpExpiry = new ConcurrentHashMap<>();
    private static final int OTP_VALIDITY_MINUTES = 10;

    @Override
    public String register(RegisterRequest request) {
        if (userRepository.findByUsername(request.getUsername()).isPresent()) {
            return "User Already Exists!";
        }

        // Create new User and set all fields from the request
        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setEmployeeId(request.getEmployeeId());
        user.setEmployeeName(request.getEmployeeName());
        user.setDesignation(request.getDesignation());
        user.setPhone(request.getPhone());
        user.setMail(request.getMail());

        userRepository.save(user);

        return "User Registered Successfully!";
    }
    
    @Override
    public String forgotPassword(String username) {
        Optional<User> user = userRepository.findByUsername(username);

        if (user.isPresent()) {
            String otp = generateOtp();
            otpStore.put(username, otp);
            otpExpiry.put(username, LocalDateTime.now().plusMinutes(OTP_VALIDITY_MINUTES));
            sendOtpToEmail(user.get().getMail(), otp);
            return "OTP Sent Successfully!";
        }
        return "User not found with the provided username.";
    }
    
    private void sendOtpToEmail(String recipientEmail, String otp) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(recipientEmail);
            message.setSubject("Your OTP for Password Recovery");
            message.setText("Dear User,\n\nYour OTP for password recovery is: " + otp + "\n\nPlease use this to proceed with resetting your password. This OTP is valid for 10 minutes.\n\nBest regards,\neGramPanchayat Team");
            mailSender.send(message);
            System.out.println("OTP sent to email: " + recipientEmail); // For debugging
        } catch (MailSendException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to send OTP email: " + e.getMessage(), e);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to send OTP email: Unknown error", e);
        }
    }


    @Override
    public String login(LoginRequest request) {
        Optional<User> userOptional = userRepository.findByUsername(request.getUsername());

        if (userOptional.isPresent() && passwordEncoder.matches(request.getPassword(), userOptional.get().getPassword())) {
            User user = userOptional.get();
            String token = jwtUtil.generateToken(user.getUsername());

            // Create a new Log entry on successful login
            Log log = new Log();
            log.setLoginTime(LocalDateTime.now());
            log.setToken(token);

            // Set employee details from the User entity
            log.setEmployeeId(user.getEmployeeId());

            logRepository.save(log);

            return "Login Successful! Token: " + token; // Return the JWT token
        }

        return "Invalid Username Or Password!";
    }
    
    // minutes:seconds:milliseconds
    @Override
    public String logout(HttpServletRequest request) {
        // Extract token from the Authorization header
        String authorizationHeader = request.getHeader("Authorization");
        String tokenToInvalidate = null;

        if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
            tokenToInvalidate = authorizationHeader.substring(7); // Extract the token
        }

        if (tokenToInvalidate != null && !tokenToInvalidate.isEmpty()) {
            invalidatedTokens.add(tokenToInvalidate); // Add to invalidated set

            // Update the Log entry for the corresponding token
            Log log = logRepository.findByToken(tokenToInvalidate);
            if (log != null) {
                log.setLogoutTime(LocalDateTime.now());

                // Calculate the duration between login and logout
                java.time.Duration duration = java.time.Duration.between(log.getLoginTime(), log.getLogoutTime());

                // Get minutes, seconds, and milliseconds
                long minutes = duration.toMinutes();
                long seconds = duration.getSeconds() % 60;
                long milliseconds = duration.toMillis() % 1000;

                // Format the duration as "mm:ss.SSS"
                String formattedDuration = String.format("%02d:%02d.%03d", minutes, seconds, milliseconds);

                // Set logged-in period as the formatted string
                log.setLoggedInPeriod(formattedDuration);  // Store the formatted string in the column

                logRepository.save(log);
            }

            return "Logout Successful!";
        }
        return "No Token To Invalidate!";
    }
    
    @Override
    public boolean verifyOtp(String username, String otp) {
        String storedOtp = otpStore.get(username);
        LocalDateTime expiryTime = otpExpiry.get(username);

        if (storedOtp != null && storedOtp.equals(otp) && LocalDateTime.now().isBefore(expiryTime)) {
            otpStore.remove(username);
            otpExpiry.remove(username);

            // Mark the user as verified
            verifiedUsers.put(username, true);

            return true;
        }
        return false;
    }


    @Override
    public String resendOtp(String username) {
        Optional<User> user = userRepository.findByUsername(username);

        if (user.isPresent()) {
            // Clear previous verification status
            verifiedUsers.remove(username);

            // Resend OTP by generating and sending again
            String otp = generateOtp();
            otpStore.put(username, otp);
            otpExpiry.put(username, LocalDateTime.now().plusMinutes(OTP_VALIDITY_MINUTES));
            sendOtpToEmail(user.get().getMail(), otp);
            return "OTP Resent Successfully!";
        }

        return "User Not Found!";
    }



    @Override
    public String updatePassword(String username, String newPassword) {
        if (verifiedUsers.getOrDefault(username, false)) {
            Optional<User> userOptional = userRepository.findByUsername(username);

            if (userOptional.isPresent()) {
                User user = userOptional.get();
                user.setPassword(passwordEncoder.encode(newPassword));
                userRepository.save(user);

                verifiedUsers.remove(username);
                return "Password Updated Successfully!";
            }
            return "User not found. Unable to update password.";
        }
        return "OTP not verified or expired. Please request a new OTP.";
    }



    // Helper method to generate a random 6-digit OTP
    private String generateOtp() {
        return String.valueOf((int)(Math.random() * 900000) + 100000); // 6-digit OTP
    }


    public boolean isTokenInvalidated(String token) {
        return invalidatedTokens.contains(token);
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<User> user = userRepository.findByUsername(username);
        if (user.isEmpty()) {
            throw new UsernameNotFoundException("User Not Found With Username: " + username);
        }

        // Convert User entity to Spring Security's UserDetails object
        return org.springframework.security.core.userdetails.User.withUsername(user.get().getUsername())
                .password(user.get().getPassword())
                .authorities("USER")  // You can add roles/authorities as required
                .build();
    }
}