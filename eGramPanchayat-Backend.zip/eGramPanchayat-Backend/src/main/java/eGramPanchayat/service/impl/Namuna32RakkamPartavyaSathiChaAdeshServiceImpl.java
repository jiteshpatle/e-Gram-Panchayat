package eGramPanchayat.service.impl;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import eGramPanchayat.dto.Namuna32RakkamPartavyaSathiChaAdeshDTO;
import eGramPanchayat.entity.Namuna32RakkamPartavyaSathiChaAdesh;
import eGramPanchayat.repository.Namuna32RakkamPartavyaSathiChaAdeshRepository;
import eGramPanchayat.service.Namuna32RakkamPartavyaSathiChaAdeshService;
import jakarta.validation.Valid;

@Service
public class Namuna32RakkamPartavyaSathiChaAdeshServiceImpl implements Namuna32RakkamPartavyaSathiChaAdeshService {

	@Autowired
	private Namuna32RakkamPartavyaSathiChaAdeshRepository service;

	@Override
	public Namuna32RakkamPartavyaSathiChaAdeshDTO create(@Valid Namuna32RakkamPartavyaSathiChaAdeshDTO dto) {

		Namuna32RakkamPartavyaSathiChaAdesh entity = new Namuna32RakkamPartavyaSathiChaAdesh();
		mapToEntity(dto, entity);
		return mapToDTO(service.save(entity));
	}

	@Override
	public Namuna32RakkamPartavyaSathiChaAdeshDTO update(Long id, @Valid Namuna32RakkamPartavyaSathiChaAdeshDTO dto) {
		Namuna32RakkamPartavyaSathiChaAdesh update = service.findById(id).orElse(null);




		// Namuna33VrukshNondViha entity = repo.findById(id).orElse(null);
        //    if (entity != null) {
        //     nullValuechecker(dto, entity);
        //     return repo.save(entity);
        // }
        // return null;
		update.setEmployeeId(dto.getEmployeeId());
		update.setEmployeeName(dto.getEmployeeName());
		update.setGramPanchayatId(dto.getGramPanchayatId());
		update.setGramPanchayatName(dto.getGramPanchayatName());
		update.setPavtiNumber(dto.getPavtiNumber());
		update.setDileliMulRakkamDate(dto.getDileliMulRakkamDate());
		update.setRakkam(dto.getRakkam());
		update.setParatKaryachiRakkam(dto.getParatKaryachiRakkam());
		update.setThevidaracheNav(dto.getThevidaracheNav());
		update.setPartavaKarnaryaPradhikaryacheNav(dto.getPartavaKarnaryaPradhikaryacheNav());
		update.setShera(dto.getShera());
		update.setDinank(dto.getDinank());
		Namuna32RakkamPartavyaSathiChaAdesh updatedEntity = service.save(update);

		return mapToDTO(updatedEntity);
	}

	@Override
	public Namuna32RakkamPartavyaSathiChaAdeshDTO findById(Long id) {
		return service.findById(id).map(this::mapToDTO).orElse(null);
	}

	@Override
	public List<Namuna32RakkamPartavyaSathiChaAdeshDTO> findAll() {
		return service.findAll()
				.stream()
				.map(this::mapToDTO)
				.collect(Collectors.toList());
	}

	@Override
	public boolean delete(Long id) {

		if (service.existsById(id)) {
			service.deleteById(id);
			return true;
		}
		return false;

	}

	// Utility methods for conversion
	private Namuna32RakkamPartavyaSathiChaAdesh mapToEntity(Namuna32RakkamPartavyaSathiChaAdeshDTO dto,
			Namuna32RakkamPartavyaSathiChaAdesh entity) {
		entity.setCreatedDate(dto.getCreatedDate());
		entity.setUpdatedDate(dto.getUpdatedDate());
		entity.setEmployeeId(dto.getEmployeeId());
		entity.setEmployeeName(dto.getEmployeeName());
		entity.setGramPanchayatId(dto.getGramPanchayatId());
		entity.setGramPanchayatName(dto.getGramPanchayatName());
		// entity.setYear(dto.getYear());
		entity.setPavtiNumber(dto.getPavtiNumber());
		entity.setDileliMulRakkamDate(dto.getDileliMulRakkamDate());
		entity.setRakkam(dto.getRakkam());
		entity.setParatKaryachiRakkam(dto.getParatKaryachiRakkam());
		entity.setThevidaracheNav(dto.getThevidaracheNav());
		entity.setPartavaKarnaryaPradhikaryacheNav(dto.getPartavaKarnaryaPradhikaryacheNav());
		entity.setShera(dto.getShera());
		entity.setDinank(dto.getDinank());
		return entity;
	}

	private Namuna32RakkamPartavyaSathiChaAdeshDTO mapToDTO(Namuna32RakkamPartavyaSathiChaAdesh entity) {
		Namuna32RakkamPartavyaSathiChaAdeshDTO dto = new Namuna32RakkamPartavyaSathiChaAdeshDTO();
		// dto.setId(entity.getId());
		// dto.setCreatedDate(entity.getCreatedDate());
		dto.setUpdatedDate(entity.getUpdatedDate());
		dto.setEmployeeId(entity.getEmployeeId());
		dto.setEmployeeName(entity.getEmployeeName());
		dto.setGramPanchayatId(entity.getGramPanchayatId());
		dto.setGramPanchayatName(entity.getGramPanchayatName());
		// dto.setYear(entity.getYear());
		dto.setPavtiNumber(entity.getPavtiNumber());
		dto.setDileliMulRakkamDate(entity.getDileliMulRakkamDate());
		dto.setRakkam(entity.getRakkam());
		dto.setParatKaryachiRakkam(entity.getParatKaryachiRakkam());
		dto.setThevidaracheNav(entity.getThevidaracheNav());
		dto.setPartavaKarnaryaPradhikaryacheNav(entity.getPartavaKarnaryaPradhikaryacheNav());
		dto.setShera(entity.getShera());
		dto.setDinank(entity.getDinank());
		return dto;
	}

}
