package eGramPanchayat.service.impl;

import java.util.*;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eGramPanchayat.dto.Namuna10DTO;
import eGramPanchayat.entity.DynamicField;
import eGramPanchayat.entity.Namuna10Entity;
import eGramPanchayat.repository.Namuna10Repo;
import eGramPanchayat.service.Namuna10Service;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;

@Service
public class Namuna10IMPL implements Namuna10Service {
    @Autowired
    private Namuna10Repo repository;

    // -------------------------------------------------------------------------------------------------------------
    @Override
    public Namuna10Entity save(Namuna10DTO dto) {

        // Convert DTO to entity
        Namuna10Entity entity = convertToEntity(dto);

        // Ensure dynamic fields are set to the parent entity
        if (entity.getItems() != null) {
            for (DynamicField dynamicField : entity.getItems()) {
                dynamicField.setNamuna10Entity(entity); // Set the parent entity to each dynamic field
            }
        }

        // Save the Namuna10Entity and associated DynamicField entities (due to
        // CascadeType.ALL)
        return repository.save(entity);
    }

    // ---------------------------------------------------------------------------------------------------------------
    @Override
    public Namuna10DTO getById(Long id) {
        Optional<Namuna10Entity> entity = repository.findById(id);
        return entity.map(this::convertToDTO).orElse(null);
    }

    // --------------------------------------------------------------------------------------------------------------
    @Transactional
    public Namuna10Entity update(Long id, Namuna10Entity updatedEntity) {
        Namuna10Entity existingEntity = repository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Data not found for ID: " + id));

        // Update static fields
        existingEntity.setEmployeeId(updatedEntity.getEmployeeId());
        existingEntity.setEmployeeName(updatedEntity.getEmployeeName());
        existingEntity.setGramPanchayatId(updatedEntity.getGramPanchayatId());
        existingEntity.setGramPanchayatName(updatedEntity.getGramPanchayatName());
        existingEntity.setPavtiNo(updatedEntity.getPavtiNo());
        existingEntity.setNav(updatedEntity.getNav());
        existingEntity.setYear(updatedEntity.getYear());
        existingEntity.setGharNo(updatedEntity.getGharNo());
        existingEntity.setBillNo(updatedEntity.getBillNo());
        existingEntity.setEkun(updatedEntity.getEkun());
        existingEntity.setDinank(updatedEntity.getDinank());

        // Remove existing dynamic fields
        existingEntity.getItems().clear();

        // Add new dynamic fields
        List<DynamicField> updatedItems = updatedEntity.getItems();
        for (DynamicField item : updatedItems) {
            item.setNamuna10Entity(existingEntity); // Set the parent entity
            existingEntity.getItems().add(item);
        }

        return repository.save(existingEntity);
    }

    // -----------------------------------------------------------------------------------------------------------------
    @Override
    public boolean deleteById(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return true;
        }
        return false;
    }

    // -------------------------------------------------------------------------------------------------------------------
    @Override
    public List<Namuna10DTO> getAll() {
        List<Namuna10Entity> entities = repository.findAll();
        return entities.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    // ----------------------------------------------------------------------------------------------------------------------
    private Namuna10Entity convertToEntity(Namuna10DTO dto) {
        Namuna10Entity entity = new Namuna10Entity();
        entity.setGramPanchayatId(dto.getGramPanchayatId());
        entity.setGramPanchayatName(dto.getGramPanchayatName());
        entity.setEmployeeId(dto.getEmployeeId());
        entity.setEmployeeName(dto.getEmployeeName());
        entity.setPavtiNo(dto.getPavtiNo());
        entity.setNav(dto.getNav());
        entity.setYear(dto.getYear());
        entity.setGharNo(dto.getGharNo());
        entity.setBillNo(dto.getBillNo());
        entity.setDinank(dto.getDinank());
        entity.setEkun(dto.getEkun());
        entity.setItems(dto.getItems());
        return entity;
    }

    private Namuna10DTO convertToDTO(Namuna10Entity entity) {
        Namuna10DTO dto = new Namuna10DTO();
        dto.setEmployeeId(entity.getEmployeeId());
        dto.setEmployeeName(entity.getEmployeeName());
        dto.setGramPanchayatId(entity.getGramPanchayatId());
        dto.setGramPanchayatName(entity.getGramPanchayatName());
        dto.setPavtiNo(entity.getPavtiNo());
        dto.setNav(entity.getNav());
        dto.setYear(entity.getYear());
        dto.setGharNo(entity.getGharNo());
        dto.setBillNo(entity.getBillNo());
        dto.setDinank(entity.getDinank());
        dto.setEkun(entity.getEkun());
        dto.setItems(entity.getItems());
        return dto;
    }
}
