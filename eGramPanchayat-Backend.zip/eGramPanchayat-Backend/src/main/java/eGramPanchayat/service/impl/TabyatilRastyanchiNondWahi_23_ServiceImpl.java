package eGramPanchayat.service.impl;

import eGramPanchayat.dto.TabyatilRastyanchiNondWahi_23_Dto;
import eGramPanchayat.entity.TabyatilRastyanchiNondWahi_23;
import eGramPanchayat.repository.TabyatilRastyanchiNondWahi_23_Repository;
import eGramPanchayat.service.TabyatilRastyanchiNondWahi_23_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TabyatilRastyanchiNondWahi_23_ServiceImpl implements TabyatilRastyanchiNondWahi_23_Service {

    @Autowired
    private TabyatilRastyanchiNondWahi_23_Repository repository;

    @Override
    public TabyatilRastyanchiNondWahi_23_Dto create(TabyatilRastyanchiNondWahi_23_Dto dto) {
        TabyatilRastyanchiNondWahi_23 entity = new TabyatilRastyanchiNondWahi_23();
        mapDtoToEntity(dto, entity);
//        entity.setCreatedDate(LocalDateTime.now());  // Set createdDate to current LocalDateTime
//        entity.setUpdatedDate(LocalDateTime.now());// Set updatedDate to current LocalDateTime
        entity = repository.save(entity);
        return mapEntityToDto(entity);
    }

    @Override
    public TabyatilRastyanchiNondWahi_23_Dto update(Long id, TabyatilRastyanchiNondWahi_23_Dto dto) {

        TabyatilRastyanchiNondWahi_23 update = repository.findById(id).orElse(null);

		if (update != null) {
			// // Update only non-null fields
			// Optional.ofNullable(dto.getGrampanchayatId()).ifPresent(update::setGrampanchayatId);
			// Optional.ofNullable(dto.getGrampanchayatName()).ifPresent(update::setGrampanchayatName);
			// Optional.ofNullable(dto.getEmployeeId()).ifPresent(update::setEmployeeId);
            // Optional.ofNullable(dto.getEmployeeName()).ifPresent(update::setEmployeeName);\
            update.setEmployeeId(dto.getEmployeeId());
            update.setEmployeeName(dto.getEmployeeName());
            update.setGrampanchayatId(dto.getGrampanchayatId());
            update.setGrampanchayatName(dto.getGrampanchayatName());
            update.setUpdatedDate(dto.getUpdatedDate());
            update.setRastyacheNaaw(dto.getRastyacheNaaw());
            update.setGaawPaasun(dto.getGaawPaasun());
            update.setGaawParyant(dto.getGaawParyant());
            update.setLaambiKm(dto.getLaambiKm());
            update.setRundiKm(dto.getRundiKm());
            update.setRastyachaPrakar(dto.getRastyachaPrakar());
            update.setPurnKelyachiTarikh(dto.getPurnKelyachiTarikh());
            update.setPratiKmRastaTayarKarnyasAalelaKharch(dto.getPratiKmRastaTayarKarnyasAalelaKharch());
            update.setDurustyaChaluKharchRupaye(dto.getDurustyaChaluKharchRupaye());
            update.setDurustyaWisheshKharchRupaye(dto.getDurustyaWisheshKharchRupaye());
            update.setDurustyaMulBandhkamKharchRupaye(dto.getDurustyaMulBandhkamKharchRupaye());
            update.setShera(dto.getShera());
            update.setDinank(dto.getDinank());
            // entity.setMalmattechiPadtalniSarpanchSachivSahya(dto.getMalmattechiPadtalniSarpanchSachivSahya());
            update.setDurustyaChaluSwarup(dto.getDurustyaChaluSwarup());
            update.setDurustyaMulBandhkamSwarup(dto.getDurustyaMulBandhkamSwarup());
            update.setDurustyaWisheshSwarup(dto.getDurustyaWisheshSwarup());
            update.setYear(dto.getYear());


        TabyatilRastyanchiNondWahi_23 updatedEntity= repository.save(update);

        return mapEntityToDto(updatedEntity);
        }
        return null;
    }

    @Override
    public boolean delete(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }


    @Override
    public Optional<TabyatilRastyanchiNondWahi_23_Dto> getById(Long id) {
        return Optional.ofNullable(repository.findById(id)
                .map(this::mapEntityToDto)
                .orElseThrow(() -> new RuntimeException("Data Not Found")));
    }

    @Override
    public List<TabyatilRastyanchiNondWahi_23_Dto> getAll() {
        return repository.findAll().stream()
                .map(this::mapEntityToDto)
                .collect(Collectors.toList());
    }

    private void mapDtoToEntity(TabyatilRastyanchiNondWahi_23_Dto dto, TabyatilRastyanchiNondWahi_23 entity) {
        // Map DTO to entity fields
        entity.setEmployeeId(dto.getEmployeeId());
        entity.setEmployeeName(dto.getEmployeeName());
        entity.setGrampanchayatId(dto.getGrampanchayatId());
        entity.setGrampanchayatName(dto.getGrampanchayatName());
//        entity.setAnukramank(dto.getAnukramank());
        entity.setRastyacheNaaw(dto.getRastyacheNaaw());
        entity.setGaawPaasun(dto.getGaawPaasun());
        entity.setGaawParyant(dto.getGaawParyant());
        entity.setLaambiKm(dto.getLaambiKm());
        entity.setRundiKm(dto.getRundiKm());
        entity.setRastyachaPrakar(dto.getRastyachaPrakar());
        entity.setPurnKelyachiTarikh(dto.getPurnKelyachiTarikh());
        entity.setPratiKmRastaTayarKarnyasAalelaKharch(dto.getPratiKmRastaTayarKarnyasAalelaKharch());
        entity.setDurustyaChaluKharchRupaye(dto.getDurustyaChaluKharchRupaye());
        entity.setDurustyaWisheshKharchRupaye(dto.getDurustyaWisheshKharchRupaye());
        entity.setDurustyaMulBandhkamKharchRupaye(dto.getDurustyaMulBandhkamKharchRupaye());
        entity.setShera(dto.getShera());
        entity.setDinank(dto.getDinank());
//        entity.setMalmattechiPadtalniSarpanchSachivSahya(dto.getMalmattechiPadtalniSarpanchSachivSahya());
        entity.setDurustyaChaluSwarup(dto.getDurustyaChaluSwarup());
        entity.setDurustyaMulBandhkamSwarup(dto.getDurustyaMulBandhkamSwarup());
        entity.setDurustyaWisheshSwarup(dto.getDurustyaWisheshSwarup());
        entity.setYear(dto.getYear());
    }

    private TabyatilRastyanchiNondWahi_23_Dto mapEntityToDto(TabyatilRastyanchiNondWahi_23 entity) {
        TabyatilRastyanchiNondWahi_23_Dto dto = new TabyatilRastyanchiNondWahi_23_Dto();
        dto.setId(entity.getId());
        dto.setEmployeeId(entity.getEmployeeId());
        dto.setEmployeeName(entity.getEmployeeName());
        dto.setGrampanchayatId(entity.getGrampanchayatId());
        dto.setGrampanchayatName(entity.getGrampanchayatName());
        dto.setCreatedDate(entity.getCreatedDate());
        dto.setUpdatedDate(entity.getUpdatedDate());
//        dto.setAnukramank(entity.getAnukramank());
        dto.setRastyacheNaaw(entity.getRastyacheNaaw());
        dto.setGaawPaasun(entity.getGaawPaasun());
        dto.setGaawParyant(entity.getGaawParyant());
        dto.setLaambiKm(entity.getLaambiKm());
        dto.setRundiKm(entity.getRundiKm());
        dto.setRastyachaPrakar(entity.getRastyachaPrakar());
        dto.setPurnKelyachiTarikh(entity.getPurnKelyachiTarikh());
        dto.setPratiKmRastaTayarKarnyasAalelaKharch(entity.getPratiKmRastaTayarKarnyasAalelaKharch());
        dto.setDurustyaChaluKharchRupaye(entity.getDurustyaChaluKharchRupaye());
        dto.setDurustyaWisheshKharchRupaye(entity.getDurustyaWisheshKharchRupaye());
        dto.setDurustyaMulBandhkamKharchRupaye(entity.getDurustyaMulBandhkamKharchRupaye());
        dto.setShera(entity.getShera());
        dto.setDinank(entity.getDinank());
//        dto.setMalmattechiPadtalniSarpanchSachivSahya(entity.getMalmattechiPadtalniSarpanchSachivSahya());
        dto.setDurustyaChaluSwarup(entity.getDurustyaChaluSwarup());
        dto.setDurustyaMulBandhkamSwarup(entity.getDurustyaMulBandhkamSwarup());
        dto.setDurustyaWisheshSwarup(entity.getDurustyaWisheshSwarup());
        dto.setYear(entity.getYear());
        return dto;
    }
}
