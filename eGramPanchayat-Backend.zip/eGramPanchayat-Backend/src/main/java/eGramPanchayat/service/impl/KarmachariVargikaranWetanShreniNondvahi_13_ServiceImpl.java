package eGramPanchayat.service.impl;

import eGramPanchayat.dto.KarmachariVargikaranWetanShreniNondvahi_13_Dto;

import eGramPanchayat.entity.KarmachariVargikaranWetanShreniNondvahi_13;
import eGramPanchayat.repository.KarmachariVargikaranWetanShreniNondvahi_13_Repository;
import eGramPanchayat.service.KarmachariVargikaranWetanShreniNondvahi_13_Service;
import jakarta.persistence.EntityNotFoundException;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class KarmachariVargikaranWetanShreniNondvahi_13_ServiceImpl
        implements KarmachariVargikaranWetanShreniNondvahi_13_Service {

    @Autowired
    private KarmachariVargikaranWetanShreniNondvahi_13_Repository repository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public KarmachariVargikaranWetanShreniNondvahi_13_Dto create(KarmachariVargikaranWetanShreniNondvahi_13_Dto Dto) {
        KarmachariVargikaranWetanShreniNondvahi_13 entity = modelMapper.map(Dto,
                KarmachariVargikaranWetanShreniNondvahi_13.class);
        entity = repository.save(entity);
        return modelMapper.map(entity, KarmachariVargikaranWetanShreniNondvahi_13_Dto.class);
    }

    @Override
    public List<KarmachariVargikaranWetanShreniNondvahi_13_Dto> getAll() {
        return repository.findAll().stream()
                .map(entity -> modelMapper.map(entity, KarmachariVargikaranWetanShreniNondvahi_13_Dto.class))
                .collect(Collectors.toList());
    }

    @Override
    public KarmachariVargikaranWetanShreniNondvahi_13_Dto getById(Long id) {
        KarmachariVargikaranWetanShreniNondvahi_13 entity = repository.findById(id).orElseThrow();
        return modelMapper.map(entity, KarmachariVargikaranWetanShreniNondvahi_13_Dto.class);
    }

    // @Override
    // public KarmachariVargikaranWetanShreniNondvahi_13 update(Long id,
    // KarmachariVargikaranWetanShreniNondvahi_13_Dto dto) {

    // Optional<KarmachariVargikaranWetanShreniNondvahi_13> entity1 =
    // repository.findById(id);
    // if (entity1.isPresent()) {
    // KarmachariVargikaranWetanShreniNondvahi_13 entity = entity1.get();
    // // Update only non-null fields
    // Optional.ofNullable(dto.getGrampanchayatId()).ifPresent(entity::setGrampanchayatId);
    // Optional.ofNullable(dto.getGrampanchayatName()).ifPresent(entity::setGrampanchayatName);
    // Optional.ofNullable(dto.getEmployeeId()).ifPresent(entity::setEmployeeId);
    // Optional.ofNullable(dto.getEmployeeName()).ifPresent(entity::setEmployeeName);

    // // entity.setNaav(dto.getNaav());
    // entity.setPadnaam(dto.getPadnaam());
    // entity.setPadanchiSankhya(dto.getPadanchiSankhya());
    // entity.setManjurPadAdeshDinank(dto.getManjurPadAdeshDinank());
    // entity.setManjurPadAdeshKramank(dto.getManjurPadAdeshKramank());
    // entity.setPurnakalikAnshkalik(dto.getPurnakalikAnshkalik());
    // entity.setManjurWetanShreni(dto.getManjurWetanShreni());
    // entity.setKarmacharyacheNaav(dto.getKarmacharyacheNaav());
    // entity.setNiyuktiDinank(dto.getNiyuktiDinank());
    // entity.setYear(dto.getYear());
    // entity.setRemark(dto.getRemark());
    // entity.setDinank(dto.getDinank());
    // entity.setUpdatedDate(dto.getUpdatedDate());

    // return repository.save(entity);
    // } else {
    // // Throw an exception or handle entity not found case
    // throw new EntityNotFoundException("Entry with ID " + id + " not found");
    // }

    // }
    // public KarmachariVargikaranWetanShreniNondvahi_13 update(Long id,
    // KarmachariVargikaranWetanShreniNondvahi_13_Dto dto) {

    // Optional<KarmachariVargikaranWetanShreniNondvahi_13> entityOptional =
    // repository.findById(id);
    // if (entityOptional.isPresent()) {
    // KarmachariVargikaranWetanShreniNondvahi_13 entity = entityOptional.get();

    // // Update fields from DTO to entity, only if they are not null
    // Optional.ofNullable(dto.getGrampanchayatId()).ifPresent(entity::setGrampanchayatId);
    // Optional.ofNullable(dto.getGrampanchayatName()).ifPresent(entity::setGrampanchayatName);
    // Optional.ofNullable(dto.getEmployeeId()).ifPresent(entity::setEmployeeId);
    // Optional.ofNullable(dto.getEmployeeName()).ifPresent(entity::setEmployeeName);
    // Optional.ofNullable(dto.getPadnaam()).ifPresent(entity::setPadnaam);
    // Optional.ofNullable(dto.getPadanchiSankhya()).ifPresent(entity::setPadanchiSankhya);
    // Optional.ofNullable(dto.getManjurPadAdeshKramank()).ifPresent(entity::setManjurPadAdeshKramank);
    // Optional.ofNullable(dto.getManjurPadAdeshDinank()).ifPresent(entity::setManjurPadAdeshDinank);
    // Optional.ofNullable(dto.getPurnakalikAnshkalik()).ifPresent(entity::setPurnakalikAnshkalik);
    // Optional.ofNullable(dto.getManjurWetanShreni()).ifPresent(entity::setManjurWetanShreni);
    // Optional.ofNullable(dto.getKarmacharyacheNaav()).ifPresent(entity::setKarmacharyacheNaav);
    // Optional.ofNullable(dto.getNiyuktiDinank()).ifPresent(entity::setNiyuktiDinank);
    // Optional.ofNullable(dto.getYear()).ifPresent(entity::setYear);
    // Optional.ofNullable(dto.getRemark()).ifPresent(entity::setRemark);
    // Optional.ofNullable(dto.getDinank()).ifPresent(entity::setDinank);

    // // Save updated entity
    // return repository.save(entity);
    // } else {
    // throw new EntityNotFoundException("Entry with ID " + id + " not found");
    // }
    // }

    @Override
    public boolean delete(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public KarmachariVargikaranWetanShreniNondvahi_13_Dto update(Long id,
            KarmachariVargikaranWetanShreniNondvahi_13_Dto dto) {
        Optional<KarmachariVargikaranWetanShreniNondvahi_13> optionalEntity = repository.findById(id);

        if (optionalEntity.isPresent()) {
            KarmachariVargikaranWetanShreniNondvahi_13 entity = optionalEntity.get();

            // // Update only non-null fields
            // Optional.ofNullable(dto.getGrampanchayatId()).ifPresent(entity::setGrampanchayatId);
            // Optional.ofNullable(dto.getGrampanchayatName()).ifPresent(entity::setGrampanchayatName);
            // Optional.ofNullable(dto.getEmployeeId()).ifPresent(entity::setEmployeeId);
            // Optional.ofNullable(dto.getEmployeeName()).ifPresent(entity::setEmployeeName);
            entity.setEmployeeId(dto.getEmployeeId());
            entity.setEmployeeName(dto.getEmployeeName());
            entity.setGrampanchayatId(dto.getGrampanchayatId());
            entity.setGrampanchayatName(dto.getGrampanchayatName());
            entity.setPadnaam(dto.getPadnaam());
            entity.setPadanchiSankhya(dto.getPadanchiSankhya());
            entity.setManjurPadAdeshDinank(dto.getManjurPadAdeshDinank());
            entity.setManjurPadAdeshKramank(dto.getManjurPadAdeshKramank());
            entity.setPurnakalikAnshkalik(dto.getPurnakalikAnshkalik());
            entity.setManjurWetanShreni(dto.getManjurWetanShreni());
            entity.setKarmacharyacheNaav(dto.getKarmacharyacheNaav());
            entity.setNiyuktiDinank(dto.getNiyuktiDinank());
            entity.setYear(dto.getYear());
            entity.setRemark(dto.getRemark());
            entity.setDinank(dto.getDinank());
            entity.setUpdatedDate(dto.getUpdatedDate());

            // Save updated entity
            KarmachariVargikaranWetanShreniNondvahi_13 updatedEntity = repository.save(entity);

            // Convert entity to DTO
            return convertToDto(updatedEntity);
        } else {
            throw new EntityNotFoundException("Entry with ID " + id + " not found");
        }
    }

    // Utility method to convert entity to DTO
    private KarmachariVargikaranWetanShreniNondvahi_13_Dto convertToDto(
            KarmachariVargikaranWetanShreniNondvahi_13 entity) {
        KarmachariVargikaranWetanShreniNondvahi_13_Dto dto = new KarmachariVargikaranWetanShreniNondvahi_13_Dto();
        dto.setGrampanchayatId(entity.getGrampanchayatId());
        dto.setGrampanchayatName(entity.getGrampanchayatName());
        dto.setEmployeeId(entity.getEmployeeId());
        dto.setEmployeeName(entity.getEmployeeName());
        dto.setPadnaam(entity.getPadnaam());
        dto.setPadanchiSankhya(entity.getPadanchiSankhya());
        dto.setManjurPadAdeshDinank(entity.getManjurPadAdeshDinank());
        dto.setManjurPadAdeshKramank(entity.getManjurPadAdeshKramank());
        dto.setPurnakalikAnshkalik(entity.getPurnakalikAnshkalik());
        dto.setManjurWetanShreni(entity.getManjurWetanShreni());
        dto.setKarmacharyacheNaav(entity.getKarmacharyacheNaav());
        dto.setNiyuktiDinank(entity.getNiyuktiDinank());
        dto.setYear(entity.getYear());
        dto.setRemark(entity.getRemark());
        dto.setDinank(entity.getDinank());
        dto.setUpdatedDate(entity.getUpdatedDate());
        return dto;
    }

}
