package eGramPanchayat.service.impl;

import eGramPanchayat.dto.MojmaapWahi_21_Dto;
import eGramPanchayat.entity.MojmaapWahi_21;
import eGramPanchayat.repository.MojmaapWahi_21_Repository;
import eGramPanchayat.service.MojmaapWahi_21_Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class MojmaapWahi_21_ServiceImpl implements MojmaapWahi_21_Service {

    @Autowired
    private MojmaapWahi_21_Repository mojmaapWahiRepository;

    @Override
    public MojmaapWahi_21_Dto addMojmaapWahi(MojmaapWahi_21_Dto mojmaapWahiDto) {
        // Convert DTO to entity
        MojmaapWahi_21 mojmaapWahi = convertDtoToEntity(mojmaapWahiDto);

        // Set the fields from the DTO
        mojmaapWahi.setEmployeeId(mojmaapWahiDto.getEmployeeId());
        mojmaapWahi.setEmployeeName(mojmaapWahiDto.getEmployeeName());
        mojmaapWahi.setGrampanchayatId(mojmaapWahiDto.getGrampanchayatId());
        mojmaapWahi.setGrampanchayatName(mojmaapWahiDto.getGrampanchayatName());
        mojmaapWahi.setCreatedDate(LocalDateTime.now()); // Set created date to current time
        mojmaapWahi.setRemark(mojmaapWahiDto.getRemark());
        mojmaapWahi.setKamachePratyakshaMojmap(mojmaapWahiDto.getKamachePratyakshaMojmap());
        mojmaapWahi.setKamkarnayaAgencyAbhikanacheNaaw(mojmaapWahiDto.getKamkarnayaAgencyAbhikanacheNaaw());
        mojmaapWahi.setKamacheWarnan(mojmaapWahiDto.getKamacheWarnan());
        mojmaapWahi.setMojmap(mojmaapWahiDto.getMojmap());
        mojmaapWahi.setKamacheWarnanKamacheUpashirshVaKshetracheAdhikari(mojmaapWahiDto.getKamacheWarnanKamacheUpashirshVaKshetracheAdhikari());
        mojmaapWahi.setMojmapachaTapshilPariman(mojmaapWahiDto.getMojmapachaTapshilPariman());
        mojmaapWahi.setMojmapachaTapshilLaambi(mojmaapWahiDto.getMojmapachaTapshilLaambi());
        mojmaapWahi.setMojmapachaTapshilRundi(mojmaapWahiDto.getMojmapachaTapshilRundi());
        mojmaapWahi.setMojmapachaTapshilKholiUnchi(mojmaapWahiDto.getMojmapachaTapshilKholiUnchi());
        mojmaapWahi.setMojmapachaTapshilEkun(mojmaapWahiDto.getMojmapachaTapshilEkun());
        mojmaapWahi.setEkunParimanMaapPurvicheHajeriPramaneWarnanKarave(mojmaapWahiDto.getEkunParimanMaapPurvicheHajeriPramaneWarnanKarave());
        mojmaapWahi.setEkunMojmapachaTapshilEkunVaEkunParimanMaap(mojmaapWahiDto.getEkunMojmapachaTapshilEkunVaEkunParimanMaap());
        mojmaapWahi.setDar(mojmaapWahiDto.getDar());
        mojmaapWahi.setRakkam(mojmaapWahiDto.getRakkam());
        mojmaapWahi.setYear(mojmaapWahiDto.getYear());

        // Explicitly set updatedDate to null
        mojmaapWahi.setUpdatedDate(null); // Ensure it is not set during creation

        // Save the entity
        mojmaapWahi = mojmaapWahiRepository.save(mojmaapWahi);

        // Convert saved entity back to DTO
        return convertEntityToDto(mojmaapWahi);
    }


    

    @Override
    public List<MojmaapWahi_21_Dto> getAllMojmaapWahi() {
        return mojmaapWahiRepository.findAll().stream()
                .map(this::convertEntityToDto)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<MojmaapWahi_21_Dto> getMojmaapWahiById(Long id) {
        MojmaapWahi_21 mojmaapWahi = mojmaapWahiRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Data Not Found"));
        return Optional.ofNullable(convertEntityToDto(mojmaapWahi));
    }

    @Override
    public boolean updateMojmaapWahi(Long id, MojmaapWahi_21_Dto mojmaapWahiDto) {
        Optional<MojmaapWahi_21> existingMojmaapWahi = mojmaapWahiRepository.findById(id);
        if (existingMojmaapWahi.isPresent()) {
            MojmaapWahi_21 mojmaapWahi = existingMojmaapWahi.get();

            // Set the updated fields from the DTO
            mojmaapWahi.setEmployeeId(mojmaapWahiDto.getEmployeeId());
            mojmaapWahi.setEmployeeName(mojmaapWahiDto.getEmployeeName());
            mojmaapWahi.setGrampanchayatId(mojmaapWahiDto.getGrampanchayatId());
            mojmaapWahi.setGrampanchayatName(mojmaapWahiDto.getGrampanchayatName());
            mojmaapWahi.setRemark(mojmaapWahiDto.getRemark());
            mojmaapWahi.setKamachePratyakshaMojmap(mojmaapWahiDto.getKamachePratyakshaMojmap());
            mojmaapWahi.setKamkarnayaAgencyAbhikanacheNaaw(mojmaapWahiDto.getKamkarnayaAgencyAbhikanacheNaaw());
            mojmaapWahi.setKamacheWarnan(mojmaapWahiDto.getKamacheWarnan());
            mojmaapWahi.setMojmap(mojmaapWahiDto.getMojmap());
            mojmaapWahi.setKamacheWarnanKamacheUpashirshVaKshetracheAdhikari(mojmaapWahiDto.getKamacheWarnanKamacheUpashirshVaKshetracheAdhikari());
            mojmaapWahi.setMojmapachaTapshilPariman(mojmaapWahiDto.getMojmapachaTapshilPariman());
            mojmaapWahi.setMojmapachaTapshilLaambi(mojmaapWahiDto.getMojmapachaTapshilLaambi());
            mojmaapWahi.setMojmapachaTapshilRundi(mojmaapWahiDto.getMojmapachaTapshilRundi());
            mojmaapWahi.setMojmapachaTapshilKholiUnchi(mojmaapWahiDto.getMojmapachaTapshilKholiUnchi());
            mojmaapWahi.setMojmapachaTapshilEkun(mojmaapWahiDto.getMojmapachaTapshilEkun());
            mojmaapWahi.setEkunParimanMaapPurvicheHajeriPramaneWarnanKarave(mojmaapWahiDto.getEkunParimanMaapPurvicheHajeriPramaneWarnanKarave());
            mojmaapWahi.setEkunMojmapachaTapshilEkunVaEkunParimanMaap(mojmaapWahiDto.getEkunMojmapachaTapshilEkunVaEkunParimanMaap());
            mojmaapWahi.setDar(mojmaapWahiDto.getDar());
            mojmaapWahi.setRakkam(mojmaapWahiDto.getRakkam());
            mojmaapWahi.setYear(mojmaapWahiDto.getYear());

            // Set the updatedDate to the current date and time
            mojmaapWahi.setUpdatedDate(LocalDateTime.now());

            // Save the updated entity
            mojmaapWahiRepository.save(mojmaapWahi);
            return true;
        }
        return false;
    }


    @Override
    public boolean deleteMojmaapWahi(Long id) {
        Optional<MojmaapWahi_21> existingMojmaapWahi = mojmaapWahiRepository.findById(id);
        if (existingMojmaapWahi.isPresent()) {
            mojmaapWahiRepository.deleteById(id);
            return true;
        }
        return false;
    }


    private MojmaapWahi_21 convertDtoToEntity(MojmaapWahi_21_Dto dto) {
        MojmaapWahi_21 entity = new MojmaapWahi_21();
        entity.setEmployeeId(dto.getEmployeeId());
        entity.setEmployeeName(dto.getEmployeeName());
        entity.setGrampanchayatId(dto.getGrampanchayatId());
        entity.setGrampanchayatName(dto.getGrampanchayatName());
        entity.setRemark(dto.getRemark());
        
        entity.setKamachePratyakshaMojmap(dto.getKamachePratyakshaMojmap());
        entity.setKamkarnayaAgencyAbhikanacheNaaw(dto.getKamkarnayaAgencyAbhikanacheNaaw());
        entity.setKamacheWarnan(dto.getKamacheWarnan());
        entity.setMojmap(dto.getMojmap());
        entity.setKamacheWarnanKamacheUpashirshVaKshetracheAdhikari(dto.getKamacheWarnanKamacheUpashirshVaKshetracheAdhikari());
        entity.setMojmapachaTapshilPariman(dto.getMojmapachaTapshilPariman());
        entity.setMojmapachaTapshilLaambi(dto.getMojmapachaTapshilLaambi());
        entity.setMojmapachaTapshilRundi(dto.getMojmapachaTapshilRundi());
        entity.setMojmapachaTapshilKholiUnchi(dto.getMojmapachaTapshilKholiUnchi());
        entity.setMojmapachaTapshilEkun(dto.getMojmapachaTapshilEkun());
        entity.setEkunParimanMaapPurvicheHajeriPramaneWarnanKarave(dto.getEkunParimanMaapPurvicheHajeriPramaneWarnanKarave());
        entity.setEkunMojmapachaTapshilEkunVaEkunParimanMaap(dto.getEkunMojmapachaTapshilEkunVaEkunParimanMaap());
        entity.setDar(dto.getDar());
        entity.setRakkam(dto.getRakkam());
        entity.setYear(dto.getYear());
        return entity;
    }

    private MojmaapWahi_21_Dto convertEntityToDto(MojmaapWahi_21 entity) {
        MojmaapWahi_21_Dto dto = new MojmaapWahi_21_Dto();
        dto.setId(entity.getId());
        dto.setEmployeeId(entity.getEmployeeId());
        dto.setEmployeeName(entity.getEmployeeName());
        dto.setGrampanchayatId(entity.getGrampanchayatId());
        dto.setGrampanchayatName(entity.getGrampanchayatName());
        dto.setCreatedDate(entity.getCreatedDate());
        dto.setUpdatedDate(entity.getUpdatedDate());
        dto.setRemark(entity.getRemark());
        
        dto.setKamachePratyakshaMojmap(entity.getKamachePratyakshaMojmap());
        dto.setKamkarnayaAgencyAbhikanacheNaaw(entity.getKamkarnayaAgencyAbhikanacheNaaw());
        dto.setKamacheWarnan(entity.getKamacheWarnan());
        dto.setMojmap(entity.getMojmap());
        dto.setKamacheWarnanKamacheUpashirshVaKshetracheAdhikari(entity.getKamacheWarnanKamacheUpashirshVaKshetracheAdhikari());
        dto.setMojmapachaTapshilPariman(entity.getMojmapachaTapshilPariman());
        dto.setMojmapachaTapshilLaambi(entity.getMojmapachaTapshilLaambi());
        dto.setMojmapachaTapshilRundi(entity.getMojmapachaTapshilRundi());
        dto.setMojmapachaTapshilKholiUnchi(entity.getMojmapachaTapshilKholiUnchi());
        dto.setMojmapachaTapshilEkun(entity.getMojmapachaTapshilEkun());
        dto.setEkunParimanMaapPurvicheHajeriPramaneWarnanKarave(entity.getEkunParimanMaapPurvicheHajeriPramaneWarnanKarave());
        dto.setEkunMojmapachaTapshilEkunVaEkunParimanMaap(entity.getEkunMojmapachaTapshilEkunVaEkunParimanMaap());
        dto.setDar(entity.getDar());
        dto.setRakkam(entity.getRakkam());
        dto.setYear(entity.getYear());
        return dto;
    }
}
