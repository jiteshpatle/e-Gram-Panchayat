package eGramPanchayat.service.impl;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eGramPanchayat.dto.Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO;
import eGramPanchayat.entity.Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahi;
import eGramPanchayat.repository.Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiRepository;
import eGramPanchayat.service.Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiService;
import jakarta.validation.Valid;

@Service
public class Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiServiceImpl
        implements Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiService {
    @Autowired
    Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiRepository service;

    @Override
    public Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO create(
            @Valid Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO dto) {
        Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahi entity = new Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahi();
        maptoEntity(dto, entity);
        return maptoDTO(service.save(entity));
    }

    @Override

    public Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO update(Long id,
            @Valid Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO dto) {

        Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahi update = service.findById(id).orElse(null);

        if (update != null) {
            // // Update only non-null fields
            // Optional.ofNullable(dto.getGramPanchayatId()).ifPresent(update::setGramPanchayatId);
            // Optional.ofNullable(dto.getGramPanchayatName()).ifPresent(update::setGramPanchayatName);
            // Optional.ofNullable(dto.getEmployeeId()).ifPresent(update::setEmployeeId);
            // Optional.ofNullable(dto.getGramPanchayatName()).ifPresent(update::setEmployeeName);

            // entityToUpdate.setAnuKramank(dto.getAnuKramank());
            update.setGramPanchayatId(dto.getGramPanchayatId());
            update.setGramPanchayatName(dto.getGramPanchayatName());
            update.setEmployeeId(dto.getEmployeeId());
            update.setEmployeeName(dto.getEmployeeName());
            update.setLekhParikshanAhwalVarsh(dto.getLekhParikshanAhwalVarsh());
            update.setlPAhwalPraptaJhalyachiDinank(dto.getlPAhwalPraptaJhalyachiDinank());
            update.setAhwalatilAkshepanchiSankhya(dto.getAhwalatilAkshepanchiSankhya());
            update.setAhwalatilAkshepanchiAnuKramank(dto.getAhwalatilAkshepanchiAnuKramank());
            update.setkMAsanaraAkshepKramank(dto.getkMAsanaraAkshepKramank());
            update.setkMAsanaraAkshepSankhya(dto.getkMAsanaraAkshepSankhya());
            update.setPurtataKarvyachyaAkshepancheKramank(dto.getPurtataKarvyachyaAkshepancheKramank());
            update.setPurtataKarvyachyaAkshepancheSankhya(dto.getPurtataKarvyachyaAkshepancheSankhya());
            update.setGpPAkshepancheKramank(dto.getGpPAkshepancheKramank());
            update.setGpPKeleleAkshepancheSankhya(dto.getGpPKeleleAkshepancheSankhya());
            update.setpKAPSamitiKadePathvilaJavakDinank(dto.getpKAPSamitiKadePathvilaJavakDinank());
            update.setpKAPtSamitiKadePathvilakramank(dto.getpKAPtSamitiKadePathvilakramank());// kramank
            update.setpKAPSamitineJPKadePathvalaThravKrmank(dto.getpKAPSamitineJPKadePathvalaThravKrmank());
            update.setpKAPSamitineJPKadePathvalychaJavakKrmank(dto.getpKAPSamitineJPKadePathvalychaJavakKrmank());
            update.setpKAPSamitineJPKadePathvalychaDinank(dto.getpKAPSamitineJPKadePathvalychaDinank());
            update.setjPYaniManjurKeleleAkshepKramank(dto.getjPYaniManjurKeleleAkshepKramank());
            update.setjPYaniManjurKeleleAkshepSankya(dto.getjPYaniManjurKeleleAkshepSankya());
            update.setsAVVKramankPustakiSamayojan(dto.getsAVVKramankPustakiSamayojan());
            update.setsAVVKramankVasuli(dto.getsAVVKramankVasuli());
            update.setsAVVKramankMulyankan(dto.getsAVVKramankMulyankan());
            update.setsAVVKramankNiyambahya(dto.getsAVVKramankNiyambahya());
            update.setsAVVKramankEkun(dto.getsAVVKramankEkun());
            update.setDinank(dto.getDinank());
            update.setShera(dto.getShera());
            // entityToUpdate.setRemark(dto.getRemark());
            Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahi updateEntity = service.save(update);
            return maptoDTO(updateEntity);

        }
        return null;
    }

    @Override
    public boolean delete(Long id) {
        if (service.existsById(id)) {
            service.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public List<Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO> findAll() {
        return service.findAll()
                .stream()
                .map(this::maptoDTO)
                .collect(Collectors.toList());
    }

    @Override
    public Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO findById(Long id) {
        return service.findById(id).map(this::maptoDTO).orElse(null);
    }

    // Method to map DTO to Entity
    private Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahi maptoEntity(
            Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO dto,
            Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahi entity) {

        // Manual mapping of all fields
        entity.setId(dto.getId());
        entity.setEmployeeId(dto.getEmployeeId());
        entity.setEmployeeName(dto.getEmployeeName());
        entity.setGramPanchayatId(dto.getGramPanchayatId());
        entity.setGramPanchayatName(dto.getGramPanchayatName());

        // entity.setAnuKramank(dto.getAnuKramank());
        entity.setLekhParikshanAhwalVarsh(dto.getLekhParikshanAhwalVarsh());

        entity.setlPAhwalPraptaJhalyachiDinank(dto.getlPAhwalPraptaJhalyachiDinank());

        entity.setAhwalatilAkshepanchiSankhya(dto.getAhwalatilAkshepanchiSankhya());
        entity.setAhwalatilAkshepanchiAnuKramank(dto.getAhwalatilAkshepanchiAnuKramank());

        entity.setkMAsanaraAkshepKramank(dto.getkMAsanaraAkshepKramank());
        entity.setkMAsanaraAkshepSankhya(dto.getkMAsanaraAkshepSankhya());

        entity.setPurtataKarvyachyaAkshepancheKramank(dto.getPurtataKarvyachyaAkshepancheKramank());
        entity.setPurtataKarvyachyaAkshepancheSankhya(dto.getPurtataKarvyachyaAkshepancheSankhya());

        entity.setGpPAkshepancheKramank(dto.getGpPAkshepancheKramank());
        entity.setGpPKeleleAkshepancheSankhya(dto.getGpPKeleleAkshepancheSankhya());

        entity.setpKAPSamitiKadePathvilaJavakDinank(dto.getpKAPSamitiKadePathvilaJavakDinank());
        entity.setpKAPtSamitiKadePathvilakramank(dto.getpKAPtSamitiKadePathvilakramank());

        entity.setpKAPSamitineJPKadePathvalaThravKrmank(dto.getpKAPSamitineJPKadePathvalaThravKrmank());
        entity.setpKAPSamitineJPKadePathvalychaJavakKrmank(dto.getpKAPSamitineJPKadePathvalychaJavakKrmank());
        entity.setpKAPSamitineJPKadePathvalychaDinank(dto.getpKAPSamitineJPKadePathvalychaDinank());

        entity.setjPYaniManjurKeleleAkshepKramank(dto.getjPYaniManjurKeleleAkshepKramank());
        entity.setjPYaniManjurKeleleAkshepSankya(dto.getjPYaniManjurKeleleAkshepSankya());

        entity.setsAVVKramankPustakiSamayojan(dto.getsAVVKramankPustakiSamayojan());
        entity.setsAVVKramankVasuli(dto.getsAVVKramankVasuli());
        entity.setsAVVKramankMulyankan(dto.getsAVVKramankMulyankan());
        entity.setsAVVKramankNiyambahya(dto.getsAVVKramankNiyambahya());
        entity.setsAVVKramankEkun(dto.getsAVVKramankEkun());
        entity.setDinank(dto.getDinank());
        entity.setShera(dto.getShera());
        // entity.setRemark(dto.getRemark());
        entity.setCreatedDate(dto.getCreatedDate());
        entity.setUpdatedDate(dto.getUpdatedDate());

        return entity;
    }

    // Method to map Entity to DTO
    private Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO maptoDTO(
            Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahi entity) {
        Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO dto = new Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO();

        dto.setId(entity.getId());
        dto.setEmployeeId(entity.getEmployeeId());
        dto.setEmployeeName(entity.getEmployeeName());
        dto.setGramPanchayatId(entity.getGramPanchayatId());
        dto.setGramPanchayatName(entity.getGramPanchayatName());
        // dto.setYear(entity.getYear());
        // dto.setAnuKramank(entity.getAnuKramank());
        dto.setLekhParikshanAhwalVarsh(entity.getLekhParikshanAhwalVarsh());

        dto.setlPAhwalPraptaJhalyachiDinank(entity.getlPAhwalPraptaJhalyachiDinank());

        dto.setAhwalatilAkshepanchiSankhya(entity.getAhwalatilAkshepanchiSankhya());
        dto.setAhwalatilAkshepanchiAnuKramank(entity.getAhwalatilAkshepanchiAnuKramank());

        dto.setkMAsanaraAkshepKramank(entity.getkMAsanaraAkshepKramank());
        dto.setkMAsanaraAkshepSankhya(entity.getkMAsanaraAkshepSankhya());

        dto.setPurtataKarvyachyaAkshepancheKramank(entity.getPurtataKarvyachyaAkshepancheKramank());
        dto.setPurtataKarvyachyaAkshepancheSankhya(entity.getPurtataKarvyachyaAkshepancheSankhya());

        dto.setGpPAkshepancheKramank(entity.getGpPAkshepancheKramank());
        dto.setGpPKeleleAkshepancheSankhya(entity.getGpPKeleleAkshepancheSankhya());

        dto.setpKAPSamitiKadePathvilaJavakDinank(entity.getpKAPSamitiKadePathvilaJavakDinank());
        dto.setpKAPtSamitiKadePathvilakramank(entity.getpKAPtSamitiKadePathvilakramank());

        dto.setpKAPSamitineJPKadePathvalaThravKrmank(entity.getpKAPSamitineJPKadePathvalaThravKrmank());
        dto.setpKAPSamitineJPKadePathvalychaJavakKrmank(entity.getpKAPSamitineJPKadePathvalychaJavakKrmank());
        dto.setpKAPSamitineJPKadePathvalychaDinank(entity.getpKAPSamitineJPKadePathvalychaDinank());

        dto.setjPYaniManjurKeleleAkshepKramank(entity.getjPYaniManjurKeleleAkshepKramank());
        dto.setjPYaniManjurKeleleAkshepSankya(entity.getjPYaniManjurKeleleAkshepSankya());

        dto.setsAVVKramankPustakiSamayojan(entity.getsAVVKramankPustakiSamayojan());
        dto.setsAVVKramankVasuli(entity.getsAVVKramankVasuli());
        dto.setsAVVKramankMulyankan(entity.getsAVVKramankMulyankan());
        dto.setsAVVKramankNiyambahya(entity.getsAVVKramankNiyambahya());
        dto.setsAVVKramankEkun(entity.getsAVVKramankEkun());
        dto.setDinank(entity.getDinank());
        dto.setShera(entity.getShera());
        // dto.setRemark(entity.getRemark());
        dto.setCreatedDate(entity.getCreatedDate());
        dto.setUpdatedDate(entity.getUpdatedDate());

        return dto;
    }

}
