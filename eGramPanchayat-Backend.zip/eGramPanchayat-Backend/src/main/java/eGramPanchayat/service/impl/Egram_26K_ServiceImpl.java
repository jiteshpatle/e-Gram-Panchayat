package eGramPanchayat.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import eGramPanchayat.entity.Egram26_K;
import eGramPanchayat.repository.Egram26KRepository;
import eGramPanchayat.service.Egram_26K_Service;

@Component
public class Egram_26K_ServiceImpl implements Egram_26K_Service {

	
	@Autowired
	private Egram26KRepository egram26kRepository;
	
	@Override
	public Egram26_K saveEgram26_K(Egram26_K egram26_K) {
		egram26_K.setJamaGramNidhiTotal(egram26_K.getJamaGramNidhiArthSankalpniyaTartud() + egram26_K.getJamaGramNidhiMagilMahinyapurviPratakshJama() + egram26_K.getJamaGramNidhiChaluMahinyapurviJama());
		egram26_K.setmalmattaKarTotal(egram26_K.getmalmattaKarArthSankalpniyaTartud()+egram26_K.getmalmattaKarMagilMahinyapurviPratakshJama()+egram26_K.getmalmattaKarChaluMahinyapurviJama());
		egram26_K.setdivabattiKarTotal(egram26_K.getdivabattiKarArthSankalpniyaTartud()+egram26_K.getdivabattiKarMagilMahinyapurviPratakshJama()+egram26_K.getdivabattiKarChaluMahinyapurviJama());
		egram26_K.setswachataKarTotal(egram26_K.getswachataKarArthSankalpniyaTartud()+ egram26_K.getswachataKarMagilMahinyapurviPratakshJama()+egram26_K.getswachataKarChaluMahinyapurviJama());
		egram26_K.setdukaneHotelKarTotal(egram26_K.getdukaneHotelKarArthSankalpniyaTartud()+egram26_K.getdukaneHotelKarMagilMahinyapurviPratakshJama() + egram26_K.getdukaneHotelKarChaluMahinyapurviJama());
		egram26_K.setyatraKAarTotal(egram26_K.getyatraKAarArthSankalpniyaTartud() + egram26_K.getyatraKAarMagilMahinyapurviPratakshJama() + egram26_K.getyatraKAarChaluMahinyapurviJama());
		egram26_K.setjatraUttasavTotal(egram26_K.getjatraUttasavArthSankalpniyaTartud() + egram26_K.getjatraUttasavMagilMahinyapurviPratakshJama()+egram26_K.getjatraUttasavChaluMahinyapurviJama());
		egram26_K.setcycleORVahnavarilKarTotal(egram26_K.getcycleORVahnavarilKarArthSankalpniyaTartud() + egram26_K.getcycleORVahnavarilKarMagilMahinyapurviPratakshJama()+ egram26_K.getcycleORVahnavarilKarChaluMahinyapurviJama());
		egram26_K.setJamakarTollTaxTotal(egram26_K.getJamakarTollTaxArthSankalpniyaTartud() + egram26_K.getJamakarTollTaxMagilMahinyapurviPratakshJama() +egram26_K.getJamakarTollTaxChaluMahinyapurviJama());
		egram26_K.setGramNidhitunKharachTotal(egram26_K.getGramNidhitunKharachArthSankalpniyaTartud()+egram26_K.getGramNidhitunKharachMagilMahinyapurviPratakshJama() +egram26_K.getGramNidhitunKharachChaluMahinyapurviJama());
		egram26_K.setSarpanchMandhanTotal(egram26_K.getSarpanchMandhanArthSankalpniyaTartud() + egram26_K.getSarpanchMandhanMagilMahinyapurviPratakshJama() +egram26_K.getSarpanchMandhanChaluMahinyapurviJama());
		egram26_K.setSadasyaBaithakBattaTotal(egram26_K.getSadasyaBaithakBattaArthSankalpniyaTartud() + egram26_K.getSadasyaBaithakBattaMagilMahinyapurviPratakshJama() +egram26_K.getSadasyaBaithakBattaChaluMahinyapurviJama());
		egram26_K.setsarpanchPravasTotal(egram26_K.getsarpanchPravasArthSankalpniyaTartud() + egram26_K.getsarpanchPravasMagilMahinyapurviPratakshJama() +egram26_K.getsarpanchPravasChaluMahinyapurviJama());
		egram26_K.setkarmchariVetanTotal(egram26_K.getkarmchariVetanArthSankalpniyaTartud() +egram26_K.getkarmchariVetanMagilMahinyapurviPratakshJama() + egram26_K.getkarmchariVetanChaluMahinyapurviJama());
		egram26_K.setkarmchariPravasTotal(egram26_K.getkarmchariPravasArthSankalpniyaTartud() + egram26_K.getkarmchariPravasMagilMahinyapurviPratakshJama() + egram26_K.getkarmchariPravasChaluMahinyapurviJama());
		egram26_K.setKaryalinKharachTotal(egram26_K.getKaryalinKharachArthSankalpniyaTartud() + egram26_K.getKaryalinKharachMagilMahinyapurviPratakshJama() + egram26_K.getKaryalinKharachChaluMahinyapurviJama());
		egram26_K.setsangnakKharchTotal(egram26_K.getsangnakKharchArthSankalpniyaTartud() + egram26_K.getsangnakKharchMagilMahinyapurviPratakshJama() + egram26_K.getsangnakKharchChaluMahinyapurviJama());
		egram26_K.setjahiratKharchTotal(egram26_K.getjahiratKharchArthSankalpniyaTartud() + egram26_K.getjahiratKharchMagilMahinyapurviPratakshJama()  + egram26_K.getjahiratKharchChaluMahinyapurviJama());
		egram26_K.setPhogingORGhantagadisathiTelTotal(egram26_K.getPhogingORGhantagadisathiTelArthSankalpniyaTartud() + egram26_K.getPhogingORGhantagadisathiTelMagilMahinyapurviPratakshJama() +egram26_K.getPhogingORGhantagadisathiTelChaluMahinyapurviJama());
		return egram26kRepository.save(egram26_K);
	}

	@Override
	public List<Egram26_K> getAllEgram26_K() {
		return egram26kRepository.findAll();
	}

	@Override
	public Egram26_K updateEgram26KById(Long id, Egram26_K update) {
		Optional<Egram26_K> entry = egram26kRepository.findById(id);
		if(entry.isPresent())
		{
			Egram26_K existing =entry.get();
			existing.setYear(update.getYear());
			existing.setEmployeeId(update.getEmployeeId());
			existing.setEmployeeName(update.getEmployeeName());
			existing.setGrampanchayatId(update.getGrampanchayatId());
			existing.setGrampanchayatName(update.getGrampanchayatName());
			existing.setRemark(update.getRemark());
			existing.setUpdatedDate(LocalDateTime.now());
			
			existing.setJamaGramNidhiArthSankalpniyaTartud(update.getJamaGramNidhiArthSankalpniyaTartud());
			existing.setJamaGramNidhiMagilMahinyapurviPratakshJama(update.getJamaGramNidhiMagilMahinyapurviPratakshJama());
			existing.setJamaGramNidhiChaluMahinyapurviJama(update.getJamaGramNidhiChaluMahinyapurviJama());
			existing.setJamaGramNidhiTotal(existing.getJamaGramNidhiArthSankalpniyaTartud() +existing.getJamaGramNidhiMagilMahinyapurviPratakshJama()+existing.getJamaGramNidhiChaluMahinyapurviJama());
			
			existing.setmalmattaKarArthSankalpniyaTartud(update.getmalmattaKarArthSankalpniyaTartud());
			existing.setmalmattaKarMagilMahinyapurviPratakshJama(update.getmalmattaKarMagilMahinyapurviPratakshJama());
			existing.setmalmattaKarChaluMahinyapurviJama(update.getmalmattaKarChaluMahinyapurviJama());
			existing.setmalmattaKarTotal(existing.getmalmattaKarArthSankalpniyaTartud()+existing.getmalmattaKarMagilMahinyapurviPratakshJama()+existing.getmalmattaKarChaluMahinyapurviJama());
			
			existing.setdivabattiKarArthSankalpniyaTartud(update.getdivabattiKarArthSankalpniyaTartud());
			existing.setdivabattiKarMagilMahinyapurviPratakshJama(update.getdivabattiKarMagilMahinyapurviPratakshJama());
			existing.setdivabattiKarChaluMahinyapurviJama(update.getdivabattiKarChaluMahinyapurviJama());
			existing.setdivabattiKarTotal(existing.getdivabattiKarArthSankalpniyaTartud()+existing.getdivabattiKarMagilMahinyapurviPratakshJama()+existing.getdivabattiKarChaluMahinyapurviJama());
			
			existing.setswachataKarArthSankalpniyaTartud(update.getswachataKarArthSankalpniyaTartud());
			existing.setswachataKarMagilMahinyapurviPratakshJama(update.getswachataKarMagilMahinyapurviPratakshJama());
			existing.setswachataKarChaluMahinyapurviJama(update.getswachataKarChaluMahinyapurviJama());
			existing.setswachataKarTotal(existing.getswachataKarArthSankalpniyaTartud()+ existing.getswachataKarMagilMahinyapurviPratakshJama()+existing.getswachataKarChaluMahinyapurviJama());
			
			existing.setdukaneHotelKarArthSankalpniyaTartud(update.getdukaneHotelKarArthSankalpniyaTartud());
			existing.setdukaneHotelKarMagilMahinyapurviPratakshJama(update.getdukaneHotelKarMagilMahinyapurviPratakshJama());
			existing.setdukaneHotelKarChaluMahinyapurviJama(update.getdukaneHotelKarChaluMahinyapurviJama());
			existing.setdukaneHotelKarTotal(existing.getdukaneHotelKarArthSankalpniyaTartud()+existing.getdukaneHotelKarMagilMahinyapurviPratakshJama() + existing.getdukaneHotelKarChaluMahinyapurviJama());
			
			existing.setyatraKAarArthSankalpniyaTartud(update.getyatraKAarArthSankalpniyaTartud());
			existing.setyatraKAarMagilMahinyapurviPratakshJama(update.getyatraKAarMagilMahinyapurviPratakshJama());
			existing.setyatraKAarChaluMahinyapurviJama(update.getyatraKAarChaluMahinyapurviJama());
			existing.setyatraKAarTotal(existing.getyatraKAarArthSankalpniyaTartud() + existing.getyatraKAarMagilMahinyapurviPratakshJama() + existing.getyatraKAarChaluMahinyapurviJama());
			
			existing.setjatraUttasavArthSankalpniyaTartud(update.getjatraUttasavArthSankalpniyaTartud());
			existing.setjatraUttasavMagilMahinyapurviPratakshJama(update.getjatraUttasavMagilMahinyapurviPratakshJama());
			existing.setjatraUttasavChaluMahinyapurviJama(update.getjatraUttasavChaluMahinyapurviJama());
			existing.setjatraUttasavTotal(existing.getjatraUttasavArthSankalpniyaTartud() + existing.getjatraUttasavMagilMahinyapurviPratakshJama()+existing.getjatraUttasavChaluMahinyapurviJama());
			
			existing.setcycleORVahnavarilKarArthSankalpniyaTartud(update.getcycleORVahnavarilKarArthSankalpniyaTartud());
			existing.setcycleORVahnavarilKarMagilMahinyapurviPratakshJama(update.getcycleORVahnavarilKarMagilMahinyapurviPratakshJama());
			existing.setcycleORVahnavarilKarChaluMahinyapurviJama(update.getcycleORVahnavarilKarChaluMahinyapurviJama());
			existing.setcycleORVahnavarilKarTotal(existing.getcycleORVahnavarilKarArthSankalpniyaTartud() + existing.getcycleORVahnavarilKarMagilMahinyapurviPratakshJama()+ existing.getcycleORVahnavarilKarChaluMahinyapurviJama());
			
			existing.setJamakarTollTaxArthSankalpniyaTartud(update.getJamakarTollTaxArthSankalpniyaTartud());
			existing.setJamakarTollTaxMagilMahinyapurviPratakshJama(update.getJamakarTollTaxMagilMahinyapurviPratakshJama());
			existing.setJamakarTollTaxChaluMahinyapurviJama(update.getJamakarTollTaxChaluMahinyapurviJama());
			existing.setJamakarTollTaxTotal(existing.getJamakarTollTaxArthSankalpniyaTartud() + existing.getJamakarTollTaxMagilMahinyapurviPratakshJama() +existing.getJamakarTollTaxChaluMahinyapurviJama());
			
			existing.setGramNidhitunKharachArthSankalpniyaTartud(update.getGramNidhitunKharachArthSankalpniyaTartud());
			existing.setGramNidhitunKharachMagilMahinyapurviPratakshJama(update.getGramNidhitunKharachMagilMahinyapurviPratakshJama());
			existing.setGramNidhitunKharachChaluMahinyapurviJama(update.getGramNidhitunKharachChaluMahinyapurviJama());
			existing.setGramNidhitunKharachTotal(existing.getGramNidhitunKharachArthSankalpniyaTartud()+existing.getGramNidhitunKharachMagilMahinyapurviPratakshJama() +existing.getGramNidhitunKharachChaluMahinyapurviJama());
			
			existing.setSarpanchMandhanArthSankalpniyaTartud(update.getSarpanchMandhanArthSankalpniyaTartud());
			existing.setSarpanchMandhanMagilMahinyapurviPratakshJama(update.getSarpanchMandhanMagilMahinyapurviPratakshJama());
			existing.setSarpanchMandhanChaluMahinyapurviJama(update.getSarpanchMandhanChaluMahinyapurviJama());
			existing.setSarpanchMandhanTotal(existing.getSarpanchMandhanArthSankalpniyaTartud() + existing.getSarpanchMandhanMagilMahinyapurviPratakshJama() +existing.getSarpanchMandhanChaluMahinyapurviJama());
			
			existing.setSadasyaBaithakBattaArthSankalpniyaTartud(update.getSadasyaBaithakBattaArthSankalpniyaTartud());
			existing.setSadasyaBaithakBattaMagilMahinyapurviPratakshJama(update.getSadasyaBaithakBattaMagilMahinyapurviPratakshJama());
			existing.setSadasyaBaithakBattaChaluMahinyapurviJama(update.getSadasyaBaithakBattaChaluMahinyapurviJama());
			existing.setSadasyaBaithakBattaTotal(existing.getSadasyaBaithakBattaArthSankalpniyaTartud() + existing.getSadasyaBaithakBattaMagilMahinyapurviPratakshJama() +existing.getSadasyaBaithakBattaChaluMahinyapurviJama());
			
			existing.setsarpanchPravasArthSankalpniyaTartud(update.getsarpanchPravasArthSankalpniyaTartud());
			existing.setsarpanchPravasMagilMahinyapurviPratakshJama(update.getsarpanchPravasMagilMahinyapurviPratakshJama());
			existing.setsarpanchPravasChaluMahinyapurviJama(update.getsarpanchPravasChaluMahinyapurviJama());
			existing.setsarpanchPravasTotal(existing.getsarpanchPravasArthSankalpniyaTartud() + existing.getsarpanchPravasMagilMahinyapurviPratakshJama() +existing.getsarpanchPravasChaluMahinyapurviJama());
			
			existing.setkarmchariVetanArthSankalpniyaTartud(update.getkarmchariVetanArthSankalpniyaTartud());
			existing.setkarmchariVetanMagilMahinyapurviPratakshJama(update.getkarmchariVetanMagilMahinyapurviPratakshJama());
			existing.setkarmchariVetanChaluMahinyapurviJama(update.getkarmchariVetanChaluMahinyapurviJama());
			existing.setkarmchariVetanTotal(existing.getkarmchariVetanArthSankalpniyaTartud() +existing.getkarmchariVetanMagilMahinyapurviPratakshJama() + existing.getkarmchariVetanChaluMahinyapurviJama());
			
			existing.setkarmchariPravasArthSankalpniyaTartud(update.getkarmchariPravasArthSankalpniyaTartud());
			existing.setkarmchariPravasMagilMahinyapurviPratakshJama(update.getkarmchariPravasMagilMahinyapurviPratakshJama());
			existing.setkarmchariPravasChaluMahinyapurviJama(update.getkarmchariPravasChaluMahinyapurviJama());
			existing.setkarmchariPravasTotal(existing.getkarmchariPravasArthSankalpniyaTartud() + existing.getkarmchariPravasMagilMahinyapurviPratakshJama() + existing.getkarmchariPravasChaluMahinyapurviJama());
			
			existing.setKaryalinKharachArthSankalpniyaTartud(update.getKaryalinKharachArthSankalpniyaTartud());
			existing.setKaryalinKharachMagilMahinyapurviPratakshJama(update.getKaryalinKharachMagilMahinyapurviPratakshJama());
			existing.setKaryalinKharachChaluMahinyapurviJama(update.getKaryalinKharachChaluMahinyapurviJama());
			existing.setKaryalinKharachTotal(existing.getKaryalinKharachArthSankalpniyaTartud() + existing.getKaryalinKharachMagilMahinyapurviPratakshJama() + existing.getKaryalinKharachChaluMahinyapurviJama());
			
			existing.setsangnakKharchArthSankalpniyaTartud(update.getsangnakKharchArthSankalpniyaTartud());
			existing.setsangnakKharchMagilMahinyapurviPratakshJama(update.getsangnakKharchMagilMahinyapurviPratakshJama());
			existing.setsangnakKharchChaluMahinyapurviJama(update.getsangnakKharchChaluMahinyapurviJama());
			existing.setsangnakKharchTotal(existing.getsangnakKharchArthSankalpniyaTartud() + existing.getsangnakKharchMagilMahinyapurviPratakshJama() + existing.getsangnakKharchChaluMahinyapurviJama());
			
			existing.setjahiratKharchArthSankalpniyaTartud(update.getjahiratKharchArthSankalpniyaTartud());
			existing.setjahiratKharchMagilMahinyapurviPratakshJama(update.getjahiratKharchMagilMahinyapurviPratakshJama());
			existing.setjahiratKharchChaluMahinyapurviJama(update.getjahiratKharchChaluMahinyapurviJama());
			existing.setjahiratKharchTotal(existing.getjahiratKharchArthSankalpniyaTartud() + existing.getjahiratKharchMagilMahinyapurviPratakshJama()  + existing.getjahiratKharchChaluMahinyapurviJama());
			
			existing.setPhogingORGhantagadisathiTelArthSankalpniyaTartud(update.getPhogingORGhantagadisathiTelArthSankalpniyaTartud());
			existing.setPhogingORGhantagadisathiTelMagilMahinyapurviPratakshJama(update.getPhogingORGhantagadisathiTelMagilMahinyapurviPratakshJama());
			existing.setPhogingORGhantagadisathiTelChaluMahinyapurviJama(update.getPhogingORGhantagadisathiTelChaluMahinyapurviJama());
			existing.setPhogingORGhantagadisathiTelTotal(existing.getPhogingORGhantagadisathiTelArthSankalpniyaTartud() + existing.getPhogingORGhantagadisathiTelMagilMahinyapurviPratakshJama() +existing.getPhogingORGhantagadisathiTelChaluMahinyapurviJama());
			
			return egram26kRepository.save(existing);
		}
		return null;
	}

	@Override
	public Optional<Egram26_K> getEgram26KById(long id) {
		Optional<Egram26_K> egram26K = egram26kRepository.findById(id);
		if(egram26K.isPresent())
		{
			return egram26K;
		}
		else
			throw new RuntimeException("Egram26K record not found for ID: " + id);
    
	}

	@Override
	public boolean deleteEgram26(Long id) {
		
		if(!egram26kRepository.existsById(id))
		{
			throw new IllegalArgumentException("Data Not Found");
		}
		egram26kRepository.deleteById(id);
		return true;
	}

	

	
}
