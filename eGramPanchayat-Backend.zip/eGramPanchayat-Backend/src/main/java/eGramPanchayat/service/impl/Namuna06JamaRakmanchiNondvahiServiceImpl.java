package eGramPanchayat.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eGramPanchayat.dto.Namuna06JamaRakmanchiNondvahiDto;
import eGramPanchayat.entity.Namuna06JamaRakmanchiNondvahi;
import eGramPanchayat.repository.Namuna06JamaRakmanchiNondvahiRepository;
import eGramPanchayat.service.Namuna06JamaRakmanchiNondvahiService;
import jakarta.persistence.EntityNotFoundException;

@Service
public class Namuna06JamaRakmanchiNondvahiServiceImpl implements Namuna06JamaRakmanchiNondvahiService {

    @Autowired
    private Namuna06JamaRakmanchiNondvahiRepository repository;

    @Override
    public Namuna06JamaRakmanchiNondvahiDto create(Namuna06JamaRakmanchiNondvahiDto dto) {
        Namuna06JamaRakmanchiNondvahi entity = new Namuna06JamaRakmanchiNondvahi();

        // Map fields from DTO to Entity
        entity.setEmployeeId(dto.getEmployeeId());
        entity.setEmployeeName(dto.getEmployeeName());
        entity.setGrampanchayatId(dto.getGrampanchayatId());
        entity.setGrampanchayatName(dto.getGrampanchayatName());
        entity.setLekhaShirsh(dto.getLekhaShirsh());
        entity.setShera(dto.getShera());
        entity.setArthsankalpiyaAnudan(dto.getArthsankalpiyaAnudan());
        entity.setMahinyaBaddalchiEkunRakkam(dto.getMahinyaBaddalchiEkunRakkam());
        entity.setMaghilMahinyachaAkherparyantchiRakkam(dto.getMaghilMahinyachaAkherparyantchiRakkam());
        entity.setMaghePasunPudheChaluEkunRakkam(dto.getMaghePasunPudheChaluEkunRakkam());
        entity.setDay(dto.getDay());
        entity.setValue(dto.getValue());
        entity.setYear(dto.getYear());
        entity.setMonth(dto.getMonth());
     

        // Save entity and return the saved object as DTO
        Namuna06JamaRakmanchiNondvahi savedEntity = repository.save(entity);
        return mapToDto(savedEntity);
    }

    // Convert entity to DTO
    private Namuna06JamaRakmanchiNondvahiDto mapToDto(Namuna06JamaRakmanchiNondvahi entity) {
        Namuna06JamaRakmanchiNondvahiDto dto = new Namuna06JamaRakmanchiNondvahiDto();

        // Map fields from Entity to DTO
        dto.setId(entity.getId());
        dto.setCreatedDate(entity.getCreatedDate());
        dto.setUpdatedDate(entity.getUpdatedDate());
        dto.setEmployeeId(entity.getEmployeeId());
        dto.setEmployeeName(entity.getEmployeeName());
        dto.setGrampanchayatId(entity.getGrampanchayatId());
        dto.setGrampanchayatName(entity.getGrampanchayatName());
        dto.setLekhaShirsh(entity.getLekhaShirsh());
        dto.setShera(entity.getShera());
        dto.setArthsankalpiyaAnudan(entity.getArthsankalpiyaAnudan());
        dto.setMahinyaBaddalchiEkunRakkam(entity.getMahinyaBaddalchiEkunRakkam());
        dto.setMaghilMahinyachaAkherparyantchiRakkam(entity.getMaghilMahinyachaAkherparyantchiRakkam());
        dto.setMaghePasunPudheChaluEkunRakkam(entity.getMaghePasunPudheChaluEkunRakkam());
        dto.setDay(entity.getDay());
        dto.setValue(entity.getValue());
        dto.setYear(entity.getYear());
        dto.setMonth(entity.getMonth());
        

        return dto;
    }


    @Override
    public Optional<Namuna06JamaRakmanchiNondvahiDto> getById(Long id) {
        Namuna06JamaRakmanchiNondvahi entity = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Data Not Found"));
        return Optional.ofNullable(mapToDto(entity));
    }

    @Override
    public List<Namuna06JamaRakmanchiNondvahiDto> getAll() {
        return repository.findAll().stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<Namuna06JamaRakmanchiNondvahiDto> update(Long id, Namuna06JamaRakmanchiNondvahiDto dto) {
        // Fetch existing entity from the repository
        Optional<Namuna06JamaRakmanchiNondvahi> optionalEntity = repository.findById(id);

        if (optionalEntity.isPresent()) {
            Namuna06JamaRakmanchiNondvahi entity = optionalEntity.get();

            // Map updated fields from DTO to the entity
            entity.setEmployeeId(dto.getEmployeeId());
            entity.setEmployeeName(dto.getEmployeeName());
            entity.setGrampanchayatId(dto.getGrampanchayatId());
            entity.setGrampanchayatName(dto.getGrampanchayatName());
            entity.setLekhaShirsh(dto.getLekhaShirsh());
            entity.setShera(dto.getShera());
            entity.setArthsankalpiyaAnudan(dto.getArthsankalpiyaAnudan());
            entity.setMahinyaBaddalchiEkunRakkam(dto.getMahinyaBaddalchiEkunRakkam());
            entity.setMaghilMahinyachaAkherparyantchiRakkam(dto.getMaghilMahinyachaAkherparyantchiRakkam());
            entity.setMaghePasunPudheChaluEkunRakkam(dto.getMaghePasunPudheChaluEkunRakkam());
            entity.setDay(dto.getDay());
            entity.setValue(dto.getValue());
            entity.setYear(dto.getYear());
            entity.setMonth(dto.getMonth());

            // Save the updated entity
            Namuna06JamaRakmanchiNondvahi updatedEntity = repository.save(entity);

            // Return the updated entity as DTO
            return Optional.ofNullable(mapToDto(updatedEntity));
        } else {
            throw new EntityNotFoundException("Data Not Found");
        }
    }


    @Override
    public boolean delete(Long id) {
        Namuna06JamaRakmanchiNondvahi entity = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Data Not Found"));
        repository.delete(entity);
		return true;
    }

   
}
