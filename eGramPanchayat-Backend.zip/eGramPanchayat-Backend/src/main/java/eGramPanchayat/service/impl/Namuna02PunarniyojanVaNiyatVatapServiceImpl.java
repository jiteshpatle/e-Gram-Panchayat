package eGramPanchayat.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eGramPanchayat.dto.Namuna02PunarniyojanVaNiyatVatapDTO;
import eGramPanchayat.entity.Namuna02PunarniyojanVaNiyatVatap;
import eGramPanchayat.repository.Namuna02PunarniyojanVaNiyatVatapRepository;
import eGramPanchayat.service.Namuna02PunarniyojanVaNiyatVatapService;
import jakarta.validation.Valid;
import jakarta.persistence.EntityNotFoundException;

@Service
public class Namuna02PunarniyojanVaNiyatVatapServiceImpl implements Namuna02PunarniyojanVaNiyatVatapService {

    @Autowired
    private Namuna02PunarniyojanVaNiyatVatapRepository repository;

    @Override
    public Namuna02PunarniyojanVaNiyatVatapDTO saveDetails(@Valid Namuna02PunarniyojanVaNiyatVatapDTO dto) {
        Namuna02PunarniyojanVaNiyatVatap entity = mapToEntity(dto);
        Namuna02PunarniyojanVaNiyatVatap savedEntity = repository.save(entity);
        return mapToDto(savedEntity);
    }

    @Override
    public List<Namuna02PunarniyojanVaNiyatVatapDTO> getAllDetails() {
        return repository.findAll().stream()
            .map(this::mapToDto)
            .collect(Collectors.toList());
    }

    @Override
    public Optional<Namuna02PunarniyojanVaNiyatVatapDTO> getDetailsById(Long id) {
        Namuna02PunarniyojanVaNiyatVatap entity = repository.findById(id)
            .orElseThrow(() -> new EntityNotFoundException("Data Not Found"));
        return Optional.of(mapToDto(entity));
    }

    @Override
    public boolean deleteDetails(Long id) {
        Namuna02PunarniyojanVaNiyatVatap entity = repository.findById(id)
            .orElseThrow(() -> new EntityNotFoundException("Data Not Found"));
        repository.delete(entity);
        return true;
    }

    @Override
    public Namuna02PunarniyojanVaNiyatVatapDTO updateDetails(Long id, @Valid Namuna02PunarniyojanVaNiyatVatapDTO dto) {
        Namuna02PunarniyojanVaNiyatVatap entity = repository.findById(id)
            .orElseThrow(() -> new EntityNotFoundException("Data Not Found"));
        
        // Update fields from DTO to Entity, preserving createdDate
        mapDtoToEntity(dto, entity);
        Namuna02PunarniyojanVaNiyatVatap updatedEntity = repository.save(entity);
        return mapToDto(updatedEntity);
    }

    // Map DTO to Entity for create/update
    private Namuna02PunarniyojanVaNiyatVatap mapToEntity(Namuna02PunarniyojanVaNiyatVatapDTO dto) {
        Namuna02PunarniyojanVaNiyatVatap entity = new Namuna02PunarniyojanVaNiyatVatap();
        entity.setId(dto.getId());
        entity.setJamaRakmecheMukhyaShirshak(dto.getJamaRakmecheMukhyaShirshak());
        entity.setManjurArthsankalp(dto.getManjurArthsankalp());
        entity.setSudharitAndaz(dto.getSudharitAndaz());
        entity.setSudharitAdhikVaja(dto.getSudharitAdhikVaja());
        entity.setKharchachePramukhShirsh(dto.getKharchachePramukhShirsh());
        entity.setManjurRakkam(dto.getManjurRakkam());
        entity.setKharchachaSudharitAndaz(dto.getKharchachaSudharitAndaz());
        entity.setKharchachaAdhikVaja(dto.getKharchachaAdhikVaja());
        entity.setShera(dto.getShera());
        entity.setEmployeeId(dto.getEmployeeId());
        entity.setEmployeeName(dto.getEmployeeName());
        entity.setGrampanchayatId(dto.getGrampanchayatId());
        entity.setGrampanchayatName(dto.getGrampanchayatName());
        entity.setYear(dto.getYear());
        entity.setCreatedDate(dto.getCreatedDate());
        entity.setUpdatedDate(dto.getUpdatedDate());
        entity.setDnyapanRupees(dto.getDnyapanRupees());
        entity.setMonth(dto.getMonth());
        return entity;
    }

    // Update existing entity with DTO values
    private void mapDtoToEntity(Namuna02PunarniyojanVaNiyatVatapDTO dto, Namuna02PunarniyojanVaNiyatVatap entity) {
        entity.setJamaRakmecheMukhyaShirshak(dto.getJamaRakmecheMukhyaShirshak());
        entity.setManjurArthsankalp(dto.getManjurArthsankalp());
        entity.setSudharitAndaz(dto.getSudharitAndaz());
        entity.setSudharitAdhikVaja(dto.getSudharitAdhikVaja());
        entity.setKharchachePramukhShirsh(dto.getKharchachePramukhShirsh());
        entity.setManjurRakkam(dto.getManjurRakkam());
        entity.setKharchachaSudharitAndaz(dto.getKharchachaSudharitAndaz());
        entity.setKharchachaAdhikVaja(dto.getKharchachaAdhikVaja());
        entity.setShera(dto.getShera());
        entity.setEmployeeId(dto.getEmployeeId());
        entity.setEmployeeName(dto.getEmployeeName());
        entity.setGrampanchayatId(dto.getGrampanchayatId());
        entity.setGrampanchayatName(dto.getGrampanchayatName());
        entity.setYear(dto.getYear());
        entity.setUpdatedDate(dto.getUpdatedDate());  // Preserve the createdDate and update only updatedDate
        entity.setDnyapanRupees(dto.getDnyapanRupees());
        entity.setMonth(dto.getMonth());
    }

    // Map Entity to DTO for returning data
    private Namuna02PunarniyojanVaNiyatVatapDTO mapToDto(Namuna02PunarniyojanVaNiyatVatap entity) {
        Namuna02PunarniyojanVaNiyatVatapDTO dto = new Namuna02PunarniyojanVaNiyatVatapDTO();
        dto.setId(entity.getId());
        dto.setJamaRakmecheMukhyaShirshak(entity.getJamaRakmecheMukhyaShirshak());
        dto.setManjurArthsankalp(entity.getManjurArthsankalp());
        dto.setSudharitAndaz(entity.getSudharitAndaz());
        dto.setSudharitAdhikVaja(entity.getSudharitAdhikVaja());
        dto.setKharchachePramukhShirsh(entity.getKharchachePramukhShirsh());
        dto.setManjurRakkam(entity.getManjurRakkam());
        dto.setKharchachaSudharitAndaz(entity.getKharchachaSudharitAndaz());
        dto.setKharchachaAdhikVaja(entity.getKharchachaAdhikVaja());
        dto.setShera(entity.getShera());
        dto.setEmployeeId(entity.getEmployeeId());
        dto.setEmployeeName(entity.getEmployeeName());
        dto.setGrampanchayatId(entity.getGrampanchayatId());
        dto.setGrampanchayatName(entity.getGrampanchayatName());
        dto.setYear(entity.getYear());
        dto.setCreatedDate(entity.getCreatedDate());
        dto.setUpdatedDate(entity.getUpdatedDate());
        dto.setDnyapanRupees(entity.getDnyapanRupees());
        dto.setMonth(entity.getMonth());
        return dto;
    }
}
