package eGramPanchayat.service.impl;

import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import eGramPanchayat.dto.GuntonukNamuna25Dto;
import eGramPanchayat.entity.GuntonukNamuna25;

import eGramPanchayat.repository.GuntonukNamuna25Repository;
import eGramPanchayat.service.GuntonukNamun25Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class GuntonukNamuna25ServiceImpl implements GuntonukNamun25Service {

    @Autowired
    private GuntonukNamuna25Repository guntonukRepository;

    @Override
    public GuntonukNamuna25Dto save(GuntonukNamuna25Dto guntonukDTO) {
        GuntonukNamuna25 entity = mapToEntity(guntonukDTO);
        entity = guntonukRepository.save(entity);
        return mapToDto(entity);
    }

    @Override
    public List<GuntonukNamuna25Dto> findAll() {
        return guntonukRepository.findAll().stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    public GuntonukNamuna25Dto findById(Long id) {
        GuntonukNamuna25 entity = guntonukRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("GuntonukNamuna25 not found for ID: " + id));
        return mapToDto(entity);
    }

    @Override
    public GuntonukNamuna25Dto update(Long id, GuntonukNamuna25Dto dto) {
        GuntonukNamuna25 update = guntonukRepository.findById(id).orElse(null);

        if (update != null) {
            

            update.setEmployeeId(dto.getEmployeeId());
            update.setEmployeeName(dto.getEmployeeName());
            update.setGrampanchyatId(dto.getGrampanchyatId());
            update.setGrampanchyatName(dto.getGrampanchyatName());
            update.setGuntonukiciTarikha(dto.getGuntonukiciTarikha());
            update.setGuntonukiciTarikha(dto.getGuntonukiciTarikha());
            update.setGuntonukiciTapisila(dto.getGuntonukiciTapisila());
            update.setGuntonukiciTarikha(dto.getGuntonukiciTarikha());
            update.setGuntonukichiRakamDarsaniMulya(dto.getGuntonukichiRakamDarsaniMulya());
            update.setGuntonukiciTarikha(dto.getGuntonukiciTarikha());
            update.setGuntonukichiRakamKharēdīKimata(dto.getGuntonukichiRakamKharēdīKimata());
            update.setGuntonukiciTarikha(dto.getGuntonukiciTarikha());
            update.setPranitHonachiTarkhi(dto.getPranitHonachiTarkhi());
            update.setGuntonukiciTarikha(dto.getGuntonukiciTarikha());
            update.setNivalDyaRakam(dto.getNivalDyaRakam());
            update.setGuntonukiciTarikha(dto.getGuntonukiciTarikha());
            update.setUparichitVachanchiTarakhi(dto.getUparichitVachanchiTarakhi());
            update.setGuntonukiciTarikha(dto.getGuntonukiciTarikha());
            update.setBadlichaPadrothrichaDinaka(dto.getBadlichaPadrothrichaDinaka());
            update.setGuntonukiciTarikha(dto.getGuntonukiciTarikha());
            update.setDainikRokadBahithilJamaRakam(dto.getDainikRokadBahithilJamaRakam());
            update.setGuntonukiciTarikha(dto.getGuntonukiciTarikha());
            update.setPrakritischiTapasni(dto.getPrakritischiTapasni());
            update.setGuntonukiciTarikha(dto.getGuntonukiciTarikha());
            update.setGuntonukiciTarikha(dto.getGuntonukiciTarikha());
            update.setUpdatedDate(dto.getUpdatedDate());
            update.setGuntonukiciTarikha(dto.getGuntonukiciTarikha());
            update.setRemark(dto.getRemark());
            update.setGuntonukiciTarikha(dto.getGuntonukiciTarikha());
            update.setYear(dto.getYear());
            update.setGuntonukiciTarikha(dto.getGuntonukiciTarikha());
            update.setDinank(dto.getDinank());

            GuntonukNamuna25 updatedEntity = guntonukRepository.save(update);

            return mapToDto(updatedEntity);
        }

        return null;
    }

    @Override
    public boolean deleteById(Long id) {
        if (guntonukRepository.existsById(id)) {
            guntonukRepository.deleteById(id);
            return true; // Deletion successful

        }
        return false; // Entity not found
        
    }

    private GuntonukNamuna25 mapToEntity(GuntonukNamuna25Dto dto) {
        GuntonukNamuna25 entity = new GuntonukNamuna25();
        entity.setId(dto.getId()); // This can be optional if ID is auto-generated
        entity.setGuntonukiciTarikha(dto.getGuntonukiciTarikha());
        entity.setGuntonukiciTapisila(dto.getGuntonukiciTapisila());
        entity.setGuntonukichiRakamDarsaniMulya(dto.getGuntonukichiRakamDarsaniMulya());
        entity.setGuntonukichiRakamKharēdīKimata(dto.getGuntonukichiRakamKharēdīKimata());
        entity.setPranitHonachiTarkhi(dto.getPranitHonachiTarkhi());
        entity.setNivalDyaRakam(dto.getNivalDyaRakam());
        entity.setUparichitVachanchiTarakhi(dto.getUparichitVachanchiTarakhi());
        entity.setBadlichaPadrothrichaDinaka(dto.getBadlichaPadrothrichaDinaka());
        entity.setDainikRokadBahithilJamaRakam(dto.getDainikRokadBahithilJamaRakam());
        entity.setPrakritischiTapasni(dto.getPrakritischiTapasni());
        entity.setCreateDate(dto.getCreateDate());
        entity.setUpdatedDate(dto.getUpdatedDate());
        entity.setEmployeeId(dto.getEmployeeId());
        entity.setEmployeeName(dto.getEmployeeName());
        entity.setGrampanchyatId(dto.getGrampanchyatId());
        entity.setGrampanchyatName(dto.getGrampanchyatName());
        entity.setRemark(dto.getRemark());
        entity.setYear(dto.getYear());
        entity.setDinank(dto.getDinank());
        return entity;
    }

    private GuntonukNamuna25Dto mapToDto(GuntonukNamuna25 entity) {
        GuntonukNamuna25Dto dto = new GuntonukNamuna25Dto();
        dto.setId(entity.getId());
        dto.setGuntonukiciTarikha(entity.getGuntonukiciTarikha());
        dto.setGuntonukiciTapisila(entity.getGuntonukiciTapisila());
        dto.setGuntonukichiRakamDarsaniMulya(entity.getGuntonukichiRakamDarsaniMulya());
        dto.setGuntonukichiRakamKharēdīKimata(entity.getGuntonukichiRakamKharēdīKimata());
        dto.setPranitHonachiTarkhi(entity.getPranitHonachiTarkhi());
        dto.setNivalDyaRakam(entity.getNivalDyaRakam());
        dto.setUparichitVachanchiTarakhi(entity.getUparichitVachanchiTarakhi());
        dto.setBadlichaPadrothrichaDinaka(entity.getBadlichaPadrothrichaDinaka());
        dto.setDainikRokadBahithilJamaRakam(entity.getDainikRokadBahithilJamaRakam());
        dto.setPrakritischiTapasni(entity.getPrakritischiTapasni());
        dto.setCreateDate(entity.getCreateDate());
        dto.setUpdatedDate(entity.getUpdatedDate());
        dto.setEmployeeId(entity.getEmployeeId());
        dto.setEmployeeName(entity.getEmployeeName());
        dto.setGrampanchyatId(entity.getGrampanchyatId());
        dto.setGrampanchyatName(entity.getGrampanchyatName());
        dto.setRemark(entity.getRemark());
        dto.setYear(entity.getYear());
        dto.setDinank(entity.getDinank());
        return dto;
    }

    private void updateEntityFromDto(GuntonukNamuna25 entity, GuntonukNamuna25Dto dto) {
        entity.setGuntonukiciTarikha(dto.getGuntonukiciTarikha());
        entity.setGuntonukiciTapisila(dto.getGuntonukiciTapisila());
        entity.setGuntonukichiRakamDarsaniMulya(dto.getGuntonukichiRakamDarsaniMulya());
        entity.setGuntonukichiRakamKharēdīKimata(dto.getGuntonukichiRakamKharēdīKimata());
        entity.setPranitHonachiTarkhi(dto.getPranitHonachiTarkhi());
        entity.setNivalDyaRakam(dto.getNivalDyaRakam());
        entity.setUparichitVachanchiTarakhi(dto.getUparichitVachanchiTarakhi());
        entity.setBadlichaPadrothrichaDinaka(dto.getBadlichaPadrothrichaDinaka());
        entity.setDainikRokadBahithilJamaRakam(dto.getDainikRokadBahithilJamaRakam());
        entity.setPrakritischiTapasni(dto.getPrakritischiTapasni());
        entity.setCreateDate(dto.getCreateDate());
        entity.setUpdatedDate(dto.getUpdatedDate());
        entity.setEmployeeId(dto.getEmployeeId());
        entity.setEmployeeName(dto.getEmployeeName());
        entity.setGrampanchyatId(dto.getGrampanchyatId());
        entity.setGrampanchyatName(dto.getGrampanchyatName());
        entity.setRemark(dto.getRemark());
        entity.setYear(dto.getYear());
        entity.setDinank(dto.getDinank());
    }
}
