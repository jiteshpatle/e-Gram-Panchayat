package eGramPanchayat.service.impl;


import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import eGramPanchayat.dto.Namuna33VrukshNondVihaDTO;
import eGramPanchayat.entity.Namuna33VrukshNondViha;
import eGramPanchayat.repository.Namuna33VrukshNondVihaRepository;
import eGramPanchayat.service.Namuna33VrukshNondVihaService;
import java.util.List;


@Component
public class Namuna33VrukshNondVihaIMPL implements Namuna33VrukshNondVihaService {

    @Autowired
    Namuna33VrukshNondVihaRepository repo;

    @Override
    public Namuna33VrukshNondViha savedata(@Valid Namuna33VrukshNondVihaDTO dto) {
        Namuna33VrukshNondViha save = new Namuna33VrukshNondViha();
        nullValuechecker(dto, save);
        return repo.save(save);
    }

    @Override
    public List<Namuna33VrukshNondViha> getalldetails() {
        return repo.findAll();
    }

    @Override
    public Namuna33VrukshNondViha getdetailsbyid(Long id) {
        return repo.findById(id).orElse(null);
    }

    // @Override
    // public Namuna33VrukshNondViha updatedata(Long id, @Valid Namuna33VrukshNondVihaDTO dto) {

    //     Namuna33VrukshNondViha entity = repo.findById(id).orElse(null);

    //     if (entity != null) {
    //         nullValuechecker(dto, entity);
    //         return repo.save(entity);
    //     }
    //     return null;
    // }

    @Override
    public Namuna33VrukshNondViha updatedata(Long id, @Valid Namuna33VrukshNondVihaDTO dto) {

        Namuna33VrukshNondViha entity = repo.findById(id).orElse(null);
           if (entity != null) {
            nullValuechecker(dto, entity);
            return repo.save(entity);
        }
        return null;
    }
    
    @Override
    public boolean deletebyid(Long id) {
        if (repo.existsById(id)) {
            repo.deleteById(id);
            return true;
        }
        return false;
    }

    public void nullValuechecker(Namuna33VrukshNondVihaDTO dto, Namuna33VrukshNondViha entity) {
        //        if (dto.getEmployeename() == null || dto.getEmployeename().isEmpty()) {
        //            throw new IllegalArgumentException("Employe Name cannot be null or empty");
        //        }
        entity.setEmployeename(dto.getEmployeename());

        //        if (dto.getGrampanchayatname() == null || dto.getGrampanchayatname().isEmpty()) {
        //            throw new IllegalArgumentException("GramPanchayat name cannot be null or empty");
        //        }
        entity.setGrampanchayatname(dto.getGrampanchayatname());

        if (dto.getNaav() == null || dto.getNaav().isEmpty()) {
            throw new IllegalArgumentException("Name cannot be null or empty");
        }
        entity.setNaav(dto.getNaav());

        if (dto.getVrukshprakar() == null || dto.getVrukshprakar().isEmpty()) {
            throw new IllegalArgumentException("Jhadachaprakar cannot be null or empty");
        }
        entity.setVrukshprakar(dto.getVrukshprakar());

        if (dto.getVrukshjopasnechijababdari() == null || dto.getVrukshjopasnechijababdari().isEmpty()) {
            throw new IllegalArgumentException("Jhadjapnaryachijababdari cannot be null or empty");
        }
        entity.setVrukshjopasnechijababdari(dto.getVrukshjopasnechijababdari());

        //        if (dto.getDate() == null || dto.getDate().isEmpty()) {
        //            throw new IllegalArgumentException("Year cannot be null or empty");
        //        }
        entity.setDate(dto.getDate());

        if (dto.getShera() == null || dto.getShera().isEmpty()) {
            throw new IllegalArgumentException("Shera cannot be null or empty");
        }
        entity.setShera(dto.getShera());

        entity.setCurrentDate(dto.getCurrentDate());

        //        if (dto.getEmployeeid()==null||dto.getEmployeeid().isEmpty()) {
        //            entity.setEmployeeid(dto.getEmployeeid());
        //        }
        entity.setEmployeeid(dto.getEmployeeid());

        //        if (dto.getGrampanchayatid() ==null|| dto.getGrampanchayatid().isEmpty()) {
        //            entity.setGrampanchayatid(dto.getGrampanchayatid());
        //        }
        entity.setGrampanchayatid(dto.getGrampanchayatid());

        if (dto.getVrukshkrmank() == null || dto.getVrukshkrmank().isEmpty()) {
            entity.setVrukshkrmank(dto.getVrukshkrmank());
        }
        entity.setVrukshkrmank(dto.getVrukshkrmank());
    }

}
