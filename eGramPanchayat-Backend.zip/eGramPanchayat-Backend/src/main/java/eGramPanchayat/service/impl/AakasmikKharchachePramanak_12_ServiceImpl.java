package eGramPanchayat.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eGramPanchayat.dto.AakasmikKharchachePramanak_12_Dto;
import eGramPanchayat.entity.AakasmikKharchachePramanak_12;
import eGramPanchayat.repository.AakasmikKharchachePramanak_12_Repository;
import eGramPanchayat.service.AakasmikKharchachePramanak_12_Service;
import jakarta.persistence.EntityNotFoundException;

@Service
public class AakasmikKharchachePramanak_12_ServiceImpl implements AakasmikKharchachePramanak_12_Service {

    @Autowired
    private AakasmikKharchachePramanak_12_Repository repository;

    @Override
    public AakasmikKharchachePramanak_12_Dto create(AakasmikKharchachePramanak_12_Dto dto) {
        AakasmikKharchachePramanak_12 entity = toEntity(dto);
        entity.setUpdatedDate(null);  // Make sure updatedDate is not set
        entity = repository.save(entity);
        return toDto(entity);
    }




    @Override
    public AakasmikKharchachePramanak_12_Dto update(Long id, AakasmikKharchachePramanak_12_Dto dto) {
        Optional<AakasmikKharchachePramanak_12> existingEntity = repository.findById(id);
        if (existingEntity.isPresent()) {
            AakasmikKharchachePramanak_12 entity = existingEntity.get();
            
            // Update other fields from dto
            entity.setEmployeeId(dto.getEmployeeId());
            entity.setEmployeeName(dto.getEmployeeName());
            entity.setGrampanchayatId(dto.getGrampanchayatId());
            entity.setGrampanchayatName(dto.getGrampanchayatName());
            entity.setRemark(dto.getRemark());
            entity.setDeyakKramank(dto.getDeyakKramank());
            entity.setPavtiLihunDenar(dto.getPavtiLihunDenar());
            entity.setKamacheKharediPavtiPramaneInNumbers(dto.getKamacheKharediPavtiPramaneInNumbers());
            entity.setKamacheKharediPavtiPramaneAkshari(dto.getKamacheKharediPavtiPramaneAkshari());
            entity.setMatraRokhCheckNo(dto.getMatraRokhCheckNo());
            entity.setNagKinwaWajan(dto.getNagKinwaWajan());
            entity.setDar(dto.getDar());
            entity.setUnit(dto.getUnit());
            entity.setRakkamRupaye(dto.getRakkamRupaye());
            entity.setWatnichiRakkamRupaye(dto.getWatnichiRakkamRupaye());
            entity.setPurvichaKharchRupaye(dto.getPurvichaKharchRupaye());
            entity.setDewakatDarshawilelaKharch(dto.getDewakatDarshawilelaKharch());
            entity.setEkunBerij2Plus2Rupaye(dto.getEkunBerij2Plus2Rupaye());
            entity.setUplabdhShillak(dto.getUplabdhShillak());
            entity.setTharavKramank(dto.getTharavKramank());
            entity.setDewakamadheDarshavileliRakkam(dto.getDewakamadheDarshavileliRakkam());
            entity.setMaganiPurvichePurnRupayeInNumbers(dto.getMaganiPurvichePurnRupayeInNumbers());
            entity.setMaganiPurvichePurnRupayeAkshari(dto.getMaganiPurvichePurnRupayeAkshari());
            entity.setPramanakKramank(dto.getPramanakKramank());
            entity.setRojwahitilPrusthKramank(dto.getRojwahitilPrusthKramank());
            entity.setYear(dto.getYear());
            
            // Set updatedDate to current date and time using LocalDateTime
            entity.setUpdatedDate(LocalDateTime.now()); 
            
            entity = repository.save(entity);
            return toDto(entity);
        }
        return null;  // Handle exception if needed
    }



    @Override
    public Optional<AakasmikKharchachePramanak_12_Dto> getById(Long id) {
        Optional<AakasmikKharchachePramanak_12> entity = repository.findById(id);
        return Optional.ofNullable(entity.map(this::toDto).orElse(null));
    }

    @Override
    public List<AakasmikKharchachePramanak_12_Dto> getAll() {
        return repository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public boolean delete(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return true;
        } else {
            throw new EntityNotFoundException("Data Not Found");
        }
    }


    private AakasmikKharchachePramanak_12 toEntity(AakasmikKharchachePramanak_12_Dto dto) {
        AakasmikKharchachePramanak_12 entity = new AakasmikKharchachePramanak_12();
        entity.setEmployeeId(dto.getEmployeeId());
        entity.setEmployeeName(dto.getEmployeeName());
        entity.setGrampanchayatId(dto.getGrampanchayatId());
        entity.setGrampanchayatName(dto.getGrampanchayatName());
        entity.setCreatedDate(dto.getCreatedDate());
        entity.setUpdatedDate(dto.getUpdatedDate());
        entity.setRemark(dto.getRemark());
        entity.setDeyakKramank(dto.getDeyakKramank());
        entity.setPavtiLihunDenar(dto.getPavtiLihunDenar());
        entity.setKamacheKharediPavtiPramaneInNumbers(dto.getKamacheKharediPavtiPramaneInNumbers());
        entity.setKamacheKharediPavtiPramaneAkshari(dto.getKamacheKharediPavtiPramaneAkshari());
        entity.setMatraRokhCheckNo(dto.getMatraRokhCheckNo());
        entity.setNagKinwaWajan(dto.getNagKinwaWajan());
        entity.setDar(dto.getDar());
        entity.setUnit(dto.getUnit());
        entity.setRakkamRupaye(dto.getRakkamRupaye());
        entity.setWatnichiRakkamRupaye(dto.getWatnichiRakkamRupaye());
        entity.setPurvichaKharchRupaye(dto.getPurvichaKharchRupaye());
        entity.setDewakatDarshawilelaKharch(dto.getDewakatDarshawilelaKharch());
        entity.setEkunBerij2Plus2Rupaye(dto.getEkunBerij2Plus2Rupaye());
        entity.setUplabdhShillak(dto.getUplabdhShillak());
        entity.setTharavKramank(dto.getTharavKramank());
        entity.setDewakamadheDarshavileliRakkam(dto.getDewakamadheDarshavileliRakkam());
        entity.setMaganiPurvichePurnRupayeInNumbers(dto.getMaganiPurvichePurnRupayeInNumbers());
        entity.setMaganiPurvichePurnRupayeAkshari(dto.getMaganiPurvichePurnRupayeAkshari());
        entity.setPramanakKramank(dto.getPramanakKramank());
        entity.setRojwahitilPrusthKramank(dto.getRojwahitilPrusthKramank());
        entity.setYear(dto.getYear());
        return entity;
    }

    private AakasmikKharchachePramanak_12_Dto toDto(AakasmikKharchachePramanak_12 entity) {
        AakasmikKharchachePramanak_12_Dto dto = new AakasmikKharchachePramanak_12_Dto();
        dto.setId(entity.getId());
        dto.setEmployeeId(entity.getEmployeeId());
        dto.setEmployeeName(entity.getEmployeeName());
        dto.setGrampanchayatId(entity.getGrampanchayatId());
        dto.setGrampanchayatName(entity.getGrampanchayatName());
        dto.setCreatedDate(entity.getCreatedDate());
        dto.setUpdatedDate(entity.getUpdatedDate());
        dto.setRemark(entity.getRemark());
        dto.setDeyakKramank(entity.getDeyakKramank());
        dto.setPavtiLihunDenar(entity.getPavtiLihunDenar());
        dto.setKamacheKharediPavtiPramaneInNumbers(entity.getKamacheKharediPavtiPramaneInNumbers());
        dto.setKamacheKharediPavtiPramaneAkshari(entity.getKamacheKharediPavtiPramaneAkshari());
        dto.setMatraRokhCheckNo(entity.getMatraRokhCheckNo());
        dto.setNagKinwaWajan(entity.getNagKinwaWajan());
        dto.setDar(entity.getDar());
        dto.setUnit(entity.getUnit());
        dto.setRakkamRupaye(entity.getRakkamRupaye());
        dto.setWatnichiRakkamRupaye(entity.getWatnichiRakkamRupaye());
        dto.setPurvichaKharchRupaye(entity.getPurvichaKharchRupaye());
        dto.setDewakatDarshawilelaKharch(entity.getDewakatDarshawilelaKharch());
        dto.setEkunBerij2Plus2Rupaye(entity.getEkunBerij2Plus2Rupaye());
        dto.setUplabdhShillak(entity.getUplabdhShillak());
        dto.setTharavKramank(entity.getTharavKramank());
        dto.setDewakamadheDarshavileliRakkam(entity.getDewakamadheDarshavileliRakkam());
        dto.setMaganiPurvichePurnRupayeInNumbers(entity.getMaganiPurvichePurnRupayeInNumbers());
        dto.setMaganiPurvichePurnRupayeAkshari(entity.getMaganiPurvichePurnRupayeAkshari());
        dto.setPramanakKramank(entity.getPramanakKramank());
        dto.setRojwahitilPrusthKramank(entity.getRojwahitilPrusthKramank());
        dto.setYear(entity.getYear());
        return dto;
    }
}
