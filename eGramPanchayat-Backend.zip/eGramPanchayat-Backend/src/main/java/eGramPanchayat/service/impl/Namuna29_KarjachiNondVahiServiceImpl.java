package eGramPanchayat.service.impl;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import eGramPanchayat.dto.Namuna29_KarjachiNondVahiDTO;
import eGramPanchayat.dto.Namuna5C_DainikRokadVahiDTO;
import eGramPanchayat.entity.Namuna29_KarjachiNondVahi;
import eGramPanchayat.entity.Namuna5C_DainikRokadVahi;
import eGramPanchayat.repository.Namuna29_KarjachiNondVahiRepository;
import eGramPanchayat.service.Namuna29_KarjachiNondVahiService;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Component
public class Namuna29_KarjachiNondVahiServiceImpl implements Namuna29_KarjachiNondVahiService {

    @Autowired
    Namuna29_KarjachiNondVahiRepository repo;

    @Override
    public Namuna29_KarjachiNondVahi savedata(Namuna29_KarjachiNondVahiDTO dto) {
        // Map DTO to entity
    	Namuna29_KarjachiNondVahi entity = new Namuna29_KarjachiNondVahi();
    	
    	 entity.setEmployeeId(dto.getEmployeeId());
         entity.setEmployeeName(dto.getEmployeeName());
         entity.setGrampanchayatId(dto.getGrampanchayatId());
         entity.setGrampanchayatName(dto.getGrampanchayatName());
         entity.setShera(dto.getShera());
         entity.setDate(dto.getDate());
         entity.setKarjUbharanechiSadhne(dto.getKarjUbharanechiSadhne());
         entity.setKarjManjuriAdeshKramank(dto.getKarjManjuriAdeshKramank());
         entity.setKarjManjuriDinank(dto.getKarjManjuriDinank());
         entity.setKarjachePrayojan(dto.getKarjachePrayojan());
         entity.setKarjRakkam(dto.getKarjRakkam());
         entity.setVyajDar(dto.getVyajDar());
         entity.setKarjMilalyachiTarikh(dto.getKarjMilalyachiTarikh());
         entity.setPradanachaTapshilDinank(dto.getPradanachaTapshilDinank());
         entity.setPradanachaTapshilMuddat(dto.getPradanachaTapshilMuddat());
         entity.setPradanachaTapshilVyaj(dto.getPradanachaTapshilVyaj());
         entity.setPradanachaTapshilEkun(dto.getPradanachaTapshilEkun());
         entity.setShillakRakkamMudat(dto.getShillakRakkamMudat());
         entity.setShillakRakkamVyaj(dto.getShillakRakkamVyaj());
         entity.setKarjVyajParatfedaMudatHaptaSankhya(dto.getKarjVyajParatfedaMudatHaptaSankhya());
         entity.setKarjVyajParatfedaVyajHaptaSankhya(dto.getKarjVyajParatfedaVyajHaptaSankhya());
         entity.setKarjVyajParatfedaMudatDinank(dto.getKarjVyajParatfedaMudatDinank());
         entity.setKarjVyajParatfedaVyajDinank(dto.getKarjVyajParatfedaVyajDinank());
         entity.setPratyekHaptyachyaMuddalasathiKarjRakkam(dto.getPratyekHaptyachyaMuddalasathiKarjRakkam());
         entity.setPratyekHaptyachyaMuddalasathiVyajRakkam(dto.getPratyekHaptyachyaMuddalasathiVyajRakkam());
         entity.setYear(dto.getYear());
         entity.setCreatedDate(dto.getCreatedDate());
         entity.setUpdatedDate(dto.getUpdatedDate());
        // Save to database
        return repo.save(entity);
    }

    @Override
    public List<Namuna29_KarjachiNondVahi> getalldetails() {
        return repo.findAll();
    }

    @Override
    public Namuna29_KarjachiNondVahi getdetailsbyid(Long id) {
        return repo.findById(id).orElse(null);
    }
    
    @Override
    public Namuna29_KarjachiNondVahi updateById(Long id, Namuna29_KarjachiNondVahiDTO dto) {
        // Check if the record exists in the database
        Optional<Namuna29_KarjachiNondVahi> existingEntityOpt = repo.findById(id);

        if (existingEntityOpt.isEmpty()) {
            return null;
        }

        Namuna29_KarjachiNondVahi existingEntity = existingEntityOpt.get();

        // Map fields from DTO to the entity
        existingEntity.setEmployeeId(dto.getEmployeeId());
        existingEntity.setEmployeeName(dto.getEmployeeName());
        existingEntity.setGrampanchayatId(dto.getGrampanchayatId());
        existingEntity.setGrampanchayatName(dto.getGrampanchayatName());
        existingEntity.setShera(dto.getShera());
        existingEntity.setDate(dto.getDate());
        existingEntity.setKarjUbharanechiSadhne(dto.getKarjUbharanechiSadhne());
        existingEntity.setKarjManjuriAdeshKramank(dto.getKarjManjuriAdeshKramank());
        existingEntity.setKarjManjuriDinank(dto.getKarjManjuriDinank());
        existingEntity.setKarjachePrayojan(dto.getKarjachePrayojan());
        existingEntity.setKarjRakkam(dto.getKarjRakkam());
        existingEntity.setVyajDar(dto.getVyajDar());
        existingEntity.setKarjMilalyachiTarikh(dto.getKarjMilalyachiTarikh());
        existingEntity.setPradanachaTapshilDinank(dto.getPradanachaTapshilDinank());
        existingEntity.setPradanachaTapshilMuddat(dto.getPradanachaTapshilMuddat());
        existingEntity.setPradanachaTapshilVyaj(dto.getPradanachaTapshilVyaj());
        existingEntity.setPradanachaTapshilEkun(dto.getPradanachaTapshilEkun());
        existingEntity.setShillakRakkamMudat(dto.getShillakRakkamMudat());
        existingEntity.setShillakRakkamVyaj(dto.getShillakRakkamVyaj());
        existingEntity.setKarjVyajParatfedaMudatHaptaSankhya(dto.getKarjVyajParatfedaMudatHaptaSankhya());
        existingEntity.setKarjVyajParatfedaVyajHaptaSankhya(dto.getKarjVyajParatfedaVyajHaptaSankhya());
        existingEntity.setKarjVyajParatfedaMudatDinank(dto.getKarjVyajParatfedaMudatDinank());
        existingEntity.setKarjVyajParatfedaVyajDinank(dto.getKarjVyajParatfedaVyajDinank());
        existingEntity.setPratyekHaptyachyaMuddalasathiKarjRakkam(dto.getPratyekHaptyachyaMuddalasathiKarjRakkam());
        existingEntity.setPratyekHaptyachyaMuddalasathiVyajRakkam(dto.getPratyekHaptyachyaMuddalasathiVyajRakkam());
        existingEntity.setYear(dto.getYear());
        existingEntity.setUpdatedDate(LocalDateTime.now());

        // Save the updated entity
        return repo.save(existingEntity);
    }

	@Override
	 public boolean deleteById(Long id) {
		if (repo.existsById(id)) {
            repo.deleteById(id);
            return true;
        }
        return false;
    }
}
