package eGramPanchayat.service.impl;

import eGramPanchayat.entity.TransactionLog;
import eGramPanchayat.repository.TransactionLogRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class TransactionLogService {

        @Autowired
        private TransactionLogRepository transactionLogRepository;

        public void logTransaction(String action, String details, String username, String employeeId,
                        String employeeName, String grampanchayatId, String grampanchayatName) {

                // Fetch the currently logged-in username if not explicitly provided
                if (username == null || username.isEmpty()) {
                        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
                        username = (authentication != null && authentication.isAuthenticated())
                                        ? authentication.getName()
                                        : "Anonymous";
                }
                // Create the transaction log object
                TransactionLog log = new TransactionLog(
                                action,
                                details,
                                username,
                                employeeId,
                                employeeName,
                                grampanchayatId,
                                grampanchayatName);
                // Print details to the console for debugging
                System.out.println("Logging Transaction: Action=" + action +
                                ", Details=" + details +
                                ", Username=" + username +
                                ", Timestamp=" + LocalDateTime.now());

                // Save the log in the database
                transactionLogRepository.save(log);
        }

}
