package eGramPanchayat.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import eGramPanchayat.dto.LekhaparikshanAaksheepanNamuna27DTO;
import eGramPanchayat.entity.LekhaparikshanAaksheepanNamuna27;
import eGramPanchayat.repository.LekhaparikshanAaksheepanNumuna27Repository;
import eGramPanchayat.service.LekhaparikshanAaksheepanNamuna27Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class LekhaparikshanAaksheepanNamun27ServiceImpl implements LekhaparikshanAaksheepanNamuna27Service {

    @Autowired
    private LekhaparikshanAaksheepanNumuna27Repository repository;

    @Override
    public LekhaparikshanAaksheepanNamuna27DTO save(LekhaparikshanAaksheepanNamuna27DTO dto) {
        LekhaparikshanAaksheepanNamuna27 entity = toEntity(dto);
        entity = repository.save(entity);
        return toDto(entity); // Return the saved DTO
    }

    @Override
    public Optional<LekhaparikshanAaksheepanNamuna27DTO> findById(Long id) {
        return repository.findById(id)
                .map(this::toDto);
    }

    @Override
    public boolean deleteById(Long id) {
            if (repository.existsById(id)) {
                    repository.deleteById(id);
                    return true; // Return true if deletion was successful
            }
            return false;

    }

    @Override
    public List<LekhaparikshanAaksheepanNamuna27DTO> getAll() {
        return repository.findAll().stream()
                .map(this::toDto)
                .collect(Collectors.toList()); // Collect all DTOs
    }

    @Override
    public LekhaparikshanAaksheepanNamuna27DTO updatee(Long id, LekhaparikshanAaksheepanNamuna27DTO dto) {
        LekhaparikshanAaksheepanNamuna27 update = repository.findById(id).orElse(null);

        update.setEmployeeId(dto.getGrampanchyatId());
        update.setEmployeeName(dto.getEmployeeName());
        update.setGrampanchyatName(dto.getGrampanchyatName());
        update.setGrampanchyatId(dto.getGrampanchyatId());
        update.setLekhaparikshanaAhvalcheVrsh(dto.getLekhaparikshanaAhvalcheVrsh());
        update.setLekhaparikshanaAhvalatilaParicchhedaSamkhaya(
                dto.getLekhaparikshanaAhvalatilaParicchhedaSamkhaya());
        update.setGrampanchayattineeYaMahinyataPootartaKelelyaPariccchhedanchiSaikhaya(
                dto.getGrampanchayattineeYaMahinyataPootartaKelelyaPariccchhedanchiSaikhaya());
        update.setPanchayatSamittineAakshepaadaraMaanyaKeleylyaaPootartachiSaikhaya(
                dto.getPanchayatSamittineAakshepaadaraMaanyaKeleylyaaPootartachiSaikhaya());
        update.setLekhaparikshkaneChyaBabatitPootartaMaanyaKeliAaheTyaAaksheepaanchyaaSakhaya(
                dto.getLekhaparikshkaneChyaBabatitPootartaMaanyaKeliAaheTyaAaksheepaanchyaaSakhaya());
        update.setPrlabitAsalellyaAakshepachiSakhaya(dto.getPrlabitAsalellyaAakshepachiSakhaya());
        update.setPootartaNaKelelayabghlachiKaarana(dto.getPootartaNaKelelayabghlachiKaarana());
        update.setShera(dto.getShera());
        update.setCreateDate(dto.getCreateDate());
        update.setUpdatedDate(dto.getUpdatedDate());
        LekhaparikshanAaksheepanNamuna27 updatedEntity = repository.save(update);
        return toDto(updatedEntity);
    }

    @Override
    public boolean existsById(Long id) {
        return repository.existsById(id); // Check if record exists
    }

    // Mapping methods
    private LekhaparikshanAaksheepanNamuna27 toEntity(LekhaparikshanAaksheepanNamuna27DTO dto) {
        LekhaparikshanAaksheepanNamuna27 entity = new LekhaparikshanAaksheepanNamuna27();
        mapDtoToEntity(dto, entity); // Map DTO to entity
        return entity; // Return the mapped entity
    }

    private void mapDtoToEntity(LekhaparikshanAaksheepanNamuna27DTO dto, LekhaparikshanAaksheepanNamuna27 entity) {
        // entity.setAnukramamka(dto.getAnukramamka());
        entity.setLekhaparikshanaAhvalcheVrsh(dto.getLekhaparikshanaAhvalcheVrsh());
        entity.setLekhaparikshanaAhvalatilaParicchhedaSamkhaya(dto.getLekhaparikshanaAhvalatilaParicchhedaSamkhaya());
        entity.setGrampanchayattineeYaMahinyataPootartaKelelyaPariccchhedanchiSaikhaya(
                dto.getGrampanchayattineeYaMahinyataPootartaKelelyaPariccchhedanchiSaikhaya());
        entity.setPanchayatSamittineAakshepaadaraMaanyaKeleylyaaPootartachiSaikhaya(
                dto.getPanchayatSamittineAakshepaadaraMaanyaKeleylyaaPootartachiSaikhaya());
        entity.setLekhaparikshkaneChyaBabatitPootartaMaanyaKeliAaheTyaAaksheepaanchyaaSakhaya(
                dto.getLekhaparikshkaneChyaBabatitPootartaMaanyaKeliAaheTyaAaksheepaanchyaaSakhaya());
        entity.setPrlabitAsalellyaAakshepachiSakhaya(dto.getPrlabitAsalellyaAakshepachiSakhaya());
        entity.setPootartaNaKelelayabghlachiKaarana(dto.getPootartaNaKelelayabghlachiKaarana());
        entity.setShera(dto.getShera());
        entity.setEmployeeId(dto.getEmployeeId());
        entity.setEmployeeName(dto.getEmployeeName());
        entity.setGrampanchyatId(dto.getGrampanchyatId());
        entity.setGrampanchyatName(dto.getGrampanchyatName());
        entity.setDinank(dto.getDinank());
        entity.setCreateDate(dto.getCreateDate());
        entity.setUpdatedDate(dto.getUpdatedDate());

    }

    private LekhaparikshanAaksheepanNamuna27DTO toDto(LekhaparikshanAaksheepanNamuna27 entity) {
        LekhaparikshanAaksheepanNamuna27DTO dto = new LekhaparikshanAaksheepanNamuna27DTO();
        dto.setId(entity.getId());
        // dto.setAnukramamka(entity.getAnukramamka());
        dto.setLekhaparikshanaAhvalcheVrsh(entity.getLekhaparikshanaAhvalcheVrsh());
        dto.setLekhaparikshanaAhvalatilaParicchhedaSamkhaya(entity.getLekhaparikshanaAhvalatilaParicchhedaSamkhaya());
        dto.setGrampanchayattineeYaMahinyataPootartaKelelyaPariccchhedanchiSaikhaya(
                entity.getGrampanchayattineeYaMahinyataPootartaKelelyaPariccchhedanchiSaikhaya());
        dto.setPanchayatSamittineAakshepaadaraMaanyaKeleylyaaPootartachiSaikhaya(
                entity.getPanchayatSamittineAakshepaadaraMaanyaKeleylyaaPootartachiSaikhaya());
        dto.setLekhaparikshkaneChyaBabatitPootartaMaanyaKeliAaheTyaAaksheepaanchyaaSakhaya(
                entity.getLekhaparikshkaneChyaBabatitPootartaMaanyaKeliAaheTyaAaksheepaanchyaaSakhaya());
        dto.setPrlabitAsalellyaAakshepachiSakhaya(entity.getPrlabitAsalellyaAakshepachiSakhaya());
        dto.setPootartaNaKelelayabghlachiKaarana(entity.getPootartaNaKelelayabghlachiKaarana());
        dto.setShera(entity.getShera());
        dto.setEmployeeId(entity.getEmployeeId());
        dto.setEmployeeName(entity.getEmployeeName());
        dto.setGrampanchyatId(entity.getGrampanchyatId());
        dto.setGrampanchyatName(entity.getGrampanchyatName());
        dto.setDinank(entity.getDinank());
        dto.setCreateDate(entity.getCreateDate());
        dto.setUpdatedDate(entity.getUpdatedDate());

        return dto; // Return the mapped DTO
    }
}
