package eGramPanchayat.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eGramPanchayat.dto.Namuna17AgrimDilelyaRakamanchiNondvahiDTO;
import eGramPanchayat.entity.Namuna17AgrimDilelyaRakamanchiNondvahi;
import eGramPanchayat.repository.Namuna17AgrimDilelyaRakamanchiNondvahiRepository;
import eGramPanchayat.service.Namuna17AgrimDilelyaRakamanchiNondvahiService;

@Service
public class Namuna17AgrimDilelyaRakamanchiNondvahiServiceImpl implements Namuna17AgrimDilelyaRakamanchiNondvahiService {

    @Autowired
    private Namuna17AgrimDilelyaRakamanchiNondvahiRepository nondvahiRepository;

    @Override
    public Namuna17AgrimDilelyaRakamanchiNondvahiDTO save(Namuna17AgrimDilelyaRakamanchiNondvahiDTO nondvahi) {
        Namuna17AgrimDilelyaRakamanchiNondvahi entity = convertDtoToEntity(nondvahi);
        return mapToDto(nondvahiRepository.save(entity));
    }

    @Override
    public Optional<Namuna17AgrimDilelyaRakamanchiNondvahiDTO> findById(Long id) {
        Namuna17AgrimDilelyaRakamanchiNondvahi entity = nondvahiRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Data Not Found"));
        return Optional.ofNullable(mapToDto(entity));
    }

    @Override
    public List<Namuna17AgrimDilelyaRakamanchiNondvahi> findAll() {
        return nondvahiRepository.findAll();
    }

    @Override
    public Optional<Namuna17AgrimDilelyaRakamanchiNondvahiDTO> update(Long id, Namuna17AgrimDilelyaRakamanchiNondvahiDTO dto) {
        Optional<Namuna17AgrimDilelyaRakamanchiNondvahi> existingNondvahi = nondvahiRepository.findById(id);
        
        if (existingNondvahi.isPresent()) {
            Namuna17AgrimDilelyaRakamanchiNondvahi updatedNondvahi = existingNondvahi.get();

            // Map updated fields from DTO to the entity
            updatedNondvahi.setEmployeeName(dto.getEmployeeName());
            updatedNondvahi.setGrampanchayatId(dto.getGrampanchayatId());
            updatedNondvahi.setGrampanchayatName(dto.getGrampanchayatName());
            updatedNondvahi.setUpdatedDate(dto.getUpdatedDate());
            updatedNondvahi.setMahinaVaTarikh(dto.getMahinaVaTarikh());
            updatedNondvahi.setPakshakaracheNav(dto.getPakshakaracheNav());
            updatedNondvahi.setAgrimRakmenchaTapshil(dto.getAgrimRakmenchaTapshil());
            updatedNondvahi.setPramanakKinvaPavatiKramank(dto.getPramanakKinvaPavatiKramank());
            updatedNondvahi.setRakkam(dto.getRakkam());
            updatedNondvahi.setMasikEkun(dto.getMasikEkun());
            updatedNondvahi.setRokhParatfedApril(dto.getRokhParatfedApril());
            updatedNondvahi.setRokhParatfedMay(dto.getRokhParatfedMay());
            updatedNondvahi.setRokhParatfedJune(dto.getRokhParatfedJune());
            updatedNondvahi.setRokhParatfedJuly(dto.getRokhParatfedJuly());
            updatedNondvahi.setRokhParatfedAugust(dto.getRokhParatfedAugust());
            updatedNondvahi.setRokhParatfedSeptember(dto.getRokhParatfedSeptember());
            updatedNondvahi.setRokhParatfedOctober(dto.getRokhParatfedOctober());
            updatedNondvahi.setRokhParatfedNovember(dto.getRokhParatfedNovember());
            updatedNondvahi.setRokhParatfedDecember(dto.getRokhParatfedDecember());
            updatedNondvahi.setRokhParatfedJanuary(dto.getRokhParatfedJanuary());
            updatedNondvahi.setRokhParatfedFebruary(dto.getRokhParatfedFebruary());
            updatedNondvahi.setRokhParatfedMarch(dto.getRokhParatfedMarch());
            updatedNondvahi.setEkunParatfed(dto.getEkunParatfed());
            updatedNondvahi.setParatFedichiTarikhKinvaSamayojanPramanakachaKramank(dto.getParatFedichiTarikhKinvaSamayojanPramanakachaKramank());
            updatedNondvahi.setVarshachaAkherchiShillak(dto.getVarshachaAkherchiShillak());
            updatedNondvahi.setShera(dto.getShera());
            updatedNondvahi.setYear(dto.getYear());

            // Save the updated entity
            Namuna17AgrimDilelyaRakamanchiNondvahi savedNondvahi = nondvahiRepository.save(updatedNondvahi);
            return Optional.of(mapToDto(savedNondvahi));
        }
        return Optional.empty(); // Return empty if the entity is not found
    }

    @Override
    public boolean delete(Long id) {
        Optional<Namuna17AgrimDilelyaRakamanchiNondvahi> existingNondvahi = nondvahiRepository.findById(id);
        if (existingNondvahi.isPresent()) {
            nondvahiRepository.deleteById(id);
            return true; // Successful deletion
        } else {
            throw new RuntimeException("Data Not Found"); // Throw exception if entity is not found
        }
    }
    
    private Namuna17AgrimDilelyaRakamanchiNondvahiDTO mapToDto(Namuna17AgrimDilelyaRakamanchiNondvahi entity) {
        if (entity == null) {
            return null; // Handle null case
        }

        Namuna17AgrimDilelyaRakamanchiNondvahiDTO dto = new Namuna17AgrimDilelyaRakamanchiNondvahiDTO();
        dto.setId(entity.getId());
        dto.setCreatedDate(entity.getCreatedDate());
        dto.setUpdatedDate(entity.getUpdatedDate());
        dto.setEmployeeId(entity.getEmployeeId());
        dto.setEmployeeName(entity.getEmployeeName());
        dto.setGrampanchayatId(entity.getGrampanchayatId());
        dto.setGrampanchayatName(entity.getGrampanchayatName());
        dto.setMahinaVaTarikh(entity.getMahinaVaTarikh());
        dto.setPakshakaracheNav(entity.getPakshakaracheNav());
        dto.setAgrimRakmenchaTapshil(entity.getAgrimRakmenchaTapshil());
        dto.setPramanakKinvaPavatiKramank(entity.getPramanakKinvaPavatiKramank());
        dto.setRakkam(entity.getRakkam());
        dto.setMasikEkun(entity.getMasikEkun());
        dto.setRokhParatfedApril(entity.getRokhParatfedApril());
        dto.setRokhParatfedMay(entity.getRokhParatfedMay());
        dto.setRokhParatfedJune(entity.getRokhParatfedJune());
        dto.setRokhParatfedJuly(entity.getRokhParatfedJuly());
        dto.setRokhParatfedAugust(entity.getRokhParatfedAugust());
        dto.setRokhParatfedSeptember(entity.getRokhParatfedSeptember());
        dto.setRokhParatfedOctober(entity.getRokhParatfedOctober());
        dto.setRokhParatfedNovember(entity.getRokhParatfedNovember());
        dto.setRokhParatfedDecember(entity.getRokhParatfedDecember());
        dto.setRokhParatfedJanuary(entity.getRokhParatfedJanuary());
        dto.setRokhParatfedFebruary(entity.getRokhParatfedFebruary());
        dto.setRokhParatfedMarch(entity.getRokhParatfedMarch());
        dto.setEkunParatfed(entity.getEkunParatfed());
        dto.setParatFedichiTarikhKinvaSamayojanPramanakachaKramank(entity.getParatFedichiTarikhKinvaSamayojanPramanakachaKramank());
        dto.setVarshachaAkherchiShillak(entity.getVarshachaAkherchiShillak());
        dto.setShera(entity.getShera());
        dto.setYear(entity.getYear());
        
        return dto;
    }

    private Namuna17AgrimDilelyaRakamanchiNondvahi convertDtoToEntity(Namuna17AgrimDilelyaRakamanchiNondvahiDTO dto) {
        if (dto == null) {
            return null; // Handle null case
        }

        Namuna17AgrimDilelyaRakamanchiNondvahi entity = new Namuna17AgrimDilelyaRakamanchiNondvahi();
        entity.setId(dto.getId());
        entity.setCreatedDate(dto.getCreatedDate());
        entity.setUpdatedDate(dto.getUpdatedDate());
        entity.setEmployeeId(dto.getEmployeeId());
        entity.setEmployeeName(dto.getEmployeeName());
        entity.setGrampanchayatId(dto.getGrampanchayatId());
        entity.setGrampanchayatName(dto.getGrampanchayatName());
        entity.setMahinaVaTarikh(dto.getMahinaVaTarikh());
        entity.setPakshakaracheNav(dto.getPakshakaracheNav());
        entity.setAgrimRakmenchaTapshil(dto.getAgrimRakmenchaTapshil());
        entity.setPramanakKinvaPavatiKramank(dto.getPramanakKinvaPavatiKramank());
        entity.setRakkam(dto.getRakkam());
        entity.setMasikEkun(dto.getMasikEkun());
        entity.setRokhParatfedApril(dto.getRokhParatfedApril());
        entity.setRokhParatfedMay(dto.getRokhParatfedMay());
        entity.setRokhParatfedJune(dto.getRokhParatfedJune());
        entity.setRokhParatfedJuly(dto.getRokhParatfedJuly());
        entity.setRokhParatfedAugust(dto.getRokhParatfedAugust());
        entity.setRokhParatfedSeptember(dto.getRokhParatfedSeptember());
        entity.setRokhParatfedOctober(dto.getRokhParatfedOctober());
        entity.setRokhParatfedNovember(dto.getRokhParatfedNovember());
        entity.setRokhParatfedDecember(dto.getRokhParatfedDecember());
        entity.setRokhParatfedJanuary(dto.getRokhParatfedJanuary());
        entity.setRokhParatfedFebruary(dto.getRokhParatfedFebruary());
        entity.setRokhParatfedMarch(dto.getRokhParatfedMarch());
        entity.setEkunParatfed(dto.getEkunParatfed());
        entity.setParatFedichiTarikhKinvaSamayojanPramanakachaKramank(dto.getParatFedichiTarikhKinvaSamayojanPramanakachaKramank());
        entity.setVarshachaAkherchiShillak(dto.getVarshachaAkherchiShillak());
        entity.setShera(dto.getShera());
        entity.setYear(dto.getYear());
        
        return entity;
    }
}
