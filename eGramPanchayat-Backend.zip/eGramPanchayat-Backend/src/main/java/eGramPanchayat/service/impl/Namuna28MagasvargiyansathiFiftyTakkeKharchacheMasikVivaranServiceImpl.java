package eGramPanchayat.service.impl;

import java.util.List;

import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import eGramPanchayat.dto.Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO;
import eGramPanchayat.entity.Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaran;
import eGramPanchayat.repository.Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranRepository;
import eGramPanchayat.service.Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranService;
import jakarta.validation.Valid;

@Service
public class Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranServiceImpl
        implements Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranService {
    @Autowired
    private Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranRepository service;

    @Override
    public Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO create(
            @Valid Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO dto) {
        Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaran entity = new Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaran();
        maptoEntity(dto, entity);
        return maptoDTO(service.save(entity));
    }

    @Override
    public List<Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO> getAll() {
        return service.findAll().stream().map(this::maptoDTO).collect(Collectors.toList());
    }

    @Override
    public Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO getById(Long id) {
        return service.findById(id).map(this::maptoDTO).orElse(null);
    }

    @Override
    // public Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO
    // update(Long id,
    // @Valid Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO dto) {

    // Optional<Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaran>
    // existingEntityOptional = service
    // .findById(id);

    // if (existingEntityOptional.isPresent()) {
    // Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaran exitingEntity =
    // existingEntityOptional.get();
    // exitingEntity.setEmployeeId(dto.getEmployeeId());
    // exitingEntity.setEmployeeName(dto.getEmployeeName());
    // exitingEntity.setGramPanchayatId(dto.getGramPanchayatId());
    // exitingEntity.setGramPanchayatName(dto.getGramPanchayatName());
    // exitingEntity.setYear(dto.getYear());
    // exitingEntity.setSanMadhemagasvargiyansathiKeleliTartud(dto.getSanMadhemagasvargiyansathiKeleliTartud());
    // exitingEntity.setChaluMahinyatPraptaJhaleleUtpanna(dto.getChaluMahinyatPraptaJhaleleUtpanna());
    // exitingEntity.setFiftyTakkeKharchaKarychiRakkam(dto.getFiftyTakkeKharchaKarychiRakkam());
    // exitingEntity.setKharchachyaBabiYojanavar(dto.getKharchachyaBabiYojanavar());
    // exitingEntity.setMagilMahinayatJhalelaKharcha(dto.getMagilMahinayatJhalelaKharcha());
    // exitingEntity.setChaluMahinyatJhalelaKharcha(dto.getChaluMahinyatJhalelaKharcha());
    // exitingEntity.setEkunKharch(dto.getEkunKharch());
    // exitingEntity.setKharchachiTakkevari(dto.getKharchachiTakkevari());
    // exitingEntity.setShera(dto.getShera());
    // exitingEntity.setSan(dto.getSan());
    // exitingEntity.setDinank(dto.getDinank());
    // exitingEntity.setMonth(dto.getMonth());
    // // exitingEntity.setRemark(dto.getRemark());
    // Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaran updatedEntity =
    // service.save(exitingEntity);
    // return maptoDTO(updatedEntity);

    // } else {
    // // return null;
    // throw new EntityNotFoundException("No record found with ID: " + id);
    // }
    // }

    public Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO update(Long id,
            @Valid Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO dto) {

        Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaran update = service.findById(id).orElse(null);

        // // Update only non-null fields
        // Optional.ofNullable(dto.getGramPanchayatId()).ifPresent(update::setGramPanchayatId);
        // Optional.ofNullable(dto.getGramPanchayatName()).ifPresent(update::setGramPanchayatName);
        // Optional.ofNullable(dto.getEmployeeId()).ifPresent(update::setEmployeeId);
        // Optional.ofNullable(dto.getGramPanchayatName()).ifPresent(update::setEmployeeName);

        update.setGramPanchayatId(dto.getGramPanchayatId());
        update.setGramPanchayatName(dto.getGramPanchayatName());
        update.setEmployeeId(dto.getEmployeeId());
        update.setEmployeeName(dto.getEmployeeName());
        update.setYear(dto.getYear());
        update.setSanMadhemagasvargiyansathiKeleliTartud(dto.getSanMadhemagasvargiyansathiKeleliTartud());
        update.setChaluMahinyatPraptaJhaleleUtpanna(dto.getChaluMahinyatPraptaJhaleleUtpanna());
        update.setFiftyTakkeKharchaKarychiRakkam(dto.getFiftyTakkeKharchaKarychiRakkam());
        update.setKharchachyaBabiYojanavar(dto.getKharchachyaBabiYojanavar());
        update.setMagilMahinayatJhalelaKharcha(dto.getMagilMahinayatJhalelaKharcha());
        update.setChaluMahinyatJhalelaKharcha(dto.getChaluMahinyatJhalelaKharcha());
        update.setEkunKharch(dto.getEkunKharch());
        update.setKharchachiTakkevari(dto.getKharchachiTakkevari());
        update.setShera(dto.getShera());
        update.setSan(dto.getSan());
        update.setDinank(dto.getDinank());
        update.setMonth(dto.getMonth());
        // update.setUpdatedDate(dto.getUpdatedDate());
        // exitingEntity.setRemark(dto.getRemark());
        Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaran updatedEntity = service.save(update);
        return maptoDTO(updatedEntity);

    }

    // if (existingEntityOptional.isPresent()) {
    // Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaran exitingEntity =
    // existingEntityOptional.get();
    // exitingEntity.setEmployeeId(dto.getEmployeeId());
    // exitingEntity.setEmployeeName(dto.getEmployeeName());
    // exitingEntity.setGramPanchayatId(dto.getGramPanchayatId());
    // exitingEntity.setGramPanchayatName(dto.getGramPanchayatName());
    // exitingEntity.setYear(dto.getYear());
    // exitingEntity.setSanMadhemagasvargiyansathiKeleliTartud(dto.getSanMadhemagasvargiyansathiKeleliTartud());
    // exitingEntity.setChaluMahinyatPraptaJhaleleUtpanna(dto.getChaluMahinyatPraptaJhaleleUtpanna());
    // exitingEntity.setFiftyTakkeKharchaKarychiRakkam(dto.getFiftyTakkeKharchaKarychiRakkam());
    // exitingEntity.setKharchachyaBabiYojanavar(dto.getKharchachyaBabiYojanavar());
    // exitingEntity.setMagilMahinayatJhalelaKharcha(dto.getMagilMahinayatJhalelaKharcha());
    // exitingEntity.setChaluMahinyatJhalelaKharcha(dto.getChaluMahinyatJhalelaKharcha());
    // exitingEntity.setEkunKharch(dto.getEkunKharch());
    // exitingEntity.setKharchachiTakkevari(dto.getKharchachiTakkevari());
    // exitingEntity.setShera(dto.getShera());
    // exitingEntity.setSan(dto.getSan());
    // exitingEntity.setDinank(dto.getDinank());
    // exitingEntity.setMonth(dto.getMonth());
    // // exitingEntity.setRemark(dto.getRemark());
    // Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaran updatedEntity =
    // service.save(exitingEntity);
    // return maptoDTO(updatedEntity);

    // } else {
    // // return null;
    // throw new EntityNotFoundException("No record found with ID: " + id);
    // }

    @Override
    public boolean delete(Long id) {

        if (service.existsById(id)) {
            service.deleteById(id);
            return true;
        }
        return false;
        
    }

    // Convert DTO to Entity
    private Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaran maptoEntity(
            Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO dto,
            Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaran entity)

    {
        entity.setCreatedDate(dto.getCreatedDate());
        entity.setUpdatedDate(dto.getUpdatedDate());
        entity.setEmployeeId(dto.getEmployeeId());
        entity.setEmployeeName(dto.getEmployeeName());
        entity.setGramPanchayatId(dto.getGramPanchayatId());
        entity.setGramPanchayatName(dto.getGramPanchayatName());
        entity.setYear(dto.getYear());
        entity.setSanMadhemagasvargiyansathiKeleliTartud(dto.getSanMadhemagasvargiyansathiKeleliTartud());
        entity.setChaluMahinyatPraptaJhaleleUtpanna(dto.getChaluMahinyatPraptaJhaleleUtpanna());
        entity.setFiftyTakkeKharchaKarychiRakkam(dto.getFiftyTakkeKharchaKarychiRakkam());
        entity.setKharchachyaBabiYojanavar(dto.getKharchachyaBabiYojanavar());
        entity.setMagilMahinayatJhalelaKharcha(dto.getMagilMahinayatJhalelaKharcha());
        entity.setChaluMahinyatJhalelaKharcha(dto.getChaluMahinyatJhalelaKharcha());
        entity.setEkunKharch(dto.getEkunKharch());
        entity.setKharchachiTakkevari(dto.getKharchachiTakkevari());
        entity.setShera(dto.getShera());
        entity.setSan(dto.getSan());
        entity.setMonth(dto.getMonth());
        entity.setDinank(dto.getDinank());
        // entity.setUpdatedDate(dto.getUpdatedDate());
        // entity.setRemark(dto.getRemark());
        return entity;
    }

    // Convert Entity to DTO
    private Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO maptoDTO(
            Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaran entity) {
        Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO dto = new Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO(); // class
        dto.setId(entity.getId());
        dto.setCreatedDate(entity.getCreatedDate());
        dto.setUpdatedDate(entity.getUpdatedDate());
        dto.setEmployeeId(entity.getEmployeeId());
        dto.setEmployeeName(entity.getEmployeeName());
        dto.setGramPanchayatId(entity.getGramPanchayatId());
        dto.setGramPanchayatName(entity.getGramPanchayatName());
        dto.setYear(entity.getYear());
        dto.setSanMadhemagasvargiyansathiKeleliTartud(entity.getSanMadhemagasvargiyansathiKeleliTartud());
        dto.setChaluMahinyatPraptaJhaleleUtpanna(entity.getChaluMahinyatPraptaJhaleleUtpanna());
        dto.setFiftyTakkeKharchaKarychiRakkam(entity.getFiftyTakkeKharchaKarychiRakkam());
        dto.setKharchachyaBabiYojanavar(entity.getKharchachyaBabiYojanavar());
        dto.setMagilMahinayatJhalelaKharcha(entity.getMagilMahinayatJhalelaKharcha());
        dto.setChaluMahinyatJhalelaKharcha(entity.getChaluMahinyatJhalelaKharcha());
        dto.setEkunKharch(entity.getEkunKharch());
        dto.setKharchachiTakkevari(entity.getKharchachiTakkevari());
        dto.setShera(entity.getShera());
        dto.setSan(entity.getSan());
        dto.setMonth(entity.getMonth());
        dto.setDinank(entity.getDinank());
        // dto.setUpdatedDate(entity.getUpdatedDate());
        // dto.setRemark(entity.getRemark());
        return dto;
    }

}
