package eGramPanchayat.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eGramPanchayat.dto.Namuna18KirkolRokadVahiDto;
import eGramPanchayat.entity.Namuna18KirkolRokadVahi;
import eGramPanchayat.repository.Namuna18KirkolRokadVahiRepository;
import eGramPanchayat.service.Namuna18KirkolRokadVahiService;

@Service
public class Namuna18KirkolRokadVahiServiceImpl implements Namuna18KirkolRokadVahiService {

    @Autowired
    private Namuna18KirkolRokadVahiRepository kirkolRokadVahiRepository;

    @Override
    public Namuna18KirkolRokadVahi save(Namuna18KirkolRokadVahiDto kirkolRokadVahiDto) {
        // Convert DTO to entity
        Namuna18KirkolRokadVahi kirkolRokadVahi = new Namuna18KirkolRokadVahi();
        mapDtoToEntity(kirkolRokadVahiDto, kirkolRokadVahi);
        return kirkolRokadVahiRepository.save(kirkolRokadVahi);
    }

    @Override
    public Optional<Namuna18KirkolRokadVahi> update(Long id, Namuna18KirkolRokadVahiDto kirkolRokadVahiDto) {
        Optional<Namuna18KirkolRokadVahi> optionalEntity = kirkolRokadVahiRepository.findById(id);
        if (optionalEntity.isPresent()) {
            Namuna18KirkolRokadVahi kirkolRokadVahi = optionalEntity.get();
            // Update entity fields with values from DTO
            mapDtoToEntity(kirkolRokadVahiDto, kirkolRokadVahi);
            return Optional.of(kirkolRokadVahiRepository.save(kirkolRokadVahi));
        }
        return Optional.empty(); // Use Optional.empty() instead of null
    }

   
    @Override
    public boolean delete(Long id) {
        if (kirkolRokadVahiRepository.existsById(id)) {
            kirkolRokadVahiRepository.deleteById(id);
            return true; // Successful deletion
        } else {
            throw new RuntimeException("Data Not Found"); // Throw exception if entity is not found
        }
    }

    @Override
    public List<Namuna18KirkolRokadVahi> findAll() {
        return kirkolRokadVahiRepository.findAll();
    }

    @Override
    public Optional<Namuna18KirkolRokadVahi> findById(Long id) {
        return Optional.ofNullable(kirkolRokadVahiRepository.findById(id).orElse(null));
    }

    // Helper method to map DTO fields to entity
    private void mapDtoToEntity(Namuna18KirkolRokadVahiDto kirkolRokadVahiDto, Namuna18KirkolRokadVahi kirkolRokadVahi) {
        // Mapping all fields from DTO to entity with null checks if necessary
        kirkolRokadVahi.setRemark(Optional.ofNullable(kirkolRokadVahiDto.getRemark()).orElse(""));
        kirkolRokadVahi.setEmployeeId(kirkolRokadVahiDto.getEmployeeId());
        kirkolRokadVahi.setEmployeeName(Optional.ofNullable(kirkolRokadVahiDto.getEmployeeName()).orElse(""));
        kirkolRokadVahi.setGrampanchayatId(kirkolRokadVahiDto.getGrampanchayatId());
        kirkolRokadVahi.setGrampanchayatName(Optional.ofNullable(kirkolRokadVahiDto.getGrampanchayatName()).orElse(""));
        kirkolRokadVahi.setJamaTarikh(kirkolRokadVahiDto.getJamaTarikh());
        kirkolRokadVahi.setDhanadeshKramank(Optional.ofNullable(kirkolRokadVahiDto.getDhanadeshKramank()).orElse(""));
        kirkolRokadVahi.setKonakadunPraptZala(Optional.ofNullable(kirkolRokadVahiDto.getKonakadunPraptZala()).orElse(""));
        kirkolRokadVahi.setJamaTapshil(Optional.ofNullable(kirkolRokadVahiDto.getJamaTapshil()).orElse(""));
        kirkolRokadVahi.setJamaRakkam(kirkolRokadVahiDto.getJamaRakkam());
        kirkolRokadVahi.setAgrim(kirkolRokadVahiDto.getAgrim());
        kirkolRokadVahi.setJamaEkun(kirkolRokadVahiDto.getJamaEkun());
        kirkolRokadVahi.setAdhyakshari(Optional.ofNullable(kirkolRokadVahiDto.getAdhyakshari()).orElse(""));
        kirkolRokadVahi.setKharchTarikh(kirkolRokadVahiDto.getKharchTarikh());
        kirkolRokadVahi.setKharchTapshil(Optional.ofNullable(kirkolRokadVahiDto.getKharchTapshil()).orElse(""));
        kirkolRokadVahi.setKonasRakkamDili(Optional.ofNullable(kirkolRokadVahiDto.getKonasRakkamDili()).orElse(""));
        kirkolRokadVahi.setKharchRakkam(kirkolRokadVahiDto.getKharchRakkam());
        kirkolRokadVahi.setAgrimatunKharch(kirkolRokadVahiDto.getAgrimatunKharch());
        kirkolRokadVahi.setKharchEkun(kirkolRokadVahiDto.getKharchEkun());
        kirkolRokadVahi.setSwakshari(Optional.ofNullable(kirkolRokadVahiDto.getSwakshari()).orElse(""));
        
        kirkolRokadVahi.setPrarambhiShillak(kirkolRokadVahiDto.getPrarambhiShillak());
        kirkolRokadVahi.setPrarambhiShillakJama(kirkolRokadVahiDto.getPrarambhiShillakJama());
        kirkolRokadVahi.setPrarambhiShillakKharch(kirkolRokadVahiDto.getPrarambhiShillakKharch());
        kirkolRokadVahi.setPrarambhiShillakEkun(kirkolRokadVahiDto.getPrarambhiShillakEkun());
        kirkolRokadVahi.setPrarambhiShillakRokh(kirkolRokadVahiDto.getPrarambhiShillakRokh());

        kirkolRokadVahi.setAarambhiShillak(kirkolRokadVahiDto.getAarambhiShillak());
        kirkolRokadVahi.setAarambhiShillakJama(kirkolRokadVahiDto.getAarambhiShillakJama());
        kirkolRokadVahi.setAarambhiShillakEkun(kirkolRokadVahiDto.getAarambhiShillakEkun());

        // Check and set the year field
        if (kirkolRokadVahiDto.getYear() != null) {
            kirkolRokadVahi.setYear(kirkolRokadVahiDto.getYear());
        }
    }

}
