package eGramPanchayat.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eGramPanchayat.entity.Kirkolmagni_11;
import eGramPanchayat.repository.Kirkolmagni11Repository;
import eGramPanchayat.service.Kirkolmagni11Service;

@Service
public class Kirkolmagni11ServiceImpl implements Kirkolmagni11Service {

	@Autowired
	Kirkolmagni11Repository kirkolmagni11Repository;
	
	
	// create the data
	@Override
	public Kirkolmagni_11 saveEgram11(Kirkolmagni_11 egram11) {
		egram11.setMagni_Total(egram11.getMagni_Happta() + egram11.getMagni_Rakam());
		return kirkolmagni11Repository.save(egram11);
	}

	//get All records
	@Override
	public List<Kirkolmagni_11> getAllEgram11() {

		return kirkolmagni11Repository.findAll();
	}

	//get the data by ID
	@Override
	public Optional<Kirkolmagni_11> getEgram11_ById(Long id) {
		Optional<Kirkolmagni_11> entry = kirkolmagni11Repository.findById(id);
		if(entry.isPresent()) {
		return entry;
		} else
			throw new RuntimeException("Egram11 record not found for ID: " + id);
	}

	// update the egram11
	@Override
	public Kirkolmagni_11 updateEgram11(Long id, Kirkolmagni_11 updatedEgram11) {
		Optional<Kirkolmagni_11> entry = kirkolmagni11Repository.findById(id);
		if(entry.isPresent())
		{
			Kirkolmagni_11 existing=entry.get();
			existing.setYear(updatedEgram11.getYear());
			existing.setEmployeeId(updatedEgram11.getEmployeeId());
			existing.setEmployeeName(updatedEgram11.getEmployeeName());
			existing.setGrampanchayatId(updatedEgram11.getGrampanchayatId());
			existing.setGrampanchayatName(updatedEgram11.getGrampanchayatName());
			existing.setRemark(updatedEgram11.getRemark());
			existing.setUpdatedDate(LocalDateTime.now());
			existing.setPropertyOwnerName(updatedEgram11.getPropertyOwnerName());
			existing.setMagniche_Swarup(updatedEgram11.getMagniche_Swarup());
			existing.setMagnisathi_Pradhikar(updatedEgram11.getMagnisathi_Pradhikar());
			existing.setMagni_Happta(updatedEgram11.getMagni_Happta());
			existing.setMagni_Rakam(updatedEgram11.getMagni_Rakam());
			existing.setMagni_Total(existing.getMagni_Happta()+existing.getMagni_Rakam());
			existing.setDeyakramankOR_Date(updatedEgram11.getDeyakramankOR_Date());
			existing.setVasuli_PavtiKramankOR_Date(updatedEgram11.getVasuli_PavtiKramankOR_Date());
			existing.setVasuli_Rakam(updatedEgram11.getVasuli_Rakam());
			existing.setSut_AadheshachaKramankOR_Date(updatedEgram11.getSut_AadheshachaKramankOR_Date());
			existing.setSut_Rakam(updatedEgram11.getSut_Rakam());
			existing.setShillak(updatedEgram11.getShillak());
			existing.setShera(updatedEgram11.getShera());
			
			return kirkolmagni11Repository.save(existing);
		}
		return null;
	}
	
	
	
	// delete by the id with id
   @Override
	public boolean deleteEgram11(Long id) {
		if (!kirkolmagni11Repository.existsById(id)) {
			throw new RuntimeException("Data Not Found with ID : "+id);
		}
		kirkolmagni11Repository.deleteById(id);
		return true;
	}

}

