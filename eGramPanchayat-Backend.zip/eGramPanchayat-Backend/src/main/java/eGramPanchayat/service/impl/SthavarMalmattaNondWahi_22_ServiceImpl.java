package eGramPanchayat.service.impl;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import eGramPanchayat.entity.SthavarMalmattaNondWahi_22;
import eGramPanchayat.repository.SthavarMalmattaNondWahi_22_Repository;
import eGramPanchayat.service.SthavarMalmattaNondWahi_22_Service;
import jakarta.persistence.EntityNotFoundException;

@Service
public class SthavarMalmattaNondWahi_22_ServiceImpl implements SthavarMalmattaNondWahi_22_Service {

    @Autowired
    private SthavarMalmattaNondWahi_22_Repository repository;

    @Override
    public SthavarMalmattaNondWahi_22 addEntry(SthavarMalmattaNondWahi_22 entry) {
        // Don't set updatedDate here; it will only be set during updates
        return repository.save(entry);
    }

    @Override
    public List<SthavarMalmattaNondWahi_22> getAllEntries() {
        return repository.findAll();
    }

    @Override
    public Optional<SthavarMalmattaNondWahi_22> getEntryById(Long id) {
        return repository.findById(id);
    }

    @Override
    public SthavarMalmattaNondWahi_22 updateEntry(Long id, SthavarMalmattaNondWahi_22 updatedEntry) {
        // Fetch the entity by ID
        Optional<SthavarMalmattaNondWahi_22> optionalEntry = repository.findById(id);

        if (optionalEntry.isPresent()) {
            SthavarMalmattaNondWahi_22 entry = optionalEntry.get();

            // // Update fields only if non-null in updatedEntry
            // Optional.ofNullable(updatedEntry.getGrampanchayatId()).ifPresent(entry::setGrampanchayatId);
            // Optional.ofNullable(updatedEntry.getGrampanchayatName()).ifPresent(entry::setGrampanchayatName);
            // Optional.ofNullable(updatedEntry.getEmployeeId()).ifPresent(entry::setEmployeeId);
            // Optional.ofNullable(updatedEntry.getEmployeeName()).ifPresent(entry::setEmployeeName);

            entry.setGrampanchayatId(updatedEntry.getGrampanchayatId());
            entry.setGrampanchayatName(updatedEntry.getGrampanchayatName());
            entry.setEmployeeId(updatedEntry.getEmployeeId());
            entry.setEmployeeName(updatedEntry.getEmployeeName());
            entry.setSanpadanchiKharediKinwaUbharnichaDinank(updatedEntry.getSanpadanchiKharediKinwaUbharnichaDinank());
            entry.setjAMSamKTyaadeshacheVPanchTharKramank(updatedEntry.getjAMSamKTyaadeshacheVPanchTharKramank());
            entry.setjAMSamKTyaadeshacheVPanchTharDinak(updatedEntry.getjAMSamKTyaadeshacheVPanchTharDinak());
            entry.setMalmattechaBhumapanKramank(updatedEntry.getMalmattechaBhumapanKramank());
            entry.setMalmattechaBhumapanMalmattecheVarnan(updatedEntry.getMalmattechaBhumapanMalmattecheVarnan());
            entry.setKonatyaKarnaSaathiWaparKela(updatedEntry.getKonatyaKarnaSaathiWaparKela());
            entry.setUbharniKinwaSampadanachaKharch(updatedEntry.getUbharniKinwaSampadanachaKharch());
            entry.setDurustyawarKinwaFerfaravarDinank(updatedEntry.getDurustyawarKinwaFerfaravarDinank());
            entry.setDurustyawarKinwaFerfaravarChaluDurustyaRupaye(
                    updatedEntry.getDurustyawarKinwaFerfaravarChaluDurustyaRupaye());
            entry.setDurustyawarKinwaFerfaravarWisheshDurustyaRupaye(
                    updatedEntry.getDurustyawarKinwaFerfaravarWisheshDurustyaRupaye());
            entry.setDurustyawarKinwaFerfaravarMulBandhKaamRupaye(
                    updatedEntry.getDurustyawarKinwaFerfaravarMulBandhKaamRupaye());
            entry.setDurustyawarKinwaFerfaravarMulBandhkaamcheSwarup(
                    updatedEntry.getDurustyawarKinwaFerfaravarMulBandhkaamcheSwarup());
            entry.setWarshaAkherisGhatleliKinmat(updatedEntry.getWarshaAkherisGhatleliKinmat());
            entry.setMalmattechiVilhewatKramank(updatedEntry.getMalmattechiVilhewatKramank());
            entry.setMalmattechiVilhewatDinank(updatedEntry.getMalmattechiVilhewatDinank());
            entry.setMalmattechiVilhewatKalam55Kramank(updatedEntry.getMalmattechiVilhewatKalam55Kramank());
            entry.setMalmattechiVilhewatKalam55Dinank(updatedEntry.getMalmattechiVilhewatKalam55Dinank());
            entry.setShera(updatedEntry.getShera());
            entry.setDinank(updatedEntry.getDinank());

            // Save and return the updated entity
            return repository.save(entry);
        } else {
            // Throw an exception or handle entity not found case
            throw new EntityNotFoundException("Entry with ID " + id + " not found");
        }
    }

    @Override
    public boolean deleteEntry(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return true;
        }
        return false;
    }
}
