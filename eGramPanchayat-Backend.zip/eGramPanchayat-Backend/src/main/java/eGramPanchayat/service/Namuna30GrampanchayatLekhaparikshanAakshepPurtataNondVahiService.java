package eGramPanchayat.service;

import java.util.List;

import eGramPanchayat.dto.Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO;





public interface Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiService 
{
	Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO create(Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO dto);
    Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO update(Long id,Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO dto);
    boolean delete(Long id);
    List<Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO> findAll();
    Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO findById(Long id);	

}
