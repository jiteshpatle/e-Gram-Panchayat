package eGramPanchayat.service;

import java.util.List;
import java.util.Optional;

import eGramPanchayat.dto.AakasmikKharchachePramanak_12_Dto;

public interface AakasmikKharchachePramanak_12_Service {
    AakasmikKharchachePramanak_12_Dto create(AakasmikKharchachePramanak_12_Dto dto);
    AakasmikKharchachePramanak_12_Dto update(Long id, AakasmikKharchachePramanak_12_Dto dto);
    Optional<AakasmikKharchachePramanak_12_Dto> getById(Long id);
    List<AakasmikKharchachePramanak_12_Dto> getAll();
    boolean delete(Long id);
}
