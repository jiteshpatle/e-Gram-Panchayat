package eGramPanchayat.service;

import java.util.List;
import java.util.Optional;

import eGramPanchayat.dto.JaminichiNondWahi_24_Dto;

public interface JaminichiNondWahi_24_Service {
    JaminichiNondWahi_24_Dto createJaminichiNondWahi(JaminichiNondWahi_24_Dto dto);
    Optional<JaminichiNondWahi_24_Dto> getJaminichiNondWahiById(Long id);
    List<JaminichiNondWahi_24_Dto> getAllJaminichiNondWahi();
    JaminichiNondWahi_24_Dto updateJaminichiNondWahi(Long id, JaminichiNondWahi_24_Dto dto);
    boolean deleteJaminichiNondWahi(Long id);
}
