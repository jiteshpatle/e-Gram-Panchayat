package eGramPanchayat.service;

import java.util.List;

import eGramPanchayat.dto.Namuna16_DeadStockDTO;
import eGramPanchayat.entity.Namuna16_DeadStock;

public interface Namuna16_DeadStockService {

	Namuna16_DeadStock savedata(Namuna16_DeadStockDTO dto);
    List<Namuna16_DeadStock> getalldetails();
    Namuna16_DeadStock getdetailsbyid(Long id);
    Namuna16_DeadStock updateById(Long id, Namuna16_DeadStockDTO dto);
    boolean deleteById(Long id);
}