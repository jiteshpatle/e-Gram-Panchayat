package eGramPanchayat.service;



import java.util.List;
import java.util.Optional;

import eGramPanchayat.dto.Namuna02PunarniyojanVaNiyatVatapDTO;
import jakarta.validation.Valid;

public interface Namuna02PunarniyojanVaNiyatVatapService {
    Namuna02PunarniyojanVaNiyatVatapDTO saveDetails(@Valid Namuna02PunarniyojanVaNiyatVatapDTO details);

    List<Namuna02PunarniyojanVaNiyatVatapDTO> getAllDetails();

    Optional<Namuna02PunarniyojanVaNiyatVatapDTO> getDetailsById(Long id);

    boolean deleteDetails(Long id);

    Namuna02PunarniyojanVaNiyatVatapDTO updateDetails(Long id, @Valid Namuna02PunarniyojanVaNiyatVatapDTO details); // Added method for updating

	
}
