package eGramPanchayat.service;



import java.util.List;

import eGramPanchayat.dto.Namuna33VrukshNondVihaDTO;
import eGramPanchayat.entity.Namuna33VrukshNondViha;

public interface Namuna33VrukshNondVihaService {

    Namuna33VrukshNondViha savedata(Namuna33VrukshNondVihaDTO dto);
    List<Namuna33VrukshNondViha> getalldetails();
    Namuna33VrukshNondViha getdetailsbyid(Long id);
    Namuna33VrukshNondViha updatedata(Long id , Namuna33VrukshNondVihaDTO dto);
    boolean deletebyid(Long id);
}
