package eGramPanchayat.service;

import java.util.List;
import java.util.Optional;

import eGramPanchayat.dto.Namuna17AgrimDilelyaRakamanchiNondvahiDTO;
import eGramPanchayat.entity.Namuna17AgrimDilelyaRakamanchiNondvahi;

public interface Namuna17AgrimDilelyaRakamanchiNondvahiService {
    
    Namuna17AgrimDilelyaRakamanchiNondvahiDTO save(Namuna17AgrimDilelyaRakamanchiNondvahiDTO nondvahi);
    
    Optional<Namuna17AgrimDilelyaRakamanchiNondvahiDTO> findById(Long id);
    
    List<Namuna17AgrimDilelyaRakamanchiNondvahi> findAll();
    
    Optional<Namuna17AgrimDilelyaRakamanchiNondvahiDTO> update(Long id, Namuna17AgrimDilelyaRakamanchiNondvahiDTO dto);
    
    boolean delete(Long id);
}
