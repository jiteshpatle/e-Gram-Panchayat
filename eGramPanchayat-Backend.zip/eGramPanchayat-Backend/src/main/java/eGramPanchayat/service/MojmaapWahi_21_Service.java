package eGramPanchayat.service;

import java.util.List;
import java.util.Optional;

import eGramPanchayat.dto.MojmaapWahi_21_Dto;

public interface MojmaapWahi_21_Service {
    MojmaapWahi_21_Dto addMojmaapWahi(MojmaapWahi_21_Dto mojmaapWahiDto);
    List<MojmaapWahi_21_Dto> getAllMojmaapWahi();
    Optional<MojmaapWahi_21_Dto> getMojmaapWahiById(Long id);
    boolean updateMojmaapWahi(Long id, MojmaapWahi_21_Dto mojmaapWahiDto);  // Change to boolean
    boolean deleteMojmaapWahi(Long id);  // Change to boolean
}
