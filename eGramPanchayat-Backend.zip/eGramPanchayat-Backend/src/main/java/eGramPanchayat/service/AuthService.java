package eGramPanchayat.service;

import eGramPanchayat.dto.LoginRequest;
import eGramPanchayat.dto.RegisterRequest;
import jakarta.servlet.http.HttpServletRequest; // Import for HttpServletRequest


public interface AuthService {
    String register(RegisterRequest request);
    String login(LoginRequest request);
    String logout(HttpServletRequest request);
    String forgotPassword(String username);
    boolean verifyOtp(String username, String otp);
    String resendOtp(String username);
    String updatePassword(String username, String newPassword);
}
