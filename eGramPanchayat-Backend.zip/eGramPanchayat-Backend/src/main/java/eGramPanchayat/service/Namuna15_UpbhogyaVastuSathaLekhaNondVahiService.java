package eGramPanchayat.service;

import java.util.List;

import eGramPanchayat.dto.Namuna15_UpbhogyaVastuSathaLekhaNondVahiDTO;
import eGramPanchayat.entity.Namuna15_UpbhogyaVastuSathaLekhaNondVahi;

public interface Namuna15_UpbhogyaVastuSathaLekhaNondVahiService {

	Namuna15_UpbhogyaVastuSathaLekhaNondVahi savedata(Namuna15_UpbhogyaVastuSathaLekhaNondVahiDTO dto);
    List<Namuna15_UpbhogyaVastuSathaLekhaNondVahi> getalldetails();
    Namuna15_UpbhogyaVastuSathaLekhaNondVahi getdetailsbyid(Long id);
    Namuna15_UpbhogyaVastuSathaLekhaNondVahi updateById(Long id, Namuna15_UpbhogyaVastuSathaLekhaNondVahiDTO dto);
    boolean deleteById(Long id);
}