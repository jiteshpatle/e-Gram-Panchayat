package eGramPanchayat.service;

import java.util.List;

import eGramPanchayat.dto.Namuna5C_DainikRokadVahiDTO;
import eGramPanchayat.entity.Namuna5C_DainikRokadVahi;

public interface Namuna5C_DainikRokadVahiService {

	Namuna5C_DainikRokadVahi savedata(Namuna5C_DainikRokadVahiDTO dto);
    List<Namuna5C_DainikRokadVahi> getalldetails();
    Namuna5C_DainikRokadVahi getdetailsbyid(Long id);
    Namuna5C_DainikRokadVahi updateById(Long id, Namuna5C_DainikRokadVahiDTO dto);
    boolean deleteById(Long id);
}
