package eGramPanchayat.service;

import java.util.List;
import java.util.Optional;

import eGramPanchayat.dto.Namuna19KamavarAslelyaVyaktinchaHajeripatDto;

public interface Namuna19KamavarAslelyaVyaktinchaHajeripatService {

    Namuna19KamavarAslelyaVyaktinchaHajeripatDto create(Namuna19KamavarAslelyaVyaktinchaHajeripatDto dto);

    Optional<Namuna19KamavarAslelyaVyaktinchaHajeripatDto> update(Long id, Namuna19KamavarAslelyaVyaktinchaHajeripatDto dto);

    Optional<Namuna19KamavarAslelyaVyaktinchaHajeripatDto> getById(Long id);

    List<Namuna19KamavarAslelyaVyaktinchaHajeripatDto> getAll();

    boolean delete(Long id);
}
