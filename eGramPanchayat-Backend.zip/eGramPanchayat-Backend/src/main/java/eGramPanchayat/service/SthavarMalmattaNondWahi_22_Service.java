package eGramPanchayat.service;

import java.util.List;
import java.util.Optional;

import eGramPanchayat.entity.SthavarMalmattaNondWahi_22;

public interface SthavarMalmattaNondWahi_22_Service {
    SthavarMalmattaNondWahi_22 addEntry(SthavarMalmattaNondWahi_22 entry);
    List<SthavarMalmattaNondWahi_22> getAllEntries();
    Optional<SthavarMalmattaNondWahi_22> getEntryById(Long id);
    SthavarMalmattaNondWahi_22 updateEntry(Long id, SthavarMalmattaNondWahi_22 updatedEntry);
    boolean deleteEntry(Long id);
}
