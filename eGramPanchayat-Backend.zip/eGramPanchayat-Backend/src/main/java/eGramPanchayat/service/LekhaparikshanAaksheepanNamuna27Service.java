package eGramPanchayat.service;

import java.util.List;
import java.util.Optional;

import eGramPanchayat.dto.LekhaparikshanAaksheepanNamuna27DTO;



public interface LekhaparikshanAaksheepanNamuna27Service {
	LekhaparikshanAaksheepanNamuna27DTO save(LekhaparikshanAaksheepanNamuna27DTO dto);
    //List<LekhaparikshanAaksheepanNamuna27DTO> findAll();
    Optional<LekhaparikshanAaksheepanNamuna27DTO> findById(Long id);
    //LekhaparikshanAaksheepanNamuna27DTO update(Long id, LekhaparikshanAaksheepanNamuna27DTO dto);
    boolean deleteById(Long id);
	List<LekhaparikshanAaksheepanNamuna27DTO> getAll();
	LekhaparikshanAaksheepanNamuna27DTO updatee(Long id, LekhaparikshanAaksheepanNamuna27DTO dto);
	boolean existsById(Long id);
}
