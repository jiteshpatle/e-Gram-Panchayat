package eGramPanchayat.service;

import java.util.List;
import java.util.Optional;


import eGramPanchayat.entity.Egram26_K;


public interface Egram_26K_Service {

	 Egram26_K saveEgram26_K(Egram26_K egram26_K);
		
		List<Egram26_K> getAllEgram26_K();
		
		 Egram26_K updateEgram26KById(Long id, Egram26_K update);
		
		Optional<Egram26_K> getEgram26KById(long id);
		
		boolean deleteEgram26(Long id);
		
}
