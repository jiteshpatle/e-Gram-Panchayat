package eGramPanchayat.service;


import java.util.List;

import eGramPanchayat.dto.GuntonukNamuna25Dto;

public interface GuntonukNamun25Service {
	GuntonukNamuna25Dto save(GuntonukNamuna25Dto guntonukDTO1);  
    List<GuntonukNamuna25Dto> findAll(); 
    GuntonukNamuna25Dto findById(Long id); 
    GuntonukNamuna25Dto update(Long id, GuntonukNamuna25Dto dto);

    boolean deleteById(Long id);
}
