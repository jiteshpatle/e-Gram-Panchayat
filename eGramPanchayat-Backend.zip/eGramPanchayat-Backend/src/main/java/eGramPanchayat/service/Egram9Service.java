package eGramPanchayat.service;

import java.util.List;
import java.util.Optional;

import eGramPanchayat.entity.Egram9;

public interface Egram9Service {
    Egram9 saveEgram9(Egram9 egram9);

    List<Egram9> getAllEgram9();

  Optional<Egram9>getEgram9ById(Long id);

    Egram9 updateEgram9(Long id, Egram9 updatedEgram9);

    boolean deleteEgram9(Long id);
}
