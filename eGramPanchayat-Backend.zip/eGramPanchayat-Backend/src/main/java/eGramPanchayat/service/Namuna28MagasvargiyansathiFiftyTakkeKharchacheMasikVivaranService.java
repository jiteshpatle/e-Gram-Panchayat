package eGramPanchayat.service;

import java.util.List;
import eGramPanchayat.dto.Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO;

public interface Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranService {
	Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO create(
			Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO dto);

	Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO getById(Long id);

	Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO update(Long id,
			Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO dto);

	List<Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO> getAll();

	boolean delete(Long id);
}
