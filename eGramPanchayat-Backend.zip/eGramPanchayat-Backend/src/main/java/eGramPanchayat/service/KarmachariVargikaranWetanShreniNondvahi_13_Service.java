package eGramPanchayat.service;

import eGramPanchayat.dto.KarmachariVargikaranWetanShreniNondvahi_13_Dto;
import java.util.List;

public interface KarmachariVargikaranWetanShreniNondvahi_13_Service {
    KarmachariVargikaranWetanShreniNondvahi_13_Dto create(KarmachariVargikaranWetanShreniNondvahi_13_Dto Dto);

    List<KarmachariVargikaranWetanShreniNondvahi_13_Dto> getAll();

    KarmachariVargikaranWetanShreniNondvahi_13_Dto getById(Long id);

    KarmachariVargikaranWetanShreniNondvahi_13_Dto update(Long id, KarmachariVargikaranWetanShreniNondvahi_13_Dto dto);

    boolean delete(Long id);

    
}
