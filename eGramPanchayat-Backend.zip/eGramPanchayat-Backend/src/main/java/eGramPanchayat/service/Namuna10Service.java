package eGramPanchayat.service;

import java.util.List;

import eGramPanchayat.dto.Namuna10DTO;
import eGramPanchayat.entity.Namuna10Entity;



public interface Namuna10Service {

    Namuna10Entity save(Namuna10DTO dto);

    Namuna10DTO getById(Long id);

    Namuna10Entity update(Long id, Namuna10Entity updatedEntity);

    boolean deleteById(Long id);

    List<Namuna10DTO> getAll();
}
