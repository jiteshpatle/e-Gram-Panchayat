package eGramPanchayat.service;

import java.util.List;

import eGramPanchayat.dto.Namuna32RakkamPartavyaSathiChaAdeshDTO;

public interface Namuna32RakkamPartavyaSathiChaAdeshService {
	Namuna32RakkamPartavyaSathiChaAdeshDTO create(Namuna32RakkamPartavyaSathiChaAdeshDTO dto);

	Namuna32RakkamPartavyaSathiChaAdeshDTO update(Long id, Namuna32RakkamPartavyaSathiChaAdeshDTO dto);

	Namuna32RakkamPartavyaSathiChaAdeshDTO findById(Long id);

	List<Namuna32RakkamPartavyaSathiChaAdeshDTO> findAll();

	boolean delete(Long id);
}
