package eGramPanchayat.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

@Entity
@Table(name = "20_kaamachya_andajachi_nond_wahi") // Change the table name as needed
public class Namuna20KamachyaAndajachiNondvahi {

    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "employee_id")
    private String employeeId;

    @Column(name = "employee_name")
    private String employeeName;

    @Column(name = "grampanchayat_id")
    private String grampanchayatId;

    @Column(name = "grampanchayat_name")
    private String grampanchayatName;

   
    @Column(name = "created_date", updatable = false)
    private LocalDateTime createdDate;

   
    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    // New Fields
    @Column(name = "kramank")
    private String kramank;

    @Column(name = "nidhiche_shirsh")
    private String nidhicheShirsh;

    @Column(name = "upa_shirsh")
    private String upaShirsh;

    @Column(name = "madhe_honyachya_sambhav_kharchach")
    private String madheHonyachyaSambhavKharchach;

    @Column(name = "yanni_kelela_andaj")
    private String yanniKelelaAndaj;

    @Column(name = "sarvasadharan_goshwara_parinam")
    private String sarvasadharanGoshwaraParinam;

    @Column(name = "sarvasadharan_goshwara_baab")
    private String sarvasadharanGoshwaraBaab;

    @Column(name = "sarvasadharan_goshwara_dar_rupaye")
    private String sarvasadharanGoshwaraDarRupaye;

    @Column(name = "sarvasadharan_goshwara_pratteki")
    private String sarvasadharanGoshwaraPratteki;

    @Column(name = "sarvasadharan_goshwara_rakkam_dashanshat")
    private String sarvasadharanGoshwaraRakkamDashanshat;

    @Column(name = "mojmap_andajpatra_kramank")
    private String mojmapAndajpatraKramank;

    @Column(name = "mojmap_andajpatra_laambi")
    private String mojmapAndajpatraLaambi;

    @Column(name = "mojmap_andajpatra_rundi")
    private String mojmapAndajpatraRundi;

    @Column(name = "mojmap_andajpatra_kholi")
    private String mojmapAndajpatraKholi;

    @Column(name = "mojmap_andajpatra_pariman_dashanshat")
    private String mojmapAndajpatraParimanDashanshat;

    @Column(name = "ekun")
    private String ekun;

    @Column(name = "year")
    private String year;
    
    @PrePersist
    protected void onCreate() {
        this.createdDate = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedDate = LocalDateTime.now();
    }
    
    
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getGrampanchayatId() {
		return grampanchayatId;
	}

	public void setGrampanchayatId(String grampanchayatId) {
		this.grampanchayatId = grampanchayatId;
	}

	public String getGrampanchayatName() {
		return grampanchayatName;
	}

	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getKramank() {
		return kramank;
	}

	public void setKramank(String kramank) {
		this.kramank = kramank;
	}

	public String getNidhicheShirsh() {
		return nidhicheShirsh;
	}

	public void setNidhicheShirsh(String nidhicheShirsh) {
		this.nidhicheShirsh = nidhicheShirsh;
	}

	public String getUpaShirsh() {
		return upaShirsh;
	}

	public void setUpaShirsh(String upaShirsh) {
		this.upaShirsh = upaShirsh;
	}

	public String getMadheHonyachyaSambhavKharchach() {
		return madheHonyachyaSambhavKharchach;
	}

	public void setMadheHonyachyaSambhavKharchach(String madheHonyachyaSambhavKharchach) {
		this.madheHonyachyaSambhavKharchach = madheHonyachyaSambhavKharchach;
	}

	public String getYanniKelelaAndaj() {
		return yanniKelelaAndaj;
	}

	public void setYanniKelelaAndaj(String yanniKelelaAndaj) {
		this.yanniKelelaAndaj = yanniKelelaAndaj;
	}

	public String getSarvasadharanGoshwaraParinam() {
		return sarvasadharanGoshwaraParinam;
	}

	public void setSarvasadharanGoshwaraParinam(String sarvasadharanGoshwaraParinam) {
		this.sarvasadharanGoshwaraParinam = sarvasadharanGoshwaraParinam;
	}

	public String getSarvasadharanGoshwaraBaab() {
		return sarvasadharanGoshwaraBaab;
	}

	public void setSarvasadharanGoshwaraBaab(String sarvasadharanGoshwaraBaab) {
		this.sarvasadharanGoshwaraBaab = sarvasadharanGoshwaraBaab;
	}

	public String getSarvasadharanGoshwaraDarRupaye() {
		return sarvasadharanGoshwaraDarRupaye;
	}

	public void setSarvasadharanGoshwaraDarRupaye(String sarvasadharanGoshwaraDarRupaye) {
		this.sarvasadharanGoshwaraDarRupaye = sarvasadharanGoshwaraDarRupaye;
	}

	public String getSarvasadharanGoshwaraPratteki() {
		return sarvasadharanGoshwaraPratteki;
	}

	public void setSarvasadharanGoshwaraPratteki(String sarvasadharanGoshwaraPratteki) {
		this.sarvasadharanGoshwaraPratteki = sarvasadharanGoshwaraPratteki;
	}

	public String getSarvasadharanGoshwaraRakkamDashanshat() {
		return sarvasadharanGoshwaraRakkamDashanshat;
	}

	public void setSarvasadharanGoshwaraRakkamDashanshat(String sarvasadharanGoshwaraRakkamDashanshat) {
		this.sarvasadharanGoshwaraRakkamDashanshat = sarvasadharanGoshwaraRakkamDashanshat;
	}

	public String getMojmapAndajpatraKramank() {
		return mojmapAndajpatraKramank;
	}

	public void setMojmapAndajpatraKramank(String mojmapAndajpatraKramank) {
		this.mojmapAndajpatraKramank = mojmapAndajpatraKramank;
	}

	public String getMojmapAndajpatraLaambi() {
		return mojmapAndajpatraLaambi;
	}

	public void setMojmapAndajpatraLaambi(String mojmapAndajpatraLaambi) {
		this.mojmapAndajpatraLaambi = mojmapAndajpatraLaambi;
	}

	public String getMojmapAndajpatraRundi() {
		return mojmapAndajpatraRundi;
	}

	public void setMojmapAndajpatraRundi(String mojmapAndajpatraRundi) {
		this.mojmapAndajpatraRundi = mojmapAndajpatraRundi;
	}

	public String getMojmapAndajpatraKholi() {
		return mojmapAndajpatraKholi;
	}

	public void setMojmapAndajpatraKholi(String mojmapAndajpatraKholi) {
		this.mojmapAndajpatraKholi = mojmapAndajpatraKholi;
	}

	public String getMojmapAndajpatraParimanDashanshat() {
		return mojmapAndajpatraParimanDashanshat;
	}

	public void setMojmapAndajpatraParimanDashanshat(String mojmapAndajpatraParimanDashanshat) {
		this.mojmapAndajpatraParimanDashanshat = mojmapAndajpatraParimanDashanshat;
	}

	public String getEkun() {
		return ekun;
	}

	public void setEkun(String ekun) {
		this.ekun = ekun;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}
      
    
    // Getters and Setters (optional based on your project structure)
}