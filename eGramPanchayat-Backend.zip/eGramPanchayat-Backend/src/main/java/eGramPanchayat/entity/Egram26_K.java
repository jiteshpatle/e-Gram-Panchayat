package eGramPanchayat.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.annotation.LastModifiedDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@JsonInclude(JsonInclude.Include.NON_NULL)
@Table(name = "26_K_Jama_Masik_Vivaran")
public class Egram26_K {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    @Column(name = "year")
	    private String year;
	    
	    @Column(name = "employee_id")
	    private String employeeId;

	    @Column(name = "employee_name")
	    private String employeeName;

	    @Column(name = "grampanchayat_id")
	    private String grampanchayatId;

	    @Column(name = "grampanchayat_name")
	    private String grampanchayatName;

	    @CreationTimestamp
	    @Column(name = "created_date", updatable = false)
	    private LocalDateTime createdDate;
	    
	    @LastModifiedDate
	    @Column(name = "updated_date")
	    private LocalDateTime updatedDate;

	    @Column(name = "remark")
	    private String remark;
	    
	    //************ jama_Gramnidi **********************************
	    @Column(name = "jamaGramNidhi_AST")
	    private Long jamaGramNidhiArthSankalpniyaTartud;
	    @Column(name = "jamaGramNidhi_MMPJ")
	    private Long jamaGramNidhiMagilMahinyapurviPratakshJama;
	    @Column(name = "jamaGramNidhi_CMJ")
	    private Long jamaGramNidhiChaluMahinyapurviJama;
	    private Long jamaGramNidhiTotal;
	    
	    //********* Jama_kar ****************************
	    
	    @Column(name = "malmattaKar_AST")
	    private Long malmattaKarArthSankalpniyaTartud;
	    @Column(name = "malmattaKar_MMPJ")
	    private Long malmattaKarMagilMahinyapurviPratakshJama;
	    @Column(name = "malmattaKar_CMJ")
	    private Long malmattaKarChaluMahinyapurviJama;
	    private Long malmattaKarTotal;
	    
	    @Column(name = "divabattiKar_AST")
	    private Long divabattiKarArthSankalpniyaTartud;
	    @Column(name = "divabattiKar_MMPJ")
	    private Long divabattiKarMagilMahinyapurviPratakshJama;
	    @Column(name = "divabattiKar_CMJ")
	    private Long divabattiKarChaluMahinyapurviJama;
	    private Long divabattiKarTotal;
	    
	    @Column(name = "swachataKar_AST")
	    private Long swachataKarArthSankalpniyaTartud;
	    @Column(name = "swachataKar_MMPJ")
	    private Long swachataKarMagilMahinyapurviPratakshJama;
	    @Column(name = "swachataKar_CMJ")
	    private Long swachataKarChaluMahinyapurviJama;
	    private Long swachataKarTotal;
	    
	    @Column(name = "dukaneHotelKar_AST")
	    private Long dukaneHotelKarArthSankalpniyaTartud;
	    @Column(name = "dukaneHotelKar_MMPJ")
	    private Long dukaneHotelKarMagilMahinyapurviPratakshJama;
	    @Column(name = "dukaneHotelKar_CMJ")
	    private Long dukaneHotelKarChaluMahinyapurviJama;
	    private Long dukaneHotelKarTotal;
	    
	    @Column(name = "yatraKAar_AST")
	    private Long yatraKAarArthSankalpniyaTartud;
	    @Column(name = "yatraKAar_MMPJ")
	    private Long yatraKAarMagilMahinyapurviPratakshJama;
	    @Column(name = "yatraKAar_CMJ")
	    private Long yatraKAarChaluMahinyapurviJama;
	    private Long yatraKAarTotal;
	    
	    @Column(name = "jatraUttasav_AST")
	    private Long jatraUttasavArthSankalpniyaTartud;
	    @Column(name = "jatraUttasav_MMPJ")
	    private Long jatraUttasavMagilMahinyapurviPratakshJama;
	    @Column(name = "jatraUttasav_CMJ")
	    private Long jatraUttasavChaluMahinyapurviJama;
	    private Long jatraUttasavTotal;
	    
	    @Column(name = "cycleORVahnavarilKar_AST")
	    private Long cycleORVahnavarilKarArthSankalpniyaTartud;
	    @Column(name = "cycleORVahnavarilKar_MMPJ")
	    private Long cycleORVahnavarilKarMagilMahinyapurviPratakshJama;
	    @Column(name = "cycleORVahnavarilKar_CMJ")
	    private Long cycleORVahnavarilKarChaluMahinyapurviJama;
	    private Long cycleORVahnavarilKarTotal;
	    
	    @Column(name = "jamakarTollTax_AST")
	    private Long jamakarTollTaxArthSankalpniyaTartud;
	    @Column(name = "jamakarTollTax_MMPJ")
	    private Long jamakarTollTaxMagilMahinyapurviPratakshJama;
	    @Column(name = "jamakarTollTax_CMJ")
	    private Long jamakarTollTaxChaluMahinyapurviJama;
	    private Long jamakarTollTaxTotal;
	    
	    //********* Kharach ***********
	    
	    @Column(name = "gramNidhitunKharach_AST")
	    private Long gramNidhitunKharachArthSankalpniyaTartud;
	    @Column(name = "gramNidhitunKharach_MMPJ")
	    private Long gramNidhitunKharachMagilMahinyapurviPratakshJama;
	    @Column(name = "gramNidhitunKharach_CMJ")
	    private Long gramNidhitunKharachChaluMahinyapurviJama;
	    private Long gramNidhitunKharachTotal;
	    
	    @Column(name = "sarpanchMandhan_AST")
	    private Long sarpanchMandhanArthSankalpniyaTartud;
	    @Column(name = "sarpanchMandhan_MMPJ")
	    private Long sarpanchMandhanMagilMahinyapurviPratakshJama;
	    @Column(name = "sarpanchMandhan_CMJ")
	    private Long sarpanchMandhanChaluMahinyapurviJama;
	    private Long sarpanchMandhanTotal;
	    
	    @Column(name = "sadasyaBaithakBatta_AST")
	    private Long sadasyaBaithakBattaArthSankalpniyaTartud;
	    @Column(name = "sadasyaBaithakBatta_MMPJ")
	    private Long sadasyaBaithakBattaMagilMahinyapurviPratakshJama;
	    @Column(name = "sadasyaBaithakBatta_CMJ")
	    private Long sadasyaBaithakBattaChaluMahinyapurviJama;
	    private Long sadasyaBaithakBattaTotal;
	    
	    @Column(name = "sarpanchPravas_AST")
	    private Long sarpanchPravasArthSankalpniyaTartud;
	    @Column(name = "sarpanchPravas_MMPJ")
	    private Long sarpanchPravasMagilMahinyapurviPratakshJama;
	    @Column(name = "sarpanchPravas_CMJ")
	    private Long sarpanchPravasChaluMahinyapurviJama;
	    private Long sarpanchPravasTotal;
	    
	    @Column(name = "karmchariVetan_AST")
	    private Long karmchariVetanArthSankalpniyaTartud;
	    @Column(name = "karmchariVetan_MMPJ")
	    private Long karmchariVetanMagilMahinyapurviPratakshJama;
	    @Column(name = "karmchariVetan_CMJ")
	    private Long karmchariVetanChaluMahinyapurviJama;
	    private Long karmchariVetanTotal;
	    
	    @Column(name = "karmchariPravas_AST")
	    private Long karmchariPravasArthSankalpniyaTartud;
	    @Column(name = "karmchariPravas_MMPJ")
	    private Long karmchariPravasMagilMahinyapurviPratakshJama;
	    @Column(name = "karmchariPravas_CMJ")
	    private Long karmchariPravasChaluMahinyapurviJama;
	    private Long karmchariPravasTotal;
	    
	    @Column(name = "karyalinKharach_AST")
	    private Long karyalinKharachArthSankalpniyaTartud;
	    @Column(name = "karyalinKharach_MMPJ")
	    private Long karyalinKharachMagilMahinyapurviPratakshJama;
	    @Column(name = "karyalinKharach_CMJ")
	    private Long karyalinKharachChaluMahinyapurviJama;
	    private Long karyalinKharachTotal;
	    
	    @Column(name = "sangnakKharch_AST")
	    private Long sangnakKharchArthSankalpniyaTartud;
	    @Column(name = "sangnakKharch_MMPJ")
	    private Long sangnakKharchMagilMahinyapurviPratakshJama;
	    @Column(name = "sangnakKharch_CMJ")
	    private Long sangnakKharchChaluMahinyapurviJama;
	    private Long sangnakKharchTotal;
	    
	    @Column(name = "jahiratKharch_AST")
	    private Long jahiratKharchArthSankalpniyaTartud;
	    @Column(name = "jahiratKharch_MMPJ")
	    private Long jahiratKharchMagilMahinyapurviPratakshJama;
	    @Column(name = "jahiratKharch_CMJ")
	    private Long jahiratKharchChaluMahinyapurviJama;
	    private Long jahiratKharchTotal;
	    
	    @Column(name = "phogingORGhantagadisathiTel_AST")
	    private Long phogingORGhantagadisathiTelArthSankalpniyaTartud;
	    @Column(name = "phogingORGhantagadisathiTel_MMPJ")
	    private Long phogingORGhantagadisathiTelMagilMahinyapurviPratakshJama;
	    @Column(name = "phogingORGhantagadisathiTel_CMJ")
	    private Long phogingORGhantagadisathiTelChaluMahinyapurviJama;
	    private Long phogingORGhantagadisathiTelTotal;
		public Egram26_K() {
			super();
		}
		public Egram26_K(Long id, String year, String employeeId, String employeeName, String grampanchayatId,
				String grampanchayatName, LocalDateTime createdDate, LocalDateTime updatedDate, String remark,
				Long jamaGramNidhiArthSankalpniyaTartud,Long jamaGramNidhiMagilMahinyapurviPratakshJama,
				Long jamaGramNidhiChaluMahinyapurviJama,Long jamaGramNidhiTotal,Long malmattaKarArthSankalpniyaTartud,
				Long malmattaKarMagilMahinyapurviPratakshJama,Long malmattaKarChaluMahinyapurviJama,
				Long malmattaKarTotal,Long divabattiKarArthSankalpniyaTartud,Long divabattiKarMagilMahinyapurviPratakshJama,
				Long divabattiKarChaluMahinyapurviJama,Long divabattiKarTotal,Long swachataKarArthSankalpniyaTartud, 
				Long swachataKarMagilMahinyapurviPratakshJama,Long swachataKarChaluMahinyapurviJama, 
				Long swachataKarTotal,Long dukaneHotelKarArthSankalpniyaTartud,
				Long dukaneHotelKarMagilMahinyapurviPratakshJama,
				Long dukaneHotelKarChaluMahinyapurviJama,Long dukaneHotelKarTotal,
				Long yatraKAarArthSankalpniyaTartud,
				Long yatraKAarMagilMahinyapurviPratakshJama,
				Long yatraKAarChaluMahinyapurviJama,Long yatraKAarTotal,
				Long jatraUttasavArthSankalpniyaTartud,
				Long jatraUttasavMagilMahinyapurviPratakshJama,
				Long jatraUttasavChaluMahinyapurviJama,Long jatraUttasavTotal, 
				Long cycleORVahnavarilKarArthSankalpniyaTartud,
				Long cycleORVahnavarilKarMagilMahinyapurviPratakshJama,
				Long cycleORVahnavarilKarChaluMahinyapurviJama,
				Long cycleORVahnavarilKarTotal,Long jamakarTollTaxArthSankalpniyaTartud, 
				Long jamakarTollTaxMagilMahinyapurviPratakshJama,
				Long jamakarTollTaxChaluMahinyapurviJama,Long jamakarTollTaxTotal,
				Long gramNidhitunKharachArthSankalpniyaTartud, Long gramNidhitunKharachMagilMahinyapurviPratakshJama,
				Long gramNidhitunKharachChaluMahinyapurviJama, Long gramNidhitunKharachTotal,
				Long sarpanchMandhanArthSankalpniyaTartud, Long sarpanchMandhanMagilMahinyapurviPratakshJama,
				Long sarpanchMandhanChaluMahinyapurviJama, Long sarpanchMandhanTotal,
				Long sadasyaBaithakBattaArthSankalpniyaTartud, Long sadasyaBaithakBattaMagilMahinyapurviPratakshJama,
				Long sadasyaBaithakBattaChaluMahinyapurviJama, Long sadasyaBaithakBattaTotal,
				Long sarpanchPravasArthSankalpniyaTartud,
				Long sarpanchPravasMagilMahinyapurviPratakshJama,
				Long sarpanchPravasChaluMahinyapurviJama,
				Long sarpanchPravasTotal, Long karmchariVetanArthSankalpniyaTartud,
				Long karmchariVetanMagilMahinyapurviPratakshJama,
				Long karmchariVetanChaluMahinyapurviJama, Long karmchariVetanTotal,
				Long karmchariPravasArthSankalpniyaTartud,
				Long karmchariPravasMagilMahinyapurviPratakshJama,
				Long karmchariPravasChaluMahinyapurviJama,
				Long karmchariPravasTotal, Long karyalinKharachArthSankalpniyaTartud,
				Long karyalinKharachMagilMahinyapurviPratakshJama, Long karyalinKharachChaluMahinyapurviJama,
				Long karyalinKharachTotal, Long sangnakKharchArthSankalpniyaTartud,
				Long sangnakKharchMagilMahinyapurviPratakshJama,
				Long sangnakKharchChaluMahinyapurviJama,Long sangnakKharchTotal,
				Long jahiratKharchArthSankalpniyaTartud,
				Long jahiratKharchMagilMahinyapurviPratakshJama,
				Long jahiratKharchChaluMahinyapurviJama,Long jahiratKharchTotal,
				Long phogingORGhantagadisathiTelArthSankalpniyaTartud,
				Long phogingORGhantagadisathiTelMagilMahinyapurviPratakshJama,
				Long phogingORGhantagadisathiTelChaluMahinyapurviJama, Long phogingORGhantagadisathiTelTotal) {
			super();
			this.id = id;
			this.year = year;
			this.employeeId = employeeId;
			this.employeeName = employeeName;
			this.grampanchayatId = grampanchayatId;
			this.grampanchayatName = grampanchayatName;
			this.createdDate = createdDate;
			this.updatedDate = updatedDate;
			this.remark = remark;
			this.jamaGramNidhiArthSankalpniyaTartud = jamaGramNidhiArthSankalpniyaTartud;
			this.jamaGramNidhiMagilMahinyapurviPratakshJama = jamaGramNidhiMagilMahinyapurviPratakshJama;
			this.jamaGramNidhiChaluMahinyapurviJama = jamaGramNidhiChaluMahinyapurviJama;
			this.jamaGramNidhiTotal = jamaGramNidhiTotal;
			this.malmattaKarArthSankalpniyaTartud = malmattaKarArthSankalpniyaTartud;
			this.malmattaKarMagilMahinyapurviPratakshJama = malmattaKarMagilMahinyapurviPratakshJama;
			this.malmattaKarChaluMahinyapurviJama = malmattaKarChaluMahinyapurviJama;
			this.malmattaKarTotal = malmattaKarTotal;
			this.divabattiKarArthSankalpniyaTartud = divabattiKarArthSankalpniyaTartud;
			this.divabattiKarMagilMahinyapurviPratakshJama = divabattiKarMagilMahinyapurviPratakshJama;
			this.divabattiKarChaluMahinyapurviJama = divabattiKarChaluMahinyapurviJama;
			this.divabattiKarTotal = divabattiKarTotal;
			this.swachataKarArthSankalpniyaTartud = swachataKarArthSankalpniyaTartud;
			this.swachataKarMagilMahinyapurviPratakshJama = swachataKarMagilMahinyapurviPratakshJama;
			this.swachataKarChaluMahinyapurviJama = swachataKarChaluMahinyapurviJama;
			this.swachataKarTotal = swachataKarTotal;
			this.dukaneHotelKarArthSankalpniyaTartud = dukaneHotelKarArthSankalpniyaTartud;
			this.dukaneHotelKarMagilMahinyapurviPratakshJama = dukaneHotelKarMagilMahinyapurviPratakshJama;
			this.dukaneHotelKarChaluMahinyapurviJama = dukaneHotelKarChaluMahinyapurviJama;
			this.dukaneHotelKarTotal = dukaneHotelKarTotal;
			this.yatraKAarArthSankalpniyaTartud = yatraKAarArthSankalpniyaTartud;
			this.yatraKAarMagilMahinyapurviPratakshJama = yatraKAarMagilMahinyapurviPratakshJama;
			this.yatraKAarChaluMahinyapurviJama = yatraKAarChaluMahinyapurviJama;
			this.yatraKAarTotal = yatraKAarTotal;
			this.jatraUttasavArthSankalpniyaTartud = jatraUttasavArthSankalpniyaTartud;
			this.jatraUttasavMagilMahinyapurviPratakshJama = jatraUttasavMagilMahinyapurviPratakshJama;
			this.jatraUttasavChaluMahinyapurviJama = jatraUttasavChaluMahinyapurviJama;
			this.jatraUttasavTotal = jatraUttasavTotal;
			this.cycleORVahnavarilKarArthSankalpniyaTartud = cycleORVahnavarilKarArthSankalpniyaTartud;
			this.cycleORVahnavarilKarMagilMahinyapurviPratakshJama = cycleORVahnavarilKarMagilMahinyapurviPratakshJama;
			this.cycleORVahnavarilKarChaluMahinyapurviJama = cycleORVahnavarilKarChaluMahinyapurviJama;
			this.cycleORVahnavarilKarTotal = cycleORVahnavarilKarTotal;
			this.jamakarTollTaxArthSankalpniyaTartud = jamakarTollTaxArthSankalpniyaTartud;
			this.jamakarTollTaxMagilMahinyapurviPratakshJama = jamakarTollTaxMagilMahinyapurviPratakshJama;
			this.jamakarTollTaxChaluMahinyapurviJama = jamakarTollTaxChaluMahinyapurviJama;
			this.jamakarTollTaxTotal = jamakarTollTaxTotal;
			this.gramNidhitunKharachArthSankalpniyaTartud = gramNidhitunKharachArthSankalpniyaTartud;
			this.gramNidhitunKharachMagilMahinyapurviPratakshJama = gramNidhitunKharachMagilMahinyapurviPratakshJama;
			this.gramNidhitunKharachChaluMahinyapurviJama = gramNidhitunKharachChaluMahinyapurviJama;
			this.gramNidhitunKharachTotal = gramNidhitunKharachTotal;
			this.sarpanchMandhanArthSankalpniyaTartud = sarpanchMandhanArthSankalpniyaTartud;
			this.sarpanchMandhanMagilMahinyapurviPratakshJama = sarpanchMandhanMagilMahinyapurviPratakshJama;
			this.sarpanchMandhanChaluMahinyapurviJama = sarpanchMandhanChaluMahinyapurviJama;
			this.sarpanchMandhanTotal = sarpanchMandhanTotal;
			this.sadasyaBaithakBattaArthSankalpniyaTartud = sadasyaBaithakBattaArthSankalpniyaTartud;
			this.sadasyaBaithakBattaMagilMahinyapurviPratakshJama = sadasyaBaithakBattaMagilMahinyapurviPratakshJama;
			this.sadasyaBaithakBattaChaluMahinyapurviJama = sadasyaBaithakBattaChaluMahinyapurviJama;
			this.sadasyaBaithakBattaTotal = sadasyaBaithakBattaTotal;
			this.sarpanchPravasArthSankalpniyaTartud = sarpanchPravasArthSankalpniyaTartud;
			this.sarpanchPravasMagilMahinyapurviPratakshJama = sarpanchPravasMagilMahinyapurviPratakshJama;
			this.sarpanchPravasChaluMahinyapurviJama = sarpanchPravasChaluMahinyapurviJama;
			this.sarpanchPravasTotal = sarpanchPravasTotal;
			this.karmchariVetanArthSankalpniyaTartud = karmchariVetanArthSankalpniyaTartud;
			this.karmchariVetanMagilMahinyapurviPratakshJama = karmchariVetanMagilMahinyapurviPratakshJama;
			this.karmchariVetanChaluMahinyapurviJama = karmchariVetanChaluMahinyapurviJama;
			this.karmchariVetanTotal = karmchariVetanTotal;
			this.karmchariPravasArthSankalpniyaTartud = karmchariPravasArthSankalpniyaTartud;
			this.karmchariPravasMagilMahinyapurviPratakshJama = karmchariPravasMagilMahinyapurviPratakshJama;
			this.karmchariPravasChaluMahinyapurviJama = karmchariPravasChaluMahinyapurviJama;
			this.karmchariPravasTotal = karmchariPravasTotal;
			this.karyalinKharachArthSankalpniyaTartud = karyalinKharachArthSankalpniyaTartud;
			this.karyalinKharachMagilMahinyapurviPratakshJama = karyalinKharachMagilMahinyapurviPratakshJama;
			this.karyalinKharachChaluMahinyapurviJama = karyalinKharachChaluMahinyapurviJama;
			this.karyalinKharachTotal = karyalinKharachTotal;
			this.sangnakKharchArthSankalpniyaTartud = sangnakKharchArthSankalpniyaTartud;
			this.sangnakKharchMagilMahinyapurviPratakshJama = sangnakKharchMagilMahinyapurviPratakshJama;
			this.sangnakKharchChaluMahinyapurviJama = sangnakKharchChaluMahinyapurviJama;
			this.sangnakKharchTotal = sangnakKharchTotal;
			this.jahiratKharchArthSankalpniyaTartud = jahiratKharchArthSankalpniyaTartud;
			this.jahiratKharchMagilMahinyapurviPratakshJama = jahiratKharchMagilMahinyapurviPratakshJama;
			this.jahiratKharchChaluMahinyapurviJama = jahiratKharchChaluMahinyapurviJama;
			this.jahiratKharchTotal = jahiratKharchTotal;
			this.phogingORGhantagadisathiTelArthSankalpniyaTartud = phogingORGhantagadisathiTelArthSankalpniyaTartud;
			this.phogingORGhantagadisathiTelMagilMahinyapurviPratakshJama = phogingORGhantagadisathiTelMagilMahinyapurviPratakshJama;
			this.phogingORGhantagadisathiTelChaluMahinyapurviJama = phogingORGhantagadisathiTelChaluMahinyapurviJama;
			this.phogingORGhantagadisathiTelTotal = phogingORGhantagadisathiTelTotal;
		}
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getYear() {
			return year;
		}
		public void setYear(String year) {
			this.year = year;
		}
		public String getEmployeeId() {
			return employeeId;
		}
		public void setEmployeeId(String employeeId) {
			this.employeeId = employeeId;
		}
		public String getEmployeeName() {
			return employeeName;
		}
		public void setEmployeeName(String employeeName) {
			this.employeeName = employeeName;
		}
		public String getGrampanchayatId() {
			return grampanchayatId;
		}
		public void setGrampanchayatId(String grampanchayatId) {
			this.grampanchayatId = grampanchayatId;
		}
		public String getGrampanchayatName() {
			return grampanchayatName;
		}
		public void setGrampanchayatName(String grampanchayatName) {
			this.grampanchayatName = grampanchayatName;
		}
		public LocalDateTime getCreatedDate() {
			return createdDate;
		}
		public void setCreatedDate(LocalDateTime createdDate) {
			this.createdDate = createdDate;
		}
		public LocalDateTime getUpdatedDate() {
			return updatedDate;
		}
		public void setUpdatedDate(LocalDateTime updatedDate) {
			this.updatedDate = updatedDate;
		}
		public String getRemark() {
			return remark;
		}
		public void setRemark(String remark) {
			this.remark = remark;
		}
		public Long getJamaGramNidhiArthSankalpniyaTartud() {
			return jamaGramNidhiArthSankalpniyaTartud;
		}
		public void setJamaGramNidhiArthSankalpniyaTartud(Long jamaGramNidhiArthSankalpniyaTartud) {
			this.jamaGramNidhiArthSankalpniyaTartud = jamaGramNidhiArthSankalpniyaTartud;
		}
		public Long getJamaGramNidhiMagilMahinyapurviPratakshJama() {
			return jamaGramNidhiMagilMahinyapurviPratakshJama;
		}
		public void setJamaGramNidhiMagilMahinyapurviPratakshJama(Long jamaGramNidhiMagilMahinyapurviPratakshJama) {
			this.jamaGramNidhiMagilMahinyapurviPratakshJama = jamaGramNidhiMagilMahinyapurviPratakshJama;
		}
		public Long getJamaGramNidhiChaluMahinyapurviJama() {
			return jamaGramNidhiChaluMahinyapurviJama;
		}
		public void setJamaGramNidhiChaluMahinyapurviJama(Long jamaGramNidhiChaluMahinyapurviJama) {
			this.jamaGramNidhiChaluMahinyapurviJama = jamaGramNidhiChaluMahinyapurviJama;
		}
		public Long getJamaGramNidhiTotal() {
			return jamaGramNidhiTotal;
		}
		public void setJamaGramNidhiTotal(Long jamaGramNidhiTotal) {
			this.jamaGramNidhiTotal = jamaGramNidhiTotal;
		}
		public Long getmalmattaKarArthSankalpniyaTartud() {
			return malmattaKarArthSankalpniyaTartud;
		}
		public void setmalmattaKarArthSankalpniyaTartud(
				Long malmattaKarArthSankalpniyaTartud) {
			this.malmattaKarArthSankalpniyaTartud = malmattaKarArthSankalpniyaTartud;
		}
		public Long getmalmattaKarMagilMahinyapurviPratakshJama() {
			return malmattaKarMagilMahinyapurviPratakshJama;
		}
		public void setmalmattaKarMagilMahinyapurviPratakshJama(
				Long malmattaKarMagilMahinyapurviPratakshJama) {
			this.malmattaKarMagilMahinyapurviPratakshJama = malmattaKarMagilMahinyapurviPratakshJama;
		}
		public Long getmalmattaKarChaluMahinyapurviJama() {
			return malmattaKarChaluMahinyapurviJama;
		}
		public void setmalmattaKarChaluMahinyapurviJama(Long malmattaKarChaluMahinyapurviJama) {
			this.malmattaKarChaluMahinyapurviJama = malmattaKarChaluMahinyapurviJama;
		}
		public Long getmalmattaKarTotal() {
			return malmattaKarTotal;
		}
		public void setmalmattaKarTotal(Long malmattaKarTotal) {
			this.malmattaKarTotal = malmattaKarTotal;
		}
		public Long getdivabattiKarArthSankalpniyaTartud() {
			return divabattiKarArthSankalpniyaTartud;
		}
		public void setdivabattiKarArthSankalpniyaTartud(Long divabattiKarArthSankalpniyaTartud) {
			this.divabattiKarArthSankalpniyaTartud = divabattiKarArthSankalpniyaTartud;
		}
		public Long getdivabattiKarMagilMahinyapurviPratakshJama() {
			return divabattiKarMagilMahinyapurviPratakshJama;
		}
		public void setdivabattiKarMagilMahinyapurviPratakshJama(
				Long divabattiKarMagilMahinyapurviPratakshJama) {
			this.divabattiKarMagilMahinyapurviPratakshJama = divabattiKarMagilMahinyapurviPratakshJama;
		}
		public Long getdivabattiKarChaluMahinyapurviJama() {
			return divabattiKarChaluMahinyapurviJama;
		}
		public void setdivabattiKarChaluMahinyapurviJama(Long divabattiKarChaluMahinyapurviJama) {
			this.divabattiKarChaluMahinyapurviJama = divabattiKarChaluMahinyapurviJama;
		}
		public Long getdivabattiKarTotal() {
			return divabattiKarTotal;
		}
		public void setdivabattiKarTotal(Long divabattiKarTotal) {
			this.divabattiKarTotal = divabattiKarTotal;
		}
		public Long getswachataKarArthSankalpniyaTartud() {
			return swachataKarArthSankalpniyaTartud;
		}
		public void setswachataKarArthSankalpniyaTartud(Long swachataKarArthSankalpniyaTartud) {
			this.swachataKarArthSankalpniyaTartud = swachataKarArthSankalpniyaTartud;
		}
		public Long getswachataKarMagilMahinyapurviPratakshJama() {
			return swachataKarMagilMahinyapurviPratakshJama;
		}
		public void setswachataKarMagilMahinyapurviPratakshJama(
				Long swachataKarMagilMahinyapurviPratakshJama) {
			this.swachataKarMagilMahinyapurviPratakshJama = swachataKarMagilMahinyapurviPratakshJama;
		}
		public Long getswachataKarChaluMahinyapurviJama() {
			return swachataKarChaluMahinyapurviJama;
		}
		public void setswachataKarChaluMahinyapurviJama(Long swachataKarChaluMahinyapurviJama) {
			this.swachataKarChaluMahinyapurviJama = swachataKarChaluMahinyapurviJama;
		}
		public Long getswachataKarTotal() {
			return swachataKarTotal;
		}
		public void setswachataKarTotal(Long swachataKarTotal) {
			this.swachataKarTotal = swachataKarTotal;
		}
		public Long getdukaneHotelKarArthSankalpniyaTartud() {
			return dukaneHotelKarArthSankalpniyaTartud;
		}
		public void setdukaneHotelKarArthSankalpniyaTartud(
				Long dukaneHotelKarArthSankalpniyaTartud) {
			this.dukaneHotelKarArthSankalpniyaTartud = dukaneHotelKarArthSankalpniyaTartud;
		}
		public Long getdukaneHotelKarMagilMahinyapurviPratakshJama() {
			return dukaneHotelKarMagilMahinyapurviPratakshJama;
		}
		public void setdukaneHotelKarMagilMahinyapurviPratakshJama(
				Long dukaneHotelKarMagilMahinyapurviPratakshJama) {
			this.dukaneHotelKarMagilMahinyapurviPratakshJama = dukaneHotelKarMagilMahinyapurviPratakshJama;
		}
		public Long getdukaneHotelKarChaluMahinyapurviJama() {
			return dukaneHotelKarChaluMahinyapurviJama;
		}
		public void setdukaneHotelKarChaluMahinyapurviJama(
				Long dukaneHotelKarChaluMahinyapurviJama) {
			this.dukaneHotelKarChaluMahinyapurviJama = dukaneHotelKarChaluMahinyapurviJama;
		}
		public Long getdukaneHotelKarTotal() {
			return dukaneHotelKarTotal;
		}
		public void setdukaneHotelKarTotal(Long dukaneHotelKarTotal) {
			this.dukaneHotelKarTotal = dukaneHotelKarTotal;
		}
		public Long getyatraKAarArthSankalpniyaTartud() {
			return yatraKAarArthSankalpniyaTartud;
		}
		public void setyatraKAarArthSankalpniyaTartud(Long yatraKAarArthSankalpniyaTartud) {
			this.yatraKAarArthSankalpniyaTartud = yatraKAarArthSankalpniyaTartud;
		}
		public Long getyatraKAarMagilMahinyapurviPratakshJama() {
			return yatraKAarMagilMahinyapurviPratakshJama;
		}
		public void setyatraKAarMagilMahinyapurviPratakshJama(Long yatraKAarMagilMahinyapurviPratakshJama) {
			this.yatraKAarMagilMahinyapurviPratakshJama = yatraKAarMagilMahinyapurviPratakshJama;
		}
		public Long getyatraKAarChaluMahinyapurviJama() {
			return yatraKAarChaluMahinyapurviJama;
		}
		public void setyatraKAarChaluMahinyapurviJama(Long yatraKAarChaluMahinyapurviJama) {
			this.yatraKAarChaluMahinyapurviJama = yatraKAarChaluMahinyapurviJama;
		}
		public Long getyatraKAarTotal() {
			return yatraKAarTotal;
		}
		public void setyatraKAarTotal(Long yatraKAarTotal) {
			this.yatraKAarTotal = yatraKAarTotal;
		}
		public Long getjatraUttasavArthSankalpniyaTartud() {
			return jatraUttasavArthSankalpniyaTartud;
		}
		public void setjatraUttasavArthSankalpniyaTartud(
				Long jatraUttasavArthSankalpniyaTartud) {
			this.jatraUttasavArthSankalpniyaTartud = jatraUttasavArthSankalpniyaTartud;
		}
		public Long getjatraUttasavMagilMahinyapurviPratakshJama() {
			return jatraUttasavMagilMahinyapurviPratakshJama;
		}
		public void setjatraUttasavMagilMahinyapurviPratakshJama(
				Long jatraUttasavMagilMahinyapurviPratakshJama) {
			this.jatraUttasavMagilMahinyapurviPratakshJama = jatraUttasavMagilMahinyapurviPratakshJama;
		}
		public Long getjatraUttasavChaluMahinyapurviJama() {
			return jatraUttasavChaluMahinyapurviJama;
		}
		public void setjatraUttasavChaluMahinyapurviJama(
				Long jatraUttasavChaluMahinyapurviJama) {
			this.jatraUttasavChaluMahinyapurviJama = jatraUttasavChaluMahinyapurviJama;
		}
		public Long getjatraUttasavTotal() {
			return jatraUttasavTotal;
		}
		public void setjatraUttasavTotal(Long jatraUttasavTotal) {
			this.jatraUttasavTotal = jatraUttasavTotal;
		}
		public Long getcycleORVahnavarilKarArthSankalpniyaTartud() {
			return cycleORVahnavarilKarArthSankalpniyaTartud;
		}
		public void setcycleORVahnavarilKarArthSankalpniyaTartud(
				Long cycleORVahnavarilKarArthSankalpniyaTartud) {
			this.cycleORVahnavarilKarArthSankalpniyaTartud = cycleORVahnavarilKarArthSankalpniyaTartud;
		}
		public Long getcycleORVahnavarilKarMagilMahinyapurviPratakshJama() {
			return cycleORVahnavarilKarMagilMahinyapurviPratakshJama;
		}
		public void setcycleORVahnavarilKarMagilMahinyapurviPratakshJama(
				Long cycleORVahnavarilKarMagilMahinyapurviPratakshJama) {
			this.cycleORVahnavarilKarMagilMahinyapurviPratakshJama = cycleORVahnavarilKarMagilMahinyapurviPratakshJama;
		}
		public Long getcycleORVahnavarilKarChaluMahinyapurviJama() {
			return cycleORVahnavarilKarChaluMahinyapurviJama;
		}
		public void setcycleORVahnavarilKarChaluMahinyapurviJama(
				Long cycleORVahnavarilKarChaluMahinyapurviJama) {
			this.cycleORVahnavarilKarChaluMahinyapurviJama = cycleORVahnavarilKarChaluMahinyapurviJama;
		}
		public Long getcycleORVahnavarilKarTotal() {
			return cycleORVahnavarilKarTotal;
		}
		public void setcycleORVahnavarilKarTotal(Long cycleORVahnavarilKarTotal) {
			this.cycleORVahnavarilKarTotal = cycleORVahnavarilKarTotal;
		}
		public Long getJamakarTollTaxArthSankalpniyaTartud() {
			return jamakarTollTaxArthSankalpniyaTartud;
		}
		public void setJamakarTollTaxArthSankalpniyaTartud(Long jamakarTollTaxArthSankalpniyaTartud) {
			this.jamakarTollTaxArthSankalpniyaTartud = jamakarTollTaxArthSankalpniyaTartud;
		}
		public Long getJamakarTollTaxMagilMahinyapurviPratakshJama() {
			return jamakarTollTaxMagilMahinyapurviPratakshJama;
		}
		public void setJamakarTollTaxMagilMahinyapurviPratakshJama(Long jamakarTollTaxMagilMahinyapurviPratakshJama) {
			this.jamakarTollTaxMagilMahinyapurviPratakshJama = jamakarTollTaxMagilMahinyapurviPratakshJama;
		}
		public Long getJamakarTollTaxChaluMahinyapurviJama() {
			return jamakarTollTaxChaluMahinyapurviJama;
		}
		public void setJamakarTollTaxChaluMahinyapurviJama(Long jamakarTollTaxChaluMahinyapurviJama) {
			this.jamakarTollTaxChaluMahinyapurviJama = jamakarTollTaxChaluMahinyapurviJama;
		}
		public Long getJamakarTollTaxTotal() {
			return jamakarTollTaxTotal;
		}
		public void setJamakarTollTaxTotal(Long jamakarTollTaxTotal) {
			this.jamakarTollTaxTotal = jamakarTollTaxTotal;
		}
		public Long getGramNidhitunKharachArthSankalpniyaTartud() {
			return gramNidhitunKharachArthSankalpniyaTartud;
		}
		public void setGramNidhitunKharachArthSankalpniyaTartud(Long gramNidhitunKharachArthSankalpniyaTartud) {
			this.gramNidhitunKharachArthSankalpniyaTartud = gramNidhitunKharachArthSankalpniyaTartud;
		}
		public Long getGramNidhitunKharachMagilMahinyapurviPratakshJama() {
			return gramNidhitunKharachMagilMahinyapurviPratakshJama;
		}
		public void setGramNidhitunKharachMagilMahinyapurviPratakshJama(
				Long gramNidhitunKharachMagilMahinyapurviPratakshJama) {
			this.gramNidhitunKharachMagilMahinyapurviPratakshJama = gramNidhitunKharachMagilMahinyapurviPratakshJama;
		}
		public Long getGramNidhitunKharachChaluMahinyapurviJama() {
			return gramNidhitunKharachChaluMahinyapurviJama;
		}
		public void setGramNidhitunKharachChaluMahinyapurviJama(Long gramNidhitunKharachChaluMahinyapurviJama) {
			this.gramNidhitunKharachChaluMahinyapurviJama = gramNidhitunKharachChaluMahinyapurviJama;
		}
		public Long getGramNidhitunKharachTotal() {
			return gramNidhitunKharachTotal;
		}
		public void setGramNidhitunKharachTotal(Long gramNidhitunKharachTotal) {
			this.gramNidhitunKharachTotal = gramNidhitunKharachTotal;
		}
		public Long getSarpanchMandhanArthSankalpniyaTartud() {
			return sarpanchMandhanArthSankalpniyaTartud;
		}
		public void setSarpanchMandhanArthSankalpniyaTartud(Long sarpanchMandhanArthSankalpniyaTartud) {
			this.sarpanchMandhanArthSankalpniyaTartud = sarpanchMandhanArthSankalpniyaTartud;
		}
		public Long getSarpanchMandhanMagilMahinyapurviPratakshJama() {
			return sarpanchMandhanMagilMahinyapurviPratakshJama;
		}
		public void setSarpanchMandhanMagilMahinyapurviPratakshJama(Long sarpanchMandhanMagilMahinyapurviPratakshJama) {
			this.sarpanchMandhanMagilMahinyapurviPratakshJama = sarpanchMandhanMagilMahinyapurviPratakshJama;
		}
		public Long getSarpanchMandhanChaluMahinyapurviJama() {
			return sarpanchMandhanChaluMahinyapurviJama;
		}
		public void setSarpanchMandhanChaluMahinyapurviJama(Long sarpanchMandhanChaluMahinyapurviJama) {
			this.sarpanchMandhanChaluMahinyapurviJama = sarpanchMandhanChaluMahinyapurviJama;
		}
		public Long getSarpanchMandhanTotal() {
			return sarpanchMandhanTotal;
		}
		public void setSarpanchMandhanTotal(Long sarpanchMandhanTotal) {
			this.sarpanchMandhanTotal = sarpanchMandhanTotal;
		}
		public Long getSadasyaBaithakBattaArthSankalpniyaTartud() {
			return sadasyaBaithakBattaArthSankalpniyaTartud;
		}
		public void setSadasyaBaithakBattaArthSankalpniyaTartud(Long sadasyaBaithakBattaArthSankalpniyaTartud) {
			this.sadasyaBaithakBattaArthSankalpniyaTartud = sadasyaBaithakBattaArthSankalpniyaTartud;
		}
		public Long getSadasyaBaithakBattaMagilMahinyapurviPratakshJama() {
			return sadasyaBaithakBattaMagilMahinyapurviPratakshJama;
		}
		public void setSadasyaBaithakBattaMagilMahinyapurviPratakshJama(
				Long sadasyaBaithakBattaMagilMahinyapurviPratakshJama) {
			this.sadasyaBaithakBattaMagilMahinyapurviPratakshJama = sadasyaBaithakBattaMagilMahinyapurviPratakshJama;
		}
		public Long getSadasyaBaithakBattaChaluMahinyapurviJama() {
			return sadasyaBaithakBattaChaluMahinyapurviJama;
		}
		public void setSadasyaBaithakBattaChaluMahinyapurviJama(Long sadasyaBaithakBattaChaluMahinyapurviJama) {
			this.sadasyaBaithakBattaChaluMahinyapurviJama = sadasyaBaithakBattaChaluMahinyapurviJama;
		}
		public Long getSadasyaBaithakBattaTotal() {
			return sadasyaBaithakBattaTotal;
		}
		public void setSadasyaBaithakBattaTotal(Long sadasyaBaithakBattaTotal) {
			this.sadasyaBaithakBattaTotal = sadasyaBaithakBattaTotal;
		}
		public Long getsarpanchPravasArthSankalpniyaTartud() {
			return sarpanchPravasArthSankalpniyaTartud;
		}
		public void setsarpanchPravasArthSankalpniyaTartud(
				Long sarpanchPravasArthSankalpniyaTartud) {
			this.sarpanchPravasArthSankalpniyaTartud = sarpanchPravasArthSankalpniyaTartud;
		}
		public Long getsarpanchPravasMagilMahinyapurviPratakshJama() {
			return sarpanchPravasMagilMahinyapurviPratakshJama;
		}
		public void setsarpanchPravasMagilMahinyapurviPratakshJama(
				Long sarpanchPravasMagilMahinyapurviPratakshJama) {
			this.sarpanchPravasMagilMahinyapurviPratakshJama = sarpanchPravasMagilMahinyapurviPratakshJama;
		}
		public Long getsarpanchPravasChaluMahinyapurviJama() {
			return sarpanchPravasChaluMahinyapurviJama;
		}
		public void setsarpanchPravasChaluMahinyapurviJama(
				Long sarpanchPravasChaluMahinyapurviJama) {
			this.sarpanchPravasChaluMahinyapurviJama = sarpanchPravasChaluMahinyapurviJama;
		}
		public Long getsarpanchPravasTotal() {
			return sarpanchPravasTotal;
		}
		public void setsarpanchPravasTotal(Long sarpanchPravasTotal) {
			this.sarpanchPravasTotal = sarpanchPravasTotal;
		}
		public Long getkarmchariVetanArthSankalpniyaTartud() {
			return karmchariVetanArthSankalpniyaTartud;
		}
		public void setkarmchariVetanArthSankalpniyaTartud(
				Long karmchariVetanArthSankalpniyaTartud) {
			this.karmchariVetanArthSankalpniyaTartud = karmchariVetanArthSankalpniyaTartud;
		}
		public Long getkarmchariVetanMagilMahinyapurviPratakshJama() {
			return karmchariVetanMagilMahinyapurviPratakshJama;
		}
		public void setkarmchariVetanMagilMahinyapurviPratakshJama(
				Long karmchariVetanMagilMahinyapurviPratakshJama) {
			this.karmchariVetanMagilMahinyapurviPratakshJama = karmchariVetanMagilMahinyapurviPratakshJama;
		}
		public Long getkarmchariVetanChaluMahinyapurviJama() {
			return karmchariVetanChaluMahinyapurviJama;
		}
		public void setkarmchariVetanChaluMahinyapurviJama(
				Long karmchariVetanChaluMahinyapurviJama) {
			this.karmchariVetanChaluMahinyapurviJama = karmchariVetanChaluMahinyapurviJama;
		}
		public Long getkarmchariVetanTotal() {
			return karmchariVetanTotal;
		}
		public void setkarmchariVetanTotal(Long karmchariVetanTotal) {
			this.karmchariVetanTotal = karmchariVetanTotal;
		}
		public Long getkarmchariPravasArthSankalpniyaTartud() {
			return karmchariPravasArthSankalpniyaTartud;
		}
		public void setkarmchariPravasArthSankalpniyaTartud(
				Long karmchariPravasArthSankalpniyaTartud) {
			this.karmchariPravasArthSankalpniyaTartud = karmchariPravasArthSankalpniyaTartud;
		}
		public Long getkarmchariPravasMagilMahinyapurviPratakshJama() {
			return karmchariPravasMagilMahinyapurviPratakshJama;
		}
		public void setkarmchariPravasMagilMahinyapurviPratakshJama(
				Long karmchariPravasMagilMahinyapurviPratakshJama) {
			this.karmchariPravasMagilMahinyapurviPratakshJama = karmchariPravasMagilMahinyapurviPratakshJama;
		}
		public Long getkarmchariPravasChaluMahinyapurviJama() {
			return karmchariPravasChaluMahinyapurviJama;
		}
		public void setkarmchariPravasChaluMahinyapurviJama(
				Long karmchariPravasChaluMahinyapurviJama) {
			this.karmchariPravasChaluMahinyapurviJama = karmchariPravasChaluMahinyapurviJama;
		}
		public Long getkarmchariPravasTotal() {
			return karmchariPravasTotal;
		}
		public void setkarmchariPravasTotal(Long karmchariPravasTotal) {
			this.karmchariPravasTotal = karmchariPravasTotal;
		}
		public Long getKaryalinKharachArthSankalpniyaTartud() {
			return karyalinKharachArthSankalpniyaTartud;
		}
		public void setKaryalinKharachArthSankalpniyaTartud(Long karyalinKharachArthSankalpniyaTartud) {
			this.karyalinKharachArthSankalpniyaTartud = karyalinKharachArthSankalpniyaTartud;
		}
		public Long getKaryalinKharachMagilMahinyapurviPratakshJama() {
			return karyalinKharachMagilMahinyapurviPratakshJama;
		}
		public void setKaryalinKharachMagilMahinyapurviPratakshJama(Long karyalinKharachMagilMahinyapurviPratakshJama) {
			this.karyalinKharachMagilMahinyapurviPratakshJama = karyalinKharachMagilMahinyapurviPratakshJama;
		}
		public Long getKaryalinKharachChaluMahinyapurviJama() {
			return karyalinKharachChaluMahinyapurviJama;
		}
		public void setKaryalinKharachChaluMahinyapurviJama(Long karyalinKharachChaluMahinyapurviJama) {
			this.karyalinKharachChaluMahinyapurviJama = karyalinKharachChaluMahinyapurviJama;
		}
		public Long getKaryalinKharachTotal() {
			return karyalinKharachTotal;
		}
		public void setKaryalinKharachTotal(Long karyalinKharachTotal) {
			this.karyalinKharachTotal = karyalinKharachTotal;
		}
		public Long getsangnakKharchArthSankalpniyaTartud() {
			return sangnakKharchArthSankalpniyaTartud;
		}
		public void setsangnakKharchArthSankalpniyaTartud(
				Long sangnakKharchArthSankalpniyaTartud) {
			this.sangnakKharchArthSankalpniyaTartud = sangnakKharchArthSankalpniyaTartud;
		}
		public Long getsangnakKharchMagilMahinyapurviPratakshJama() {
			return sangnakKharchMagilMahinyapurviPratakshJama;
		}
		public void setsangnakKharchMagilMahinyapurviPratakshJama(
				Long sangnakKharchMagilMahinyapurviPratakshJama) {
			this.sangnakKharchMagilMahinyapurviPratakshJama = sangnakKharchMagilMahinyapurviPratakshJama;
		}
		public Long getsangnakKharchChaluMahinyapurviJama() {
			return sangnakKharchChaluMahinyapurviJama;
		}
		public void setsangnakKharchChaluMahinyapurviJama(
				Long sangnakKharchChaluMahinyapurviJama) {
			this.sangnakKharchChaluMahinyapurviJama = sangnakKharchChaluMahinyapurviJama;
		}
		public Long getsangnakKharchTotal() {
			return sangnakKharchTotal;
		}
		public void setsangnakKharchTotal(Long sangnakKharchTotal) {
			this.sangnakKharchTotal = sangnakKharchTotal;
		}
		public Long getjahiratKharchArthSankalpniyaTartud() {
			return jahiratKharchArthSankalpniyaTartud;
		}
		public void setjahiratKharchArthSankalpniyaTartud(
				Long jahiratKharchArthSankalpniyaTartud) {
			this.jahiratKharchArthSankalpniyaTartud = jahiratKharchArthSankalpniyaTartud;
		}
		public Long getjahiratKharchMagilMahinyapurviPratakshJama() {
			return jahiratKharchMagilMahinyapurviPratakshJama;
		}
		public void setjahiratKharchMagilMahinyapurviPratakshJama(
				Long jahiratKharchMagilMahinyapurviPratakshJama) {
			this.jahiratKharchMagilMahinyapurviPratakshJama = jahiratKharchMagilMahinyapurviPratakshJama;
		}
		public Long getjahiratKharchChaluMahinyapurviJama() {
			return jahiratKharchChaluMahinyapurviJama;
		}
		public void setjahiratKharchChaluMahinyapurviJama(
				Long jahiratKharchChaluMahinyapurviJama) {
			this.jahiratKharchChaluMahinyapurviJama = jahiratKharchChaluMahinyapurviJama;
		}
		public Long getjahiratKharchTotal() {
			return jahiratKharchTotal;
		}
		public void setjahiratKharchTotal(Long jahiratKharchTotal) {
			this.jahiratKharchTotal = jahiratKharchTotal;
		}
		public Long getPhogingORGhantagadisathiTelArthSankalpniyaTartud() {
			return phogingORGhantagadisathiTelArthSankalpniyaTartud;
		}
		public void setPhogingORGhantagadisathiTelArthSankalpniyaTartud(
				Long phogingORGhantagadisathiTelArthSankalpniyaTartud) {
			this.phogingORGhantagadisathiTelArthSankalpniyaTartud = phogingORGhantagadisathiTelArthSankalpniyaTartud;
		}
		public Long getPhogingORGhantagadisathiTelMagilMahinyapurviPratakshJama() {
			return phogingORGhantagadisathiTelMagilMahinyapurviPratakshJama;
		}
		public void setPhogingORGhantagadisathiTelMagilMahinyapurviPratakshJama(
				Long phogingORGhantagadisathiTelMagilMahinyapurviPratakshJama) {
			this.phogingORGhantagadisathiTelMagilMahinyapurviPratakshJama = phogingORGhantagadisathiTelMagilMahinyapurviPratakshJama;
		}
		public Long getPhogingORGhantagadisathiTelChaluMahinyapurviJama() {
			return phogingORGhantagadisathiTelChaluMahinyapurviJama;
		}
		public void setPhogingORGhantagadisathiTelChaluMahinyapurviJama(
				Long phogingORGhantagadisathiTelChaluMahinyapurviJama) {
			this.phogingORGhantagadisathiTelChaluMahinyapurviJama = phogingORGhantagadisathiTelChaluMahinyapurviJama;
		}
		public Long getPhogingORGhantagadisathiTelTotal() {
			return phogingORGhantagadisathiTelTotal;
		}
		public void setPhogingORGhantagadisathiTelTotal(Long phogingORGhantagadisathiTelTotal) {
			this.phogingORGhantagadisathiTelTotal = phogingORGhantagadisathiTelTotal;
		}   
	    
}

