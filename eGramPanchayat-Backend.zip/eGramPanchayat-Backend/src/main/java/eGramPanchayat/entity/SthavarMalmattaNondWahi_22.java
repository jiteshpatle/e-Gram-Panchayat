package eGramPanchayat.entity;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "22_sthavar_malmatta_nondwahi")
public class SthavarMalmattaNondWahi_22 {

	// Common Fields
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "employee_id")
	private String employeeId;

	@Column(name = "employee_name")
	private String employeeName;

	@Column(name = "grampanchayat_id")
	private String grampanchayatId;

	@Column(name = "grampanchayat_name")
	private String grampanchayatName;

	@CreationTimestamp
	@Column(name = "created_date", updatable = false)
	private LocalDateTime createdDate;

	@UpdateTimestamp
	@Column(name = "updated_date")
	private LocalDateTime updatedDate;

	// Custom Fields
	// @Column(name = "anukramank")
	// private String anukramank;

	@Column(name = "sanpadanchi_kharedi_kinwa_ubharni_dinank")
	@NotNull(message = "Input Field cannot be null.")
	@NotBlank(message = "Input Field cannot be empty.")
	private String sanpadanchiKharediKinwaUbharnichaDinank;
	// 2nd insert two fields
	@Column(name = "JaAnvay_MalMatta_SampadhitKele_adeshache_kramank")
	@NotNull(message = "Input Field cannot be null.")
	@NotBlank(message = "Input Field cannot be empty.")
	private String jAMSamKTyaadeshacheVPanchTharKramank;

	@Column(name = "JaAnvay_MalMatta_SampadhitKele_adeshache_dinank")
	@NotNull(message = "Input Field cannot be null.")
	@NotBlank(message = "Input Field cannot be empty.")
	private String jAMSamKTyaadeshacheVPanchTharDinak;

	@Column(name = "malmattecha_bhumapan_kramank")
	@NotNull(message = "Input Field cannot be null.")
	@NotBlank(message = "Input Field cannot be empty.")
	private String malmattechaBhumapanKramank;

	@Column(name = "malmattecha_bhumapan_malmatteche_varnan")
	@NotNull(message = "Input Field cannot be null.")
	@NotBlank(message = "Input Field cannot be empty.")
	private String malmattechaBhumapanMalmattecheVarnan;

	@Column(name = "konatya_karna_saathi_wapar_kela")
	@NotNull(message = "Input Field cannot be null.")
	@NotBlank(message = "Input Field cannot be empty.")
	private String konatyaKarnaSaathiWaparKela;

	@Column(name = "ubharni_kinwa_sampadanacha_kharch")
	@NotNull(message = "Input Field cannot be null.")
	@NotBlank(message = "Input Field cannot be empty.")
	private String ubharniKinwaSampadanachaKharch;

	@Column(name = "durustyawar_kinwa_ferfaravar_dinank")
	@NotNull(message = "Input Field cannot be null.")
	@NotBlank(message = "Input Field cannot be empty.")
	private String durustyawarKinwaFerfaravarDinank;

	@Column(name = "durustyawar_kinwa_ferfaravar_chalu_durustya_rupaye")
	@NotNull(message = "Input Field cannot be null.")
	@NotBlank(message = "Input Field cannot be empty.")
	private String durustyawarKinwaFerfaravarChaluDurustyaRupaye;

	@Column(name = "durustyawar_kinwa_ferfaravar_wishesh_durustya_rupaye")
	@NotNull(message = "Input Field cannot be null.")
	@NotBlank(message = "Input Field cannot be empty.")
	private String durustyawarKinwaFerfaravarWisheshDurustyaRupaye;

	@Column(name = "durustyawar_kinwa_ferfaravar_mulbandh_kaam_rupaye")
	@NotNull(message = "Input Field cannot be null.")
	@NotBlank(message = "Input Field cannot be empty.")
	private String durustyawarKinwaFerfaravarMulBandhKaamRupaye;

	@Column(name = "durustyawar_kinwa_ferfaravar_mulbandhkaamche_swarup")
	@NotNull(message = "Input Field cannot be null.")
	@NotBlank(message = "Input Field cannot be empty.")
	private String durustyawarKinwaFerfaravarMulBandhkaamcheSwarup;

	@Column(name = "warsha_akheris_ghatleli_kinmat")
	@NotNull(message = "Input Field cannot be null.")
	@NotBlank(message = "Input Field cannot be empty.")
	private String warshaAkherisGhatleliKinmat;

	// @Column(name = "sarpanch_wa_sachiv_yanchi_aadhyakshari")
	// private String sarpanchVaSachivYanchiAadhyakshari;

	@Column(name = "malmattechi_vilhewat_kramank")
	@NotNull(message = "Input Field cannot be null.")
	@NotBlank(message = "Input Field cannot be empty.")
	private String malmattechiVilhewatKramank;

	@Column(name = "malmattechi_vilhewat_dinank")
	@NotNull(message = "Input Field cannot be null.")
	@NotBlank(message = "Input Field cannot be empty.")
	private String malmattechiVilhewatDinank;

	@Column(name = "malmattechi_vilhewat_kalam_55_kramank")
	@NotNull(message = "Input Field cannot be null.")
	@NotBlank(message = "Input Field cannot be empty.")
	private String malmattechiVilhewatKalam55Kramank;

	@Column(name = "malmattechi_vilhewat_kalam_55_dinank")
	@NotNull(message = "Input Field cannot be null.")
	@NotBlank(message = "Input Field cannot be empty.")
	private String malmattechiVilhewatKalam55Dinank;

	@Column(name = "shera")
	@NotNull(message = "Input Field cannot be null.")
	@NotBlank(message = "Input Field cannot be empty.")
	private String shera;

	@Column(name = "dinank")
	private String dinank;

	// Getter Setters------------------------------------

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getDurustyawarKinwaFerfaravarChaluDurustyaRupaye() {
		return durustyawarKinwaFerfaravarChaluDurustyaRupaye;
	}

	public void setDurustyawarKinwaFerfaravarChaluDurustyaRupaye(String durustyawarKinwaFerfaravarChaluDurustyaRupaye) {
		this.durustyawarKinwaFerfaravarChaluDurustyaRupaye = durustyawarKinwaFerfaravarChaluDurustyaRupaye;
	}

	public String getDurustyawarKinwaFerfaravarMulBandhkaamcheSwarup() {
		return durustyawarKinwaFerfaravarMulBandhkaamcheSwarup;
	}

	public void setDurustyawarKinwaFerfaravarMulBandhkaamcheSwarup(
			String durustyawarKinwaFerfaravarMulBandhkaamcheSwarup) {
		this.durustyawarKinwaFerfaravarMulBandhkaamcheSwarup = durustyawarKinwaFerfaravarMulBandhkaamcheSwarup;
	}

	public String getDurustyawarKinwaFerfaravarMulBandhKaamRupaye() {
		return durustyawarKinwaFerfaravarMulBandhKaamRupaye;
	}

	public void setDurustyawarKinwaFerfaravarMulBandhKaamRupaye(String durustyawarKinwaFerfaravarMulBandhKaamRupaye) {
		this.durustyawarKinwaFerfaravarMulBandhKaamRupaye = durustyawarKinwaFerfaravarMulBandhKaamRupaye;
	}

	public String getDurustyawarKinwaFerfaravarWisheshDurustyaRupaye() {
		return durustyawarKinwaFerfaravarWisheshDurustyaRupaye;
	}

	public void setDurustyawarKinwaFerfaravarWisheshDurustyaRupaye(
			String durustyawarKinwaFerfaravarWisheshDurustyaRupaye) {
		this.durustyawarKinwaFerfaravarWisheshDurustyaRupaye = durustyawarKinwaFerfaravarWisheshDurustyaRupaye;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getGrampanchayatId() {
		return grampanchayatId;
	}

	public void setGrampanchayatId(String grampanchayatId) {
		this.grampanchayatId = grampanchayatId;
	}

	public String getGrampanchayatName() {
		return grampanchayatName;
	}

	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getjAMSamKTyaadeshacheVPanchTharDinak() {
		return jAMSamKTyaadeshacheVPanchTharDinak;
	}

	public void setjAMSamKTyaadeshacheVPanchTharDinak(String jAMSamKTyaadeshacheVPanchTharDinak) {
		this.jAMSamKTyaadeshacheVPanchTharDinak = jAMSamKTyaadeshacheVPanchTharDinak;
	}

	public String getjAMSamKTyaadeshacheVPanchTharKramank() {
		return jAMSamKTyaadeshacheVPanchTharKramank;
	}

	public void setjAMSamKTyaadeshacheVPanchTharKramank(String jAMSamKTyaadeshacheVPanchTharKramank) {
		this.jAMSamKTyaadeshacheVPanchTharKramank = jAMSamKTyaadeshacheVPanchTharKramank;
	}

	public String getKonatyaKarnaSaathiWaparKela() {
		return konatyaKarnaSaathiWaparKela;
	}

	public void setKonatyaKarnaSaathiWaparKela(String konatyaKarnaSaathiWaparKela) {
		this.konatyaKarnaSaathiWaparKela = konatyaKarnaSaathiWaparKela;
	}

	public String getMalmattechaBhumapanKramank() {
		return malmattechaBhumapanKramank;
	}

	public void setMalmattechaBhumapanKramank(String malmattechaBhumapanKramank) {
		this.malmattechaBhumapanKramank = malmattechaBhumapanKramank;
	}

	public String getMalmattechaBhumapanMalmattecheVarnan() {
		return malmattechaBhumapanMalmattecheVarnan;
	}

	public void setMalmattechaBhumapanMalmattecheVarnan(String malmattechaBhumapanMalmattecheVarnan) {
		this.malmattechaBhumapanMalmattecheVarnan = malmattechaBhumapanMalmattecheVarnan;
	}

	public String getMalmattechiVilhewatDinank() {
		return malmattechiVilhewatDinank;
	}

	public void setMalmattechiVilhewatDinank(String malmattechiVilhewatDinank) {
		this.malmattechiVilhewatDinank = malmattechiVilhewatDinank;
	}

	public String getMalmattechiVilhewatKalam55Dinank() {
		return malmattechiVilhewatKalam55Dinank;
	}

	public void setMalmattechiVilhewatKalam55Dinank(String malmattechiVilhewatKalam55Dinank) {
		this.malmattechiVilhewatKalam55Dinank = malmattechiVilhewatKalam55Dinank;
	}

	public String getMalmattechiVilhewatKalam55Kramank() {
		return malmattechiVilhewatKalam55Kramank;
	}

	public void setMalmattechiVilhewatKalam55Kramank(String malmattechiVilhewatKalam55Kramank) {
		this.malmattechiVilhewatKalam55Kramank = malmattechiVilhewatKalam55Kramank;
	}

	public String getMalmattechiVilhewatKramank() {
		return malmattechiVilhewatKramank;
	}

	public void setMalmattechiVilhewatKramank(String malmattechiVilhewatKramank) {
		this.malmattechiVilhewatKramank = malmattechiVilhewatKramank;
	}

	public String getDurustyawarKinwaFerfaravarDinank() {
		return durustyawarKinwaFerfaravarDinank;
	}

	public void setDurustyawarKinwaFerfaravarDinank(String durustyawarKinwaFerfaravarDinank) {
		this.durustyawarKinwaFerfaravarDinank = durustyawarKinwaFerfaravarDinank;
	}

	public String getSanpadanchiKharediKinwaUbharnichaDinank() {
		return sanpadanchiKharediKinwaUbharnichaDinank;
	}

	public void setSanpadanchiKharediKinwaUbharnichaDinank(String sanpadanchiKharediKinwaUbharnichaDinank) {
		this.sanpadanchiKharediKinwaUbharnichaDinank = sanpadanchiKharediKinwaUbharnichaDinank;
	}

	public String getShera() {
		return shera;
	}

	public void setShera(String shera) {
		this.shera = shera;
	}

	public String getUbharniKinwaSampadanachaKharch() {
		return ubharniKinwaSampadanachaKharch;
	}

	public void setUbharniKinwaSampadanachaKharch(String ubharniKinwaSampadanachaKharch) {
		this.ubharniKinwaSampadanachaKharch = ubharniKinwaSampadanachaKharch;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getWarshaAkherisGhatleliKinmat() {
		return warshaAkherisGhatleliKinmat;
	}

	public void setWarshaAkherisGhatleliKinmat(String warshaAkherisGhatleliKinmat) {
		this.warshaAkherisGhatleliKinmat = warshaAkherisGhatleliKinmat;
	}

	public String getDinank() {
		return dinank;
	}

	public void setDinank(String dinank) {
		this.dinank = dinank;
	}

}
