package eGramPanchayat.entity;

import java.sql.Timestamp;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import jakarta.persistence.*;

@Entity
@Table(name = "13_karmachari_vargikaran_wetan_shreni_nondvahi")
public class KarmachariVargikaranWetanShreniNondvahi_13 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // @Column(name = "serial_no")
    // private Integer serialNo; // अ. क्र. (Serial number)

    @Column(name = "employee_id")
    private String employeeId; // Employee ID

    @Column(name = "employee_name")
    private String employeeName; // Employee name

    @Column(name = "grampanchayat_id")
    private String grampanchayatId; // Grampanchayat ID

    @Column(name = "grampanchayat_name")
    private String grampanchayatName; // Grampanchayat name

    @Column(name = "padnaam")
    private String padnaam;

    @Column(name = "padanchi_sankhya")
    private Integer padanchiSankhya;

    @Column(name = "manjur_pad_adesh_kramank")
    private String manjurPadAdeshKramank;

    @Column(name = "manjur_pad_adesh_dinank")
    private String manjurPadAdeshDinank;

    @Column(name = "purnakalik_anshkalik")
    private String purnakalikAnshkalik;

    @Column(name = "manjur_wetan_shreni")
    private String manjurWetanShreni;

    @Column(name = "karmacharyache_naav")
    private String karmacharyacheNaav;

    @Column(name = "niyukti_dinank")
    private String niyuktiDinank;

    @CreationTimestamp
    @Column(name = "created_date")
    private Timestamp createdDate;

    @UpdateTimestamp
    @Column(name = "updated_date")
    private Timestamp updatedDate;

    @Column(name = "year")
    private String year;

    @Column(name = "remark")
    private String remark;

    @Column(name = "dinank")
    private String dinank;

    // Getters and Setters


    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    // public Integer getSerialNo() {
    //     return serialNo;
    // }

    // public void setSerialNo(Integer serialNo) {
    //     this.serialNo = serialNo;
    // }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getGrampanchayatId() {
        return grampanchayatId;
    }

    public void setGrampanchayatId(String grampanchayatId) {
        this.grampanchayatId = grampanchayatId;
    }

    public String getGrampanchayatName() {
        return grampanchayatName;
    }

    public void setGrampanchayatName(String grampanchayatName) {
        this.grampanchayatName = grampanchayatName;
    }

    public String getPadnaam() {
        return padnaam;
    }

    public void setPadnaam(String padnaam) {
        this.padnaam = padnaam;
    }

    public Integer getPadanchiSankhya() {
        return padanchiSankhya;
    }

    public void setPadanchiSankhya(Integer padanchiSankhya) {
        this.padanchiSankhya = padanchiSankhya;
    }

    public String getPurnakalikAnshkalik() {
        return purnakalikAnshkalik;
    }

    public void setPurnakalikAnshkalik(String purnakalikAnshkalik) {
        this.purnakalikAnshkalik = purnakalikAnshkalik;
    }

    public String getManjurWetanShreni() {
        return manjurWetanShreni;
    }

    public void setManjurWetanShreni(String manjurWetanShreni) {
        this.manjurWetanShreni = manjurWetanShreni;
    }

    public String getKarmacharyacheNaav() {
        return karmacharyacheNaav;
    }

    public void setKarmacharyacheNaav(String karmacharyacheNaav) {
        this.karmacharyacheNaav = karmacharyacheNaav;
    }

    public String getNiyuktiDinank() {
        return niyuktiDinank;
    }

    public void setNiyuktiDinank(String niyuktiDinank) {
        this.niyuktiDinank = niyuktiDinank;
    }

    public Timestamp getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate) {
        this.createdDate = createdDate;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getManjurPadAdeshKramank() {
        return manjurPadAdeshKramank;
    }

    public void setManjurPadAdeshKramank(String manjurPadAdeshKramank) {
        this.manjurPadAdeshKramank = manjurPadAdeshKramank;
    }

    public String getManjurPadAdeshDinank() {
        return manjurPadAdeshDinank;
    }

    public void setManjurPadAdeshDinank(String manjurPadAdeshDinank) {
        this.manjurPadAdeshDinank = manjurPadAdeshDinank;
    }

    public String getDinank() {
        return dinank;
    }

    public void setDinank(String dinank) {
        this.dinank = dinank;
    }

}
