package eGramPanchayat.entity;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "30_lekha_parikshan_aakshep_purtata_nond_vahi")
public class Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahi {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "employee_id")
	// @NotBlank(message = "Employee Id must not be blank")
	// @Pattern(regexp = "^[a-zA-Z0-9]+$", message = "Employee Id must contain only
	// letters or numbers")
	private String employeeId;

	@Column(name = "employee_name")
	// @NotBlank(message = "Employee Name must not be blank")
	// @Pattern(regexp = "^[a-zA-Z\\s]+$", message = "Employee Name must contain
	// characters or spaces")
	private String employeeName;

	@Column(name = "gram_panchayat_id")
	// @NotBlank(message = "Gram Panchayat Id must not be blank")
	// @Pattern(regexp = "^[a-zA-Z0-9]+$", message = "Gram Panchayat Id must contain
	// characters or numbers")
	private String gramPanchayatId;

	@Column(name = "gram_panchayat_name")
	// @NotBlank(message = "Gram Panchayat Name must not be blank")
	// @Pattern(regexp = "^[a-zA-Z\\s]+$", message = "Gram Panchayat Name must
	// contain characters or spaces")
	private String gramPanchayatName;

	@Column(name = "l_p_ahwal_varsh")
	private String lekhParikshanAhwalVarsh;

	@Column(name = "l_p_ahwal_prapta_jhalyachi_dinank")
	private String lPAhwalPraptaJhalyachiDinank;

	@Column(name = "ahwalatil_akshepanchi_sankhya")
	@NotBlank(message = "Ahwalatil Akshepanchi Sankhya must not be blank")
	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Ahwalatil Akshepanchi
	// Sankhya must contain characters or numbers or spaces")
	private String ahwalatilAkshepanchiSankhya;

	@Column(name = "ahwalatil_akshepanchi_anukramank")
	@NotBlank(message = "Ahwalatil Akshepanchi Anu Kramank must not be blank")
	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Ahwalatil Akshepanchi Anu
	// Kramank must contain characters or numbers or spaces")
	private String ahwalatilAkshepanchiAnuKramank;

	@Column(name = "k_m_asanara_akshep_kramank")
	@NotBlank(message = "Keval Mahitisathi Asanara Akshep Kramank must not be blank")
	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Keval Mahitisathi Asanara
	// Akshep Kramank must contain characters or numbers or spaces")
	private String kMAsanaraAkshepKramank;

	@Column(name = "k_m_asanara_akshep_sankhya")
	@NotBlank(message = "Keval Mahitisathi Asanara Akshep Sankhya must not be blank")
	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Keval Mahitisathi Asanara
	// Akshep Sankhya must contain characters or numbers or spaces")
	private String kMAsanaraAkshepSankhya;

	@Column(name = "purtata_karvyachya_akshepanche_kramank")
	@NotBlank(message = "Purtata Karvyachya Akshepanche Kramank must not be blank")
	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Purtata Karvyachya
	// Akshepanche Kramank must contain characters or numbers or spaces")
	private String purtataKarvyachyaAkshepancheKramank;

	@Column(name = "purtata_karvyachya_akshepanche_sankhya")
	@NotBlank(message = "Purtata Karvyachya Akshepanche Sankhya must not be blank")
	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Purtata Karvyachya
	// Akshepanche Sankhya must contain characters or numbers or spaces")
	private String purtataKarvyachyaAkshepancheSankhya;

	@Column(name = "gp_p_kelele_akshepanche_kramank")
	@NotBlank(message = "Grampanchyat Purtata Kelele Akshepanche Kramank must not be blank")
	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Grampanchyat Purtata Kelele
	// Akshepanche Kramank must contain characters or numbers or spaces")
	private String gpPAkshepancheKramank;

	@Column(name = "gp_p_kelele_akshepanche_sankhya")
	@NotBlank(message = "Grampanchyat Purtata Kelele Akshepanche Sankhya must not be blank")
	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Grampanchyat Purtata Kelele
	// Akshepanche Sankhya must contain characters or numbers or spaces")
	private String gpPKeleleAkshepancheSankhya;

	@Column(name = "p_k_a_p_samiti_kade_pathvila_javak_dinank")
	@NotBlank(message = "p_k_a_p_samiti_kade_pathvila_javak_dinank must not be blank")
	private String pKAPSamitiKadePathvilaJavakDinank;

	@Column(name = "p_k_a_p_samiti_kade_pathvila_Kramank")
	@NotBlank(message = "p_k_a_p_samiti_kade_pathvila_Kramank must not be blank")
	private String pKAPtSamitiKadePathvilakramank;

	@Column(name = "p_k_a_p_samitine_jP_Kade_pathvalycha_thrav_krmank")
	@NotBlank(message = "Purtata Kelele Akshep Panchyat Samitine JP Kade Pathvalycha Thrav Kramank  must not be blank")
	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Purtata Kelele Akshep
	// Panchyat Samitine JP Kade Pathvalycha Thrav Kramank must contain characters
	// or numbers or spaces")
	private String pKAPSamitineJPKadePathvalaThravKrmank;

	@Column(name = "p_k_a_p_samitine_jp_Kade_pathvalycha_Javak_krmank")
	@NotBlank(message = "Purtata Kelele Akshep Panchyat Samitine Pathvalycha Javak Kramank must not be blank")
	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Purtata Kelele Akshep
	// Panchyat Samitine Pathvalycha Javak Kramank must contain characters or
	// numbers or spaces")
	private String pKAPSamitineJPKadePathvalychaJavakKrmank;

	@Column(name = "p_k_a_p_samitine_jp_Kade_pathvalycha_dinank")
	@NotBlank(message = "Purtata Kelele Akshep Panchyat Samitine Pathvalycha Dinank must not be blank")
	private String pKAPSamitineJPKadePathvalychaDinank;

	@Column(name = "jp_yani_manjur_kelele_akshep_kramank")
	@NotBlank(message = "Jilha Parishad Yani Manjur Kelele Akshep Kramank must not be blank")
	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Jilha Parishad Yani Manjur
	// Kelele Akshep Kramank must contain characters or numbers or spaces")
	private String jPYaniManjurKeleleAkshepKramank;

	@Column(name = "jp_yani_manjur_kelele_akshep_sankya")
	@NotBlank(message = "Jilha Parishad Yani Manjur Kelele Akshep Sankya must not be blank")
	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Jilha Parishad Yani Manjur
	// Kelele Akshep Sankya must contain characters or numbers or spaces")
	private String jPYaniManjurKeleleAkshepSankya;

	@Column(name = "s_a_v_v_kramank_pustaki_samayojan")
	@NotBlank(message = "Shillak Aakshepanchi Vargawari va Karmank Pustaki Samayojan must not be blank")
	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Shillak Aakshepanchi
	// Vargawari va Karmank Pustaki Samayojan must contain characters or numbers or
	// spaces")
	private String sAVVKramankPustakiSamayojan;

	@Column(name = "s_a_v_v_kramank_vasuli")
	@NotBlank(message = "Shillak Aakshepanchi Vargawari va Karmank vasuli must not be blank")
	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Shillak Aakshepanchi
	// Vargawari va Karmank vasuli must contain characters or numbers or spaces")
	private String sAVVKramankVasuli;

	@Column(name = "s_a_v_v_kramank_mulyankan")
	@NotBlank(message = "Shillak Aakshepanchi Vargawari va Karmank Mulyankan must not be blank")
	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Shillak Aakshepanchi
	// Vargawari va Karmank Mulyankan must contain characters or numbers or spaces")
	private String sAVVKramankMulyankan;

	@Column(name = "s_a_v_v_kramank_niyambahya")
	@NotBlank(message = "Shillak Aakshepanchi Vargawari va Karmank Niyambahya must not be blank")
	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Shillak Aakshepanchi
	// Vargawari va Karmank Niyambahya must contain characters or numbers or
	// spaces")
	private String sAVVKramankNiyambahya;

	@Column(name = "s_a_v_v_kramank_ekun")
	@NotBlank(message = "Shillak Aakshepanchi Vargawari va Karmank Ekun must not be blank")
	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Shillak Aakshepanchi
	// Vargawari va Karmank Ekun must contain characters or numbers or spaces")
	private String sAVVKramankEkun;

	@Column(name = "dinank")
	private String dinank;

	@Column(name = "shera")
	@NotBlank(message = "Shera must not be blank")
	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Shillak Aakshepanchi
	// Vargawari va Karmank Ekun must contain characters or numbers or spaces")
	private String shera;

	@Column(name = "created_date")
	@CreationTimestamp
	private LocalDateTime createdDate;

	@Column(name = "updated_date")
	@UpdateTimestamp
	private LocalDateTime updatedDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getGramPanchayatId() {
		return gramPanchayatId;
	}

	public void setGramPanchayatId(String gramPanchayatId) {
		this.gramPanchayatId = gramPanchayatId;
	}

	public String getGramPanchayatName() {
		return gramPanchayatName;
	}

	public void setGramPanchayatName(String gramPanchayatName) {
		this.gramPanchayatName = gramPanchayatName;
	}

	public String getpKAPtSamitiKadePathvilakramank() {
		return pKAPtSamitiKadePathvilakramank;
	}

	public void setpKAPtSamitiKadePathvilakramank(String pKAPtSamitiKadePathvilakramank) {
		this.pKAPtSamitiKadePathvilakramank = pKAPtSamitiKadePathvilakramank;
	}

	// public String getAnuKramank() {
	// return anuKramank;
	// }
	//
	// public void setAnuKramank(String anuKramank) {
	// this.anuKramank = anuKramank;
	// }

	public String getLekhParikshanAhwalVarsh() {
		return lekhParikshanAhwalVarsh;
	}

	public void setLekhParikshanAhwalVarsh(String lekhParikshanAhwalVarsh) {
		this.lekhParikshanAhwalVarsh = lekhParikshanAhwalVarsh;
	}

	public String getlPAhwalPraptaJhalyachiDinank() {
		return lPAhwalPraptaJhalyachiDinank;
	}

	public void setlPAhwalPraptaJhalyachiDinank(String lPAhwalPraptaJhalyachiDinank) {
		this.lPAhwalPraptaJhalyachiDinank = lPAhwalPraptaJhalyachiDinank;
	}

	public String getAhwalatilAkshepanchiSankhya() {
		return ahwalatilAkshepanchiSankhya;
	}

	public void setAhwalatilAkshepanchiSankhya(String ahwalatilAkshepanchiSankhya) {
		this.ahwalatilAkshepanchiSankhya = ahwalatilAkshepanchiSankhya;
	}

	public String getAhwalatilAkshepanchiAnuKramank() {
		return ahwalatilAkshepanchiAnuKramank;
	}

	public void setAhwalatilAkshepanchiAnuKramank(String ahwalatilAkshepanchiAnuKramank) {
		this.ahwalatilAkshepanchiAnuKramank = ahwalatilAkshepanchiAnuKramank;
	}

	public String getkMAsanaraAkshepKramank() {
		return kMAsanaraAkshepKramank;
	}

	public void setkMAsanaraAkshepKramank(String kMAsanaraAkshepKramank) {
		this.kMAsanaraAkshepKramank = kMAsanaraAkshepKramank;
	}

	public String getkMAsanaraAkshepSankhya() {
		return kMAsanaraAkshepSankhya;
	}

	public void setkMAsanaraAkshepSankhya(String kMAsanaraAkshepSankhya) {
		this.kMAsanaraAkshepSankhya = kMAsanaraAkshepSankhya;
	}

	public String getPurtataKarvyachyaAkshepancheKramank() {
		return purtataKarvyachyaAkshepancheKramank;
	}

	public void setPurtataKarvyachyaAkshepancheKramank(String purtataKarvyachyaAkshepancheKramank) {
		this.purtataKarvyachyaAkshepancheKramank = purtataKarvyachyaAkshepancheKramank;
	}

	public String getPurtataKarvyachyaAkshepancheSankhya() {
		return purtataKarvyachyaAkshepancheSankhya;
	}

	public void setPurtataKarvyachyaAkshepancheSankhya(String purtataKarvyachyaAkshepancheSankhya) {
		this.purtataKarvyachyaAkshepancheSankhya = purtataKarvyachyaAkshepancheSankhya;
	}

	public String getGpPAkshepancheKramank() {
		return gpPAkshepancheKramank;
	}

	public void setGpPAkshepancheKramank(String gpPAkshepancheKramank) {
		this.gpPAkshepancheKramank = gpPAkshepancheKramank;
	}

	public String getGpPKeleleAkshepancheSankhya() {
		return gpPKeleleAkshepancheSankhya;
	}

	public void setGpPKeleleAkshepancheSankhya(String gpPKeleleAkshepancheSankhya) {
		this.gpPKeleleAkshepancheSankhya = gpPKeleleAkshepancheSankhya;
	}

	public String getpKAPSamitiKadePathvilaJavakDinank() {
		return pKAPSamitiKadePathvilaJavakDinank;
	}

	public void setpKAPSamitiKadePathvilaJavakDinank(String pKAPSamitiKadePathvilaJavakDinank) {
		this.pKAPSamitiKadePathvilaJavakDinank = pKAPSamitiKadePathvilaJavakDinank;
	}

	public String getpKAPSamitineJPKadePathvalaThravKrmank() {
		return pKAPSamitineJPKadePathvalaThravKrmank;
	}

	public void setpKAPSamitineJPKadePathvalaThravKrmank(String pKAPSamitineJPKadePathvalaThravKrmank) {
		this.pKAPSamitineJPKadePathvalaThravKrmank = pKAPSamitineJPKadePathvalaThravKrmank;
	}

	public String getpKAPSamitineJPKadePathvalychaJavakKrmank() {
		return pKAPSamitineJPKadePathvalychaJavakKrmank;
	}

	public void setpKAPSamitineJPKadePathvalychaJavakKrmank(String pKAPSamitineJPKadePathvalychaJavakKrmank) {
		this.pKAPSamitineJPKadePathvalychaJavakKrmank = pKAPSamitineJPKadePathvalychaJavakKrmank;
	}

	public String getpKAPSamitineJPKadePathvalychaDinank() {
		return pKAPSamitineJPKadePathvalychaDinank;
	}

	public void setpKAPSamitineJPKadePathvalychaDinank(String pKAPSamitineJPKadePathvalychaDinank) {
		this.pKAPSamitineJPKadePathvalychaDinank = pKAPSamitineJPKadePathvalychaDinank;
	}

	public String getjPYaniManjurKeleleAkshepKramank() {
		return jPYaniManjurKeleleAkshepKramank;
	}

	public void setjPYaniManjurKeleleAkshepKramank(String jPYaniManjurKeleleAkshepKramank) {
		this.jPYaniManjurKeleleAkshepKramank = jPYaniManjurKeleleAkshepKramank;
	}

	public String getjPYaniManjurKeleleAkshepSankya() {
		return jPYaniManjurKeleleAkshepSankya;
	}

	public void setjPYaniManjurKeleleAkshepSankya(String jPYaniManjurKeleleAkshepSankya) {
		this.jPYaniManjurKeleleAkshepSankya = jPYaniManjurKeleleAkshepSankya;
	}

	public String getsAVVKramankPustakiSamayojan() {
		return sAVVKramankPustakiSamayojan;
	}

	public void setsAVVKramankPustakiSamayojan(String sAVVKramankPustakiSamayojan) {
		this.sAVVKramankPustakiSamayojan = sAVVKramankPustakiSamayojan;
	}

	public String getsAVVKramankVasuli() {
		return sAVVKramankVasuli;
	}

	public void setsAVVKramankVasuli(String sAVVKramankVasuli) {
		this.sAVVKramankVasuli = sAVVKramankVasuli;
	}

	public String getsAVVKramankMulyankan() {
		return sAVVKramankMulyankan;
	}

	public void setsAVVKramankMulyankan(String sAVVKramankMulyankan) {
		this.sAVVKramankMulyankan = sAVVKramankMulyankan;
	}

	public String getsAVVKramankNiyambahya() {
		return sAVVKramankNiyambahya;
	}

	public void setsAVVKramankNiyambahya(String sAVVKramankNiyambahya) {
		this.sAVVKramankNiyambahya = sAVVKramankNiyambahya;
	}

	public String getsAVVKramankEkun() {
		return sAVVKramankEkun;
	}

	public void setsAVVKramankEkun(String sAVVKramankEkun) {
		this.sAVVKramankEkun = sAVVKramankEkun;
	}

	public String getShera() {
		return shera;
	}

	public void setShera(String shera) {
		this.shera = shera;
	}

	// public String getRemark() {
	// return remark;
	// }
	//
	// public void setRemark(String remark) {
	// this.remark = remark;
	// }

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getDinank() {
		return dinank;
	}

	public void setDinank(String dinank) {
		this.dinank = dinank;
	}

	
}
