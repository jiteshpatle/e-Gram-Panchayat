package eGramPanchayat.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

@Entity
@Table(name = "18_kirkol_rokad_vahi")
public class Namuna18KirkolRokadVahi {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "remark")
    private String remark;

    @Column(name = "employee_id")
    private Long employeeId;

    @Column(name = "employee_name")
    private String employeeName;

    @Column(name = "grampanchayat_id")
    private Long grampanchayatId;

    @Column(name = "grampanchayat_name")
    private String grampanchayatName;

    @Column(name = "jama_tarikh")
    private String jamaTarikh;

    @Column(name = "dhanadesh_kramank")
    private String dhanadeshKramank;

    @Column(name = "konakadun_prapt_zala")
    private String konakadunPraptZala;

    @Column(name = "jama_tapshil")
    private String jamaTapshil;

    @Column(name = "jama_rakkam")
    private String jamaRakkam;

    @Column(name = "agrim")
    private String agrim;

    @Column(name = "jama_ekun")
    private String jamaEkun;

    @Column(name = "adhyakshari")
    private String adhyakshari;

    @Column(name = "kharch_tarikh")
    private String kharchTarikh;

    @Column(name = "kharch_tapshil")
    private String kharchTapshil;

    @Column(name = "konas_rakkam_dili")
    private String konasRakkamDili;

    @Column(name = "kharch_rakkam")
    private String kharchRakkam;

    @Column(name = "agrimatun_kharch")
    private String agrimatunKharch;

    @Column(name = "kharch_ekun")
    private String kharchEkun;

    @Column(name = "swakshari")
    private String swakshari;

    @Column(name = "prarambhi_shillak")   
    private String prarambhiShillak;

    @Column(name = "prarambhi_shillak_jama")   
    private String prarambhiShillakJama;

    @Column(name = "prarambhi_shillak_kharch", length = 50)   
    private String prarambhiShillakKharch;

    @Column(name = "prarambhi_shillak_ekun", length = 50)   
    private String prarambhiShillakEkun;

    @Column(name = "prarambhi_shillak_rokh", length = 50)   
    private String prarambhiShillakRokh;

    @Column(name = "aarambhi_shillak", length = 50)   
    private String aarambhiShillak;

    @Column(name = "aarambhi_shillak_jama", length = 50)   
    private String aarambhiShillakJama;

    @Column(name = "aarambhi_shillak_ekun", length = 50)   
    private String aarambhiShillakEkun;

    @Column(name = "year", length = 50)   
    private String year;

    // Auto-generate dates
    @PrePersist
    protected void onCreate() {
        this.createdDate = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedDate = LocalDateTime.now();
    }
    // Getters and Setters for new fields
    public String getPrarambhiShillak() {
        return prarambhiShillak;
    }

    public void setPrarambhiShillak(String prarambhiShillak) {
        this.prarambhiShillak = prarambhiShillak;
    }

    public String getPrarambhiShillakJama() {
        return prarambhiShillakJama;
    }

    public void setPrarambhiShillakJama(String prarambhiShillakJama) {
        this.prarambhiShillakJama = prarambhiShillakJama;
    }

    public String getPrarambhiShillakKharch() {
        return prarambhiShillakKharch;
    }

    public void setPrarambhiShillakKharch(String prarambhiShillakKharch) {
        this.prarambhiShillakKharch = prarambhiShillakKharch;
    }

    public String getPrarambhiShillakEkun() {
        return prarambhiShillakEkun;
    }

    public void setPrarambhiShillakEkun(String prarambhiShillakEkun) {
        this.prarambhiShillakEkun = prarambhiShillakEkun;
    }

    public String getPrarambhiShillakRokh() {
        return prarambhiShillakRokh;
    }

    public void setPrarambhiShillakRokh(String prarambhiShillakRokh) {
        this.prarambhiShillakRokh = prarambhiShillakRokh;
    }

    public String getAarambhiShillak() {
        return aarambhiShillak;
    }

    public void setAarambhiShillak(String aarambhiShillak) {
        this.aarambhiShillak = aarambhiShillak;
    }

    public String getAarambhiShillakJama() {
        return aarambhiShillakJama;
    }

    public void setAarambhiShillakJama(String aarambhiShillakJama) {
        this.aarambhiShillakJama = aarambhiShillakJama;
    }

    public String getAarambhiShillakEkun() {
        return aarambhiShillakEkun;
    }

    public void setAarambhiShillakEkun(String aarambhiShillakEkun) {
        this.aarambhiShillakEkun = aarambhiShillakEkun;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Long getGrampanchayatId() {
		return grampanchayatId;
	}

	public void setGrampanchayatId(Long grampanchayatId) {
		this.grampanchayatId = grampanchayatId;
	}

	public String getGrampanchayatName() {
		return grampanchayatName;
	}

	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}

	public String getJamaTarikh() {
		return jamaTarikh;
	}

	public void setJamaTarikh(String jamaTarikh) {
		this.jamaTarikh = jamaTarikh;
	}

	public String getDhanadeshKramank() {
		return dhanadeshKramank;
	}

	public void setDhanadeshKramank(String dhanadeshKramank) {
		this.dhanadeshKramank = dhanadeshKramank;
	}

	public String getKonakadunPraptZala() {
		return konakadunPraptZala;
	}

	public void setKonakadunPraptZala(String konakadunPraptZala) {
		this.konakadunPraptZala = konakadunPraptZala;
	}

	public String getJamaTapshil() {
		return jamaTapshil;
	}

	public void setJamaTapshil(String jamaTapshil) {
		this.jamaTapshil = jamaTapshil;
	}

	public String getJamaRakkam() {
		return jamaRakkam;
	}

	public void setJamaRakkam(String jamaRakkam) {
		this.jamaRakkam = jamaRakkam;
	}

	public String getAgrim() {
		return agrim;
	}

	public void setAgrim(String agrim) {
		this.agrim = agrim;
	}

	public String getJamaEkun() {
		return jamaEkun;
	}

	public void setJamaEkun(String jamaEkun) {
		this.jamaEkun = jamaEkun;
	}

	public String getAdhyakshari() {
		return adhyakshari;
	}

	public void setAdhyakshari(String adhyakshari) {
		this.adhyakshari = adhyakshari;
	}

	public String getKharchTarikh() {
		return kharchTarikh;
	}

	public void setKharchTarikh(String kharchTarikh) {
		this.kharchTarikh = kharchTarikh;
	}

	public String getKharchTapshil() {
		return kharchTapshil;
	}

	public void setKharchTapshil(String kharchTapshil) {
		this.kharchTapshil = kharchTapshil;
	}

	public String getKonasRakkamDili() {
		return konasRakkamDili;
	}

	public void setKonasRakkamDili(String konasRakkamDili) {
		this.konasRakkamDili = konasRakkamDili;
	}

	public String getKharchRakkam() {
		return kharchRakkam;
	}

	public void setKharchRakkam(String kharchRakkam) {
		this.kharchRakkam = kharchRakkam;
	}

	public String getAgrimatunKharch() {
		return agrimatunKharch;
	}

	public void setAgrimatunKharch(String agrimatunKharch) {
		this.agrimatunKharch = agrimatunKharch;
	}

	public String getKharchEkun() {
		return kharchEkun;
	}

	public void setKharchEkun(String kharchEkun) {
		this.kharchEkun = kharchEkun;
	}

	public String getSwakshari() {
		return swakshari;
	}

	public void setSwakshari(String swakshari) {
		this.swakshari = swakshari;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}
    
}
