package eGramPanchayat.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "Namuna10_Items")
public class DynamicField {
    @ManyToOne
    @JoinColumn(name = "namuna10Entity_id") // This is the foreign key column referencing Namuna10Entity
    private Namuna10Entity namuna10Entity; // Reference to the parent entity (Namuna10Entity)

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Primary key of DynamicField

    @Column(name = "Tapshil")
    private String tapshil;

    @Column(name = "MagilBaki")
    private String magilBaki;

    @Column(name = "ChaluBaki")
    private String chaluBaki;

    @Column(name = "EkunRakkam")
    private String ekunRakkam;

    // Getters and Setters for each field, including the new Namuna10Entity
    // reference

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Namuna10Entity getNamuna10Entity() {
        return namuna10Entity;
    }

    public void setNamuna10Entity(Namuna10Entity namuna10Entity) {
        this.namuna10Entity = namuna10Entity;
    }

    public String getTapshil() {
        return tapshil;
    }

    public void setTapshil(String tapshil) {
        this.tapshil = tapshil;
    }

    public String getMagilBaki() {
        return magilBaki;
    }

    public void setMagilBaki(String magilBaki) {
        this.magilBaki = magilBaki;
    }

    public String getChaluBaki() {
        return chaluBaki;
    }

    public void setChaluBaki(String chaluBaki) {
        this.chaluBaki = chaluBaki;
    }

    public String getEkunRakkam() {
        return ekunRakkam;
    }

    public void setEkunRakkam(String ekunRakkam) {
        this.ekunRakkam = ekunRakkam;
    }

}
