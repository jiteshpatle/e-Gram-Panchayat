package eGramPanchayat.entity;

import java.time.LocalDateTime;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

@Entity
@Access(AccessType.FIELD)
@Table(name = "27_lekhaparikshan_aaksheepan")
public class LekhaparikshanAaksheepanNamuna27 {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id; // Primary Key

	// @NotNull(message = "Anukramamka cannot be null.")
	// @Column(name = "anukramamka")
	// private String anukramamka;

	@Column(name = "lekhaparikshana_ahvalche_vrsh")
	@NotNull(message = "Lekhaparikshana_ahvalche_vrsh cannot be null.")
	private String lekhaparikshanaAhvalcheVrsh;

	@NotNull(message = "Lekhaparikshana Ahvalatila Paricchheda Samkhaya cannot be null.")
	@Column(name = "lekhaparikshana_ahvalatila_paricchheda_samkhaya")
	private String lekhaparikshanaAhvalatilaParicchhedaSamkhaya;

	@NotNull(message = "Grampanchayat Nee Ya Mahinyata cannot be null.")
	@Column(name = "gymm_pootarta_kelelya_pariccchhedanchi_saikhaya")
	private String grampanchayattineeYaMahinyataPootartaKelelyaPariccchhedanchiSaikhaya;

	@NotNull(message = "Panchayat Samitti cannot be null.")
	@Column(name = "pssmmaanya_keleylyaa_pootartachi_saikhaya")
	private String panchayatSamittineAakshepaadaraMaanyaKeleylyaaPootartachiSaikhaya;

	@NotNull(message = "Lekhaparikshkane cannot be null.")
	@Column(name = "lcbpmaanya_keli_aahe_tya_aaksheepaanchyaa_sakhaya")
	private String lekhaparikshkaneChyaBabatitPootartaMaanyaKeliAaheTyaAaksheepaanchyaaSakhaya;

	@NotNull(message = "Prlabit Asalellya Aakshepachi cannot be null.")
	@Column(name = "prlabit_asalellya_aakshepachi_sakhaya")
	private String prlabitAsalellyaAakshepachiSakhaya;

	@NotNull(message = "Pootarta Na Kelelayabghlachi Kaarana cannot be null.")
	@Column(name = "pootarta_na_kelelayabghlachi_kaarana")
	private String pootartaNaKelelayabghlachiKaarana;

	@NotNull(message = "Sora cannot be null.")
	@Column(name = "shera")
	private String shera;

	// @NotNull(message = "Employee ID cannot be null.")
	@Column(name = "employee_id")
	private String employeeId;

	@Column(name = "dinank")
	private String dinank;

	// @NotNull(message = "Employee Name cannot be null.")
	@Column(name = "employee_name")
	private String employeeName;

	// @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	// @NotNull(message = "Create Date cannot be null.")
	// @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	@Column(name = "create_date", updatable = false)
	@CreationTimestamp
	private LocalDateTime createDate;

	// @NotNull(message = "Year cannot be null.")
	// @Column(name = "year")
	// private String year;

	// @NotNull(message = "Updated Date cannot be null.")
	@Column(name = "updated_date")
	@UpdateTimestamp
	private LocalDateTime updatedDate;

	// @NotNull(message = "Grampanchyat ID cannot be null.")
	@Column(name = "grampanchyat_id")
	private String grampanchyatId;

	// @NotNull(message = "Grampanchyat Name cannot be null.")
	@Column(name = "grampanchyat_name")
	private String grampanchyatName;

	// public String getYear() {
	// return year;
	// }
	//
	// public void setYear(String year) {
	// this.year = year;
	// }

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public LocalDateTime getCreateDate() {
		return createDate;
	}

	public void setCreateDate(LocalDateTime createDate) {
		this.createDate = createDate;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getGrampanchyatName() {
		return grampanchyatName;
	}

	public void setGrampanchyatName(String grampanchyatName) {
		this.grampanchyatName = grampanchyatName;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	// public String getAnukramamka() {
	// return anukramamka;
	// }
	//
	// public void setAnukramamka(String anukramamka) {
	// this.anukramamka = anukramamka;
	// }

	public String getLekhaparikshanaAhvalcheVrsh() {
		return lekhaparikshanaAhvalcheVrsh;
	}

	public void setLekhaparikshanaAhvalcheVrsh(String lekhaparikshanaAhvalcheVrsh) {
		this.lekhaparikshanaAhvalcheVrsh = lekhaparikshanaAhvalcheVrsh;
	}

	public String getLekhaparikshanaAhvalatilaParicchhedaSamkhaya() {
		return lekhaparikshanaAhvalatilaParicchhedaSamkhaya;
	}

	public void setLekhaparikshanaAhvalatilaParicchhedaSamkhaya(String lekhaparikshanaAhvalatilaParicchhedaSamkhaya) {
		this.lekhaparikshanaAhvalatilaParicchhedaSamkhaya = lekhaparikshanaAhvalatilaParicchhedaSamkhaya;
	}

	public String getGrampanchayattineeYaMahinyataPootartaKelelyaPariccchhedanchiSaikhaya() {
		return grampanchayattineeYaMahinyataPootartaKelelyaPariccchhedanchiSaikhaya;
	}

	public void setGrampanchayattineeYaMahinyataPootartaKelelyaPariccchhedanchiSaikhaya(
			String grampanchayattineeYaMahinyataPootartaKelelyaPariccchhedanchiSaikhaya) {
		this.grampanchayattineeYaMahinyataPootartaKelelyaPariccchhedanchiSaikhaya = grampanchayattineeYaMahinyataPootartaKelelyaPariccchhedanchiSaikhaya;
	}

	public String getPanchayatSamittineAakshepaadaraMaanyaKeleylyaaPootartachiSaikhaya() {
		return panchayatSamittineAakshepaadaraMaanyaKeleylyaaPootartachiSaikhaya;
	}

	public void setPanchayatSamittineAakshepaadaraMaanyaKeleylyaaPootartachiSaikhaya(
			String panchayatSamittineAakshepaadaraMaanyaKeleylyaaPootartachiSaikhaya) {
		this.panchayatSamittineAakshepaadaraMaanyaKeleylyaaPootartachiSaikhaya = panchayatSamittineAakshepaadaraMaanyaKeleylyaaPootartachiSaikhaya;
	}

	public String getLekhaparikshkaneChyaBabatitPootartaMaanyaKeliAaheTyaAaksheepaanchyaaSakhaya() {
		return lekhaparikshkaneChyaBabatitPootartaMaanyaKeliAaheTyaAaksheepaanchyaaSakhaya;
	}

	public void setLekhaparikshkaneChyaBabatitPootartaMaanyaKeliAaheTyaAaksheepaanchyaaSakhaya(
			String lekhaparikshkaneChyaBabatitPootartaMaanyaKeliAaheTyaAaksheepaanchyaaSakhaya) {
		this.lekhaparikshkaneChyaBabatitPootartaMaanyaKeliAaheTyaAaksheepaanchyaaSakhaya = lekhaparikshkaneChyaBabatitPootartaMaanyaKeliAaheTyaAaksheepaanchyaaSakhaya;
	}

	public String getPrlabitAsalellyaAakshepachiSakhaya() {
		return prlabitAsalellyaAakshepachiSakhaya;
	}

	public void setPrlabitAsalellyaAakshepachiSakhaya(String prlabitAsalellyaAakshepachiSakhaya) {
		this.prlabitAsalellyaAakshepachiSakhaya = prlabitAsalellyaAakshepachiSakhaya;
	}

	public String getPootartaNaKelelayabghlachiKaarana() {
		return pootartaNaKelelayabghlachiKaarana;
	}

	public void setPootartaNaKelelayabghlachiKaarana(String pootartaNaKelelayabghlachiKaarana) {
		this.pootartaNaKelelayabghlachiKaarana = pootartaNaKelelayabghlachiKaarana;
	}

	public String getShera() {
		return shera;
	}

	public void setShera(String shera) {
		this.shera = shera;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getGrampanchyatId() {
		return grampanchyatId;
	}

	public void setGrampanchyatId(String grampanchyatId) {
		this.grampanchyatId = grampanchyatId;
	}

	public String getDinank() {
		return dinank;
	}

	public void setDinank(String dinank) {
		this.dinank = dinank;
	}

	// Getters and Setters
	// ...
}