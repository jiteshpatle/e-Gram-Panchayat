package eGramPanchayat.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "21_mojmaap_wahi")
public class MojmaapWahi_21 {

    // Common Fields
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "year")
    private String year;
    
    @Column(name = "employee_id")
    private String employeeId;

    @Column(name = "employee_name")
    private String employeeName;

    @Column(name = "grampanchayat_id")
    private String grampanchayatId;

    @Column(name = "grampanchayat_name")
    private String grampanchayatName;

    @CreationTimestamp
    @Column(name = "created_date", updatable = false)
    private LocalDateTime createdDate;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "remark")
    private String remark;

    // MojmaapWahi Fields
    @Column(name = "kamache_pratyaksha_mojmap")
    private String kamachePratyakshaMojmap;

    @Column(name = "kamkarnaya_agency_abhikanache_naaw")
    private String kamkarnayaAgencyAbhikanacheNaaw;

    @Column(name = "kamache_warnan")
    private String kamacheWarnan;

    @Column(name = "mojmap")
    private String mojmap;

    @Column(name = "kamache_warnan_kamache_upashirsh_va_kshetrache_adhikari")
    private String kamacheWarnanKamacheUpashirshVaKshetracheAdhikari;;

    @Column(name = "mojmapacha_tapshil_pariman")
    private String mojmapachaTapshilPariman;

    @Column(name = "mojmapacha_tapshil_laambi")
    private String mojmapachaTapshilLaambi;

    @Column(name = "mojmapacha_tapshil_rundi")
    private String mojmapachaTapshilRundi;

    @Column(name = "mojmapacha_tapshil_kholi_unchi")
    private String mojmapachaTapshilKholiUnchi;

    @Column(name = "mojmapacha_tapshil_ekun")
    private String mojmapachaTapshilEkun;

    @Column(name = "ekun_pariman_maap_purviche_hajeri_pramane_warnan_karave")
    private String ekunParimanMaapPurvicheHajeriPramaneWarnanKarave;

    @Column(name = "ekun_mojmapacha_tapshil_ekun_va_ekun_pariman_maap")
    private String ekunMojmapachaTapshilEkunVaEkunParimanMaap;

    @Column(name = "dar")
    private String dar;

    @Column(name = "rakkam")
    private String rakkam;


    // Getters and Setters
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getGrampanchayatId() {
		return grampanchayatId;
	}

	public void setGrampanchayatId(String grampanchayatId) {
		this.grampanchayatId = grampanchayatId;
	}

	public String getGrampanchayatName() {
		return grampanchayatName;
	}

	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime localDateTime) {
		this.createdDate = localDateTime;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getKamachePratyakshaMojmap() {
		return kamachePratyakshaMojmap;
	}

	public void setKamachePratyakshaMojmap(String kamachePratyakshaMojmap) {
		this.kamachePratyakshaMojmap = kamachePratyakshaMojmap;
	}

	public String getKamkarnayaAgencyAbhikanacheNaaw() {
		return kamkarnayaAgencyAbhikanacheNaaw;
	}

	public void setKamkarnayaAgencyAbhikanacheNaaw(String kamkarnayaAgencyAbhikanacheNaaw) {
		this.kamkarnayaAgencyAbhikanacheNaaw = kamkarnayaAgencyAbhikanacheNaaw;
	}

	public String getKamacheWarnan() {
		return kamacheWarnan;
	}

	public void setKamacheWarnan(String kamacheWarnan) {
		this.kamacheWarnan = kamacheWarnan;
	}

	public String getMojmap() {
		return mojmap;
	}

	public void setMojmap(String mojmap) {
		this.mojmap = mojmap;
	}

	public String getKamacheWarnanKamacheUpashirshVaKshetracheAdhikari() {
		return kamacheWarnanKamacheUpashirshVaKshetracheAdhikari;
	}

	public void setKamacheWarnanKamacheUpashirshVaKshetracheAdhikari(
			String kamacheWarnanKamacheUpashirshVaKshetracheAdhikari) {
		this.kamacheWarnanKamacheUpashirshVaKshetracheAdhikari = kamacheWarnanKamacheUpashirshVaKshetracheAdhikari;
	}

	public String getMojmapachaTapshilPariman() {
		return mojmapachaTapshilPariman;
	}

	public void setMojmapachaTapshilPariman(String mojmapachaTapshilPariman) {
		this.mojmapachaTapshilPariman = mojmapachaTapshilPariman;
	}

	public String getMojmapachaTapshilLaambi() {
		return mojmapachaTapshilLaambi;
	}

	public void setMojmapachaTapshilLaambi(String mojmapachaTapshilLaambi) {
		this.mojmapachaTapshilLaambi = mojmapachaTapshilLaambi;
	}

	public String getMojmapachaTapshilRundi() {
		return mojmapachaTapshilRundi;
	}

	public void setMojmapachaTapshilRundi(String mojmapachaTapshilRundi) {
		this.mojmapachaTapshilRundi = mojmapachaTapshilRundi;
	}

	public String getMojmapachaTapshilKholiUnchi() {
		return mojmapachaTapshilKholiUnchi;
	}

	public void setMojmapachaTapshilKholiUnchi(String mojmapachaTapshilKholiUnchi) {
		this.mojmapachaTapshilKholiUnchi = mojmapachaTapshilKholiUnchi;
	}

	public String getMojmapachaTapshilEkun() {
		return mojmapachaTapshilEkun;
	}

	public void setMojmapachaTapshilEkun(String mojmapachaTapshilEkun) {
		this.mojmapachaTapshilEkun = mojmapachaTapshilEkun;
	}

	public String getEkunParimanMaapPurvicheHajeriPramaneWarnanKarave() {
		return ekunParimanMaapPurvicheHajeriPramaneWarnanKarave;
	}

	public void setEkunParimanMaapPurvicheHajeriPramaneWarnanKarave(
			String ekunParimanMaapPurvicheHajeriPramaneWarnanKarave) {
		this.ekunParimanMaapPurvicheHajeriPramaneWarnanKarave = ekunParimanMaapPurvicheHajeriPramaneWarnanKarave;
	}

	public String getEkunMojmapachaTapshilEkunVaEkunParimanMaap() {
		return ekunMojmapachaTapshilEkunVaEkunParimanMaap;
	}

	public void setEkunMojmapachaTapshilEkunVaEkunParimanMaap(String ekunMojmapachaTapshilEkunVaEkunParimanMaap) {
		this.ekunMojmapachaTapshilEkunVaEkunParimanMaap = ekunMojmapachaTapshilEkunVaEkunParimanMaap;
	}

	public String getDar() {
		return dar;
	}

	public void setDar(String dar) {
		this.dar = dar;
	}

	public String getRakkam() {
		return rakkam;
	}

	public void setRakkam(String rakkam) {
		this.rakkam = rakkam;
	}
}
