package eGramPanchayat.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name = "16_GramPanchayatNamuna")
public class Namuna16_DeadStock {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "Employee_id")
    private String employeeId;

    @Column(name = "Employee_Name")
    private String employeeName;

    @Column(name = "GramPanchayat_id")
    private String grampanchayatId;

    @Column(name = "GramPanchayat_Name")
    private String grampanchayatName;

    @Column(name = "Shera")
    private String shera;

    @Column(name = "Vastuche_Varnan")
    private String vastucheVarnan;

    @Column(name = "Kharedibaddal_Pradhikar")
    private String kharedibaddalPradhikar;

    @Column(name = "Kharedichi_Tarikh")
    private String kharedichiTarikh;

    @Column(name = "Sankhya_Kinva_Praman")
    private String sankhyaKinvaPraman;
    
    @Column(name = "Kimmat")
    private Double kimmat;
    
    @Column(name = "Antim_Vilhevat_Sankhya_Kinva_Pariman")
    private String antimVilhevatsathiSankhyaKinvaPariman;
    
    @Column(name = "Vilhevatiche_Swarup")
    private String vilhevaticheSwarup;
    
    @Column(name = "Pradhikar_Patra_Kinva_Pramanak")
    private String pradhikarPatraKinvaPramanak;
    
    @Column(name = "Vasul_Keleli_Rakkam")
    private String vasulKeleliRakkam;
    
    @Column(name = "Vasul_Rakkam_Koshagarat_Bharnyachi_Tarikh")
    private String vasulRakkamKoshagaratBharnyachiTarikh;
    
    @Column(name = "Sathyatil_Shillak")
    private String sathyatilShillak;
    
    @Column(name = "Dinank")
    private String date;

    @Column(name = "year")
    private String year;

    @Column(name = "Created_Date", updatable = false)
    @CreationTimestamp
    private LocalDateTime createdDate;

    @Column(name = "UpdatedDate")
    @UpdateTimestamp
    private LocalDateTime updatedDate;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getGrampanchayatId() {
		return grampanchayatId;
	}

	public void setGrampanchayatId(String grampanchayatId) {
		this.grampanchayatId = grampanchayatId;
	}

	public String getGrampanchayatName() {
		return grampanchayatName;
	}

	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}

	public String getShera() {
		return shera;
	}

	public void setShera(String shera) {
		this.shera = shera;
	}

	public String getVastucheVarnan() {
		return vastucheVarnan;
	}

	public void setVastucheVarnan(String vastucheVarnan) {
		this.vastucheVarnan = vastucheVarnan;
	}

	public String getKharedibaddalPradhikar() {
		return kharedibaddalPradhikar;
	}

	public void setKharedibaddalPradhikar(String kharedibaddalPradhikar) {
		this.kharedibaddalPradhikar = kharedibaddalPradhikar;
	}

	public String getKharedichiTarikh() {
		return kharedichiTarikh;
	}

	public void setKharedichiTarikh(String kharedichiTarikh) {
		this.kharedichiTarikh = kharedichiTarikh;
	}

	public String getSankhyaKinvaPraman() {
		return sankhyaKinvaPraman;
	}

	public void setSankhyaKinvaPraman(String sankhyaKinvaPraman) {
		this.sankhyaKinvaPraman = sankhyaKinvaPraman;
	}

	public Double getKimmat() {
		return kimmat;
	}

	public void setKimmat(Double kimmat) {
		this.kimmat = kimmat;
	}

	public String getAntimVilhevatsathiSankhyaKinvaPariman() {
		return antimVilhevatsathiSankhyaKinvaPariman;
	}

	public void setAntimVilhevatsathiSankhyaKinvaPariman(String antimVilhevatsathiSankhyaKinvaPariman) {
		this.antimVilhevatsathiSankhyaKinvaPariman = antimVilhevatsathiSankhyaKinvaPariman;
	}

	public String getVilhevaticheSwarup() {
		return vilhevaticheSwarup;
	}

	public void setVilhevaticheSwarup(String vilhevaticheSwarup) {
		this.vilhevaticheSwarup = vilhevaticheSwarup;
	}

	public String getPradhikarPatraKinvaPramanak() {
		return pradhikarPatraKinvaPramanak;
	}

	public void setPradhikarPatraKinvaPramanak(String pradhikarPatraKinvaPramanak) {
		this.pradhikarPatraKinvaPramanak = pradhikarPatraKinvaPramanak;
	}

	public String getVasulKeleliRakkam() {
		return vasulKeleliRakkam;
	}

	public void setVasulKeleliRakkam(String vasulKeleliRakkam) {
		this.vasulKeleliRakkam = vasulKeleliRakkam;
	}

	public String getVasulRakkamKoshagaratBharnyachiTarikh() {
		return vasulRakkamKoshagaratBharnyachiTarikh;
	}

	public void setVasulRakkamKoshagaratBharnyachiTarikh(String vasulRakkamKoshagaratBharnyachiTarikh) {
		this.vasulRakkamKoshagaratBharnyachiTarikh = vasulRakkamKoshagaratBharnyachiTarikh;
	}

	public String getSathyatilShillak() {
		return sathyatilShillak;
	}

	public void setSathyatilShillak(String sathyatilShillak) {
		this.sathyatilShillak = sathyatilShillak;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}
	
}