package eGramPanchayat.entity;



import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@JsonInclude(JsonInclude.Include.NON_NULL) 
@Table(name = "11_kirkol_Magani_nondvahi")
public class Kirkolmagni_11 {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "year")
    private String year;
    
    @Column(name = "employee_id")
    private String employeeId;

    @Column(name = "employee_name")
    private String employeeName;

    @Column(name = "grampanchayat_id")
    private String grampanchayatId;

    @Column(name = "grampanchayat_name")
    private String grampanchayatName;

    @CreationTimestamp
    @Column(name = "created_date", updatable = false)
    private LocalDateTime createdDate;
    
    @UpdateTimestamp
    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "remark")
    private String remark;
    
    @Column(name = "property_owner_name")
    private String propertyOwnerName;
    
    private String magniche_Swarup;
    private String magnisathi_Pradhikar;
    private long magni_Happta;
    private long magni_Rakam;
    private long magni_Total;
    private String deyakramankOR_Date;
    private String vasuli_PavtiKramankOR_Date;
    private long vasuli_Rakam;
    private String sut_AadheshachaKramankOR_Date;
    private long sut_Rakam;
    private long shillak;
    private String shera;
	public Kirkolmagni_11() {
		super();
	}
	public Kirkolmagni_11(Long id, String year, String employeeId, String employeeName, String grampanchayatId,
			String grampanchayatName, LocalDateTime createdDate, LocalDateTime updatedDate, String remark,
			String propertyOwnerName, String magniche_Swarup, String magnisathi_Pradhikar, long magni_Happta,
			long magni_Rakam, long magni_Total, String deyakramankOR_Date, String vasuli_PavtiKramankOR_Date,
			long vasuli_Rakam, String sut_AadheshachaKramankOR_Date, long sut_Rakam, long shillak, String shera) {
		super();
		this.id = id;
		this.year = year;
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.grampanchayatId = grampanchayatId;
		this.grampanchayatName = grampanchayatName;
		this.createdDate = createdDate;
		this.updatedDate = updatedDate;
		this.remark = remark;
		this.propertyOwnerName = propertyOwnerName;
		this.magniche_Swarup = magniche_Swarup;
		this.magnisathi_Pradhikar = magnisathi_Pradhikar;
		this.magni_Happta = magni_Happta;
		this.magni_Rakam = magni_Rakam;
		this.magni_Total = magni_Total;
		this.deyakramankOR_Date = deyakramankOR_Date;
		this.vasuli_PavtiKramankOR_Date = vasuli_PavtiKramankOR_Date;
		this.vasuli_Rakam = vasuli_Rakam;
		this.sut_AadheshachaKramankOR_Date = sut_AadheshachaKramankOR_Date;
		this.sut_Rakam = sut_Rakam;
		this.shillak = shillak;
		this.shera = shera;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getGrampanchayatId() {
		return grampanchayatId;
	}
	public void setGrampanchayatId(String grampanchayatId) {
		this.grampanchayatId = grampanchayatId;
	}
	public String getGrampanchayatName() {
		return grampanchayatName;
	}
	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}
	public LocalDateTime getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getPropertyOwnerName() {
		return propertyOwnerName;
	}
	public void setPropertyOwnerName(String propertyOwnerName) {
		this.propertyOwnerName = propertyOwnerName;
	}
	public String getMagniche_Swarup() {
		return magniche_Swarup;
	}
	public void setMagniche_Swarup(String magniche_Swarup) {
		this.magniche_Swarup = magniche_Swarup;
	}
	public String getMagnisathi_Pradhikar() {
		return magnisathi_Pradhikar;
	}
	public void setMagnisathi_Pradhikar(String magnisathi_Pradhikar) {
		this.magnisathi_Pradhikar = magnisathi_Pradhikar;
	}
	public long getMagni_Happta() {
		return magni_Happta;
	}
	public void setMagni_Happta(long magni_Happta) {
		this.magni_Happta = magni_Happta;
	}
	public long getMagni_Rakam() {
		return magni_Rakam;
	}
	public void setMagni_Rakam(long magni_Rakam) {
		this.magni_Rakam = magni_Rakam;
	}
	public long getMagni_Total() {
		return magni_Total;
	}
	public void setMagni_Total(long magni_Total) {
		this.magni_Total = magni_Total;
	}
	public String getDeyakramankOR_Date() {
		return deyakramankOR_Date;
	}
	public void setDeyakramankOR_Date(String deyakramankOR_Date) {
		this.deyakramankOR_Date = deyakramankOR_Date;
	}
	public String getVasuli_PavtiKramankOR_Date() {
		return vasuli_PavtiKramankOR_Date;
	}
	public void setVasuli_PavtiKramankOR_Date(String vasuli_PavtiKramankOR_Date) {
		this.vasuli_PavtiKramankOR_Date = vasuli_PavtiKramankOR_Date;
	}
	public long getVasuli_Rakam() {
		return vasuli_Rakam;
	}
	public void setVasuli_Rakam(long vasuli_Rakam) {
		this.vasuli_Rakam = vasuli_Rakam;
	}
	public String getSut_AadheshachaKramankOR_Date() {
		return sut_AadheshachaKramankOR_Date;
	}
	public void setSut_AadheshachaKramankOR_Date(String sut_AadheshachaKramankOR_Date) {
		this.sut_AadheshachaKramankOR_Date = sut_AadheshachaKramankOR_Date;
	}
	public long getSut_Rakam() {
		return sut_Rakam;
	}
	public void setSut_Rakam(long sut_Rakam) {
		this.sut_Rakam = sut_Rakam;
	}
	public long getShillak() {
		return shillak;
	}
	public void setShillak(long shillak) {
		this.shillak = shillak;
	}
	public String getShera() {
		return shera;
	}
	public void setShera(String shera) {
		this.shera = shera;
	}
    
}

