package eGramPanchayat.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name = "5C_GramPanchayatNamuna")
public class Namuna5C_DainikRokadVahi {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "Employee_id")
    private String employeeId;

    @Column(name = "Employee_Name")
    private String employeeName;

    @Column(name = "GramPanchayat_id")
    private String grampanchayatId;

    @Column(name = "GramPanchayat_Name")
    private String grampanchayatName;

    @Column(name = "Shera")
    private String shera;

    @Column(name = "pavti_Kramank")
    private Integer pavtiKramank;

    @Column(name = "Konakadun_Milali")
    private String konakdunMilali;

    @Column(name = "jama_Rakkam_Tapshil")
    private String jamaRakkamTapshil;

    @Column(name = "rokh_Rakkam")
    private Double rokhRakkam;
    
    @Column(name = "dhanadesh_Rakkam")
    private Double dhanadeshRakkam;
    
    @Column(name = "dhanadesh_Kinva_Rakkam_JamaDinank")
    private String dhanadeshKinvaRakkamJamaDinank;
    
    @Column(name = "dhanadesh_Vatvilyacha_Dinank")
    private String dhanadeshVatvilyachaDinank;
    
    @Column(name = "Dinank")
    private String date;

	@Column(name = "year")
    private String year;

    @Column(name = "Creared_Date", updatable = false)
    @CreationTimestamp
    private LocalDateTime createdDate;

    @Column(name = "UpdatedDate")
    @UpdateTimestamp
    private LocalDateTime updatedDate;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getGrampanchayatId() {
		return grampanchayatId;
	}

	public void setGrampanchayatId(String grampanchayatId) {
		this.grampanchayatId = grampanchayatId;
	}

	public String getGrampanchayatName() {
		return grampanchayatName;
	}

	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}

	public String getShera() {
		return shera;
	}

	public void setShera(String shera) {
		this.shera = shera;
	}

	public Integer getPavtiKramank() {
		return pavtiKramank;
	}

	public void setPavtiKramank(Integer pavtiKramank) {
		this.pavtiKramank = pavtiKramank;
	}

	public String getKonakdunMilali() {
		return konakdunMilali;
	}

	public void setKonakdunMilali(String konakdunMilali) {
		this.konakdunMilali = konakdunMilali;
	}

	public String getJamaRakkamTapshil() {
		return jamaRakkamTapshil;
	}

	public void setJamaRakkamTapshil(String jamaRakkamTapshil) {
		this.jamaRakkamTapshil = jamaRakkamTapshil;
	}

	public Double getRokhRakkam() {
		return rokhRakkam;
	}

	public void setRokhRakkam(Double rokhRakkam) {
		this.rokhRakkam = rokhRakkam;
	}

	public Double getDhanadeshRakkam() {
		return dhanadeshRakkam;
	}

	public void setDhanadeshRakkam(Double dhanadeshRakkam) {
		this.dhanadeshRakkam = dhanadeshRakkam;
	}

	public String getDhanadeshKinvaRakkamJamaDinank() {
		return dhanadeshKinvaRakkamJamaDinank;
	}

	public void setDhanadeshKinvaRakkamJamaDinank(String dhanadeshKinvaRakkamJamaDinank) {
		this.dhanadeshKinvaRakkamJamaDinank = dhanadeshKinvaRakkamJamaDinank;
	}

	public String getDhanadeshVatvilyachaDinank() {
		return dhanadeshVatvilyachaDinank;
	}

	public void setDhanadeshVatvilyachaDinank(String dhanadeshVatvilyachaDinank) {
		this.dhanadeshVatvilyachaDinank = dhanadeshVatvilyachaDinank;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

    public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
	
}