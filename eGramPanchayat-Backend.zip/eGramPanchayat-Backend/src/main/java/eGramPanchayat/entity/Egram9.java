package eGramPanchayat.entity;

import java.time.LocalDateTime;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@JsonInclude(JsonInclude.Include.NON_NULL)
@Table(name = "09_Kar_Maghni_Nondvahi")
public class Egram9 {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "year")
	private String year;

	@Column(name = "employee_id")
	private String employeeId;

	@Column(name = "employee_name")
	private String employeeName;

	@Column(name = "grampanchayat_id")
	private String grampanchayatId;

	@Column(name = "grampanchayat_name")
	private String grampanchayatName;

	@CreationTimestamp
	@Column(name = "created_date", updatable = false)
	private LocalDateTime createdDate;

	@UpdateTimestamp
	// @CreationTimestamp
	@Column(name = "updated_date")
	private LocalDateTime updatedDate;

	@Column(name = "remark")
	private String remark;

	@Column(name = "serial_no")
	private Integer serialNo;

	private Long milkat_Number;

	@Column(name = "property_owner_name")
	private String propertyOwnerName;

	private Long na_GharMagilBaki;
	private Long na_GharChaluKar;
	private Long na_GharTotal;

	private Long na_VijMagilBaki;
	private Long na_VijChaluKar;
	private Long na_VijTotal;

	private Long na_ArogyaMagilBaki;
	private Long na_ArogyaChaluKar;
	private Long na_ArogyaTotal;

	private Long na_PaniMagilBaki;
	private Long na_PaniChaluKar;
	private Long na_PaniTotal;

	private Long na_TotalKar;
	private String bookNo;
	private String bookNoOR_Date;
	private String pavti_Number;

	private Long vasuli_GharMagilBaki;
	private Long vasuli_GharChaluKar;
	private Long vasuli_GharTotal;

	private Long vasuli_VijMagilBaki;
	private Long vasuli_VijChaluKar;
	private Long vasuli_VijTotal;

	private Long vasuli_ArogyaMagilBaki;
	private Long vasuli_ArogyaChaluKar;
	private Long vasuli_ArogyaTotal;

	private Long vasuli_PaniMagilBaki;
	private Long vasuli_PaniChaluKar;
	private Long vasuli_PaniTotal;

	private Long vasuli_TotalKar;
	private String sutManjuriHukmacha_Ullekh;
	private String sutManjuriHukmacha_Shera;

	public Egram9() {
		super();
	}

	public Egram9(Long id, String year, String employeeId, String employeeName, String grampanchayatId,
			String grampanchayatName, LocalDateTime createdDate, LocalDateTime updatedDate, String remark,
			Integer serialNo, Long milkat_Number, String propertyOwnerName, Long na_GharMagilBaki, Long na_GharChaluKar,
			Long na_GharTotal, Long na_VijMagilBaki, Long na_VijChaluKar, Long na_VijTotal, Long na_ArogyaMagilBaki,
			Long na_ArogyaChaluKar, Long na_ArogyaTotal, Long na_PaniMagilBaki, Long na_PaniChaluKar, Long na_PaniTotal,
			Long na_TotalKar, String bookNo, String bookNoOR_Date, String pavti_Number, Long vasuli_GharMagilBaki,
			Long vasuli_GharChaluKar, Long vasuli_GharTotal, Long vasuli_VijMagilBaki, Long vasuli_VijChaluKar,
			Long vasuli_VijTotal, Long vasuli_ArogyaMagilBaki, Long vasuli_ArogyaChaluKar, Long vasuli_ArogyaTotal,
			Long vasuli_PaniMagilBaki, Long vasuli_PaniChaluKar, Long vasuli_PaniTotal, Long vasuli_TotalKar,
			String sutManjuriHukmacha_Ullekh, String sutManjuriHukmacha_Shera) {
		super();
		this.id = id;
		this.year = year;
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.grampanchayatId = grampanchayatId;
		this.grampanchayatName = grampanchayatName;
		this.createdDate = createdDate;
		this.updatedDate = updatedDate;
		this.remark = remark;
		this.serialNo = serialNo;
		this.milkat_Number = milkat_Number;
		this.propertyOwnerName = propertyOwnerName;
		this.na_GharMagilBaki = na_GharMagilBaki;
		this.na_GharChaluKar = na_GharChaluKar;
		this.na_GharTotal = na_GharTotal;
		this.na_VijMagilBaki = na_VijMagilBaki;
		this.na_VijChaluKar = na_VijChaluKar;
		this.na_VijTotal = na_VijTotal;
		this.na_ArogyaMagilBaki = na_ArogyaMagilBaki;
		this.na_ArogyaChaluKar = na_ArogyaChaluKar;
		this.na_ArogyaTotal = na_ArogyaTotal;
		this.na_PaniMagilBaki = na_PaniMagilBaki;
		this.na_PaniChaluKar = na_PaniChaluKar;
		this.na_PaniTotal = na_PaniTotal;
		this.na_TotalKar = na_TotalKar;
		this.bookNo = bookNo;
		this.bookNoOR_Date = bookNoOR_Date;
		this.pavti_Number = pavti_Number;
		this.vasuli_GharMagilBaki = vasuli_GharMagilBaki;
		this.vasuli_GharChaluKar = vasuli_GharChaluKar;
		this.vasuli_GharTotal = vasuli_GharTotal;
		this.vasuli_VijMagilBaki = vasuli_VijMagilBaki;
		this.vasuli_VijChaluKar = vasuli_VijChaluKar;
		this.vasuli_VijTotal = vasuli_VijTotal;
		this.vasuli_ArogyaMagilBaki = vasuli_ArogyaMagilBaki;
		this.vasuli_ArogyaChaluKar = vasuli_ArogyaChaluKar;
		this.vasuli_ArogyaTotal = vasuli_ArogyaTotal;
		this.vasuli_PaniMagilBaki = vasuli_PaniMagilBaki;
		this.vasuli_PaniChaluKar = vasuli_PaniChaluKar;
		this.vasuli_PaniTotal = vasuli_PaniTotal;
		this.vasuli_TotalKar = vasuli_TotalKar;
		this.sutManjuriHukmacha_Ullekh = sutManjuriHukmacha_Ullekh;
		this.sutManjuriHukmacha_Shera = sutManjuriHukmacha_Shera;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getGrampanchayatId() {
		return grampanchayatId;
	}

	public void setGrampanchayatId(String grampanchayatId) {
		this.grampanchayatId = grampanchayatId;
	}

	public String getGrampanchayatName() {
		return grampanchayatName;
	}

	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(Integer serialNo) {
		this.serialNo = serialNo;
	}

	public Long getMilkat_Number() {
		return milkat_Number;
	}

	public void setMilkat_Number(Long milkat_Number) {
		this.milkat_Number = milkat_Number;
	}

	public String getPropertyOwnerName() {
		return propertyOwnerName;
	}

	public void setPropertyOwnerName(String propertyOwnerName) {
		this.propertyOwnerName = propertyOwnerName;
	}

	public Long getNa_GharMagilBaki() {
		return na_GharMagilBaki;
	}

	public void setNa_GharMagilBaki(Long na_GharMagilBaki) {
		this.na_GharMagilBaki = na_GharMagilBaki;
	}

	public Long getNa_GharChaluKar() {
		return na_GharChaluKar;
	}

	public void setNa_GharChaluKar(Long na_GharChaluKar) {
		this.na_GharChaluKar = na_GharChaluKar;
	}

	public Long getNa_GharTotal() {
		return na_GharTotal;
	}

	public void setNa_GharTotal(Long na_GharTotal) {
		this.na_GharTotal = na_GharTotal;
	}

	public Long getNa_VijMagilBaki() {
		return na_VijMagilBaki;
	}

	public void setNa_VijMagilBaki(Long na_VijMagilBaki) {
		this.na_VijMagilBaki = na_VijMagilBaki;
	}

	public Long getNa_VijChaluKar() {
		return na_VijChaluKar;
	}

	public void setNa_VijChaluKar(Long na_VijChaluKar) {
		this.na_VijChaluKar = na_VijChaluKar;
	}

	public Long getNa_VijTotal() {
		return na_VijTotal;
	}

	public void setNa_VijTotal(Long na_VijTotal) {
		this.na_VijTotal = na_VijTotal;
	}

	public Long getNa_ArogyaMagilBaki() {
		return na_ArogyaMagilBaki;
	}

	public void setNa_ArogyaMagilBaki(Long na_ArogyaMagilBaki) {
		this.na_ArogyaMagilBaki = na_ArogyaMagilBaki;
	}

	public Long getNa_ArogyaChaluKar() {
		return na_ArogyaChaluKar;
	}

	public void setNa_ArogyaChaluKar(Long na_ArogyaChaluKar) {
		this.na_ArogyaChaluKar = na_ArogyaChaluKar;
	}

	public Long getNa_ArogyaTotal() {
		return na_ArogyaTotal;
	}

	public void setNa_ArogyaTotal(Long na_ArogyaTotal) {
		this.na_ArogyaTotal = na_ArogyaTotal;
	}

	public Long getNa_PaniMagilBaki() {
		return na_PaniMagilBaki;
	}

	public void setNa_PaniMagilBaki(Long na_PaniMagilBaki) {
		this.na_PaniMagilBaki = na_PaniMagilBaki;
	}

	public Long getNa_PaniChaluKar() {
		return na_PaniChaluKar;
	}

	public void setNa_PaniChaluKar(Long na_PaniChaluKar) {
		this.na_PaniChaluKar = na_PaniChaluKar;
	}

	public Long getNa_PaniTotal() {
		return na_PaniTotal;
	}

	public void setNa_PaniTotal(Long na_PaniTotal) {
		this.na_PaniTotal = na_PaniTotal;
	}

	public Long getNa_TotalKar() {
		return na_TotalKar;
	}

	public void setNa_TotalKar(Long na_TotalKar) {
		this.na_TotalKar = na_TotalKar;
	}

	public String getBookNo() {
		return bookNo;
	}

	public void setBookNo(String bookNo) {
		this.bookNo = bookNo;
	}

	public String getBookNoOR_Date() {
		return bookNoOR_Date;
	}

	public void setBookNoOR_Date(String bookNoOR_Date) {
		this.bookNoOR_Date = bookNoOR_Date;
	}

	public String getPavti_Number() {
		return pavti_Number;
	}

	public void setPavti_Number(String pavti_Number) {
		this.pavti_Number = pavti_Number;
	}

	public Long getVasuli_GharMagilBaki() {
		return vasuli_GharMagilBaki;
	}

	public void setVasuli_GharMagilBaki(Long vasuli_GharMagilBaki) {
		this.vasuli_GharMagilBaki = vasuli_GharMagilBaki;
	}

	public Long getVasuli_GharChaluKar() {
		return vasuli_GharChaluKar;
	}

	public void setVasuli_GharChaluKar(Long vasuli_GharChaluKar) {
		this.vasuli_GharChaluKar = vasuli_GharChaluKar;
	}

	public Long getVasuli_GharTotal() {
		return vasuli_GharTotal;
	}

	public void setVasuli_GharTotal(Long vasuli_GharTotal) {
		this.vasuli_GharTotal = vasuli_GharTotal;
	}

	public Long getVasuli_VijMagilBaki() {
		return vasuli_VijMagilBaki;
	}

	public void setVasuli_VijMagilBaki(Long vasuli_VijMagilBaki) {
		this.vasuli_VijMagilBaki = vasuli_VijMagilBaki;
	}

	public Long getVasuli_VijChaluKar() {
		return vasuli_VijChaluKar;
	}

	public void setVasuli_VijChaluKar(Long vasuli_VijChaluKar) {
		this.vasuli_VijChaluKar = vasuli_VijChaluKar;
	}

	public Long getVasuli_VijTotal() {
		return vasuli_VijTotal;
	}

	public void setVasuli_VijTotal(Long vasuli_VijTotal) {
		this.vasuli_VijTotal = vasuli_VijTotal;
	}

	public Long getVasuli_ArogyaMagilBaki() {
		return vasuli_ArogyaMagilBaki;
	}

	public void setVasuli_ArogyaMagilBaki(Long vasuli_ArogyaMagilBaki) {
		this.vasuli_ArogyaMagilBaki = vasuli_ArogyaMagilBaki;
	}

	public Long getVasuli_ArogyaChaluKar() {
		return vasuli_ArogyaChaluKar;
	}

	public void setVasuli_ArogyaChaluKar(Long vasuli_ArogyaChaluKar) {
		this.vasuli_ArogyaChaluKar = vasuli_ArogyaChaluKar;
	}

	public Long getVasuli_ArogyaTotal() {
		return vasuli_ArogyaTotal;
	}

	public void setVasuli_ArogyaTotal(Long vasuli_ArogyaTotal) {
		this.vasuli_ArogyaTotal = vasuli_ArogyaTotal;
	}

	public Long getVasuli_PaniMagilBaki() {
		return vasuli_PaniMagilBaki;
	}

	public void setVasuli_PaniMagilBaki(Long vasuli_PaniMagilBaki) {
		this.vasuli_PaniMagilBaki = vasuli_PaniMagilBaki;
	}

	public Long getVasuli_PaniChaluKar() {
		return vasuli_PaniChaluKar;
	}

	public void setVasuli_PaniChaluKar(Long vasuli_PaniChaluKar) {
		this.vasuli_PaniChaluKar = vasuli_PaniChaluKar;
	}

	public Long getVasuli_PaniTotal() {
		return vasuli_PaniTotal;
	}

	public void setVasuli_PaniTotal(Long vasuli_PaniTotal) {
		this.vasuli_PaniTotal = vasuli_PaniTotal;
	}

	public Long getVasuli_TotalKar() {
		return vasuli_TotalKar;
	}

	public void setVasuli_TotalKar(Long vasuli_TotalKar) {
		this.vasuli_TotalKar = vasuli_TotalKar;
	}

	public String getSutManjuriHukmacha_Ullekh() {
		return sutManjuriHukmacha_Ullekh;
	}

	public void setSutManjuriHukmacha_Ullekh(String sutManjuriHukmacha_Ullekh) {
		this.sutManjuriHukmacha_Ullekh = sutManjuriHukmacha_Ullekh;
	}

	public String getSutManjuriHukmacha_Shera() {
		return sutManjuriHukmacha_Shera;
	}

	public void setSutManjuriHukmacha_Shera(String sutManjuriHukmacha_Shera) {
		this.sutManjuriHukmacha_Shera = sutManjuriHukmacha_Shera;
	}

}