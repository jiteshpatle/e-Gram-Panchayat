package eGramPanchayat.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "33_GramPanchayatNamuna")
public class Namuna33VrukshNondViha {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "Employee_id")
    private String employeeid;

    @Column(name = "Employee_Name")
    private String employeename;

    @Column(name = "GramPanchayat_id")
    private String grampanchayatid;

    @Column(name = "GramPanchayat_Name")
    private String grampanchayatname;

    @Column(name = "Shera")
    private String shera;

    @Column(name = "naav")
    private String naav;

    @Column(name = "vrukshkrmank_C-C")
    private String vrukshkrmank;

    @Column(name = "vrukshprakar")
    private String vrukshprakar;

    @Column(name = "vrukshjopasnechijababdari")
    private String vrukshjopasnechijababdari;

    @Column(name = "Dinank")
    private String date;

    @Column(name = "Creared_Date", updatable = false)
    @CreationTimestamp
    private LocalDateTime currentDate;

    @Column(name = "UpdatedDate")
    @UpdateTimestamp
    private LocalDateTime updatedDate;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getEmployeename() {
        return employeename;
    }

    public void setEmployeename(String employeename) {
        this.employeename = employeename;
    }

    public String getGrampanchayatname() {
        return grampanchayatname;
    }

    public void setGrampanchayatname(String grampanchayatname) {
        this.grampanchayatname = grampanchayatname;
    }

    public String getNaav() {
        return naav;
    }

    public void setNaav(String naav) {
        this.naav = naav;
    }

    public String getVrukshprakar() {
        return vrukshprakar;
    }

    public void setVrukshprakar(String vrukshprakar) {
        this.vrukshprakar = vrukshprakar;
    }

    public String getVrukshjopasnechijababdari() {
        return vrukshjopasnechijababdari;
    }

    public void setVrukshjopasnechijababdari(String vrukshjopasnechijababdari) {
        this.vrukshjopasnechijababdari = vrukshjopasnechijababdari;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public LocalDateTime getCurrentDate() {
        return currentDate;
    }

    public void setCurrentDate(LocalDateTime currentDate) {
        this.currentDate = currentDate;
    }

    public String getShera() {
        return shera;
    }

    public void setShera(String shera) {
        this.shera = shera;
    }

    public String getGrampanchayatid() {
        return grampanchayatid;
    }

    public void setGrampanchayatid(String grampanchayatid) {
        this.grampanchayatid = grampanchayatid;
    }

    public String getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(String employeeid) {
        this.employeeid = employeeid;
    }

    public String getVrukshkrmank() {
        return vrukshkrmank;
    }

    public void setVrukshkrmank(String vrukshkrmank) {
        this.vrukshkrmank = vrukshkrmank;
    }
}