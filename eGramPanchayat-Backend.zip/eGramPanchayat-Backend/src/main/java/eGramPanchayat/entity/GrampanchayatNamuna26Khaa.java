package eGramPanchayat.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import java.time.LocalDateTime;

@Entity
@Table(name = "26_Khaa_grampanchayat")
public class GrampanchayatNamuna26Khaa {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id; // Primary Key

	@NotNull(message = "Mahina cannot be null.")
	@NotBlank(message = "Mahina cannot be empty.")
	// @Pattern(regexp = "^[u0900-u097F]*$", message = "Mahina cannot contain the @
	// character.")
	@Column(name = "mahina")
	private String mahina;

	@NotNull(message = "Praarabhit Shillak cannot be null.")
	@NotBlank(message = "Praarabhit Shillak cannot be empty.")
	// @Pattern(regexp = "^[u0900-u097F0-9 .]*$", message = "Praarabhit Shillak
	// cannot contain the @ character.")
	@Column(name = "praarabhit_shillak")
	private String praarabhitShillak;

	@NotNull(message = "Rakam Jama Kileyacha Mahina cannot be null.")
	@NotBlank(message = "Rakam Jama Kileyacha Mahina cannot be empty.")
	// @Pattern(regexp = "^[u0900-u097]*$", message = "Rakam Jama Kileyacha Mahina
	// cannot contain the @ character.")
	@Column(name = "rakam_jama_kileyacha_mahina")
	private String rakamJamaKileyachaMahina;

	@NotNull(message = "Mahina Aakhrichi Shillak Sachivakdila cannot be null.")
	@NotBlank(message = "Mahina Aakhrichi Shillak Sachivakdila cannot be empty.")
	// @Pattern(regexp = "^[u0900-u097F0-9 . ]*$", message = "Mahina Aakhrichi
	// Shillak Sachivakdila cannot contain the @ character.")
	@Column(name = "mahina_aakhrichi_shillak_sachivakdila")
	private String mahinaAakhrichiShillakSachivakdila;

	@NotNull(message = "Mahina Aakhrichi Shillak Banketila cannot be null.")
	@NotBlank(message = "Mahina Aakhrichi Shillak Banketila cannot be empty.")
	// @Pattern(regexp = "^[u0900-u097F0-9 .]*$", message = "Mahina Aakhrichi
	// Shillak Banketila cannot contain the @ character.")
	@Column(name = "mahina_aakhrichi_shillak_banketila")
	private String mahinaAakhrichiShillakBanketila;

	@NotNull(message = "Mahina Aakhrichi Shillak Postateil cannot be null.")
	@NotBlank(message = "Mahina Aakhrichi Shillak Postateil cannot be empty.")
	// @Pattern(regexp = "^[u0900-u097F0-9 .]*$", message = "Mahina Aakhrichi
	// Shillak Postateil cannot contain the @ character.")
	@Column(name = "mahina_aakhrichi_shillak_postateil")
	private String mahinaAakhrichiShillakPostateil;

	@NotNull(message = "Alpabachat Pramanapatrata Guntviloli Rakam cannot be null.")
	@NotBlank(message = "Alpabachat Pramanapatrata Guntviloli Rakam cannot be empty.")
	// @Pattern(regexp = "^[u0900-u097F0-9 .]*$", message = "Alpabachat
	// Pramanapatrata Guntviloli Rakam cannot contain the @ character.")
	@Column(name = "alpabachat_pramanapatrata_guntviloli_rakam")
	private String alpabachatPramanapatrataGuntviloliRakam;

	@NotNull(message = "Banketa Mudata Thevita Guntavilili Rakam cannot be null.")
	@NotBlank(message = "Banketa Mudata Thevita Guntavilili Rakam cannot be empty.")
	// @Pattern(regexp = "^[u0900-u097F0-9 .]*$", message = "Banketa Mudata Thevita
	// Guntavilili Rakam cannot contain the @ character.")
	@Column(name = "banketa_mudata_thevita_guntavilili_rakam")
	private String banketaMudataThevitaGuntavililiRakam;

	@NotNull(message = "Ekun cannot be null.")
	@NotBlank(message = "Ekun cannot be empty.")
	// @Pattern(regexp = "^[u0900-u097F0-9 .]*$", message = "Ekun cannot contain the
	// @ character.")
	@Column(name = "ekun")
	private String ekun;

	// @NotNull(message = "Shora Niyamapesha Jasata Rakam cannot be null.")
	// @NotBlank(message = "Shora Niyamapesha Jasata Rakam cannot be empty.")
	// @Pattern(regexp = "^[u0900-u097F0-9a-zA-Z ]*$", message = "Shora Niyamapesha
	// Jasata Rakam cannot contain the @ character.")
	// @Column(name = "shora_niyamapesha_jasata_rakam", columnDefinition = "TEXT")
	// private String shoraNiyamapeshaJasataRakam;

	// @NotNull(message = "Employee ID cannot be null.")
	@Column(name = "employee_id")
	private String employeeId;

	@Column(name = "dinank")
	private String dinank;

	@Column(name = "create_date")
	@CreationTimestamp
	private LocalDateTime createDate;

	@Column(name = "updated_date")
	@UpdateTimestamp
	private LocalDateTime updatedDate;

	// @NotNull(message = "Grampanchyat ID cannot be null.")
	@Column(name = "grampanchyat_id")
	private String grampanchyatId;

	//// @NotNull(message = "Employee Name cannot be null.")
	//// @NotBlank(message = "Employee Name cannot be empty.")
	// @Pattern(regexp = "^[^@]*$", message = "Employee Name cannot contain the @
	//// character.")
	@Column(name = "employee_name")
	private String employeeName;

	// @NotNull(message = "Grampanchyat Name cannot be null.")
	// @NotBlank(message = "Grampanchyat Name cannot be empty.")
	// @Pattern(regexp = "^[^@]*$", message = "Grampanchyat Name cannot contain the
	// @ character.")
	@Column(name = "grampanchyat_name")
	private String grampanchyatName;

	// @NotNull(message = "Year cannot be null.")
	// @NotBlank(message = "Year cannot be empty.")
	// @Pattern(regexp = "^[0-9]+$", message = "Field must contain only digits.")
	// @Column(name = "year")
	// private String Year;

	@NotNull(message = "Shear cannot be null.")
	@NotBlank(message = "Shear cannot be empty.")
	// @Pattern(regexp = "^[\u0900-\u097F]+$", message = "Field must contain only
	// digits.")
	@Column(name = "Shera")
	private String shera;

	public String getShera() {
		return shera;
	}

	public void setShera(String shera) {
		this.shera = shera;
	}

	// public String getYear() {
	// return Year;
	// }
	//
	// public void setYear(String year) {
	// Year = year;
	// }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMahina() {
		return mahina;
	}

	public void setMahina(String mahina) {
		this.mahina = mahina;
	}

	public String getPraarabhitShillak() {
		return praarabhitShillak;
	}

	public void setPraarabhitShillak(String praarabhitShillak) {
		this.praarabhitShillak = praarabhitShillak;
	}

	public String getRakamJamaKileyachaMahina() {
		return rakamJamaKileyachaMahina;
	}

	public void setRakamJamaKileyachaMahina(String rakamJamaKileyachaMahina) {
		this.rakamJamaKileyachaMahina = rakamJamaKileyachaMahina;
	}

	public String getMahinaAakhrichiShillakSachivakdila() {
		return mahinaAakhrichiShillakSachivakdila;
	}

	public void setMahinaAakhrichiShillakSachivakdila(String mahinaAakhrichiShillakSachivakdila) {
		this.mahinaAakhrichiShillakSachivakdila = mahinaAakhrichiShillakSachivakdila;
	}

	public String getMahinaAakhrichiShillakBanketila() {
		return mahinaAakhrichiShillakBanketila;
	}

	public void setMahinaAakhrichiShillakBanketila(String mahinaAakhrichiShillakBanketila) {
		this.mahinaAakhrichiShillakBanketila = mahinaAakhrichiShillakBanketila;
	}

	public String getMahinaAakhrichiShillakPostateil() {
		return mahinaAakhrichiShillakPostateil;
	}

	public void setMahinaAakhrichiShillakPostateil(String mahinaAakhrichiShillakPostateil) {
		this.mahinaAakhrichiShillakPostateil = mahinaAakhrichiShillakPostateil;
	}

	public String getAlpabachatPramanapatrataGuntviloliRakam() {
		return alpabachatPramanapatrataGuntviloliRakam;
	}

	public void setAlpabachatPramanapatrataGuntviloliRakam(String alpabachatPramanapatrataGuntviloliRakam) {
		this.alpabachatPramanapatrataGuntviloliRakam = alpabachatPramanapatrataGuntviloliRakam;
	}

	public String getBanketaMudataThevitaGuntavililiRakam() {
		return banketaMudataThevitaGuntavililiRakam;
	}

	public void setBanketaMudataThevitaGuntavililiRakam(String banketaMudataThevitaGuntavililiRakam) {
		this.banketaMudataThevitaGuntavililiRakam = banketaMudataThevitaGuntavililiRakam;
	}

	public String getEkun() {
		return ekun;
	}

	public void setEkun(String ekun) {
		this.ekun = ekun;
	}

	// public String getShoraNiyamapeshaJasataRakam() {
	// return shoraNiyamapeshaJasataRakam;
	// }
	//
	// public void setShoraNiyamapeshaJasataRakam(String
	// shoraNiyamapeshaJasataRakam) {
	// this.shoraNiyamapeshaJasataRakam = shoraNiyamapeshaJasataRakam;
	// }

	

	public LocalDateTime getCreateDate() {
		return createDate;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public String getGrampanchyatId() {
		return grampanchyatId;
	}

	public void setCreateDate(LocalDateTime createDate) {
		this.createDate = createDate;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getGrampanchyatName() {
		return grampanchyatName;
	}

	public void setGrampanchyatName(String grampanchyatName) {
		this.grampanchyatName = grampanchyatName;
	}

	public String getDinank() {
		return dinank;
	}

	public void setDinank(String dinank) {
		this.dinank = dinank;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public void setGrampanchyatId(String grampanchyatId) {
		this.grampanchyatId = grampanchyatId;
	}

}
