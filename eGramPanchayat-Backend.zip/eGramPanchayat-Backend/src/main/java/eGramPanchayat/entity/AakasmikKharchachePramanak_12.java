package eGramPanchayat.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "12_aakasmik_kharchache_pramanak")
public class AakasmikKharchachePramanak_12 {
    
    // Common Fields
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "employee_id")
    private String employeeId;

    @Column(name = "employee_name")
    private String employeeName;

    @Column(name = "grampanchayat_id")
    private String grampanchayatId;

    @Column(name = "grampanchayat_name")
    private String grampanchayatName;

    @CreationTimestamp
    @Column(name = "created_date", updatable = false)
    private LocalDateTime createdDate;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;
    
    @Column(name = "year")
    private String year;
    
    @Column(name = "remark")
    private String remark;

    // New Fields
    @Column(name = "deyak_kramank")
    private String deyakKramank;

    @Column(name = "pavti_lihun_denar")
    private String pavtiLihunDenar;

    @Column(name = "kamache_kharedi_pavti_pramane_in_numbers")
    private String kamacheKharediPavtiPramaneInNumbers;

    @Column(name = "kamache_kharedi_pavti_pramane_akshari")
    private String kamacheKharediPavtiPramaneAkshari;

    @Column(name = "matra_rokh_check_no")
    private String matraRokhCheckNo;

    @Column(name = "nag_kinwa_wajan")
    private String nagKinwaWajan;

    @Column(name = "dar")
    private String dar;

    @Column(name = "unit")
    private String unit;

    @Column(name = "rakkam_rupaye")
    private String rakkamRupaye;

    @Column(name = "watnichi_rakkam_rupaye")
    private String watnichiRakkamRupaye;

    @Column(name = "purvicha_kharch_rupaye")
    private String purvichaKharchRupaye;

    @Column(name = "dewakat_darshawilela_kharch")
    private String dewakatDarshawilelaKharch;

    @Column(name = "ekun_berij_2_plus_2_rupaye")
    private String ekunBerij2Plus2Rupaye;

    @Column(name = "uplabdh_shillak")
    private String uplabdhShillak;

    @Column(name = "tharav_kramank")
    private String tharavKramank;

    @Column(name = "dewakamadhe_darshavileli_rakkam")
    private String dewakamadheDarshavileliRakkam;

    @Column(name = "magani_purviche_purn_rupaye_in_numbers")
    private String maganiPurvichePurnRupayeInNumbers;

    @Column(name = "magani_purviche_purn_rupaye_akshari")
    private String maganiPurvichePurnRupayeAkshari;

    @Column(name = "pramanak_kramank")
    private String pramanakKramank;

    @Column(name = "rojwahitil_prusth_kramank")
    private String rojwahitilPrusthKramank;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getGrampanchayatId() {
		return grampanchayatId;
	}

	public void setGrampanchayatId(String grampanchayatId) {
		this.grampanchayatId = grampanchayatId;
	}

	public String getGrampanchayatName() {
		return grampanchayatName;
	}

	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getDeyakKramank() {
		return deyakKramank;
	}

	public void setDeyakKramank(String deyakKramank) {
		this.deyakKramank = deyakKramank;
	}

	public String getPavtiLihunDenar() {
		return pavtiLihunDenar;
	}

	public void setPavtiLihunDenar(String pavtiLihunDenar) {
		this.pavtiLihunDenar = pavtiLihunDenar;
	}

	public String getKamacheKharediPavtiPramaneInNumbers() {
		return kamacheKharediPavtiPramaneInNumbers;
	}

	public void setKamacheKharediPavtiPramaneInNumbers(String kamacheKharediPavtiPramaneInNumbers) {
		this.kamacheKharediPavtiPramaneInNumbers = kamacheKharediPavtiPramaneInNumbers;
	}

	public String getKamacheKharediPavtiPramaneAkshari() {
		return kamacheKharediPavtiPramaneAkshari;
	}

	public void setKamacheKharediPavtiPramaneAkshari(String kamacheKharediPavtiPramaneAkshari) {
		this.kamacheKharediPavtiPramaneAkshari = kamacheKharediPavtiPramaneAkshari;
	}

	public String getMatraRokhCheckNo() {
		return matraRokhCheckNo;
	}

	public void setMatraRokhCheckNo(String matraRokhCheckNo) {
		this.matraRokhCheckNo = matraRokhCheckNo;
	}

	public String getNagKinwaWajan() {
		return nagKinwaWajan;
	}

	public void setNagKinwaWajan(String nagKinwaWajan) {
		this.nagKinwaWajan = nagKinwaWajan;
	}

	public String getDar() {
		return dar;
	}

	public void setDar(String dar) {
		this.dar = dar;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getRakkamRupaye() {
		return rakkamRupaye;
	}

	public void setRakkamRupaye(String rakkamRupaye) {
		this.rakkamRupaye = rakkamRupaye;
	}

	public String getWatnichiRakkamRupaye() {
		return watnichiRakkamRupaye;
	}

	public void setWatnichiRakkamRupaye(String watnichiRakkamRupaye) {
		this.watnichiRakkamRupaye = watnichiRakkamRupaye;
	}

	public String getPurvichaKharchRupaye() {
		return purvichaKharchRupaye;
	}

	public void setPurvichaKharchRupaye(String purvichaKharchRupaye) {
		this.purvichaKharchRupaye = purvichaKharchRupaye;
	}

	public String getDewakatDarshawilelaKharch() {
		return dewakatDarshawilelaKharch;
	}

	public void setDewakatDarshawilelaKharch(String dewakatDarshawilelaKharch) {
		this.dewakatDarshawilelaKharch = dewakatDarshawilelaKharch;
	}

	public String getEkunBerij2Plus2Rupaye() {
		return ekunBerij2Plus2Rupaye;
	}

	public void setEkunBerij2Plus2Rupaye(String ekunBerij2Plus2Rupaye) {
		this.ekunBerij2Plus2Rupaye = ekunBerij2Plus2Rupaye;
	}

	public String getUplabdhShillak() {
		return uplabdhShillak;
	}

	public void setUplabdhShillak(String uplabdhShillak) {
		this.uplabdhShillak = uplabdhShillak;
	}

	public String getTharavKramank() {
		return tharavKramank;
	}

	public void setTharavKramank(String tharavKramank) {
		this.tharavKramank = tharavKramank;
	}

	public String getDewakamadheDarshavileliRakkam() {
		return dewakamadheDarshavileliRakkam;
	}

	public void setDewakamadheDarshavileliRakkam(String dewakamadheDarshavileliRakkam) {
		this.dewakamadheDarshavileliRakkam = dewakamadheDarshavileliRakkam;
	}

	public String getMaganiPurvichePurnRupayeInNumbers() {
		return maganiPurvichePurnRupayeInNumbers;
	}

	public void setMaganiPurvichePurnRupayeInNumbers(String maganiPurvichePurnRupayeInNumbers) {
		this.maganiPurvichePurnRupayeInNumbers = maganiPurvichePurnRupayeInNumbers;
	}

	public String getMaganiPurvichePurnRupayeAkshari() {
		return maganiPurvichePurnRupayeAkshari;
	}

	public void setMaganiPurvichePurnRupayeAkshari(String maganiPurvichePurnRupayeAkshari) {
		this.maganiPurvichePurnRupayeAkshari = maganiPurvichePurnRupayeAkshari;
	}

	public String getPramanakKramank() {
		return pramanakKramank;
	}

	public void setPramanakKramank(String pramanakKramank) {
		this.pramanakKramank = pramanakKramank;
	}

	public String getRojwahitilPrusthKramank() {
		return rojwahitilPrusthKramank;
	}

	public void setRojwahitilPrusthKramank(String rojwahitilPrusthKramank) {
		this.rojwahitilPrusthKramank = rojwahitilPrusthKramank;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}
}
