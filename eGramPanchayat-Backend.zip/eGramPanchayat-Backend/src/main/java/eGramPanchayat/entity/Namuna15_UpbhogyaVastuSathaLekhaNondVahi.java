package eGramPanchayat.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name = "15_UpbhogyaVastuSathaLekhaNondVahi")
public class Namuna15_UpbhogyaVastuSathaLekhaNondVahi {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "Employee_id")
    private String employeeId;

    @Column(name = "Employee_Name")
    private String employeeName;

    @Column(name = "GramPanchayat_id")
    private String grampanchayatId;

    @Column(name = "GramPanchayat_Name")
    private String grampanchayatName;

    @Column(name = "Shera")
    private String shera;

    @Column(name = "tarikh")
    private String tarikh;

    @Column(name = "aarambhichi_Shillak")
    private String aarambhichiShillak;

    @Column(name = "milaleli_Sankhya_Kinva_Pariman")
    private String milaleliSankhyaKinvaPariman;
    
    @Column(name = "ekun")
    private String ekun;
    
    @Column(name = "konas_Dile")
    private String konasDile;
    
    @Column(name = "kontya_Karnasathi_Dile")
    private String kontyaKarnasathiDile;
    
    @Column(name = "dilelya_Jinsachi_Sankhya_Kinva_Pariman")
    private String dilelyaJinsachiSankhyaKinvaPariman;
    
    @Column(name = "shillak")
    private String shillak;
    
    @Column(name = "vastu_Denarya_Adhikaryache_Nav")
    private String vastuDenaryaAdhikaryacheNav;
    
    @Column(name = "Dinank")
    private String date;

	@Column(name = "year")
    private String year;

    @Column(name = "Created_Date", updatable = false)
    @CreationTimestamp
    private LocalDateTime createdDate;

    @Column(name = "UpdatedDate")
    @UpdateTimestamp
    private LocalDateTime updatedDate;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getGrampanchayatId() {
		return grampanchayatId;
	}

	public void setGrampanchayatId(String grampanchayatId) {
		this.grampanchayatId = grampanchayatId;
	}

	public String getGrampanchayatName() {
		return grampanchayatName;
	}

	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}

	public String getShera() {
		return shera;
	}

	public void setShera(String shera) {
		this.shera = shera;
	}

	public String getTarikh() {
		return tarikh;
	}

	public void setTarikh(String tarikh) {
		this.tarikh = tarikh;
	}

	public String getAarambhichiShillak() {
		return aarambhichiShillak;
	}

	public void setAarambhichiShillak(String aarambhichiShillak) {
		this.aarambhichiShillak = aarambhichiShillak;
	}

	public String getMilaleliSankhyaKinvaPariman() {
		return milaleliSankhyaKinvaPariman;
	}

	public void setMilaleliSankhyaKinvaPariman(String milaleliSankhyaKinvaPariman) {
		this.milaleliSankhyaKinvaPariman = milaleliSankhyaKinvaPariman;
	}

	public String getEkun() {
		return ekun;
	}

	public void setEkun(String ekun) {
		this.ekun = ekun;
	}

	public String getKonasDile() {
		return konasDile;
	}

	public void setKonasDile(String konasDile) {
		this.konasDile = konasDile;
	}

	public String getKontyaKarnasathiDile() {
		return kontyaKarnasathiDile;
	}

	public void setKontyaKarnasathiDile(String kontyaKarnasathiDile) {
		this.kontyaKarnasathiDile = kontyaKarnasathiDile;
	}

	public String getDilelyaJinsachiSankhyaKinvaPariman() {
		return dilelyaJinsachiSankhyaKinvaPariman;
	}

	public void setDilelyaJinsachiSankhyaKinvaPariman(String dilelyaJinsachiSankhyaKinvaPariman) {
		this.dilelyaJinsachiSankhyaKinvaPariman = dilelyaJinsachiSankhyaKinvaPariman;
	}

	public String getShillak() {
		return shillak;
	}

	public void setShillak(String shillak) {
		this.shillak = shillak;
	}

	public String getVastuDenaryaAdhikaryacheNav() {
		return vastuDenaryaAdhikaryacheNav;
	}

	public void setVastuDenaryaAdhikaryacheNav(String vastuDenaryaAdhikaryacheNav) {
		this.vastuDenaryaAdhikaryacheNav = vastuDenaryaAdhikaryacheNav;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}
	
}