package eGramPanchayat.entity;



import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

@Entity
@Table(name = "17_agrim_dilelya_rakmanchi_nondvahi")
public class Namuna17AgrimDilelyaRakamanchiNondvahi {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "created_date", nullable = false, updatable = false)
    private LocalDateTime createdDate;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "employee_id")
    private Long employeeId;

    @Column(name = "employee_name")
    private String employeeName;

    @Column(name = "grampanchayat_id")
    private Long grampanchayatId;

    @Column(name = "grampanchayat_name")
    private String grampanchayatName;

    @Column(name = "mahina_va_tarikh")
    private String mahinaVaTarikh;

    @Column(name = "pakshakarache_nav")
    private String pakshakaracheNav;

    @Column(name = "agrim_rakmencha_tapshil")
    private String agrimRakmenchaTapshil;

    @Column(name = "pramanak_kinva_pavati_kramank")
    private String pramanakKinvaPavatiKramank;

    @Column(name = "rakkam")
    private String rakkam;

    @Column(name = "masik_ekun")
    private String masikEkun;

    @Column(name = "rokh_paratfed_april")
    private String rokhParatfedApril;

    @Column(name = "rokh_paratfed_may")
    private String rokhParatfedMay;

    @Column(name = "rokh_paratfed_june")
    private String rokhParatfedJune;

    @Column(name = "rokh_paratfed_july")
    private String rokhParatfedJuly;

    @Column(name = "rokh_paratfed_august")
    private String rokhParatfedAugust;

    @Column(name = "rokh_paratfed_september")
    private String rokhParatfedSeptember;

    @Column(name = "rokh_paratfed_october")
    private String rokhParatfedOctober;

    @Column(name = "rokh_paratfed_november")
    private String rokhParatfedNovember;

    @Column(name = "rokh_paratfed_december")
    private String rokhParatfedDecember;

    @Column(name = "rokh_paratfed_january")
    private String rokhParatfedJanuary;

    @Column(name = "rokh_paratfed_february")
    private String rokhParatfedFebruary;

    @Column(name = "rokh_paratfed_march")
    private String rokhParatfedMarch;

    @Column(name = "ekun_paratfed")
    private String ekunParatfed;

    @Column(name = "parat_fedichi_tarikh_kinva_samayojan_pramanakacha_kramank")
    private String paratFedichiTarikhKinvaSamayojanPramanakachaKramank;

    @Column(name = "varshacha_akherchi_shillak")
    private String varshachaAkherchiShillak;
    
    @Column(name = "year")
    private String year;

    @Column(name = "shera")
    private String shera;
    
    // Auto-generate dates
    @PrePersist
    protected void onCreate() {
        this.createdDate = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedDate = LocalDateTime.now();
    }


	public Long getId() {
		return id;
	}
	

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}


	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}


	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}


	public void setId(Long id) {
		this.id = id;
	}

	public Long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Long getGrampanchayatId() {
		return grampanchayatId;
	}

	public void setGrampanchayatId(Long grampanchayatId) {
		this.grampanchayatId = grampanchayatId;
	}

	public String getGrampanchayatName() {
		return grampanchayatName;
	}

	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}

	public String getMahinaVaTarikh() {
		return mahinaVaTarikh;
	}

	public void setMahinaVaTarikh(String mahinaVaTarikh) {
		this.mahinaVaTarikh = mahinaVaTarikh;
	}

	public String getPakshakaracheNav() {
		return pakshakaracheNav;
	}

	public void setPakshakaracheNav(String pakshakaracheNav) {
		this.pakshakaracheNav = pakshakaracheNav;
	}

	public String getAgrimRakmenchaTapshil() {
		return agrimRakmenchaTapshil;
	}

	public void setAgrimRakmenchaTapshil(String agrimRakmenchaTapshil) {
		this.agrimRakmenchaTapshil = agrimRakmenchaTapshil;
	}

	public String getPramanakKinvaPavatiKramank() {
		return pramanakKinvaPavatiKramank;
	}

	public void setPramanakKinvaPavatiKramank(String pramanakKinvaPavatiKramank) {
		this.pramanakKinvaPavatiKramank = pramanakKinvaPavatiKramank;
	}

	public String getRakkam() {
		return rakkam;
	}

	public void setRakkam(String rakkam) {
		this.rakkam = rakkam;
	}

	public String getMasikEkun() {
		return masikEkun;
	}

	public void setMasikEkun(String masikEkun) {
		this.masikEkun = masikEkun;
	}

	public String getRokhParatfedApril() {
		return rokhParatfedApril;
	}

	public void setRokhParatfedApril(String rokhParatfedApril) {
		this.rokhParatfedApril = rokhParatfedApril;
	}

	public String getRokhParatfedMay() {
		return rokhParatfedMay;
	}

	public void setRokhParatfedMay(String rokhParatfedMay) {
		this.rokhParatfedMay = rokhParatfedMay;
	}

	public String getRokhParatfedJune() {
		return rokhParatfedJune;
	}

	public void setRokhParatfedJune(String rokhParatfedJune) {
		this.rokhParatfedJune = rokhParatfedJune;
	}

	public String getRokhParatfedJuly() {
		return rokhParatfedJuly;
	}

	public void setRokhParatfedJuly(String rokhParatfedJuly) {
		this.rokhParatfedJuly = rokhParatfedJuly;
	}

	public String getRokhParatfedAugust() {
		return rokhParatfedAugust;
	}

	public void setRokhParatfedAugust(String rokhParatfedAugust) {
		this.rokhParatfedAugust = rokhParatfedAugust;
	}

	public String getRokhParatfedSeptember() {
		return rokhParatfedSeptember;
	}

	public void setRokhParatfedSeptember(String rokhParatfedSeptember) {
		this.rokhParatfedSeptember = rokhParatfedSeptember;
	}

	public String getRokhParatfedOctober() {
		return rokhParatfedOctober;
	}

	public void setRokhParatfedOctober(String rokhParatfedOctober) {
		this.rokhParatfedOctober = rokhParatfedOctober;
	}

	public String getRokhParatfedNovember() {
		return rokhParatfedNovember;
	}

	public void setRokhParatfedNovember(String rokhParatfedNovember) {
		this.rokhParatfedNovember = rokhParatfedNovember;
	}

	public String getRokhParatfedDecember() {
		return rokhParatfedDecember;
	}

	public void setRokhParatfedDecember(String rokhParatfedDecember) {
		this.rokhParatfedDecember = rokhParatfedDecember;
	}

	public String getRokhParatfedJanuary() {
		return rokhParatfedJanuary;
	}

	public void setRokhParatfedJanuary(String rokhParatfedJanuary) {
		this.rokhParatfedJanuary = rokhParatfedJanuary;
	}

	public String getRokhParatfedFebruary() {
		return rokhParatfedFebruary;
	}

	public void setRokhParatfedFebruary(String rokhParatfedFebruary) {
		this.rokhParatfedFebruary = rokhParatfedFebruary;
	}

	public String getRokhParatfedMarch() {
		return rokhParatfedMarch;
	}

	public void setRokhParatfedMarch(String rokhParatfedMarch) {
		this.rokhParatfedMarch = rokhParatfedMarch;
	}

	public String getEkunParatfed() {
		return ekunParatfed;
	}

	public void setEkunParatfed(String ekunParatfed) {
		this.ekunParatfed = ekunParatfed;
	}

	public String getParatFedichiTarikhKinvaSamayojanPramanakachaKramank() {
		return paratFedichiTarikhKinvaSamayojanPramanakachaKramank;
	}

	public void setParatFedichiTarikhKinvaSamayojanPramanakachaKramank(
			String paratFedichiTarikhKinvaSamayojanPramanakachaKramank) {
		this.paratFedichiTarikhKinvaSamayojanPramanakachaKramank = paratFedichiTarikhKinvaSamayojanPramanakachaKramank;
	}

	public String getVarshachaAkherchiShillak() {
		return varshachaAkherchiShillak;
	}

	public void setVarshachaAkherchiShillak(String varshachaAkherchiShillak) {
		this.varshachaAkherchiShillak = varshachaAkherchiShillak;
	}

	public String getShera() {
		return shera;
	}

	public void setShera(String shera) {
		this.shera = shera;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

    
}
