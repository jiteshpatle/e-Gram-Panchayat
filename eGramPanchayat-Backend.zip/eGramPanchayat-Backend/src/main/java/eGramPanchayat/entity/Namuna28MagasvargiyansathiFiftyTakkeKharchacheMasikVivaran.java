package eGramPanchayat.entity;

import java.time.LocalDateTime;
import jakarta.validation.constraints.NotNull;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "28_magasvargiyansathi_fifty_takke_che_masik_vivaran")
public class Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaran {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "employee_id")

	// @Pattern(regexp = "^[a-zA-Z0-9]+$",message = "Employee ID must contains only
	// characters or numbers.")
	private String employeeId;

	@Column(name = "employee_name")
	// @Pattern(regexp = "^[a-zA-Z0-9\\s]*$",message = "Employee Name must contains
	// only characters.")
	private String employeeName;

	@Column(name = "gram_panchayat_id")
	// @Pattern(regexp = "^[a-zA-Z0-9]*$",message = "Grampanchayat id must contains
	// only characters or numbers.")
	private String gramPanchayatId;

	@Column(name = "gram_panchayat_name")
	// @Pattern(regexp = "^[a-zA-Z\\s]+$",message = "Grampanchayat name must
	// contains only characters.")
	private String gramPanchayatName;

	@Column(name = "year")
	@NotNull(message = "Year cannot be null.")
	private String year;

	@Column(name = "san_madhe_magasvargiyansathi_keleli_Tartud")
	@NotNull(message = "San_madhe_magasvargiyansathi_keleli_Tartud cannot be null.")
	// @Pattern(regexp ="^[a-zA-Z0-9\s]*$",message = "San Madhe magasvargiyansathi
	// Keleli Tartud must contains character or numbers")
	private String sanMadhemagasvargiyansathiKeleliTartud;

	@Column(name = "chalu_mahinyat_prapta_jhalele_utpanna")
	@NotNull(message = "chalu_mahinyat_prapta_jhalele_utpanna cannot be null.")
	/// @Pattern(regexp = "^[0-9]+$",message = "chalu Mahinyat Prapta Jhalele
	/// Utpanna must contains only numbers")
	private String chaluMahinyatPraptaJhaleleUtpanna;

	@Column(name = "fifty_takke_kharcha_karychi_rakkam")
	@NotNull(message = "fifty_takke_kharcha_karychi_rakkam cannot be null.")
	// @Pattern(regexp = "^[0-9%]+$",message = "fifty Takke Kharcha Karychi Rakkam
	// must contains only numbers")
	private String fiftyTakkeKharchaKarychiRakkam;

	@Column(name = "kharchachya_babi_yojanavar")
	@NotNull(message = "kharchachya_babi_yojanavar cannot be null.")
	// @Pattern(regexp = "^[a-zA-Z\s]+$",message = "kharchachya Babi Yojanavar must
	// contains only character")
	private String kharchachyaBabiYojanavar;

	@Column(name = "magil_mahinyat_jhalela_kharcha")
	@NotNull(message = "magil_mahinyat_jhalela_kharcha cannot be null.")
	// @Pattern(regexp = "^[0-9]+$",message = "Magil Mahinayat Jhalela Kharcha must
	// contains only numbers")
	private String magilMahinayatJhalelaKharcha;

	@Column(name = "chalu_mahinyat_jhalela_kharcha")
	@NotNull(message = "chalu_mahinyat_jhalela_kharcha cannot be null.")
	// @Pattern(regexp = "^[0-9]+$",message = "Chalu Mahinayat Jhalela Kharcha must
	// contains only numbers")
	private String chaluMahinyatJhalelaKharcha;

	@Column(name = "ekun_kharcha")
	@NotNull(message = "ekun_kharcha cannot be null.")
	// @Pattern(regexp = "^[0-9]+$",message = "ekun Kharch must contains only
	// numbers")
	private String ekunKharch;

	@Column(name = "kharchachi_takkevari")
	@NotNull(message = "kharchachi_takkevari cannot be null.")
	// @Pattern(regexp = "^[a-zA-Z0-9%]+$",message = "Kharcha chi Takkevari must
	// contains characters or numbers")
	private String kharchachiTakkevari;

	@Column(name = "shera")
	@NotNull(message = " Shera cannot be null.")
	// @Pattern(regexp = "^[a-zA-Z0-9]+$",message = "Shera must contains characters
	// or numbers")
	private String shera;

	@Column(name = "dinank")
	private String dinank;

	@Column(name = "san")
	@NotNull(message = "San cannot be null.")
	private String san;

	@Column(name = "month")
	private String month;

	@Column(name = "created_date")
	@CreationTimestamp
	private LocalDateTime createdDate;

	@Column(name = "updated_date")
	@UpdateTimestamp
	private LocalDateTime updatedDate;

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getGramPanchayatId() {
		return gramPanchayatId;
	}

	public void setGramPanchayatId(String gramPanchayatId) {
		this.gramPanchayatId = gramPanchayatId;
	}

	public String getGramPanchayatName() {
		return gramPanchayatName;
	}

	public void setGramPanchayatName(String gramPanchayatName) {
		this.gramPanchayatName = gramPanchayatName;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getSanMadhemagasvargiyansathiKeleliTartud() {
		return sanMadhemagasvargiyansathiKeleliTartud;
	}

	public void setSanMadhemagasvargiyansathiKeleliTartud(String sanMadhemagasvargiyansathiKeleliTartud) {
		this.sanMadhemagasvargiyansathiKeleliTartud = sanMadhemagasvargiyansathiKeleliTartud;
	}

	public String getChaluMahinyatPraptaJhaleleUtpanna() {
		return chaluMahinyatPraptaJhaleleUtpanna;
	}

	public void setChaluMahinyatPraptaJhaleleUtpanna(String chaluMahinyatPraptaJhaleleUtpanna) {
		this.chaluMahinyatPraptaJhaleleUtpanna = chaluMahinyatPraptaJhaleleUtpanna;
	}

	public String getFiftyTakkeKharchaKarychiRakkam() {
		return fiftyTakkeKharchaKarychiRakkam;
	}

	public void setFiftyTakkeKharchaKarychiRakkam(String fiftyTakkeKharchaKarychiRakkam) {
		this.fiftyTakkeKharchaKarychiRakkam = fiftyTakkeKharchaKarychiRakkam;
	}

	public String getKharchachyaBabiYojanavar() {
		return kharchachyaBabiYojanavar;
	}

	public void setKharchachyaBabiYojanavar(String kharchachyaBabiYojanavar) {
		this.kharchachyaBabiYojanavar = kharchachyaBabiYojanavar;
	}

	public String getMagilMahinayatJhalelaKharcha() {
		return magilMahinayatJhalelaKharcha;
	}

	public void setMagilMahinayatJhalelaKharcha(String magilMahinayatJhalelaKharcha) {
		this.magilMahinayatJhalelaKharcha = magilMahinayatJhalelaKharcha;
	}

	public String getChaluMahinyatJhalelaKharcha() {
		return chaluMahinyatJhalelaKharcha;
	}

	public void setChaluMahinyatJhalelaKharcha(String chaluMahinyatJhalelaKharcha) {
		this.chaluMahinyatJhalelaKharcha = chaluMahinyatJhalelaKharcha;
	}

	public String getEkunKharch() {
		return ekunKharch;
	}

	public void setEkunKharch(String ekunKharch) {
		this.ekunKharch = ekunKharch;
	}

	public String getKharchachiTakkevari() {
		return kharchachiTakkevari;
	}

	public void setKharchachiTakkevari(String kharchachiTakkevari) {
		this.kharchachiTakkevari = kharchachiTakkevari;
	}

	public String getShera() {
		return shera;
	}

	public void setShera(String shera) {
		this.shera = shera;
	}

	public String getSan() {
		return san;
	}

	public void setSan(String san) {
		this.san = san;
	}

	public String getDinank() {
		return dinank;
	}

	public void setDinank(String dinank) {
		this.dinank = dinank;
	}

	
}
