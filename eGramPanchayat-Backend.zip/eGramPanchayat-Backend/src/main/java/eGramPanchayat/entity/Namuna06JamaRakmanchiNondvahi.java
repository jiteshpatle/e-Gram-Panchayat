package eGramPanchayat.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

@Entity
@Table(name = "06_Jama_Rakmanchi_Nondvahi")
public class Namuna06JamaRakmanchiNondvahi {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "employee_id")
    private Long employeeId;

    @Column(name = "employee_name")
    private String employeeName;

    @Column(name = "grampanchayat_id")
    private Long grampanchayatId;

    @Column(name = "grampanchayat_name")
    private String grampanchayatName;

    @Column(name = "lekha_shirsh")
    private String lekhaShirsh;

    @Column(name = "shera")
    private String shera;

    @Column(name = "arthsankalpiya_anudan")
    private String arthsankalpiyaAnudan;

    @Column(name = "mahinya_baddalchi_ekun_rakkam")
    private String mahinyaBaddalchiEkunRakkam;

    @Column(name = "maghil_mahinyacha_akherparyantchi_rakkam")
    private String maghilMahinyachaAkherparyantchiRakkam;

    @Column(name = "maghe_pasun_pudhe_chalu_ekun_rakkam")
    private String maghePasunPudheChaluEkunRakkam;

    @Column(name = "day")
    private String day;  // New field for day

    @Column(name = "value")
    private String value;  // New field for value
    
    @Column(name = "year")
    private String year;  // New field for value
    
    @Column(name = "month")
    private String month;  // New field for value

    // Auto-generate dates
    @PrePersist
    protected void onCreate() {
        this.createdDate = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedDate = LocalDateTime.now();
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getShera() {
        return shera;
    }

    public void setShera(String shera) {
        this.shera = shera;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getLekhaShirsh() {
        return lekhaShirsh;
    }

    public void setLekhaShirsh(String lekhaShirsh) {
        this.lekhaShirsh = lekhaShirsh;
    }

    public String getArthsankalpiyaAnudan() {
        return arthsankalpiyaAnudan;
    }

    public void setArthsankalpiyaAnudan(String arthsankalpiyaAnudan) {
        this.arthsankalpiyaAnudan = arthsankalpiyaAnudan;
    }

    public String getMahinyaBaddalchiEkunRakkam() {
        return mahinyaBaddalchiEkunRakkam;
    }

    public void setMahinyaBaddalchiEkunRakkam(String mahinyaBaddalchiEkunRakkam) {
        this.mahinyaBaddalchiEkunRakkam = mahinyaBaddalchiEkunRakkam;
    }

    public String getMaghilMahinyachaAkherparyantchiRakkam() {
        return maghilMahinyachaAkherparyantchiRakkam;
    }

    public void setMaghilMahinyachaAkherparyantchiRakkam(String maghilMahinyachaAkherparyantchiRakkam) {
        this.maghilMahinyachaAkherparyantchiRakkam = maghilMahinyachaAkherparyantchiRakkam;
    }

    public String getMaghePasunPudheChaluEkunRakkam() {
        return maghePasunPudheChaluEkunRakkam;
    }

    public void setMaghePasunPudheChaluEkunRakkam(String maghePasunPudheChaluEkunRakkam) {
        this.maghePasunPudheChaluEkunRakkam = maghePasunPudheChaluEkunRakkam;
    }

    public Long getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Long employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public Long getGrampanchayatId() {
        return grampanchayatId;
    }

    public void setGrampanchayatId(Long grampanchayatId) {
        this.grampanchayatId = grampanchayatId;
    }

    public String getGrampanchayatName() {
        return grampanchayatName;
    }

    public void setGrampanchayatName(String grampanchayatName) {
        this.grampanchayatName = grampanchayatName;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}
    
}
