package eGramPanchayat.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Embeddable;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "04_matte_va_dayitwe")
public class MatteVaDayitwe_04 {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Embedded
    private CommonFields commonFields;

    @Embedded
    private MatteFields matteFields;

    @Embedded
    private DayitweFields dayitweFields;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public CommonFields getCommonFields() {
        return commonFields;
    }

    public void setCommonFields(CommonFields commonFields) {
        this.commonFields = commonFields;
    }

    public MatteFields getMatteFields() {
        return matteFields;
    }

    public void setMatteFields(MatteFields matteFields) {
        this.matteFields = matteFields;
    }

    public DayitweFields getDayitweFields() {
        return dayitweFields;
    }

    public void setDayitweFields(DayitweFields dayitweFields) {
        this.dayitweFields = dayitweFields;
    }

    // CommonFields Entity
    @Embeddable
    public static class CommonFields {
        private String employeeId;
        private String employeeName;
        private String grampanchayatId;
        private String grampanchayatName;
        private LocalDateTime createdDate;
        private LocalDateTime updatedDate;
        private String remark;
        private String year;

        // Getters and Setters
        public String getEmployeeId() {
            return employeeId;
        }

        public void setEmployeeId(String employeeId) {
            this.employeeId = employeeId;
        }

        public String getEmployeeName() {
            return employeeName;
        }

        public void setEmployeeName(String employeeName) {
            this.employeeName = employeeName;
        }

        public String getGrampanchayatId() {
            return grampanchayatId;
        }

        public void setGrampanchayatId(String grampanchayatId) {
            this.grampanchayatId = grampanchayatId;
        }

        public String getGrampanchayatName() {
            return grampanchayatName;
        }

        public void setGrampanchayatName(String grampanchayatName) {
            this.grampanchayatName = grampanchayatName;
        }

        public LocalDateTime getCreatedDate() {
            return createdDate;
        }

        public void setCreatedDate(LocalDateTime createdDate) {
            this.createdDate = createdDate;
        }

        public LocalDateTime getUpdatedDate() {
            return updatedDate;
        }

        public void setUpdatedDate(LocalDateTime updatedDate) {
            this.updatedDate = updatedDate;
        }

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String getYear() {
            return year;
        }

        public void setYear(String year) {
            this.year = year;
        }
    }

    // MatteFields Entity
    @Embeddable
    public static class MatteFields {
        private String mattaId;
        private Double kar;
        private String emaratKar;
        private String jameenKar;
        private String aarogyaKar;
        private String diwabattiKar;
        private String paniPatti;
        private String karettar;
        private String dukanGaleBhade;
        private String nuksanAnudan;
        private String sahayyakAnudan;
        private Double shasanakadun;
        private String ekunNuksanAnudanSahayyakAnudan;
        private String etarJamaRakama;
        private String agrimWasuliBaki;
        private String panchayatichiSthavarMalmatta;
        private Double grampanchayatikadunYeneAslelyaThakitRakama;

        // Getters and Setters
        public String getMattaId() {
            return mattaId;
        }

        public void setMattaId(String mattaId) {
            this.mattaId = mattaId;
        }

        public Double getKar() {
            return kar;
        }

        public void setKar(Double kar) {
            this.kar = kar;
        }

        public String getEmaratKar() {
            return emaratKar;
        }

        public void setEmaratKar(String emaratKar) {
            this.emaratKar = emaratKar;
        }

        public String getJameenKar() {
            return jameenKar;
        }

        public void setJameenKar(String jameenKar) {
            this.jameenKar = jameenKar;
        }

        public String getAarogyaKar() {
            return aarogyaKar;
        }

        public void setAarogyaKar(String aarogyaKar) {
            this.aarogyaKar = aarogyaKar;
        }

        public String getDiwabattiKar() {
            return diwabattiKar;
        }

        public void setDiwabattiKar(String diwabattiKar) {
            this.diwabattiKar = diwabattiKar;
        }

        public String getPaniPatti() {
            return paniPatti;
        }

        public void setPaniPatti(String paniPatti) {
            this.paniPatti = paniPatti;
        }

        public String getKarettar() {
            return karettar;
        }

        public void setKarettar(String karettar) {
            this.karettar = karettar;
        }

        public String getDukanGaleBhade() {
            return dukanGaleBhade;
        }

        public void setDukanGaleBhade(String dukanGaleBhade) {
            this.dukanGaleBhade = dukanGaleBhade;
        }

        public String getNuksanAnudan() {
            return nuksanAnudan;
        }

        public void setNuksanAnudan(String nuksanAnudan) {
            this.nuksanAnudan = nuksanAnudan;
        }

        public String getSahayyakAnudan() {
            return sahayyakAnudan;
        }

        public void setSahayyakAnudan(String sahayyakAnudan) {
            this.sahayyakAnudan = sahayyakAnudan;
        }

        public Double getShasanakadun() {
            return shasanakadun;
        }

        public void setShasanakadun(Double shasanakadun) {
            this.shasanakadun = shasanakadun;
        }

        public String getEkunNuksanAnudanSahayyakAnudan() {
            return ekunNuksanAnudanSahayyakAnudan;
        }

        public void setEkunNuksanAnudanSahayyakAnudan(String ekunNuksanAnudanSahayyakAnudan) {
            this.ekunNuksanAnudanSahayyakAnudan = ekunNuksanAnudanSahayyakAnudan;
        }

        public String getEtarJamaRakama() {
            return etarJamaRakama;
        }

        public void setEtarJamaRakama(String etarJamaRakama) {
            this.etarJamaRakama = etarJamaRakama;
        }

        public String getAgrimWasuliBaki() {
            return agrimWasuliBaki;
        }

        public void setAgrimWasuliBaki(String agrimWasuliBaki) {
            this.agrimWasuliBaki = agrimWasuliBaki;
        }

        public String getPanchayatichiSthavarMalmatta() {
            return panchayatichiSthavarMalmatta;
        }

        public void setPanchayatichiSthavarMalmatta(String panchayatichiSthavarMalmatta) {
            this.panchayatichiSthavarMalmatta = panchayatichiSthavarMalmatta;
        }

        public Double getGrampanchayatikadunYeneAslelyaThakitRakama() {
            return grampanchayatikadunYeneAslelyaThakitRakama;
        }

        public void setGrampanchayatikadunYeneAslelyaThakitRakama(Double grampanchayatikadunYeneAslelyaThakitRakama) {
            this.grampanchayatikadunYeneAslelyaThakitRakama = grampanchayatikadunYeneAslelyaThakitRakama;
        }
    }

    // DayitweFields Entity
    @Embeddable
    public static class DayitweFields {
        private String dayitweId;
        private String thakitDeyak;
        private String wetan;
        private String wetanWyatiriktaEtarAasthapana;
        private String sadhanSamagri;
        private String bandhkaam;
        private String etar;
        private String grampanchayatiKadunDeneAslelyaThakitRakma;
        private String karjHaftaWaKarjawarilWyajHafta;
        private String etarDeyaRakkam;
        private String theviPartachaBaki;
        private String samajKalyanBaki;
        private String mahilaWaBalkalyanAnushesh;

        // Getters and Setters
        
        
        public String getDayitweId() {
            return dayitweId;
        }

        public String getSamajKalyanBaki() {
			return samajKalyanBaki;
		}

		public void setSamajKalyanBaki(String samajKalyanBaki) {
			this.samajKalyanBaki = samajKalyanBaki;
		}

		public String getMahilaWaBalkalyanAnushesh() {
			return mahilaWaBalkalyanAnushesh;
		}

		public void setMahilaWaBalkalyanAnushesh(String mahilaWaBalkalyanAnushesh) {
			this.mahilaWaBalkalyanAnushesh = mahilaWaBalkalyanAnushesh;
		}

		public String getTheviPartachaBaki() {
			return theviPartachaBaki;
		}

		public void setTheviPartachaBaki(String theviPartachaBaki) {
			this.theviPartachaBaki = theviPartachaBaki;
		}

		public void setDayitweId(String dayitweId) {
            this.dayitweId = dayitweId;
        }

        public String getThakitDeyak() {
            return thakitDeyak;
        }

        public void setThakitDeyak(String thakitDeyak) {
            this.thakitDeyak = thakitDeyak;
        }

        public String getWetan() {
            return wetan;
        }

        public void setWetan(String wetan) {
            this.wetan = wetan;
        }

        public String getWetanWyatiriktaEtarAasthapana() {
            return wetanWyatiriktaEtarAasthapana;
        }

        public void setWetanWyatiriktaEtarAasthapana(String wetanWyatiriktaEtarAasthapana) {
            this.wetanWyatiriktaEtarAasthapana = wetanWyatiriktaEtarAasthapana;
        }

        public String getSadhanSamagri() {
            return sadhanSamagri;
        }

        public void setSadhanSamagri(String sadhanSamagri) {
            this.sadhanSamagri = sadhanSamagri;
        }

        public String getBandhkaam() {
            return bandhkaam;
        }

        public void setBandhkaam(String bandhkaam) {
            this.bandhkaam = bandhkaam;
        }

        public String getEtar() {
            return etar;
        }

        public void setEtar(String etar) {
            this.etar = etar;
        }

        public String getGrampanchayatiKadunDeneAslelyaThakitRakma() {
            return grampanchayatiKadunDeneAslelyaThakitRakma;
        }

        public void setGrampanchayatiKadunDeneAslelyaThakitRakma(String grampanchayatiKadunDeneAslelyaThakitRakma) {
            this.grampanchayatiKadunDeneAslelyaThakitRakma = grampanchayatiKadunDeneAslelyaThakitRakma;
        }

        public String getKarjHaftaWaKarjawarilWyajHafta() {
            return karjHaftaWaKarjawarilWyajHafta;
        }

        public void setKarjHaftaWaKarjawarilWyajHafta(String karjHaftaWaKarjawarilWyajHafta) {
            this.karjHaftaWaKarjawarilWyajHafta = karjHaftaWaKarjawarilWyajHafta;
        }

        public String getEtarDeyaRakkam() {
            return etarDeyaRakkam;
        }

        public void setEtarDeyaRakkam(String etarDeyaRakkam) {
            this.etarDeyaRakkam = etarDeyaRakkam;
        }
    }

	public void setUpdatedDate(Object object) {
		// TODO Auto-generated method stub
		
	}
}
