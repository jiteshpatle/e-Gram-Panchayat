package eGramPanchayat.entity;



import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import eGramPanchayat.service.impl.AttendanceConverter;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

@Entity
@Table(name = "19_kamavar_aslelya_vyaktincha_hajeripat")
public class Namuna19KamavarAslelyaVyaktinchaHajeripat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "remark")
    private String remark;

    @Column(name = "employee_id")
    private Long employeeId;

    @Column(name = "employee_name")
    private String employeeName;

    @Column(name = "grampanchayat_id")
    private Long grampanchayatId;

    @Column(name = "grampanchayat_name")
    private String grampanchayatName;

    @Column(name = "sampurna_naav")
    private String sampurnaNaav;

    @Column(name = "gaon")
    private String gaon;

    @Column(name = "hudda")
    private String hudda;

    @Column(name = "dar")
    private String dar;

    @Column(name = "ekun")
    private String ekun;

    @Column(name = "dileli_rakkam")
    private String dileliRakkam;

    @Column(name = "yene_asleli_shillak_rakkam")
    private String yeneAsleliShillakRakkam;

    @Column(name = "paise_denarya_adhikaryane_karavayachi_ta_nishaa")
    private String paiseDenaryaAdhikaryaneKaravayachiTaNishaA;

    @Convert(converter = AttendanceConverter.class)
    @Column(name = "attendance_data", columnDefinition = "TEXT")  // Store the JSON data in a text column
    private Map<String, String> attendanceData = new HashMap<>();
    
    @Column(name = "year")
    private String year;
    
    @PrePersist
    protected void onCreate() {
        this.createdDate = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedDate = LocalDateTime.now();
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Long getGrampanchayatId() {
		return grampanchayatId;
	}

	public void setGrampanchayatId(Long grampanchayatId) {
		this.grampanchayatId = grampanchayatId;
	}

	public String getGrampanchayatName() {
		return grampanchayatName;
	}

	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}

	public String getSampurnaNaav() {
		return sampurnaNaav;
	}

	public void setSampurnaNaav(String sampurnaNaav) {
		this.sampurnaNaav = sampurnaNaav;
	}

	public String getGaon() {
		return gaon;
	}

	public void setGaon(String gaon) {
		this.gaon = gaon;
	}

	public String getHudda() {
		return hudda;
	}

	public void setHudda(String hudda) {
		this.hudda = hudda;
	}

	public String getDar() {
		return dar;
	}

	public void setDar(String dar) {
		this.dar = dar;
	}

	public String getEkun() {
		return ekun;
	}

	public void setEkun(String ekun) {
		this.ekun = ekun;
	}

	public String getDileliRakkam() {
		return dileliRakkam;
	}

	public void setDileliRakkam(String dileliRakkam) {
		this.dileliRakkam = dileliRakkam;
	}

	public String getYeneAsleliShillakRakkam() {
		return yeneAsleliShillakRakkam;
	}

	public void setYeneAsleliShillakRakkam(String yeneAsleliShillakRakkam) {
		this.yeneAsleliShillakRakkam = yeneAsleliShillakRakkam;
	}

	public String getPaiseDenaryaAdhikaryaneKaravayachiTaNishaA() {
		return paiseDenaryaAdhikaryaneKaravayachiTaNishaA;
	}

	public void setPaiseDenaryaAdhikaryaneKaravayachiTaNishaA(String paiseDenaryaAdhikaryaneKaravayachiTaNishaA) {
		this.paiseDenaryaAdhikaryaneKaravayachiTaNishaA = paiseDenaryaAdhikaryaneKaravayachiTaNishaA;
	}

	public Map<String, String> getAttendanceData() {
		return attendanceData;
	}

	public void setAttendanceData(Map<String, String> attendanceData) {
		this.attendanceData = attendanceData;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

}
