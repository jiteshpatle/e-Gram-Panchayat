package eGramPanchayat.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "23_tabyatil_rastyanchi_nondwahi") // Replace with your actual table name
public class TabyatilRastyanchiNondWahi_23 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "year")
    private String year;

    @Column(name = "dinank")
    private String dinank;

    @Column(name = "employee_id")
    private String employeeId;

    @Column(name = "employee_name")
    private String employeeName;

    @Column(name = "grampanchayat_id")
    private String grampanchayatId;

    @Column(name = "grampanchayat_name")
    private String grampanchayatName;

    @Column(name = "created_date")
    @CreationTimestamp
    private LocalDateTime createdDate;

    @Column(name = "updated_date")
    @UpdateTimestamp
    private LocalDateTime updatedDate;

//    @Column(name = "anukramank")
//    private Integer anukramank;

    @Column(name = "rastyache_naaw")
    private String rastyacheNaaw;

    @Column(name = "gaaw_paasun")
    private String gaawPaasun;

    @Column(name = "gaaw_paryant")
    private String gaawParyant;

    @Column(name = "laambi_km")
    private String laambiKm;

    @Column(name = "rundi_km")
    private String rundiKm;

    @Column(name = "rastyacha_prakar")
    private String rastyachaPrakar;

    @Column(name = "purn_kelyachi_tarikh")
    private LocalDate purnKelyachiTarikh;

    @Column(name = "prati_km_rasta_tayar_karnyas_aalela_kharch")
    private String pratiKmRastaTayarKarnyasAalelaKharch;

    @Column(name = "durustya_chalu_kharch_rupaye")
    private String durustyaChaluKharchRupaye;

    @Column(name = "durustya_chalu_swarup")
    private String durustyaChaluSwarup;

    @Column(name = "durustya_wishesh_kharch_rupaye")
    private String durustyaWisheshKharchRupaye;

    @Column(name = "durustya_wishesh_swarup")
    private String durustyaWisheshSwarup;

    @Column(name = "durustya_mul_bandhkam_kharch_rupaye")
    private String durustyaMulBandhkamKharchRupaye;

    @Column(name = "durustya_mul_bandhkam_swarup")
    private String durustyaMulBandhkamSwarup;

    @Column(name = "shera")
    private String shera;

//    @Column(name = "malmattechi_padtalni_sarpanch_sachiv_sahya")
//    private String malmattechiPadtalniSarpanchSachivSahya;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getGrampanchayatName() {
        return grampanchayatName;
    }

    public void setGrampanchayatName(String grampanchayatName) {
        this.grampanchayatName = grampanchayatName;
    }

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

//	public Integer getAnukramank() {
//        return anukramank;
//    }
//
//    public void setAnukramank(Integer anukramank) {
//        this.anukramank = anukramank;
//    }

    public String getRastyacheNaaw() {
        return rastyacheNaaw;
    }

    public void setRastyacheNaaw(String rastyacheNaaw) {
        this.rastyacheNaaw = rastyacheNaaw;
    }

    public String getGaawPaasun() {
        return gaawPaasun;
    }

    public void setGaawPaasun(String gaawPaasun) {
        this.gaawPaasun = gaawPaasun;
    }

    public String getGaawParyant() {
        return gaawParyant;
    }

    public void setGaawParyant(String gaawParyant) {
        this.gaawParyant = gaawParyant;
    }

    public String getRastyachaPrakar() {
        return rastyachaPrakar;
    }

    public void setRastyachaPrakar(String rastyachaPrakar) {
        this.rastyachaPrakar = rastyachaPrakar;
    }

    public LocalDate getPurnKelyachiTarikh() {
        return purnKelyachiTarikh;
    }

    public void setPurnKelyachiTarikh(LocalDate purnKelyachiTarikh) {
        this.purnKelyachiTarikh = purnKelyachiTarikh;
    }

    public String getDurustyaChaluSwarup() {
        return durustyaChaluSwarup;
    }

    public void setDurustyaChaluSwarup(String durustyaChaluSwarup) {
        this.durustyaChaluSwarup = durustyaChaluSwarup;
    }

    public String getDurustyaWisheshSwarup() {
        return durustyaWisheshSwarup;
    }

    public void setDurustyaWisheshSwarup(String durustyaWisheshSwarup) {
        this.durustyaWisheshSwarup = durustyaWisheshSwarup;
    }

    public String getDurustyaMulBandhkamSwarup() {
        return durustyaMulBandhkamSwarup;
    }

    public void setDurustyaMulBandhkamSwarup(String durustyaMulBandhkamSwarup) {
        this.durustyaMulBandhkamSwarup = durustyaMulBandhkamSwarup;
    }

    public String getShera() {
        return shera;
    }

    public void setShera(String shera) {
        this.shera = shera;
    }

    public String getDurustyaChaluKharchRupaye() {
        return durustyaChaluKharchRupaye;
    }

    public void setDurustyaChaluKharchRupaye(String durustyaChaluKharchRupaye) {
        this.durustyaChaluKharchRupaye = durustyaChaluKharchRupaye;
    }

    public String getDurustyaMulBandhkamKharchRupaye() {
        return durustyaMulBandhkamKharchRupaye;
    }

    public void setDurustyaMulBandhkamKharchRupaye(String durustyaMulBandhkamKharchRupaye) {
        this.durustyaMulBandhkamKharchRupaye = durustyaMulBandhkamKharchRupaye;
    }

    public String getDurustyaWisheshKharchRupaye() {
        return durustyaWisheshKharchRupaye;
    }

    public void setDurustyaWisheshKharchRupaye(String durustyaWisheshKharchRupaye) {
        this.durustyaWisheshKharchRupaye = durustyaWisheshKharchRupaye;
    }

    public String getLaambiKm() {
        return laambiKm;
    }

    public void setLaambiKm(String laambiKm) {
        this.laambiKm = laambiKm;
    }

    public String getPratiKmRastaTayarKarnyasAalelaKharch() {
        return pratiKmRastaTayarKarnyasAalelaKharch;
    }

    public void setPratiKmRastaTayarKarnyasAalelaKharch(String pratiKmRastaTayarKarnyasAalelaKharch) {
        this.pratiKmRastaTayarKarnyasAalelaKharch = pratiKmRastaTayarKarnyasAalelaKharch;
    }

    public String getRundiKm() {
        return rundiKm;
    }

    public void setRundiKm(String rundiKm) {
        this.rundiKm = rundiKm;
    }

    public String getDinank() {
        return dinank;
    }

    public void setDinank(String dinank) {
        this.dinank = dinank;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getGrampanchayatId() {
        return grampanchayatId;
    }

    public void setGrampanchayatId(String grampanchayatId) {
        this.grampanchayatId = grampanchayatId;
    }

    

    //    public String getMalmattechiPadtalniSarpanchSachivSahya() {
//        return malmattechiPadtalniSarpanchSachivSahya;
//    }
//
//    public void setMalmattechiPadtalniSarpanchSachivSahya(String malmattechiPadtalniSarpanchSachivSahya) {
//        this.malmattechiPadtalniSarpanchSachivSahya = malmattechiPadtalniSarpanchSachivSahya;
//    }
}
