package eGramPanchayat.entity;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.hibernate.annotations.CreationTimestamp;

import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.persistence.Table;

@Entity
@Table(name = "32_rakkam_partavya_sathi_cha_adesh")
public class Namuna32RakkamPartavyaSathiChaAdesh {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "employee_id")


    // @Pattern(regexp = "^[a-zA-Z0-9]*$", message = "Employee ID must contain only
    // characters or numbers.")
    private String employeeId;

    @Column(name = "employee_name")

    // @Pattern(regexp = "^[a-zA-Z0-9\\s]*$", message = "Employee Name must contain
    // only characters.")
    private String employeeName;

    @Column(name = "gram_panchayat_id")

    // @Pattern(regexp = "^[a-zA-Z0-9]*$", message = "Grampanchayat ID must contain
    // only characters or numbers.")
    private String gramPanchayatId;

    @Column(name = "gram_panchayat_name")

    // @Pattern(regexp = "^[a-zA-Z\\s]+$", message = "Grampanchayat name must not
    // contain special characters.")
    private String gramPanchayatName;

//    @Column(name = "year")
//    @NotNull(message = "Year cannot be null.")
//    @NotBlank(message = "Year cannot be empty.")
//    private String year;

    @Column(name = "pavti_number")
    @NotNull(message = "Pavti Number cannot be null.")
    @NotBlank(message = "Pavti Number cannot be empty.")
    private String pavtiNumber;

    @Column(name = "dileli_mul_rakkam_date")
    @NotNull(message = "dileli_mul_rakkam_date cannot be null.")
    @NotBlank(message = "dileli_mul_rakkam_date cannot be empty.")

    private String dileliMulRakkamDate;

    @Column(name = "rakkam")
    @NotNull(message = "rakkam cannot be null.")
    @NotBlank(message = "rakkam cannot be empty.")
    // @Pattern(regexp = "^[0-9]+$", message = "Rakkam must contain only numbers.")
    private String rakkam;

    @Column(name = "parat_Karyachi_rakkam")
    @NotNull(message = "parat_Karyachi_rakkam cannot be null.")
    @NotBlank(message = "parat_Karyachi_rakkam cannot be empty.")
    // @Pattern(regexp = "^[0-9]+$", message = "Parat Karyachi Rakkam must contain
    // only numbers.")
    private String paratKaryachiRakkam;

    @Column(name = "thevidarache_nav")
    @NotNull(message = "Thevidarache_nav cannot be null.")
    @NotBlank(message = "Thevidarache_nav cannot be empty.")
    // @Pattern(regexp = "^[a-zA-Z\\s]+$", message = "Thevi Darache Nav must be
    // character.")
    private String thevidaracheNav;

    @Column(name = "shera")
    @NotNull(message = "Shera Number cannot be null.")
    @NotBlank(message = "Shera Number cannot be empty.")
    // @Pattern(regexp = "^[a-zA-Z\\s]+$", message = "Thevi Darache Nav must be
    // character.")
    private String shera;

    @Column(name = "partava_karnarya_pradhikaryache_nav")
    @NotNull(message = "Partava Karnarya Pradhikaryache Nav cannot be null.")
    @NotBlank(message = "Partava Karnarya Pradhikaryache Nav cannot be empty.")
    // @Pattern(regexp = "^[a-zA-Z\\s]+$", message = "Partava Karnarya
    // Pradhikaryache Nav must be character.")
    private String partavaKarnaryaPradhikaryacheNav;

    @Column(name = "dinank")
    private String dinank;

    @Column(name = "created_date", updatable = false)
    @CreationTimestamp
    private LocalDateTime createdDate;

    @Column(name = "updated_date")
    @UpdateTimestamp
    private LocalDateTime updatedDate;

    // Getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getGramPanchayatId() {
        return gramPanchayatId;
    }

    public void setGramPanchayatId(String gramPanchayatId) {
        this.gramPanchayatId = gramPanchayatId;
    }

    public String getGramPanchayatName() {
        return gramPanchayatName;
    }

    public void setGramPanchayatName(String gramPanchayatName) {
        this.gramPanchayatName = gramPanchayatName;
    }

//    public String getYear() {
//        return year;
//    }
//
//    public void setYear(String year) {
//        this.year = year;
//    }

    public String getPavtiNumber() {
        return pavtiNumber;
    }

    public void setPavtiNumber(String pavtiNumber) {
        this.pavtiNumber = pavtiNumber;
    }

    public String getDileliMulRakkamDate() {
        return dileliMulRakkamDate;
    }

    public void setDileliMulRakkamDate(String dileliMulRakkamDate) {
        this.dileliMulRakkamDate = dileliMulRakkamDate;
    }

    public String getRakkam() {
        return rakkam;
    }

    public void setRakkam(String rakkam) {
        this.rakkam = rakkam;
    }

    public String getParatKaryachiRakkam() {
        return paratKaryachiRakkam;
    }

    public void setParatKaryachiRakkam(String paratKaryachiRakkam) {
        this.paratKaryachiRakkam = paratKaryachiRakkam;
    }

    public String getThevidaracheNav() {
        return thevidaracheNav;
    }

    public void setThevidaracheNav(String thevidaracheNav) {
        this.thevidaracheNav = thevidaracheNav;
    }

    public String getPartavaKarnaryaPradhikaryacheNav() {
        return partavaKarnaryaPradhikaryacheNav;
    }

    public void setPartavaKarnaryaPradhikaryacheNav(String partavaKarnaryaPradhikaryacheNav) {
        this.partavaKarnaryaPradhikaryacheNav = partavaKarnaryaPradhikaryacheNav;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getShera() {
        return shera;
    }

    public void setShera(String shera) {
        this.shera = shera;
    }

    public String getDinank() {
        return dinank;
    }

    public void setDinank(String dinank) {
        this.dinank = dinank;
    }
}
