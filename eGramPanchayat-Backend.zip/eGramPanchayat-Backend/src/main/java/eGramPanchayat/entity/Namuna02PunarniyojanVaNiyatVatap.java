package eGramPanchayat.entity;


import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;



@Entity
@Table(name = "02_punarniyojan_va_niyat_vatap")
public class Namuna02PunarniyojanVaNiyatVatap {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

  
    @Column(name = "jama_rakmeche_mukhya_shirshak")
    private String jamaRakmecheMukhyaShirshak;

    @Column(name = "manjur_arthsankalp")
    private String manjurArthsankalp;

    @Column(name = "sudharit_andaz")
    private String sudharitAndaz;

    @Column(name = "sudharit_adhik_vaja")
    private String sudharitAdhikVaja;

    @Column(name = "kharchache_pramukh_shirsh")
    private String kharchachePramukhShirsh;

    @Column(name = "manjur_rakkam")
    private String manjurRakkam;

    @Column(name = "kharchacha_sudharit_andaz")
    private String kharchachaSudharitAndaz;

    @Column(name = "kharchacha_adhik_vaja")
    private String kharchachaAdhikVaja;

    @Column(name = "shera")
    private String shera;

    @Column(name = "employee_id")
    private Long employeeId;

    @Column(name = "employee_name")
    private String employeeName;

    @Column(name = "grampanchayat_id")
    private Long grampanchayatId;

    @Column(name = "grampanchayat_name")
    private String grampanchayatName;

    @Column(name = "created_date", nullable = false, updatable = false)
    private LocalDateTime createdDate;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;
    
    @Column(name = "month")  // New field
    private String month;

    @Column(name = "dnyapan_rupees")  // New field
    private String dnyapanRupees;

    @Column(name = "year")
    private String year;  // New field for value
    
    // Auto-generate dates
    @PrePersist
    protected void onCreate() {
        this.createdDate = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedDate = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public String getJamaRakmecheMukhyaShirshak() {
        return jamaRakmecheMukhyaShirshak;
    }

    public void setJamaRakmecheMukhyaShirshak(String jamaRakmecheMukhyaShirshak) {
        this.jamaRakmecheMukhyaShirshak = jamaRakmecheMukhyaShirshak;
    }

    public String getManjurArthsankalp() {
        return manjurArthsankalp;
    }

    public void setManjurArthsankalp(String manjurArthsankalp) {
        this.manjurArthsankalp = manjurArthsankalp;
    }

    public String getSudharitAndaz() {
        return sudharitAndaz;
    }

    public void setSudharitAndaz(String sudharitAndaz) {
        this.sudharitAndaz = sudharitAndaz;
    }

    public String getSudharitAdhikVaja() {
        return sudharitAdhikVaja;
    }

    public void setSudharitAdhikVaja(String sudharitAdhikVaja) {
        this.sudharitAdhikVaja = sudharitAdhikVaja;
    }

    public String getKharchachePramukhShirsh() {
        return kharchachePramukhShirsh;
    }

    public void setKharchachePramukhShirsh(String kharchachePramukhShirsh) {
        this.kharchachePramukhShirsh = kharchachePramukhShirsh;
    }

    public String getManjurRakkam() {
        return manjurRakkam;
    }

    public void setManjurRakkam(String manjurRakkam) {
        this.manjurRakkam = manjurRakkam;
    }

    public String getKharchachaSudharitAndaz() {
        return kharchachaSudharitAndaz;
    }

    public void setKharchachaSudharitAndaz(String kharchachaSudharitAndaz) {
        this.kharchachaSudharitAndaz = kharchachaSudharitAndaz;
    }

    public String getKharchachaAdhikVaja() {
        return kharchachaAdhikVaja;
    }

    public void setKharchachaAdhikVaja(String kharchachaAdhikVaja) {
        this.kharchachaAdhikVaja = kharchachaAdhikVaja;
    }

    public String getShera() {
        return shera;
    }

    public void setShera(String shera) {
        this.shera = shera;
    }

    public Long getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Long employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public Long getGrampanchayatId() {
        return grampanchayatId;
    }

    public void setGrampanchayatId(Long grampanchayatId) {
        this.grampanchayatId = grampanchayatId;
    }

    public String getGrampanchayatName() {
        return grampanchayatName;
    }

    public void setGrampanchayatName(String grampanchayatName) {
        this.grampanchayatName = grampanchayatName;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getDnyapanRupees() {
		return dnyapanRupees;
	}

	public void setDnyapanRupees(String dnyapanRupees) {
		this.dnyapanRupees = dnyapanRupees;
	}

	
}
