package eGramPanchayat.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Pattern;
import java.util.Date;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "25_guntonuk")
public class GuntonukNamuna25 {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "guntonukici_tarikha")
	@Temporal(TemporalType.TIMESTAMP)
	private Date guntonukiciTarikha;

	@Column(name = "guntonukici_tapasila")
	@Pattern(regexp = "^[^@]*$", message = "Guntonukici Tapisila cannot contain the @ character.")
	private String guntonukiciTapisila;

	@Column(name = "guntonukichi_rakam_darsani_mulya")
	@Pattern(regexp = "^[^@]*$", message = "Guntonukichi Rakam Darsani Mulya cannot contain the @ character.")
	private String guntonukichiRakamDarsaniMulya;

	@Column(name = "guntonukichi_rakam_kharēdī_kimata")
	@Pattern(regexp = "^[^@]*$", message = "Guntonukichi Rakam Kharēdī Kimata cannot contain the @ character.")
	private String guntonukichiRakamKharēdīKimata;

	@Column(name = "pranit_honachi_tarkhi")
	@Temporal(TemporalType.TIMESTAMP)
	private Date pranitHonachiTarkhi;

	@Column(name = "nival_dya_rakam")
	@Pattern(regexp = "^[^@]*$", message = "Nival Dya Rakam cannot contain the @ character.")
	private String nivalDyaRakam;

	@Column(name = "uparichit_vachanchi_tarakhi")
	@Temporal(TemporalType.TIMESTAMP)
	private Date uparichitVachanchiTarakhi;

	@Column(name = "badlicha_padrothricha_dinaka")
	@Temporal(TemporalType.TIMESTAMP)
	// @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-dd-MM")
	// @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "Date must be in the
	// format yyyy-MM-dd")
	private String badlichaPadrothrichaDinaka;

	@Column(name = "dainik_rokad_bahithil_jama_rakam")
	@Pattern(regexp = "^[^@]*$", message = "Dainik Rokad Bahithil Jama Rakam cannot contain the @ character.")
	private String dainikRokadBahithilJamaRakam;

	@Column(name = "prakritischi_tapasni")
	@Pattern(regexp = "^[^@]*$", message = "Prakritischi Tapasni cannot contain the @ character.")
	private String prakritischiTapasni;

	@Column(name = "create_date")
	// @Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	private Date createDate;

	@Column(name = "updated_date")
	// @Temporal(TemporalType.TIMESTAMP)
	@UpdateTimestamp
	private Date updatedDate;

	@Column(name = "employee_id")
	private String employeeId;

	@Column(name = "employee_name")
	@Pattern(regexp = "^[^@]*$", message = "Employee Name cannot contain the @ character.")
	private String employeeName;

	@Column(name = "month")
	private String month;

	@Column(name = "grampanchyat_id")
	private String grampanchyatId;

	@Column(name = "grampanchyat_name")
	@Pattern(regexp = "^[^@]*$", message = "Grampanchyat Name cannot contain the @ character.")
	private String grampanchyatName;

	@Pattern(regexp = "^[^@]*$", message = "Grampanchyat Name cannot contain the @ character.")
	@Column(name = "remark", columnDefinition = "TEXT")
	private String remark;

	@Column(name = "year")
	@Pattern(regexp = "^[0-9]+$", message = "Field must contain only digits.")
	private String Year;

	@Column(name = "dinank")
	private String dinank;

	public String getYear() {
		return Year;
	}

	public void setYear(String year) {
		Year = year;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getGuntonukiciTarikha() {
		return guntonukiciTarikha;
	}

	public void setGuntonukiciTarikha(Date guntonukiciTarikha) {
		this.guntonukiciTarikha = guntonukiciTarikha;
	}

	public String getGuntonukiciTapisila() {
		return guntonukiciTapisila;
	}

	public void setGuntonukiciTapisila(String guntonukiciTapisila) {
		this.guntonukiciTapisila = guntonukiciTapisila;
	}

	public String getGuntonukichiRakamDarsaniMulya() {
		return guntonukichiRakamDarsaniMulya;
	}

	public void setGuntonukichiRakamDarsaniMulya(String guntonukichiRakamDarsaniMulya) {
		this.guntonukichiRakamDarsaniMulya = guntonukichiRakamDarsaniMulya;
	}

	public String getGuntonukichiRakamKharēdīKimata() {
		return guntonukichiRakamKharēdīKimata;
	}

	public void setGuntonukichiRakamKharēdīKimata(String guntonukichiRakamKharēdīKimata) {
		this.guntonukichiRakamKharēdīKimata = guntonukichiRakamKharēdīKimata;
	}

	public Date getPranitHonachiTarkhi() {
		return pranitHonachiTarkhi;
	}

	public void setPranitHonachiTarkhi(Date pranitHonachiTarkhi) {
		this.pranitHonachiTarkhi = pranitHonachiTarkhi;
	}

	public String getNivalDyaRakam() {
		return nivalDyaRakam;
	}

	public void setNivalDyaRakam(String nivalDyaRakam) {
		this.nivalDyaRakam = nivalDyaRakam;
	}

	public Date getUparichitVachanchiTarakhi() {
		return uparichitVachanchiTarakhi;
	}

	public void setUparichitVachanchiTarakhi(Date uparichitVachanchiTarakhi) {
		this.uparichitVachanchiTarakhi = uparichitVachanchiTarakhi;
	}

	public String getBadlichaPadrothrichaDinaka() {
		return badlichaPadrothrichaDinaka;
	}

	public void setBadlichaPadrothrichaDinaka(String badlichaPadrothrichaDinaka) {
		this.badlichaPadrothrichaDinaka = badlichaPadrothrichaDinaka;
	}

	public String getDainikRokadBahithilJamaRakam() {
		return dainikRokadBahithilJamaRakam;
	}

	public void setDainikRokadBahithilJamaRakam(String dainikRokadBahithilJamaRakam) {
		this.dainikRokadBahithilJamaRakam = dainikRokadBahithilJamaRakam;
	}

	public String getPrakritischiTapasni() {
		return prakritischiTapasni;
	}

	public void setPrakritischiTapasni(String prakritischiTapasni) {
		this.prakritischiTapasni = prakritischiTapasni;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getGrampanchyatName() {
		return grampanchyatName;
	}

	public void setGrampanchyatName(String grampanchyatName) {
		this.grampanchyatName = grampanchyatName;
	}


	public String getDinank() {
		return dinank;
	}

	public void setDinank(String dinank) {
		this.dinank = dinank;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getGrampanchyatId() {
		return grampanchyatId;
	}

	public void setGrampanchyatId(String grampanchyatId) {
		this.grampanchyatId = grampanchyatId;
	}

	

	
	// Getters and Setters...

}
