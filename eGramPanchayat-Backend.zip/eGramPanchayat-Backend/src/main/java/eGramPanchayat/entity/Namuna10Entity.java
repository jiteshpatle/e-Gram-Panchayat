package eGramPanchayat.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "10_Kar_Va_Fee_Baabat_Pavti")
public class Namuna10Entity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Static fields
    private String employeeId;
    private String employeeName;
    private String gramPanchayatId;
    private String gramPanchayatName;
    private String pavtiNo;
    private String nav;
    private String year;
    private String gharNo;
    private String billNo;
    private String ekun;
    private String dinank;

    @CreationTimestamp
    private LocalDateTime createdDate;

    @UpdateTimestamp
    private LocalDateTime updatedDate;

    // One-to-many relationship with DynamicField
    @OneToMany(mappedBy = "namuna10Entity", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<DynamicField> items = new ArrayList<>();

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getGramPanchayatId() {
        return gramPanchayatId;
    }

    public void setGramPanchayatId(String gramPanchayatId) {
        this.gramPanchayatId = gramPanchayatId;
    }

    public String getGramPanchayatName() {
        return gramPanchayatName;
    }

    public void setGramPanchayatName(String gramPanchayatName) {
        this.gramPanchayatName = gramPanchayatName;
    }

    public String getPavtiNo() {
        return pavtiNo;
    }

    public void setPavtiNo(String pavtiNo) {
        this.pavtiNo = pavtiNo;
    }

    public String getNav() {
        return nav;
    }

    public void setNav(String nav) {
        this.nav = nav;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getGharNo() {
        return gharNo;
    }

    public void setGharNo(String gharNo) {
        this.gharNo = gharNo;
    }

    public String getBillNo() {
        return billNo;
    }

    public void setBillNo(String billNo) {
        this.billNo = billNo;
    }

    public String getEkun() {
        return ekun;
    }

    public void setEkun(String ekun) {
        this.ekun = ekun;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getDinank() {
        return dinank;
    }

    public void setDinank(String dinank) {
        this.dinank = dinank;
    }

    public List<DynamicField> getItems() {
        return items;
    }

    public void setItems(List<DynamicField> items) {
        this.items = items;
    }
}
