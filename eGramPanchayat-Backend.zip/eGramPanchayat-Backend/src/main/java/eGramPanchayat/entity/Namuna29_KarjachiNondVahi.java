package eGramPanchayat.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name = "29_GramPanchayatNamuna")
public class Namuna29_KarjachiNondVahi {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "Employee_id")
    private String employeeId;

    @Column(name = "Employee_Name")
    private String employeeName;

    @Column(name = "GramPanchayat_id")
    private String grampanchayatId;

    @Column(name = "GramPanchayat_Name")
    private String grampanchayatName;

    @Column(name = "Shera")
    private String shera;

    @Column(name = "Karj_Ubharanechi_Sadhne")
    private String karjUbharanechiSadhne;

    @Column(name = "Karj_Manjuri_Adesh_Kramank")
    private String karjManjuriAdeshKramank;

    @Column(name = "Karj_Manjuri_Dinank")
    private String karjManjuriDinank;

    @Column(name = "Karj_Prayojan")
    private String karjachePrayojan;
    
    @Column(name = "Karj_Rakkam")
    private Double karjRakkam;
    
    @Column(name = "Vyaj_Dar")
    private String vyajDar;
    
    @Column(name = "Karj_Milalyachi_Tarikh")
    private String karjMilalyachiTarikh;
    
    @Column(name = "Pradanacha_Tapshil_Dinank")
    private String pradanachaTapshilDinank;
    
    @Column(name = "Pradanacha_Tapshil_Muddat")
    private String pradanachaTapshilMuddat;
    
    @Column(name = "Pradanacha_Tapshil_Vyaj")
    private String pradanachaTapshilVyaj;
    
    @Column(name = "Pradanacha_Tapshil_Ekun")
    private String pradanachaTapshilEkun;
    
    @Column(name = "Shillak_Rakkam_Mudat")
    private String shillakRakkamMudat;
    
    @Column(name = "Shillak_Rakkam_Vyaj")
    private String shillakRakkamVyaj;
    
    @Column(name = "Karj_Vyaj_Paratfeda_Mudat_Hapta_Sankhya")
    private String karjVyajParatfedaMudatHaptaSankhya;
    
    @Column(name = "Karj_Vyaj_Paratfeda_Vyaj_Hapta_Sankhya")
    private String karjVyajParatfedaVyajHaptaSankhya;
    
    @Column(name = "Karj_Vyaj_Paratfeda_Mudat_Dinank")
    private String karjVyajParatfedaMudatDinank;
    
    @Column(name = "Karj_Vyaj_Paratfeda_Vyaj_Dinank")
    private String karjVyajParatfedaVyajDinank;
    
    @Column(name = "Pratyek_Haptyachya_Muddalasathi_Karj_Rakkam")
    private String pratyekHaptyachyaMuddalasathiKarjRakkam;
    
    @Column(name = "Pratyek_Haptyachya_Muddalasathi_Vyaj_Rakkam")
    private String pratyekHaptyachyaMuddalasathiVyajRakkam;
    
    @Column(name = "Dinank")
    private String date;

    @Column(name = "year")
    private String year;

    @Column(name = "Created_Date", updatable = false)
    @CreationTimestamp
    private LocalDateTime createdDate;

    @Column(name = "UpdatedDate")
    @UpdateTimestamp
    private LocalDateTime updatedDate;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getGrampanchayatId() {
		return grampanchayatId;
	}

	public void setGrampanchayatId(String grampanchayatId) {
		this.grampanchayatId = grampanchayatId;
	}

	public String getGrampanchayatName() {
		return grampanchayatName;
	}

	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}

	public String getShera() {
		return shera;
	}

	public void setShera(String shera) {
		this.shera = shera;
	}

	public String getKarjUbharanechiSadhne() {
		return karjUbharanechiSadhne;
	}

	public void setKarjUbharanechiSadhne(String karjUbharanechiSadhne) {
		this.karjUbharanechiSadhne = karjUbharanechiSadhne;
	}

	public String getKarjManjuriAdeshKramank() {
		return karjManjuriAdeshKramank;
	}

	public void setKarjManjuriAdeshKramank(String karjManjuriAdeshKramank) {
		this.karjManjuriAdeshKramank = karjManjuriAdeshKramank;
	}

	public String getKarjManjuriDinank() {
		return karjManjuriDinank;
	}

	public void setKarjManjuriDinank(String karjManjuriDinank) {
		this.karjManjuriDinank = karjManjuriDinank;
	}

	public String getKarjachePrayojan() {
		return karjachePrayojan;
	}

	public void setKarjachePrayojan(String karjachePrayojan) {
		this.karjachePrayojan = karjachePrayojan;
	}

	public Double getKarjRakkam() {
		return karjRakkam;
	}

	public void setKarjRakkam(Double karjRakkam) {
		this.karjRakkam = karjRakkam;
	}

	public String getVyajDar() {
		return vyajDar;
	}

	public void setVyajDar(String vyajDar) {
		this.vyajDar = vyajDar;
	}

	public String getKarjMilalyachiTarikh() {
		return karjMilalyachiTarikh;
	}

	public void setKarjMilalyachiTarikh(String karjMilalyachiTarikh) {
		this.karjMilalyachiTarikh = karjMilalyachiTarikh;
	}

	public String getPradanachaTapshilDinank() {
		return pradanachaTapshilDinank;
	}

	public void setPradanachaTapshilDinank(String pradanachaTapshilDinank) {
		this.pradanachaTapshilDinank = pradanachaTapshilDinank;
	}

	public String getPradanachaTapshilMuddat() {
		return pradanachaTapshilMuddat;
	}

	public void setPradanachaTapshilMuddat(String pradanachaTapshilMuddat) {
		this.pradanachaTapshilMuddat = pradanachaTapshilMuddat;
	}

	public String getPradanachaTapshilVyaj() {
		return pradanachaTapshilVyaj;
	}

	public void setPradanachaTapshilVyaj(String pradanachaTapshilVyaj) {
		this.pradanachaTapshilVyaj = pradanachaTapshilVyaj;
	}

	public String getPradanachaTapshilEkun() {
		return pradanachaTapshilEkun;
	}

	public void setPradanachaTapshilEkun(String pradanachaTapshilEkun) {
		this.pradanachaTapshilEkun = pradanachaTapshilEkun;
	}

	public String getShillakRakkamMudat() {
		return shillakRakkamMudat;
	}

	public void setShillakRakkamMudat(String shillakRakkamMudat) {
		this.shillakRakkamMudat = shillakRakkamMudat;
	}

	public String getShillakRakkamVyaj() {
		return shillakRakkamVyaj;
	}

	public void setShillakRakkamVyaj(String shillakRakkamVyaj) {
		this.shillakRakkamVyaj = shillakRakkamVyaj;
	}

	public String getKarjVyajParatfedaMudatHaptaSankhya() {
		return karjVyajParatfedaMudatHaptaSankhya;
	}

	public void setKarjVyajParatfedaMudatHaptaSankhya(String karjVyajParatfedaMudatHaptaSankhya) {
		this.karjVyajParatfedaMudatHaptaSankhya = karjVyajParatfedaMudatHaptaSankhya;
	}

	public String getKarjVyajParatfedaVyajHaptaSankhya() {
		return karjVyajParatfedaVyajHaptaSankhya;
	}

	public void setKarjVyajParatfedaVyajHaptaSankhya(String karjVyajParatfedaVyajHaptaSankhya) {
		this.karjVyajParatfedaVyajHaptaSankhya = karjVyajParatfedaVyajHaptaSankhya;
	}

	public String getKarjVyajParatfedaMudatDinank() {
		return karjVyajParatfedaMudatDinank;
	}

	public void setKarjVyajParatfedaMudatDinank(String karjVyajParatfedaMudatDinank) {
		this.karjVyajParatfedaMudatDinank = karjVyajParatfedaMudatDinank;
	}

	public String getKarjVyajParatfedaVyajDinank() {
		return karjVyajParatfedaVyajDinank;
	}

	public void setKarjVyajParatfedaVyajDinank(String karjVyajParatfedaVyajDinank) {
		this.karjVyajParatfedaVyajDinank = karjVyajParatfedaVyajDinank;
	}

	public String getPratyekHaptyachyaMuddalasathiKarjRakkam() {
		return pratyekHaptyachyaMuddalasathiKarjRakkam;
	}

	public void setPratyekHaptyachyaMuddalasathiKarjRakkam(String pratyekHaptyachyaMuddalasathiKarjRakkam) {
		this.pratyekHaptyachyaMuddalasathiKarjRakkam = pratyekHaptyachyaMuddalasathiKarjRakkam;
	}

	public String getPratyekHaptyachyaMuddalasathiVyajRakkam() {
		return pratyekHaptyachyaMuddalasathiVyajRakkam;
	}

	public void setPratyekHaptyachyaMuddalasathiVyajRakkam(String pratyekHaptyachyaMuddalasathiVyajRakkam) {
		this.pratyekHaptyachyaMuddalasathiVyajRakkam = pratyekHaptyachyaMuddalasathiVyajRakkam;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}
	
}