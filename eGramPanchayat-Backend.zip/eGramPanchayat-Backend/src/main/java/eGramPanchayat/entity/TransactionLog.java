package eGramPanchayat.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.*;

@Entity
public class TransactionLog {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String action; // e.g., "SAVE", "UPDATE", "DELETE", "GET_BY_ID", "GET_ALL"
	// private Long entityId; // ID of the Namuna02PunarniyojanVaNiyatVatap entity (if applicable)
	private String details; // Additional details about the transaction
	@Column(nullable = false)
	@CreationTimestamp
	private LocalDateTime timestamp; // Timestamp when the transaction occurred
	private String username;
	@Column(name = "employee_id")
	private String employeeId;
	@Column(name = "employee_name")
	private String employeeName;
	@Column(name = "grampanchayat_id")
	private String grampanchayatId;
	@Column(name = "grampanchayat_name")
	private String grampanchayatName;
	// Getters and setters
	// ...

	public TransactionLog(String action,String details,
			String username, String employeeId, String employeeName, String grampanchayatId, String grampanchayatName) {
		this.action = action;
		this.details = details;
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		// this.entityId = entityId;
		this.grampanchayatId = grampanchayatId;
		this.grampanchayatName = grampanchayatName;
		this.username = username;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	// public Long getEntityId() {
	// 	return entityId;
	// }

	// public void setEntityId(Long entityId) {
	// 	this.entityId = entityId;
	// }

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getGrampanchayatName() {
		return grampanchayatName;
	}

	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}

}
