package eGramPanchayat.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eGramPanchayat.entity.Egram26_K;


@Repository
public interface Egram26KRepository extends JpaRepository<Egram26_K, Long>{

}
