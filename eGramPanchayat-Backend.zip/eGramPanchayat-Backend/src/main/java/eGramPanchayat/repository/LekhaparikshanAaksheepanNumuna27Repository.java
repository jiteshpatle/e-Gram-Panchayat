package eGramPanchayat.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import eGramPanchayat.entity.LekhaparikshanAaksheepanNamuna27;

public interface LekhaparikshanAaksheepanNumuna27Repository extends JpaRepository<LekhaparikshanAaksheepanNamuna27, Long> {
}
