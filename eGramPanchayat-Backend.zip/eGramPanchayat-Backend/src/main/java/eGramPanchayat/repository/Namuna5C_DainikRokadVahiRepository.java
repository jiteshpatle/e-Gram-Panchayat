package eGramPanchayat.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eGramPanchayat.entity.Namuna5C_DainikRokadVahi;

@Repository
public interface Namuna5C_DainikRokadVahiRepository extends JpaRepository<Namuna5C_DainikRokadVahi, Long> {
    List<Namuna5C_DainikRokadVahi> findAll();
}
