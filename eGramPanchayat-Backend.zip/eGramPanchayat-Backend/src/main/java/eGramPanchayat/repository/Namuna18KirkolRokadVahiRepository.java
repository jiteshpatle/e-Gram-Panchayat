package eGramPanchayat.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import eGramPanchayat.dto.Namuna18KirkolRokadVahiDto;
import eGramPanchayat.entity.Namuna18KirkolRokadVahi;

public interface Namuna18KirkolRokadVahiRepository extends JpaRepository<Namuna18KirkolRokadVahi, Long> {

	Namuna18KirkolRokadVahi save(Namuna18KirkolRokadVahiDto kirkolRokadVahiDto);
}
