package eGramPanchayat.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eGramPanchayat.entity.Namuna10Entity;


@Repository
public interface Namuna10Repo extends JpaRepository<Namuna10Entity,Long> {
}
