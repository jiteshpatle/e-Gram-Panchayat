package eGramPanchayat.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import eGramPanchayat.entity.Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaran;


@Repository
public interface Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranRepository extends JpaRepository<Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaran,Long>
{

}
