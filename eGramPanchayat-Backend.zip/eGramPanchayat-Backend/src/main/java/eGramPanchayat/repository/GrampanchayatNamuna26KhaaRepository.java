package eGramPanchayat.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eGramPanchayat.entity.GrampanchayatNamuna26Khaa;


@Repository
public interface GrampanchayatNamuna26KhaaRepository extends JpaRepository<GrampanchayatNamuna26Khaa, Long> {
}
