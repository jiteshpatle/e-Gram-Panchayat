package eGramPanchayat.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eGramPanchayat.entity.Namuna29_KarjachiNondVahi;

@Repository
public interface Namuna29_KarjachiNondVahiRepository extends JpaRepository<Namuna29_KarjachiNondVahi, Long> {
    List<Namuna29_KarjachiNondVahi> findAll();
}