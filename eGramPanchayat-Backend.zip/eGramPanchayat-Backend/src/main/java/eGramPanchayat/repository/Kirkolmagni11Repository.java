package eGramPanchayat.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import eGramPanchayat.entity.Kirkolmagni_11;

public interface Kirkolmagni11Repository  extends JpaRepository<Kirkolmagni_11,Long>{

}
