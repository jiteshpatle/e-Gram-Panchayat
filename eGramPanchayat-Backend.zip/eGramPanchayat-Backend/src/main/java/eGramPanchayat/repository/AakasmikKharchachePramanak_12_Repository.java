package eGramPanchayat.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eGramPanchayat.entity.AakasmikKharchachePramanak_12;

@Repository
public interface AakasmikKharchachePramanak_12_Repository extends JpaRepository<AakasmikKharchachePramanak_12, Long> {
}
