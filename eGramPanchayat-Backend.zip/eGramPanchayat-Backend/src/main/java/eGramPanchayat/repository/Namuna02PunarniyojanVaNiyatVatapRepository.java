package eGramPanchayat.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eGramPanchayat.entity.Namuna02PunarniyojanVaNiyatVatap;

@Repository
public interface Namuna02PunarniyojanVaNiyatVatapRepository extends JpaRepository<Namuna02PunarniyojanVaNiyatVatap, Long> {
  
}