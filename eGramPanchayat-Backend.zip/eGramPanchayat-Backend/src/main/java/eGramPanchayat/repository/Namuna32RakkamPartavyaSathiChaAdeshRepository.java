package eGramPanchayat.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eGramPanchayat.entity.Namuna32RakkamPartavyaSathiChaAdesh;




@Repository
public interface Namuna32RakkamPartavyaSathiChaAdeshRepository extends JpaRepository<Namuna32RakkamPartavyaSathiChaAdesh,Long>
{

}
