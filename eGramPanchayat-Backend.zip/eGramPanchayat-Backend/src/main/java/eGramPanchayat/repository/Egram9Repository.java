package eGramPanchayat.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import eGramPanchayat.entity.Egram9;

public interface Egram9Repository extends JpaRepository<Egram9, Long> {

}
