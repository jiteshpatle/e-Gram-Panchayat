package eGramPanchayat.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eGramPanchayat.entity.Namuna16_DeadStock;

@Repository
public interface Namuna16_DeadStockRepository extends JpaRepository<Namuna16_DeadStock, Long> {
    List<Namuna16_DeadStock> findAll();
}
