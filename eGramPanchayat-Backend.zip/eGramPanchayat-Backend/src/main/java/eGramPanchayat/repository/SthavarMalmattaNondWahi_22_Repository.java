package eGramPanchayat.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eGramPanchayat.entity.SthavarMalmattaNondWahi_22;

@Repository
public interface SthavarMalmattaNondWahi_22_Repository extends JpaRepository<SthavarMalmattaNondWahi_22, Long> {
}
