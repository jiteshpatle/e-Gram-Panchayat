package eGramPanchayat.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eGramPanchayat.entity.MojmaapWahi_21;

@Repository
public interface MojmaapWahi_21_Repository extends JpaRepository<MojmaapWahi_21, Long> {
}