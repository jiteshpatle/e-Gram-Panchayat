package eGramPanchayat.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import eGramPanchayat.entity.MatteVaDayitwe_04;

public interface MatteVaDayitwe_04_Repository extends JpaRepository<MatteVaDayitwe_04, Long> {
}
