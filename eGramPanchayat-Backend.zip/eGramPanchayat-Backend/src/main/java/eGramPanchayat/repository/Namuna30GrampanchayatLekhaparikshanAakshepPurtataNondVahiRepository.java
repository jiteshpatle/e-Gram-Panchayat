package eGramPanchayat.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eGramPanchayat.entity.Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahi;




@Repository
public interface Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiRepository extends JpaRepository<Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahi,Long>
{

}
