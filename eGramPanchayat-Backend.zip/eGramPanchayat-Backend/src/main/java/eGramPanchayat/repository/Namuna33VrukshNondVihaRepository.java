package eGramPanchayat.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eGramPanchayat.entity.Namuna33VrukshNondViha;

@Repository
public interface Namuna33VrukshNondVihaRepository extends JpaRepository<Namuna33VrukshNondViha, Long> {
}
