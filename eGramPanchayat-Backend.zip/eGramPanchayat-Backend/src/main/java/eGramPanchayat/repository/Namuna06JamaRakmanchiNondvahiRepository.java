package eGramPanchayat.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eGramPanchayat.entity.Namuna06JamaRakmanchiNondvahi;

@Repository
public interface Namuna06JamaRakmanchiNondvahiRepository extends JpaRepository<Namuna06JamaRakmanchiNondvahi, Long> {

	
}

