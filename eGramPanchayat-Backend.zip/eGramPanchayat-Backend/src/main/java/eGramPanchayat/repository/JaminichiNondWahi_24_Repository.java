package eGramPanchayat.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eGramPanchayat.entity.JaminichiNondWahi_24;

@Repository
public interface JaminichiNondWahi_24_Repository extends JpaRepository<JaminichiNondWahi_24, Long> {
}
