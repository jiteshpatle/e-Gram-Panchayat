package eGramPanchayat.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eGramPanchayat.dto.Namuna17AgrimDilelyaRakamanchiNondvahiDTO;
import eGramPanchayat.entity.Namuna17AgrimDilelyaRakamanchiNondvahi;

@Repository
public interface Namuna17AgrimDilelyaRakamanchiNondvahiRepository extends JpaRepository<Namuna17AgrimDilelyaRakamanchiNondvahi, Long> {

	Namuna17AgrimDilelyaRakamanchiNondvahiDTO save(Namuna17AgrimDilelyaRakamanchiNondvahiDTO nondvahi);
	
}