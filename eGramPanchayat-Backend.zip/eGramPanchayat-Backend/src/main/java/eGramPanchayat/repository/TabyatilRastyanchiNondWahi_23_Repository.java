package eGramPanchayat.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eGramPanchayat.entity.TabyatilRastyanchiNondWahi_23;

@Repository
public interface TabyatilRastyanchiNondWahi_23_Repository extends JpaRepository<TabyatilRastyanchiNondWahi_23, Long> {
}
