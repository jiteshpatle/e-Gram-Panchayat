package eGramPanchayat.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eGramPanchayat.entity.Namuna15_UpbhogyaVastuSathaLekhaNondVahi;

@Repository
public interface Namuna15_UpbhogyaVastuSathaLekhaNondVahiRepository extends JpaRepository<Namuna15_UpbhogyaVastuSathaLekhaNondVahi, Long> {
    List<Namuna15_UpbhogyaVastuSathaLekhaNondVahi> findAll();
}
