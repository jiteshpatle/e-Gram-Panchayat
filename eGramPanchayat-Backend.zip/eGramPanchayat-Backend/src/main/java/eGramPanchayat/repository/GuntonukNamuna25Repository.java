package eGramPanchayat.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import eGramPanchayat.entity.GuntonukNamuna25;

public interface GuntonukNamuna25Repository extends JpaRepository<GuntonukNamuna25, Long> {
    // Additional query methods can be defined here if needed
}
