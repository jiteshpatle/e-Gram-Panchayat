package eGramPanchayat.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eGramPanchayat.dto.Namuna19KamavarAslelyaVyaktinchaHajeripatDto;
import eGramPanchayat.entity.Namuna19KamavarAslelyaVyaktinchaHajeripat;

@Repository
public interface Namuna19KamavarAslelyaVyaktinchaHajeripatRepository extends JpaRepository<Namuna19KamavarAslelyaVyaktinchaHajeripat, Long> {

	Namuna19KamavarAslelyaVyaktinchaHajeripatDto save(Namuna19KamavarAslelyaVyaktinchaHajeripatDto dto);
}