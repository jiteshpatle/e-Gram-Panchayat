package eGramPanchayat.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;

import eGramPanchayat.util.ResponseWrapper;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<String> handleValidationExceptions(MethodArgumentNotValidException ex) {
		StringBuilder errorMessage = new StringBuilder();
        
		// Use a for loop instead of forEach
        for (FieldError error : ex.getBindingResult().getFieldErrors())
        {
            
            	errorMessage.append(error.getDefaultMessage()).append("\n");
        }
        return ResponseEntity.badRequest().body(errorMessage.toString().trim());
    }
    


@ExceptionHandler(MethodArgumentTypeMismatchException.class)
public ResponseEntity<String> handleTypeMismatch(MethodArgumentTypeMismatchException ex) {
   
    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid ID format: " + ex.getValue());
}

@ExceptionHandler(Exception.class)
public ResponseEntity<String> handleGeneralException(Exception ex) {
	System.out.println(ex.getMessage());
    
    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed.");
}

@ExceptionHandler(NoHandlerFoundException.class)
public ResponseEntity<?> handleNoHandlerFoundException(NoHandlerFoundException ex) {
    // Create a response with a 404 status and a JSON body
    ResponseWrapper<String> response = new ResponseWrapper<>(
        "01", // Error code
        "Endpoint not found: " + ex.getRequestURL(), // Message
        null, // No data
        null  // No additional error code
    );
    return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
}

}
