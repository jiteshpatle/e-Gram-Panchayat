package eGramPanchayat.dto;

import java.time.LocalDateTime;

public class Namuna17AgrimDilelyaRakamanchiNondvahiDTO {
    
    private Long id;

    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;
    private String remark;
    private Long employeeId;
    private String employeeName;
    private Long grampanchayatId;
    private String grampanchayatName;
    private String mahinaVaTarikh;
    private String pakshakaracheNav;
    private String agrimRakmenchaTapshil;
    private String pramanakKinvaPavatiKramank;
    private String rakkam;
    private String masikEkun;
    private String rokhParatfedApril;
    private String rokhParatfedMay;
    private String rokhParatfedJune;
    private String rokhParatfedJuly;
    private String rokhParatfedAugust;
    private String rokhParatfedSeptember;
    private String rokhParatfedOctober;
    private String rokhParatfedNovember;
    private String rokhParatfedDecember;
    private String rokhParatfedJanuary;
    private String rokhParatfedFebruary;
    private String rokhParatfedMarch;
    private String ekunParatfed;
    private String paratFedichiTarikhKinvaSamayojanPramanakachaKramank;
    private String varshachaAkherchiShillak;
    private String shera;
    private String year;
    
    
    
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public LocalDateTime getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public Long getGrampanchayatId() {
		return grampanchayatId;
	}
	public void setGrampanchayatId(Long grampanchayatId) {
		this.grampanchayatId = grampanchayatId;
	}
	public String getGrampanchayatName() {
		return grampanchayatName;
	}
	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}
	public String getMahinaVaTarikh() {
		return mahinaVaTarikh;
	}
	public void setMahinaVaTarikh(String mahinaVaTarikh) {
		this.mahinaVaTarikh = mahinaVaTarikh;
	}
	public String getPakshakaracheNav() {
		return pakshakaracheNav;
	}
	public void setPakshakaracheNav(String pakshakaracheNav) {
		this.pakshakaracheNav = pakshakaracheNav;
	}
	public String getAgrimRakmenchaTapshil() {
		return agrimRakmenchaTapshil;
	}
	public void setAgrimRakmenchaTapshil(String agrimRakmenchaTapshil) {
		this.agrimRakmenchaTapshil = agrimRakmenchaTapshil;
	}
	public String getPramanakKinvaPavatiKramank() {
		return pramanakKinvaPavatiKramank;
	}
	public void setPramanakKinvaPavatiKramank(String pramanakKinvaPavatiKramank) {
		this.pramanakKinvaPavatiKramank = pramanakKinvaPavatiKramank;
	}
	public String getRakkam() {
		return rakkam;
	}
	public void setRakkam(String rakkam) {
		this.rakkam = rakkam;
	}
	public String getMasikEkun() {
		return masikEkun;
	}
	public void setMasikEkun(String masikEkun) {
		this.masikEkun = masikEkun;
	}
	public String getRokhParatfedApril() {
		return rokhParatfedApril;
	}
	public void setRokhParatfedApril(String rokhParatfedApril) {
		this.rokhParatfedApril = rokhParatfedApril;
	}
	public String getRokhParatfedMay() {
		return rokhParatfedMay;
	}
	public void setRokhParatfedMay(String rokhParatfedMay) {
		this.rokhParatfedMay = rokhParatfedMay;
	}
	public String getRokhParatfedJune() {
		return rokhParatfedJune;
	}
	public void setRokhParatfedJune(String rokhParatfedJune) {
		this.rokhParatfedJune = rokhParatfedJune;
	}
	public String getRokhParatfedJuly() {
		return rokhParatfedJuly;
	}
	public void setRokhParatfedJuly(String rokhParatfedJuly) {
		this.rokhParatfedJuly = rokhParatfedJuly;
	}
	public String getRokhParatfedAugust() {
		return rokhParatfedAugust;
	}
	public void setRokhParatfedAugust(String rokhParatfedAugust) {
		this.rokhParatfedAugust = rokhParatfedAugust;
	}
	public String getRokhParatfedSeptember() {
		return rokhParatfedSeptember;
	}
	public void setRokhParatfedSeptember(String rokhParatfedSeptember) {
		this.rokhParatfedSeptember = rokhParatfedSeptember;
	}
	public String getRokhParatfedOctober() {
		return rokhParatfedOctober;
	}
	public void setRokhParatfedOctober(String rokhParatfedOctober) {
		this.rokhParatfedOctober = rokhParatfedOctober;
	}
	public String getRokhParatfedNovember() {
		return rokhParatfedNovember;
	}
	public void setRokhParatfedNovember(String rokhParatfedNovember) {
		this.rokhParatfedNovember = rokhParatfedNovember;
	}
	public String getRokhParatfedDecember() {
		return rokhParatfedDecember;
	}
	public void setRokhParatfedDecember(String rokhParatfedDecember) {
		this.rokhParatfedDecember = rokhParatfedDecember;
	}
	public String getRokhParatfedJanuary() {
		return rokhParatfedJanuary;
	}
	public void setRokhParatfedJanuary(String rokhParatfedJanuary) {
		this.rokhParatfedJanuary = rokhParatfedJanuary;
	}
	public String getRokhParatfedFebruary() {
		return rokhParatfedFebruary;
	}
	public void setRokhParatfedFebruary(String rokhParatfedFebruary) {
		this.rokhParatfedFebruary = rokhParatfedFebruary;
	}
	public String getRokhParatfedMarch() {
		return rokhParatfedMarch;
	}
	public void setRokhParatfedMarch(String rokhParatfedMarch) {
		this.rokhParatfedMarch = rokhParatfedMarch;
	}
	public String getEkunParatfed() {
		return ekunParatfed;
	}
	public void setEkunParatfed(String ekunParatfed) {
		this.ekunParatfed = ekunParatfed;
	}
	public String getParatFedichiTarikhKinvaSamayojanPramanakachaKramank() {
		return paratFedichiTarikhKinvaSamayojanPramanakachaKramank;
	}
	public void setParatFedichiTarikhKinvaSamayojanPramanakachaKramank(
			String paratFedichiTarikhKinvaSamayojanPramanakachaKramank) {
		this.paratFedichiTarikhKinvaSamayojanPramanakachaKramank = paratFedichiTarikhKinvaSamayojanPramanakachaKramank;
	}
	public String getVarshachaAkherchiShillak() {
		return varshachaAkherchiShillak;
	}
	public void setVarshachaAkherchiShillak(String varshachaAkherchiShillak) {
		this.varshachaAkherchiShillak = varshachaAkherchiShillak;
	}
	public String getShera() {
		return shera;
	}
	public void setShera(String shera) {
		this.shera = shera;
	}
    // Getters and Setters
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
}