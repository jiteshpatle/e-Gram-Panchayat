package eGramPanchayat.dto;

import java.time.LocalDateTime;
import jakarta.validation.constraints.Pattern;


public class Namuna32RakkamPartavyaSathiChaAdeshDTO {

    private Long id;

    //@Pattern(regexp = "^[a-zA-Z0-9]+$", message = "Employee ID can not contains special characters.")
//    @Pattern(regexp = "^[0-9]+$", message = "Employee ID can not contains special characters.")
    private String employeeId;

//    @Pattern(regexp = "^[a-zA-Z0-9\\s]*$", message = "Employee Name can not contains special characters..")
    private String employeeName;

    //@Pattern(regexp = "^[a-zA-Z0-9]*$", message = "Grampanchayat ID can not contains special characters.")
//    @Pattern(regexp = "^[0-9]*$", message = "Grampanchayat ID can not contains special characters.")
    private String gramPanchayatId;

//    @Pattern(regexp = "^[a-zA-Z\\s]+$", message = "Grampanchayat name can not contains special characters.")
    private String gramPanchayatName;

//    private String year;

    @Pattern(regexp = "^[0-9 0-9\u0966-\u096F\\s.]+$", message = "Pavti Namuber can not contains special characters.")
    private String pavtiNumber;

    private String dileliMulRakkamDate;

    @Pattern(regexp = "^[0-9\u0966-\u096F .]+$", message = "Rakkam can not contains special characters.")
    private String rakkam;
    @Pattern(regexp = "^[0-9\u0966-\u096F .]+$", message = "Parat Karyachi Rakkam can not contains special characters.")
    private String paratKaryachiRakkam;

    @Pattern(regexp = "^[\\u0900-\\u097F a-zA-Z\\s0-9]*$", message = "Thevi Darache Nav can not contains special characters.")
    private String thevidaracheNav;
    @Pattern(regexp = "^[\\u0900-\\u097F a-zA-Z\\s0-9]*$", message = "Partava Karnarya Pradhikaryache Nav can not contains special characters.")
    private String partavaKarnaryaPradhikaryacheNav;

    @Pattern(regexp = "^[\\u0900-\\u097F a-zA-Z\\s]*$", message = "Shera can not contains special characters.")
    private String shera;
    private String dinank;

    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;

    // Getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getGramPanchayatId() {
        return gramPanchayatId;
    }

    public void setGramPanchayatId(String gramPanchayatId) {
        this.gramPanchayatId = gramPanchayatId;
    }

    public String getGramPanchayatName() {
        return gramPanchayatName;
    }

    public void setGramPanchayatName(String gramPanchayatName) {
        this.gramPanchayatName = gramPanchayatName;
    }

//    public String getYear() {
//        return year;
//    }
//
//    public void setYear(String year) {
//        this.year = year;
//    }

    public String getPavtiNumber() {
        return pavtiNumber;
    }

    public void setPavtiNumber(String pavtiNumber) {
        this.pavtiNumber = pavtiNumber;
    }

    public String getDileliMulRakkamDate() {
        return dileliMulRakkamDate;
    }

    public void setDileliMulRakkamDate(String dileliMulRakkamDate) {
        this.dileliMulRakkamDate = dileliMulRakkamDate;
    }

    public String getRakkam() {
        return rakkam;
    }

    public void setRakkam(String rakkam) {
        this.rakkam = rakkam;
    }

    public String getParatKaryachiRakkam() {
        return paratKaryachiRakkam;
    }

    public void setParatKaryachiRakkam(String paratKaryachiRakkam) {
        this.paratKaryachiRakkam = paratKaryachiRakkam;
    }

    public String getThevidaracheNav() {
        return thevidaracheNav;
    }

    public void setThevidaracheNav(String thevidaracheNav) {
        this.thevidaracheNav = thevidaracheNav;
    }

    public String getPartavaKarnaryaPradhikaryacheNav() {
        return partavaKarnaryaPradhikaryacheNav;
    }

    public void setPartavaKarnaryaPradhikaryacheNav(String partavaKarnaryaPradhikaryacheNav) {
        this.partavaKarnaryaPradhikaryacheNav = partavaKarnaryaPradhikaryacheNav;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getShera() {
        return shera;
    }

    public void setShera(String shera) {
        this.shera = shera;
    }

    public String getDinank() {
        return dinank;
    }

    public void setDinank(String dinank) {
        this.dinank = dinank;
    }
}
