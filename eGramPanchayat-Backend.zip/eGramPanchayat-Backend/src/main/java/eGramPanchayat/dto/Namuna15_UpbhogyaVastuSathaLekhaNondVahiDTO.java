package eGramPanchayat.dto;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;

public class Namuna15_UpbhogyaVastuSathaLekhaNondVahiDTO {

    private long id;
    private String employeeId;
    private String employeeName;
    private String grampanchayatId;
    private String grampanchayatName;
    private String shera;
    private String tarikh;
    private String aarambhichiShillak;
    private String milaleliSankhyaKinvaPariman;
    private String ekun;
    private String konasDile;
    private String kontyaKarnasathiDile;
    private String dilelyaJinsachiSankhyaKinvaPariman;
    private String shillak;
    private String vastuDenaryaAdhikaryacheNav;
    private String date;
    private String year;
    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;

    // Getters and Setters
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getGrampanchayatId() {
        return grampanchayatId;
    }

    public void setGrampanchayatId(String grampanchayatId) {
        this.grampanchayatId = grampanchayatId;
    }

    public String getGrampanchayatName() {
        return grampanchayatName;
    }

    public void setGrampanchayatName(String grampanchayatName) {
        this.grampanchayatName = grampanchayatName;
    }

    public String getShera() {
        return shera;
    }

    public void setShera(String shera) {
        this.shera = shera;
    }

    public String getTarikh() {
        return tarikh;
    }

    public void setTarikh(String tarikh) {
        this.tarikh = tarikh;
    }

    public String getAarambhichiShillak() {
        return aarambhichiShillak;
    }

    public void setAarambhichiShillak(String aarambhichiShillak) {
        this.aarambhichiShillak = aarambhichiShillak;
    }

    public String getMilaleliSankhyaKinvaPariman() {
        return milaleliSankhyaKinvaPariman;
    }

    public void setMilaleliSankhyaKinvaPariman(String milaleliSankhyaKinvaPariman) {
        this.milaleliSankhyaKinvaPariman = milaleliSankhyaKinvaPariman;
    }

    public String getEkun() {
        return ekun;
    }

    public void setEkun(String ekun) {
        this.ekun = ekun;
    }

    public String getKonasDile() {
        return konasDile;
    }

    public void setKonasDile(String konasDile) {
        this.konasDile = konasDile;
    }

    public String getKontyaKarnasathiDile() {
        return kontyaKarnasathiDile;
    }

    public void setKontyaKarnasathiDile(String kontyaKarnasathiDile) {
        this.kontyaKarnasathiDile = kontyaKarnasathiDile;
    }

    public String getDilelyaJinsachiSankhyaKinvaPariman() {
        return dilelyaJinsachiSankhyaKinvaPariman;
    }

    public void setDilelyaJinsachiSankhyaKinvaPariman(String dilelyaJinsachiSankhyaKinvaPariman) {
        this.dilelyaJinsachiSankhyaKinvaPariman = dilelyaJinsachiSankhyaKinvaPariman;
    }

    public String getShillak() {
        return shillak;
    }

    public void setShillak(String shillak) {
        this.shillak = shillak;
    }

    public String getVastuDenaryaAdhikaryacheNav() {
        return vastuDenaryaAdhikaryacheNav;
    }

    public void setVastuDenaryaAdhikaryacheNav(String vastuDenaryaAdhikaryacheNav) {
        this.vastuDenaryaAdhikaryacheNav = vastuDenaryaAdhikaryacheNav;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}
}
