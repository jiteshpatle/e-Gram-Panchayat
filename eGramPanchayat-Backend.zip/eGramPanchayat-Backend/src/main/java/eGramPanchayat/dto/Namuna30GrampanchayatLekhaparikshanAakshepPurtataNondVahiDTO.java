package eGramPanchayat.dto;

import java.time.LocalDateTime;
import jakarta.validation.constraints.Pattern;

public class Namuna30GrampanchayatLekhaparikshanAakshepPurtataNondVahiDTO {
	private Long id;

	// @Pattern(regexp = "^[0-9]+$", message = "Employee Id can not contain special
	// character")
	private String employeeId;

	// @Pattern(regexp = "^[a-zA-Z ]+$", message = "Employee Name can not contain
	// special character")
	private String employeeName;

	// @Pattern(regexp = "^[0-9]+$", message = "Gram Panchayat Id can not contain
	// special character")
	private String gramPanchayatId;

	// @Pattern(regexp = "^[a-zA-Z\\s]+$", message = "Gram Panchayat Name can not
	// contain special character")
	private String gramPanchayatName;

	// --------^[\u0900-\u097F0-9\s]+$

	@Pattern(regexp = "^[\u0966-\u096F0-9 -]+$", message = "Ahwalatil Akshepanchi Varsh can not contain special character")
	private String lekhParikshanAhwalVarsh;

	private String lPAhwalPraptaJhalyachiDinank;

	@Pattern(regexp = "^[\u0966-\u096F0-9]+$", message = "Ahwalatil Akshepanchi Sankhya can not contain special character")
	private String ahwalatilAkshepanchiSankhya;

	@Pattern(regexp = "^[\u0966-\u096F0-9]+$", message = "Ahwalatil Akshepanchi Anu Kramank can not contain special character")
	private String ahwalatilAkshepanchiAnuKramank;

	@Pattern(regexp = "^[\u0966-\u096F0-9]+$", message = "Keval Mahitisathi Asanara Akshep Kramank can not contain special character")
	private String kMAsanaraAkshepKramank;

	@Pattern(regexp = "^[\u0966-\u096F0-9]+$", message = "Keval Mahitisathi Asanara Akshep Sankhya can not contain special character")
	private String kMAsanaraAkshepSankhya;

	@Pattern(regexp = "^[\u0966-\u096F0-9]+$", message = "Purtata Karvyachya Akshepanche Kramank can not contain special character")
	private String purtataKarvyachyaAkshepancheKramank;

	@Pattern(regexp = "^[\u0966-\u096F0-9]+$", message = "Purtata Karvyachya Akshepanche Sankhya can not contain special character")
	private String purtataKarvyachyaAkshepancheSankhya;

	@Pattern(regexp = "^[\u0966-\u096F0-9]+$", message = "Grampanchyat Purtata Kelele Akshepanche can not contain special character")
	private String gpPAkshepancheKramank;

	@Pattern(regexp = "^[\u0966-\u096F0-9]+$", message = "Grampanchyat Purtata Kelele Akshepanche can not contain special character")
	private String gpPKeleleAkshepancheSankhya;

	private String pKAPSamitiKadePathvilaJavakDinank;

	@Pattern(regexp = "^[\u0966-\u096F0-9]+$", message = "Purtata Kelele Akshep Panchyat Samiti Kade Pavti Kramank can not contain special character")
	private String pKAPtSamitiKadePathvilakramank;

	@Pattern(regexp = "^[\u0966-\u096F0-9]+$", message = "Purtata Kelele Akshep Panchyat Samitine JP Kade Pathvalycha Thrav Kramank can not contain special character")
	private String pKAPSamitineJPKadePathvalaThravKrmank;

	@Pattern(regexp = "^[\u0966-\u096F0-9]+$", message = "Purtata Kelele Akshep Panchyat Samitine Pathvalycha Javak Kramank can not contain special character")
	private String pKAPSamitineJPKadePathvalychaJavakKrmank;

	private String pKAPSamitineJPKadePathvalychaDinank;

	@Pattern(regexp = "^[\u0966-\u096F0-9]+$", message = "Jilha Parishad Yani Manjur Kelele Akshep Kramank can not contain special character")
	private String jPYaniManjurKeleleAkshepKramank;

	@Pattern(regexp = "^[\u0966-\u096F0-9]+$", message = "Jilha Parishad Yani Manjur Kelele Akshep Sankya can not contain special character")
	private String jPYaniManjurKeleleAkshepSankya;

	@Pattern(regexp = "[\u0900-\u097FA-Za-z]+$", message = "Shillak Aakshepanchi Vargawari va Karmank Pustaki Samayojan can not contain special character")
	private String sAVVKramankPustakiSamayojan;

	@Pattern(regexp = "^[\u0966-\u096F0-9]+$", message = "Shillak Aakshepanchi Vargawari va vasuli must can not contain special character")
	private String sAVVKramankVasuli;

	@Pattern(regexp = "[\u0900-\u097FA-Za-z]+$", message = "Shillak Aakshepanchi Vargawari va Mulyankan can not contain special character")
	private String sAVVKramankMulyankan;

	@Pattern(regexp = "[\u0900-\u097FA-Za-z\\s]+$", message = "Shillak Aakshepanchi Vargawari va Karmank Niyambahya can not contain special character")
	private String sAVVKramankNiyambahya;

	@Pattern(regexp = "^[\u0966-\u096F0-9]+$", message = "Shillak Aakshepanchi Vargawari va Karmank Ekun can not contain special character")
	private String sAVVKramankEkun;

	private String dinank;

	@Pattern(regexp = "[\u0900-\u097FA-Za-z\\s]+$", message = "Shera can not contain special character")
	private String shera;

	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Remark can not contain
	// special character")
	// private String remark;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getGramPanchayatId() {
		return gramPanchayatId;
	}

	public void setGramPanchayatId(String gramPanchayatId) {
		this.gramPanchayatId = gramPanchayatId;
	}

	public String getGramPanchayatName() {
		return gramPanchayatName;
	}

	public void setGramPanchayatName(String gramPanchayatName) {
		this.gramPanchayatName = gramPanchayatName;
	}

	public String getLekhParikshanAhwalVarsh() {
		return lekhParikshanAhwalVarsh;
	}

	public void setLekhParikshanAhwalVarsh(String lekhParikshanAhwalVarsh) {
		this.lekhParikshanAhwalVarsh = lekhParikshanAhwalVarsh;
	}

	public String getlPAhwalPraptaJhalyachiDinank() {
		return lPAhwalPraptaJhalyachiDinank;
	}

	public void setlPAhwalPraptaJhalyachiDinank(String lPAhwalPraptaJhalyachiDinank) {
		this.lPAhwalPraptaJhalyachiDinank = lPAhwalPraptaJhalyachiDinank;
	}

	public String getAhwalatilAkshepanchiSankhya() {
		return ahwalatilAkshepanchiSankhya;
	}

	public void setAhwalatilAkshepanchiSankhya(String ahwalatilAkshepanchiSankhya) {
		this.ahwalatilAkshepanchiSankhya = ahwalatilAkshepanchiSankhya;
	}

	public String getAhwalatilAkshepanchiAnuKramank() {
		return ahwalatilAkshepanchiAnuKramank;
	}

	public void setAhwalatilAkshepanchiAnuKramank(String ahwalatilAkshepanchiAnuKramank) {
		this.ahwalatilAkshepanchiAnuKramank = ahwalatilAkshepanchiAnuKramank;
	}

	public String getkMAsanaraAkshepKramank() {
		return kMAsanaraAkshepKramank;
	}

	public void setkMAsanaraAkshepKramank(String kMAsanaraAkshepKramank) {
		this.kMAsanaraAkshepKramank = kMAsanaraAkshepKramank;
	}

	public String getkMAsanaraAkshepSankhya() {
		return kMAsanaraAkshepSankhya;
	}

	public void setkMAsanaraAkshepSankhya(String kMAsanaraAkshepSankhya) {
		this.kMAsanaraAkshepSankhya = kMAsanaraAkshepSankhya;
	}

	public String getPurtataKarvyachyaAkshepancheKramank() {
		return purtataKarvyachyaAkshepancheKramank;
	}

	public void setPurtataKarvyachyaAkshepancheKramank(String purtataKarvyachyaAkshepancheKramank) {
		this.purtataKarvyachyaAkshepancheKramank = purtataKarvyachyaAkshepancheKramank;
	}

	public String getPurtataKarvyachyaAkshepancheSankhya() {
		return purtataKarvyachyaAkshepancheSankhya;
	}

	public void setPurtataKarvyachyaAkshepancheSankhya(String purtataKarvyachyaAkshepancheSankhya) {
		this.purtataKarvyachyaAkshepancheSankhya = purtataKarvyachyaAkshepancheSankhya;
	}

	public String getGpPAkshepancheKramank() {
		return gpPAkshepancheKramank;
	}

	public void setGpPAkshepancheKramank(String gpPAkshepancheKramank) {
		this.gpPAkshepancheKramank = gpPAkshepancheKramank;
	}

	public String getGpPKeleleAkshepancheSankhya() {
		return gpPKeleleAkshepancheSankhya;
	}

	public void setGpPKeleleAkshepancheSankhya(String gpPKeleleAkshepancheSankhya) {
		this.gpPKeleleAkshepancheSankhya = gpPKeleleAkshepancheSankhya;
	}

	public String getpKAPSamitiKadePathvilaJavakDinank() {
		return pKAPSamitiKadePathvilaJavakDinank;
	}

	public void setpKAPSamitiKadePathvilaJavakDinank(String pKAPSamitiKadePathvilaJavakDinank) {
		this.pKAPSamitiKadePathvilaJavakDinank = pKAPSamitiKadePathvilaJavakDinank;
	}

	public String getpKAPtSamitiKadePathvilakramank() {
		return pKAPtSamitiKadePathvilakramank;
	}

	public void setpKAPtSamitiKadePathvilakramank(String pKAPtSamitiKadePathvilakramank) {
		this.pKAPtSamitiKadePathvilakramank = pKAPtSamitiKadePathvilakramank;
	}

	public String getpKAPSamitineJPKadePathvalaThravKrmank() {
		return pKAPSamitineJPKadePathvalaThravKrmank;
	}

	public void setpKAPSamitineJPKadePathvalaThravKrmank(String pKAPSamitineJPKadePathvalaThravKrmank) {
		this.pKAPSamitineJPKadePathvalaThravKrmank = pKAPSamitineJPKadePathvalaThravKrmank;
	}

	public String getpKAPSamitineJPKadePathvalychaJavakKrmank() {
		return pKAPSamitineJPKadePathvalychaJavakKrmank;
	}

	public void setpKAPSamitineJPKadePathvalychaJavakKrmank(String pKAPSamitineJPKadePathvalychaJavakKrmank) {
		this.pKAPSamitineJPKadePathvalychaJavakKrmank = pKAPSamitineJPKadePathvalychaJavakKrmank;
	}

	public String getpKAPSamitineJPKadePathvalychaDinank() {
		return pKAPSamitineJPKadePathvalychaDinank;
	}

	public void setpKAPSamitineJPKadePathvalychaDinank(String pKAPSamitineJPKadePathvalychaDinank) {
		this.pKAPSamitineJPKadePathvalychaDinank = pKAPSamitineJPKadePathvalychaDinank;
	}

	public String getjPYaniManjurKeleleAkshepKramank() {
		return jPYaniManjurKeleleAkshepKramank;
	}

	public void setjPYaniManjurKeleleAkshepKramank(String jPYaniManjurKeleleAkshepKramank) {
		this.jPYaniManjurKeleleAkshepKramank = jPYaniManjurKeleleAkshepKramank;
	}

	public String getjPYaniManjurKeleleAkshepSankya() {
		return jPYaniManjurKeleleAkshepSankya;
	}

	public void setjPYaniManjurKeleleAkshepSankya(String jPYaniManjurKeleleAkshepSankya) {
		this.jPYaniManjurKeleleAkshepSankya = jPYaniManjurKeleleAkshepSankya;
	}

	public String getsAVVKramankPustakiSamayojan() {
		return sAVVKramankPustakiSamayojan;
	}

	public void setsAVVKramankPustakiSamayojan(String sAVVKramankPustakiSamayojan) {
		this.sAVVKramankPustakiSamayojan = sAVVKramankPustakiSamayojan;
	}

	public String getsAVVKramankVasuli() {
		return sAVVKramankVasuli;
	}

	public void setsAVVKramankVasuli(String sAVVKramankVasuli) {
		this.sAVVKramankVasuli = sAVVKramankVasuli;
	}

	public String getsAVVKramankMulyankan() {
		return sAVVKramankMulyankan;
	}

	public void setsAVVKramankMulyankan(String sAVVKramankMulyankan) {
		this.sAVVKramankMulyankan = sAVVKramankMulyankan;
	}

	public String getsAVVKramankNiyambahya() {
		return sAVVKramankNiyambahya;
	}

	public void setsAVVKramankNiyambahya(String sAVVKramankNiyambahya) {
		this.sAVVKramankNiyambahya = sAVVKramankNiyambahya;
	}

	public String getsAVVKramankEkun() {
		return sAVVKramankEkun;
	}

	public void setsAVVKramankEkun(String sAVVKramankEkun) {
		this.sAVVKramankEkun = sAVVKramankEkun;
	}

	public String getShera() {
		return shera;
	}

	public void setShera(String shera) {
		this.shera = shera;
	}

	// public String getRemark() {
	// return remark;
	// }
	//
	// public void setRemark(String remark) {
	// this.remark = remark;
	// }

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getDinank() {
		return dinank;
	}

	public void setDinank(String dinank) {
		this.dinank = dinank;
	}

}
