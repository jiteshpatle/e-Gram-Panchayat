package eGramPanchayat.dto;

import java.time.LocalDateTime;

public class Namuna06JamaRakmanchiNondvahiDto {
    private Long id;
    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;
    private Long employeeId;
    private String employeeName;
    private Long grampanchayatId;
    private String grampanchayatName;
    private String lekhaShirsh;
    private String shera;
    private String arthsankalpiyaAnudan;
    private String mahinyaBaddalchiEkunRakkam;
    private String maghilMahinyachaAkherparyantchiRakkam;
    private String maghePasunPudheChaluEkunRakkam;
    private String day;
    private String value;
    private String month;
    private String year;
    
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public LocalDateTime getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}
	public Long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public Long getGrampanchayatId() {
		return grampanchayatId;
	}
	public void setGrampanchayatId(Long grampanchayatId) {
		this.grampanchayatId = grampanchayatId;
	}
	public String getGrampanchayatName() {
		return grampanchayatName;
	}
	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}
	public String getLekhaShirsh() {
		return lekhaShirsh;
	}
	public void setLekhaShirsh(String lekhaShirsh) {
		this.lekhaShirsh = lekhaShirsh;
	}
	public String getShera() {
		return shera;
	}
	public void setShera(String shera) {
		this.shera = shera;
	}
	public String getArthsankalpiyaAnudan() {
		return arthsankalpiyaAnudan;
	}
	public void setArthsankalpiyaAnudan(String arthsankalpiyaAnudan) {
		this.arthsankalpiyaAnudan = arthsankalpiyaAnudan;
	}
	public String getMahinyaBaddalchiEkunRakkam() {
		return mahinyaBaddalchiEkunRakkam;
	}
	public void setMahinyaBaddalchiEkunRakkam(String mahinyaBaddalchiEkunRakkam) {
		this.mahinyaBaddalchiEkunRakkam = mahinyaBaddalchiEkunRakkam;
	}
	public String getMaghilMahinyachaAkherparyantchiRakkam() {
		return maghilMahinyachaAkherparyantchiRakkam;
	}
	public void setMaghilMahinyachaAkherparyantchiRakkam(String maghilMahinyachaAkherparyantchiRakkam) {
		this.maghilMahinyachaAkherparyantchiRakkam = maghilMahinyachaAkherparyantchiRakkam;
	}
	public String getMaghePasunPudheChaluEkunRakkam() {
		return maghePasunPudheChaluEkunRakkam;
	}
	public void setMaghePasunPudheChaluEkunRakkam(String maghePasunPudheChaluEkunRakkam) {
		this.maghePasunPudheChaluEkunRakkam = maghePasunPudheChaluEkunRakkam;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}

    // Getters and Setters
    // ...
}
