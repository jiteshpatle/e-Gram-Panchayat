package eGramPanchayat.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

public class GrampanchayatNamuna26KhaaDto {

	Long id;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@NotNull(message = "Mahina cannot be null.")
	@NotBlank(message = "Mahina cannot be empty.")
	// @Pattern(regexp = "^[^@]*$", message = "Mahina cannot contain the @
	// character.")
	private String mahina;

	// @NotNull(message = "Praarabhit Shillak cannot be null.")
	// @NotBlank(message = "Praarabhit Shillak cannot be empty.")
	// @Pattern(regexp = "^[^@]*$", message = "Praarabhit Shillak cannot contain the
	// @ character.")
	private String praarabhitShillak;

	// @NotNull(message = "Rakam Jama Kileyacha Mahina cannot be null.")
	// @NotBlank(message = "Rakam Jama Kileyacha Mahina cannot be empty.")
	// @Pattern(regexp = "^[^@]*$", message = "Rakam Jama Kileyacha Mahina cannot
	// contain the @ character.")
	private String rakamJamaKileyachaMahina;

	@NotNull(message = "Mahina Aakhrichi Shillak Sachivakdila cannot be null.")
	@NotBlank(message = "Mahina Aakhrichi Shillak Sachivakdila cannot be empty.")
	// @Pattern(regexp = "^[u0900-u097F0-9 . ]*$", message = "Mahina Aakhrichi
	// Shillak Sachivakdila cannot contain the @ character.")
	private String mahinaAakhrichiShillakSachivakdila;

	// @NotNull(message = "Mahina Aakhrichi Shillak Banketila cannot be null.")
	// @NotBlank(message = "Mahina Aakhrichi Shillak Banketila cannot be empty.")
	// @Pattern(regexp = "^[^@]*$", message = "Mahina Aakhrichi Shillak Banketila
	// cannot contain the @ character.")
	private String mahinaAakhrichiShillakBanketila;

	// @NotNull(message = "Mahina Aakhrichi Shillak Postateil cannot be null.")
	// @NotBlank(message = "Mahina Aakhrichi Shillak Postateil cannot be empty.")
	// @Pattern(regexp = "^[^@]*$", message = "Mahina Aakhrichi Shillak Postateil
	// cannot contain the @ character.")
	private String mahinaAakhrichiShillakPostateil;

	// @NotNull(message = "Alpabachat Pramanapatrata Guntviloli Rakam cannot be
	// null.")
	// @NotBlank(message = "Alpabachat Pramanapatrata Guntviloli Rakam cannot be
	// empty.")
	// @Pattern(regexp = "^[^@]*$", message = "Alpabachat Pramanapatrata Guntviloli
	// Rakam cannot contain the @ character.")
	private String alpabachatPramanapatrataGuntviloliRakam;

	// @NotNull(message = "Banketa Mudata Thevita Guntavilili Rakam cannot be
	// null.")
	// @NotBlank(message = "Banketa Mudata Thevita Guntavilili Rakam cannot be
	// empty.")
	// @Pattern(regexp = "^[^@]*$", message = "Banketa Mudata Thevita Guntavilili
	// Rakam cannot contain the @ character.")
	private String banketaMudataThevitaGuntavililiRakam;

	// public @NotNull(message = "Cash cannot be null.") @NotBlank(message = "Cash
	// cannot be empty.") @Pattern(regexp = "^[^@]*$", message = "Cash cannot
	// contain the @ character.") String getCash() {
	// return cash;
	// }
	//
	// public void setCash(@NotNull(message = "Cash cannot be null.")
	// @NotBlank(message = "Cash cannot be empty.") @Pattern(regexp = "^[^@]*$",
	// message = "Cash cannot contain the @ character.") String cash) {
	// this.cash = cash;
	// }

	// @NotNull(message = "Ekun cannot be null.")
	// @NotBlank(message = "Ekun cannot be empty.")
	// @Pattern(regexp = "^[^@]*$", message = "Ekun cannot contain the @
	// character.")
	private String ekun;

	// @NotNull(message = "Shora Niyamapesha Jasata Rakam cannot be null.")
	// @NotBlank(message = "Shora Niyamapesha Jasata Rakam cannot be empty.")
	// @Pattern(regexp = "^[^@]*$", message = "Shora Niyamapesha Jasata Rakam cannot
	// contain the @ character.")
	// private String shoraNiyamapeshaJasataRakam;

	// @NotNull(message = "Employee ID cannot be null.")
	private String employeeId;

	// @NotNull(message = "Create Date cannot be null.")
	private LocalDateTime createDate;

	// @NotNull(message = "Updated Date cannot be null.")
	private LocalDateTime updatedDate;

	// @NotNull(message = "Grampanchyat ID cannot be null.")
	private String grampanchyatId;

	// @NotNull(message = "Employee Name cannot be null.")
	// @NotBlank(message = "Employee Name cannot be empty.")
	// @Pattern(regexp = "^[^@]*$", message = "Employee Name cannot contain the @
	// character.")
	private String employeeName;

	// @NotNull(message = "Grampanchyat Name cannot be null.")
	// @NotBlank(message = "Grampanchyat Name cannot be empty.")
	// @Pattern(regexp = "^[^@]*$", message = "Grampanchyat Name cannot contain the
	// @ character.")
	private String grampanchyatName;

	// @NotNull(message = "Year cannot be null.")
	// @NotBlank(message = "Year cannot be empty.")
	// @Pattern(regexp = "^[0-9]+$", message = "Field must contain only digits.")
	// private String Year;

	// @NotNull(message = "Shear cannot be null.")
	// @NotBlank(message = "Shear cannot be empty.")
	// @Pattern(regexp = "^[^@]*$", message = "Field must contain only digits.")
	private String shera;

	private String dinank;

	public String getShera() {
		return shera;
	}

	public void setShera(String shera) {
		this.shera = shera;
	}

	// public String getYear() {
	// return Year;
	// }
	//
	// public void setYear(String year) {
	// Year = year;
	// }

	public String getMahina() {
		return mahina;
	}

	public void setMahina(String mahina) {
		this.mahina = mahina;
	}

	public String getPraarabhitShillak() {
		return praarabhitShillak;
	}

	public void setPraarabhitShillak(String praarabhitShillak) {
		this.praarabhitShillak = praarabhitShillak;
	}

	public String getRakamJamaKileyachaMahina() {
		return rakamJamaKileyachaMahina;
	}

	public void setRakamJamaKileyachaMahina(String rakamJamaKileyachaMahina) {
		this.rakamJamaKileyachaMahina = rakamJamaKileyachaMahina;
	}

	public LocalDateTime getCreateDate() {
		return createDate;
	}

	public void setCreateDate(LocalDateTime createDate) {
		this.createDate = createDate;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getMahinaAakhrichiShillakBanketila() {
		return mahinaAakhrichiShillakBanketila;
	}

	public void setMahinaAakhrichiShillakBanketila(String mahinaAakhrichiShillakBanketila) {
		this.mahinaAakhrichiShillakBanketila = mahinaAakhrichiShillakBanketila;
	}

	public String getMahinaAakhrichiShillakPostateil() {
		return mahinaAakhrichiShillakPostateil;
	}

	public void setMahinaAakhrichiShillakPostateil(String mahinaAakhrichiShillakPostateil) {
		this.mahinaAakhrichiShillakPostateil = mahinaAakhrichiShillakPostateil;
	}

	public String getAlpabachatPramanapatrataGuntviloliRakam() {
		return alpabachatPramanapatrataGuntviloliRakam;
	}

	public void setAlpabachatPramanapatrataGuntviloliRakam(String alpabachatPramanapatrataGuntviloliRakam) {
		this.alpabachatPramanapatrataGuntviloliRakam = alpabachatPramanapatrataGuntviloliRakam;
	}

	public String getBanketaMudataThevitaGuntavililiRakam() {
		return banketaMudataThevitaGuntavililiRakam;
	}

	public void setBanketaMudataThevitaGuntavililiRakam(String banketaMudataThevitaGuntavililiRakam) {
		this.banketaMudataThevitaGuntavililiRakam = banketaMudataThevitaGuntavililiRakam;
	}

	public String getEkun() {
		return ekun;
	}

	public void setEkun(String ekun) {
		this.ekun = ekun;
	}

	// public String getShoraNiyamapeshaJasataRakam() {
	// return shoraNiyamapeshaJasataRakam;
	// }
	//
	// public void setShoraNiyamapeshaJasataRakam(String
	// shoraNiyamapeshaJasataRakam) {
	// this.shoraNiyamapeshaJasataRakam = shoraNiyamapeshaJasataRakam;
	// }

	

	public String getEmployeeName() {
		return employeeName;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getGrampanchyatId() {
		return grampanchyatId;
	}

	public void setGrampanchyatId(String grampanchyatId) {
		this.grampanchyatId = grampanchyatId;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getGrampanchyatName() {
		return grampanchyatName;
	}

	public void setGrampanchyatName(String grampanchyatName) {
		this.grampanchyatName = grampanchyatName;
	}

	public String getMahinaAakhrichiShillakSachivakdila() {
		return mahinaAakhrichiShillakSachivakdila;
	}

	public void setMahinaAakhrichiShillakSachivakdila(String mahinaAakhrichiShillakSachivakdila) {
		this.mahinaAakhrichiShillakSachivakdila = mahinaAakhrichiShillakSachivakdila;
	}

	public String getDinank() {
		return dinank;
	}

	public void setDinank(String dinank) {
		this.dinank = dinank;
	}

	//
	
}
