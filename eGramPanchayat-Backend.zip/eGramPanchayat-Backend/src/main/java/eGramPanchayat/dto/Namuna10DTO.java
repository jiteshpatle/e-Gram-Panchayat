package eGramPanchayat.dto;

import java.util.List;
import eGramPanchayat.entity.DynamicField;

public class Namuna10DTO {

    // Static fields
    private String employeeId;
    private String employeeName;
    private String gramPanchayatId;
    private String gramPanchayatName;
    private String pavtiNo;
    private String nav;
    private String year;
    private String gharNo;
    private String billNo;
    private String ekun;
    private String dinank;

    // Dynamic fields
    private List<DynamicField> items;

    // Getters and Setters
    public String getPavtiNo() {
        return pavtiNo;
    }

    public void setPavtiNo(String pavtiNo) {
        this.pavtiNo = pavtiNo;
    }

    public String getNav() {
        return nav;
    }

    public void setNav(String nav) {
        this.nav = nav;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getGharNo() {
        return gharNo;
    }

    public void setGharNo(String gharNo) {
        this.gharNo = gharNo;
    }

    public String getBillNo() {
        return billNo;
    }

    public void setBillNo(String billNo) {
        this.billNo = billNo;
    }

    

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getGramPanchayatId() {
        return gramPanchayatId;
    }

    public void setGramPanchayatId(String gramPanchayatId) {
        this.gramPanchayatId = gramPanchayatId;
    }

    public String getGramPanchayatName() {
        return gramPanchayatName;
    }

    public void setGramPanchayatName(String gramPanchayatName) {
        this.gramPanchayatName = gramPanchayatName;
    }

    public String getDinank() {
        return dinank;
    }

    public void setDinank(String dinank) {
        this.dinank = dinank;
    }

    public String getEkun() {
        return ekun;
    }

    public void setEkun(String ekun) {
        this.ekun = ekun;
    }

    public List<DynamicField> getItems() {
        return items;
    }

    public void setItems(List<DynamicField> items) {
        this.items = items;
    }

}
