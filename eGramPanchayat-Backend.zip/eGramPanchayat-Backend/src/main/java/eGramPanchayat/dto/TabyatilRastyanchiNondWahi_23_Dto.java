package eGramPanchayat.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class TabyatilRastyanchiNondWahi_23_Dto {

    private Long id;
    private String employeeId;
    private String employeeName;
    private String grampanchayatId;
    private String grampanchayatName;
    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;
	private String year;
	private String dinank;
//    private Integer anukramank;
    private String rastyacheNaaw;
    private String gaawPaasun;
    private String gaawParyant;
    private String laambiKm;
    private String rundiKm;
    private String rastyachaPrakar;
    private LocalDate purnKelyachiTarikh;
    private String pratiKmRastaTayarKarnyasAalelaKharch;
    private String durustyaChaluKharchRupaye;
    private String durustyaChaluSwarup;
    private String durustyaWisheshKharchRupaye;
    private String durustyaWisheshSwarup;
    private String durustyaMulBandhkamKharchRupaye;
    private String durustyaMulBandhkamSwarup;
    private String shera;
//    private String malmattechiPadtalniSarpanchSachivSahya;

    // Getters and Setters
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getGrampanchayatId() {
		return grampanchayatId;
	}

	public void setGrampanchayatId(String grampanchayatId) {
		this.grampanchayatId = grampanchayatId;
	}

	public String getGrampanchayatName() {
		return grampanchayatName;
	}

	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getRastyacheNaaw() {
		return rastyacheNaaw;
	}

	public void setRastyacheNaaw(String rastyacheNaaw) {
		this.rastyacheNaaw = rastyacheNaaw;
	}

	public String getGaawPaasun() {
		return gaawPaasun;
	}

	public void setGaawPaasun(String gaawPaasun) {
		this.gaawPaasun = gaawPaasun;
	}

	public String getGaawParyant() {
		return gaawParyant;
	}

	public void setGaawParyant(String gaawParyant) {
		this.gaawParyant = gaawParyant;
	}


	public String getRastyachaPrakar() {
		return rastyachaPrakar;
	}

	public void setRastyachaPrakar(String rastyachaPrakar) {
		this.rastyachaPrakar = rastyachaPrakar;
	}

	public LocalDate getPurnKelyachiTarikh() {
		return purnKelyachiTarikh;
	}

	public void setPurnKelyachiTarikh(LocalDate purnKelyachiTarikh) {
		this.purnKelyachiTarikh = purnKelyachiTarikh;
	}

	public String getDurustyaChaluSwarup() {
		return durustyaChaluSwarup;
	}

	public void setDurustyaChaluSwarup(String durustyaChaluSwarup) {
		this.durustyaChaluSwarup = durustyaChaluSwarup;
	}

	public String getDurustyaWisheshSwarup() {
		return durustyaWisheshSwarup;
	}

	public void setDurustyaWisheshSwarup(String durustyaWisheshSwarup) {
		this.durustyaWisheshSwarup = durustyaWisheshSwarup;
	}

	public String getDurustyaMulBandhkamSwarup() {
		return durustyaMulBandhkamSwarup;
	}

	public void setDurustyaMulBandhkamSwarup(String durustyaMulBandhkamSwarup) {
		this.durustyaMulBandhkamSwarup = durustyaMulBandhkamSwarup;
	}

	public String getShera() {
		return shera;
	}

	public void setShera(String shera) {
		this.shera = shera;
	}

	public String getDurustyaChaluKharchRupaye() {
		return durustyaChaluKharchRupaye;
	}

	public void setDurustyaChaluKharchRupaye(String durustyaChaluKharchRupaye) {
		this.durustyaChaluKharchRupaye = durustyaChaluKharchRupaye;
	}

	public String getDurustyaMulBandhkamKharchRupaye() {
		return durustyaMulBandhkamKharchRupaye;
	}

	public void setDurustyaMulBandhkamKharchRupaye(String durustyaMulBandhkamKharchRupaye) {
		this.durustyaMulBandhkamKharchRupaye = durustyaMulBandhkamKharchRupaye;
	}

	public String getDurustyaWisheshKharchRupaye() {
		return durustyaWisheshKharchRupaye;
	}

	public void setDurustyaWisheshKharchRupaye(String durustyaWisheshKharchRupaye) {
		this.durustyaWisheshKharchRupaye = durustyaWisheshKharchRupaye;
	}

	public String getLaambiKm() {
		return laambiKm;
	}

	public void setLaambiKm(String laambiKm) {
		this.laambiKm = laambiKm;
	}

	public String getPratiKmRastaTayarKarnyasAalelaKharch() {
		return pratiKmRastaTayarKarnyasAalelaKharch;
	}

	public void setPratiKmRastaTayarKarnyasAalelaKharch(String pratiKmRastaTayarKarnyasAalelaKharch) {
		this.pratiKmRastaTayarKarnyasAalelaKharch = pratiKmRastaTayarKarnyasAalelaKharch;
	}

	public String getRundiKm() {
		return rundiKm;
	}

	public void setRundiKm(String rundiKm) {
		this.rundiKm = rundiKm;
	}

	public String getDinank() {
		return dinank;
	}

	public void setDinank(String dinank) {
		this.dinank = dinank;
	}
	
}