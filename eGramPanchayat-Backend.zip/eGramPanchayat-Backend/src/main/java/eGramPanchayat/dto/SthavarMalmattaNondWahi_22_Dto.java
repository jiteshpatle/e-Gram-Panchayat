package eGramPanchayat.dto;


import java.time.LocalDateTime;

public class SthavarMalmattaNondWahi_22_Dto {


    private Long id;
    private String employeeId;
    private String employeeName;
    private String grampanchayatId;
    private String grampanchayatName;
    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;
    private String sanpadanchiKharediKinwaUbharnichaDinank;
    private String jAMSamKTyaadeshacheVPanchTharKramank;
    private String jAMSamKTyaadeshacheVPanchTharDinak;
    private String malmattechaBhumapanKramank;
    private String malmattechaBhumapanMalmattecheVarnan;
    private String konatyaKarnaSaathiWaparKela;
    private String ubharniKinwaSampadanachaKharch;
    private String durustyawarKinwaFerfaravarDinank;
    private String durustyawarKinwaFerfaravarChaluDurustyaRupaye;
    private String durustyawarKinwaFerfaravarWisheshDurustyaRupaye;
    private String durustyawarKinwaFerfaravarMulBandhKaamRupaye;
    private String durustyawarKinwaFerfaravarMulBandhkaamcheSwarup;
    private String warshaAkherisGhatleliKinmat;
    private String malmattechiVilhewatKramank;
    private String malmattechiVilhewatDinank;
    private String malmattechiVilhewatKalam55Kramank;
    private String malmattechiVilhewatKalam55Dinank;
    private String shera;
    private String dinank;

    //    @Column(name = "sarpanch_wa_sachiv_yanchi_aadhyakshari")
//    private String sarpanchVaSachivYanchiAadhyakshari;


    // Getters and Setters

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public String getDurustyawarKinwaFerfaravarChaluDurustyaRupaye() {
        return durustyawarKinwaFerfaravarChaluDurustyaRupaye;
    }

    public void setDurustyawarKinwaFerfaravarChaluDurustyaRupaye(String durustyawarKinwaFerfaravarChaluDurustyaRupaye) {
        this.durustyawarKinwaFerfaravarChaluDurustyaRupaye = durustyawarKinwaFerfaravarChaluDurustyaRupaye;
    }

    public String getDurustyawarKinwaFerfaravarMulBandhkaamcheSwarup() {
        return durustyawarKinwaFerfaravarMulBandhkaamcheSwarup;
    }

    public void setDurustyawarKinwaFerfaravarMulBandhkaamcheSwarup(String durustyawarKinwaFerfaravarMulBandhkaamcheSwarup) {
        this.durustyawarKinwaFerfaravarMulBandhkaamcheSwarup = durustyawarKinwaFerfaravarMulBandhkaamcheSwarup;
    }

    public String getDurustyawarKinwaFerfaravarMulBandhKaamRupaye() {
        return durustyawarKinwaFerfaravarMulBandhKaamRupaye;
    }

    public void setDurustyawarKinwaFerfaravarMulBandhKaamRupaye(String durustyawarKinwaFerfaravarMulBandhKaamRupaye) {
        this.durustyawarKinwaFerfaravarMulBandhKaamRupaye = durustyawarKinwaFerfaravarMulBandhKaamRupaye;
    }

    public String getDurustyawarKinwaFerfaravarWisheshDurustyaRupaye() {
        return durustyawarKinwaFerfaravarWisheshDurustyaRupaye;
    }

    public void setDurustyawarKinwaFerfaravarWisheshDurustyaRupaye(String durustyawarKinwaFerfaravarWisheshDurustyaRupaye) {
        this.durustyawarKinwaFerfaravarWisheshDurustyaRupaye = durustyawarKinwaFerfaravarWisheshDurustyaRupaye;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getGrampanchayatId() {
        return grampanchayatId;
    }

    public void setGrampanchayatId(String grampanchayatId) {
        this.grampanchayatId = grampanchayatId;
    }

    public String getGrampanchayatName() {
        return grampanchayatName;
    }

    public void setGrampanchayatName(String grampanchayatName) {
        this.grampanchayatName = grampanchayatName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getjAMSamKTyaadeshacheVPanchTharDinak() {
        return jAMSamKTyaadeshacheVPanchTharDinak;
    }

    public void setjAMSamKTyaadeshacheVPanchTharDinak(String jAMSamKTyaadeshacheVPanchTharDinak) {
        this.jAMSamKTyaadeshacheVPanchTharDinak = jAMSamKTyaadeshacheVPanchTharDinak;
    }

    public String getjAMSamKTyaadeshacheVPanchTharKramank() {
        return jAMSamKTyaadeshacheVPanchTharKramank;
    }

    public void setjAMSamKTyaadeshacheVPanchTharKramank(String jAMSamKTyaadeshacheVPanchTharKramank) {
        this.jAMSamKTyaadeshacheVPanchTharKramank = jAMSamKTyaadeshacheVPanchTharKramank;
    }

    public String getKonatyaKarnaSaathiWaparKela() {
        return konatyaKarnaSaathiWaparKela;
    }

    public void setKonatyaKarnaSaathiWaparKela(String konatyaKarnaSaathiWaparKela) {
        this.konatyaKarnaSaathiWaparKela = konatyaKarnaSaathiWaparKela;
    }

    public String getMalmattechaBhumapanKramank() {
        return malmattechaBhumapanKramank;
    }

    public void setMalmattechaBhumapanKramank(String malmattechaBhumapanKramank) {
        this.malmattechaBhumapanKramank = malmattechaBhumapanKramank;
    }

    public String getMalmattechaBhumapanMalmattecheVarnan() {
        return malmattechaBhumapanMalmattecheVarnan;
    }

    public void setMalmattechaBhumapanMalmattecheVarnan(String malmattechaBhumapanMalmattecheVarnan) {
        this.malmattechaBhumapanMalmattecheVarnan = malmattechaBhumapanMalmattecheVarnan;
    }

    public String getMalmattechiVilhewatDinank() {
        return malmattechiVilhewatDinank;
    }

    public void setMalmattechiVilhewatDinank(String malmattechiVilhewatDinank) {
        this.malmattechiVilhewatDinank = malmattechiVilhewatDinank;
    }

    public String getMalmattechiVilhewatKalam55Dinank() {
        return malmattechiVilhewatKalam55Dinank;
    }

    public void setMalmattechiVilhewatKalam55Dinank(String malmattechiVilhewatKalam55Dinank) {
        this.malmattechiVilhewatKalam55Dinank = malmattechiVilhewatKalam55Dinank;
    }

    public String getMalmattechiVilhewatKalam55Kramank() {
        return malmattechiVilhewatKalam55Kramank;
    }

    public void setMalmattechiVilhewatKalam55Kramank(String malmattechiVilhewatKalam55Kramank) {
        this.malmattechiVilhewatKalam55Kramank = malmattechiVilhewatKalam55Kramank;
    }

    public String getMalmattechiVilhewatKramank() {
        return malmattechiVilhewatKramank;
    }

    public void setMalmattechiVilhewatKramank(String malmattechiVilhewatKramank) {
        this.malmattechiVilhewatKramank = malmattechiVilhewatKramank;
    }

    public String getDurustyawarKinwaFerfaravarDinank() {
        return durustyawarKinwaFerfaravarDinank;
    }

    public void setDurustyawarKinwaFerfaravarDinank(String durustyawarKinwaFerfaravarDinank) {
        this.durustyawarKinwaFerfaravarDinank = durustyawarKinwaFerfaravarDinank;
    }

    public String getSanpadanchiKharediKinwaUbharnichaDinank() {
        return sanpadanchiKharediKinwaUbharnichaDinank;
    }

    public void setSanpadanchiKharediKinwaUbharnichaDinank(String sanpadanchiKharediKinwaUbharnichaDinank) {
        this.sanpadanchiKharediKinwaUbharnichaDinank = sanpadanchiKharediKinwaUbharnichaDinank;
    }

    public String getShera() {
        return shera;
    }

    public void setShera(String shera) {
        this.shera = shera;
    }

    public String getUbharniKinwaSampadanachaKharch() {
        return ubharniKinwaSampadanachaKharch;
    }

    public void setUbharniKinwaSampadanachaKharch(String ubharniKinwaSampadanachaKharch) {
        this.ubharniKinwaSampadanachaKharch = ubharniKinwaSampadanachaKharch;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getWarshaAkherisGhatleliKinmat() {
        return warshaAkherisGhatleliKinmat;
    }

    public void setWarshaAkherisGhatleliKinmat(String warshaAkherisGhatleliKinmat) {
        this.warshaAkherisGhatleliKinmat = warshaAkherisGhatleliKinmat;
    }

    public String getDinank() {
        return dinank;
    }

    public void setDinank(String dinank) {
        this.dinank = dinank;
    }



}
