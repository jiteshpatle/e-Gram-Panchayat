package eGramPanchayat.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;


import java.time.LocalDateTime;


public class Namuna33VrukshNondVihaDTO {

    private long id;

   // @Pattern(regexp = "^[^@]*$", message = "Employee Id cannot contain the @ character.")
//    @NotNull(message = "Employee Id cannot be null.")
    private String employeeid;

    //@Pattern(regexp = "^[^@]*$", message = "Employee Name cannot contain the @ character.")
//    @NotNull(message = "Employee Name cannot be null.")
//    @NotBlank(message = "Employee Name cannot be empty.")
    private String employeename;

    //@Pattern(regexp = "^[^@]*$", message = "Grampanchayat Id cannot contain the @ character.")
//    @NotNull(message = "Grampanchayat Id cannot be null.")
    private String grampanchayatid;

    //@Pattern(regexp = "^[^@]*$", message = "Grampanchayatname cannot contain the @ character.")
//    @NotNull(message = "Grampanchayatname cannot be null.")
//    @NotBlank(message = "Grampanchayatname cannot be empty.")
    private String grampanchayatname;

   // @Pattern(regexp = "^[^@]*$", message = "Shera cannot contain the @ character.")
    @NotNull(message = "Shera cannot be null.")
    @NotBlank(message = "Shera cannot be empty.")
    private String shera;


   // @Pattern(regexp = "^[^@]*$", message = "Naav cannot contain the @ character.")
    @NotNull(message = "Naav cannot be null.")
    @NotBlank(message = "Naav cannot be empty.")
    private String naav;

//    @Pattern(regexp = "^[^@]*$", message = "Vrukshkrmank cannot contain the @ character.")
    @NotNull(message = "Vrukshkrmank cannot be null.")
//    @NotBlank(message = "Vrukshkrmank cannot be empty.")
    private String vrukshkrmank;


   // @Pattern(regexp = "^[^@]*$", message = "Vrukshprakar cannot contain the @ character.")
    @NotNull(message = "Vrukshprakar cannot be null.")
    @NotBlank(message = "Vrukshprakar cannot be empty.")
    private String vrukshprakar;

   // @Pattern(regexp = "^[^@]*$", message = "Vrukshjopasnechijababdari cannot contain the @ character.")
    @NotNull(message = "Vrukshjopasnechijababdari cannot be null.")
    @NotBlank(message = "Vrukshjopasnechijababdari cannot be empty.")
    private String vrukshjopasnechijababdari;

    @NotNull(message = "Date cannot be null.")
//    @NotBlank(message = "Date cannot be empty.")

    private String date;

    private LocalDateTime currentDate;
    private LocalDateTime updatedDate;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }


    public String getEmployeename() {
        return employeename;
    }

    public void setEmployeename(String employeename) {
        this.employeename = employeename;
    }


    public String getGrampanchayatname() {
        return grampanchayatname;
    }

    public void setGrampanchayatname(String grampanchayatname) {
        this.grampanchayatname = grampanchayatname;
    }

    public String getNaav() {
        return naav;
    }

    public void setNaav(String naav) {
        this.naav = naav;
    }

    public String getVrukshprakar() {
        return vrukshprakar;
    }

    public void setVrukshprakar(String vrukshprakar) {
        this.vrukshprakar = vrukshprakar;
    }

    public String getVrukshjopasnechijababdari() {
        return vrukshjopasnechijababdari;
    }

    public void setVrukshjopasnechijababdari(String vrukshjopasnechijababdari) {
        this.vrukshjopasnechijababdari = vrukshjopasnechijababdari;
    }

    public LocalDateTime getCurrentDate() {
        return currentDate;
    }

    public void setCurrentDate(LocalDateTime currentDate) {
        this.currentDate = currentDate;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getShera() {
        return shera;
    }

    public void setShera(String shera) {
        this.shera = shera;
    }

    public  String getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid (String employeeid) {
        this.employeeid = employeeid;
    }

    public String getGrampanchayatid() {
        return grampanchayatid;
    }

    public void setGrampanchayatid(String grampanchayatid) {
        this.grampanchayatid = grampanchayatid;
    }

    public  String getVrukshkrmank() {
        return vrukshkrmank;
    }

    public void setVrukshkrmank(String vrukshkrmank) {
        this.vrukshkrmank = vrukshkrmank;
    }

}