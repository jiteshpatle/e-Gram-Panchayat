package eGramPanchayat.dto;

import java.time.LocalDateTime;

public class Namuna20KamachaAndajachiNondvahiDto {
	
	    private Long id;
	    private String employeeId;
	    private String employeeName;
	    private String grampanchayatId;
	    private String grampanchayatName;
	    private LocalDateTime createdDate;
	    private LocalDateTime updatedDate;
	    private String kramank;
	    private String nidhicheShirsh;
	    private String upaShirsh;
	    private String madheHonyachyaSambhavKharchach;
	    private String yanniKelelaAndaj;
	    private String sarvasadharanGoshwaraParinam;
	    private String sarvasadharanGoshwaraBaab;
	    private String sarvasadharanGoshwaraDarRupaye;
	    private String sarvasadharanGoshwaraPratteki;
	    private String sarvasadharanGoshwaraRakkamDashanshat;
	    private String mojmapAndajpatraKramank;
	    private String mojmapAndajpatraLaambi;
	    private String mojmapAndajpatraRundi;
	    private String mojmapAndajpatraKholi;
	    private String mojmapAndajpatraParimanDashanshat;
	    private String ekun;
	    private String year;
	    
	    
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getEmployeeId() {
			return employeeId;
		}
		public void setEmployeeId(String employeeId) {
			this.employeeId = employeeId;
		}
		public String getEmployeeName() {
			return employeeName;
		}
		public void setEmployeeName(String employeeName) {
			this.employeeName = employeeName;
		}
		public String getGrampanchayatId() {
			return grampanchayatId;
		}
		public void setGrampanchayatId(String grampanchayatId) {
			this.grampanchayatId = grampanchayatId;
		}
		public String getGrampanchayatName() {
			return grampanchayatName;
		}
		public void setGrampanchayatName(String grampanchayatName) {
			this.grampanchayatName = grampanchayatName;
		}
		public LocalDateTime getCreatedDate() {
			return createdDate;
		}
		public void setCreatedDate(LocalDateTime createdDate) {
			this.createdDate = createdDate;
		}
		public LocalDateTime getUpdatedDate() {
			return updatedDate;
		}
		public void setUpdatedDate(LocalDateTime updatedDate) {
			this.updatedDate = updatedDate;
		}
		public String getKramank() {
			return kramank;
		}
		public void setKramank(String kramank) {
			this.kramank = kramank;
		}
		public String getNidhicheShirsh() {
			return nidhicheShirsh;
		}
		public void setNidhicheShirsh(String nidhicheShirsh) {
			this.nidhicheShirsh = nidhicheShirsh;
		}
		public String getUpaShirsh() {
			return upaShirsh;
		}
		public void setUpaShirsh(String upaShirsh) {
			this.upaShirsh = upaShirsh;
		}
		public String getMadheHonyachyaSambhavKharchach() {
			return madheHonyachyaSambhavKharchach;
		}
		public void setMadheHonyachyaSambhavKharchach(String madheHonyachyaSambhavKharchach) {
			this.madheHonyachyaSambhavKharchach = madheHonyachyaSambhavKharchach;
		}
		public String getYanniKelelaAndaj() {
			return yanniKelelaAndaj;
		}
		public void setYanniKelelaAndaj(String yanniKelelaAndaj) {
			this.yanniKelelaAndaj = yanniKelelaAndaj;
		}
		public String getSarvasadharanGoshwaraParinam() {
			return sarvasadharanGoshwaraParinam;
		}
		public void setSarvasadharanGoshwaraParinam(String sarvasadharanGoshwaraParinam) {
			this.sarvasadharanGoshwaraParinam = sarvasadharanGoshwaraParinam;
		}
		public String getSarvasadharanGoshwaraBaab() {
			return sarvasadharanGoshwaraBaab;
		}
		public void setSarvasadharanGoshwaraBaab(String sarvasadharanGoshwaraBaab) {
			this.sarvasadharanGoshwaraBaab = sarvasadharanGoshwaraBaab;
		}
		public String getSarvasadharanGoshwaraDarRupaye() {
			return sarvasadharanGoshwaraDarRupaye;
		}
		public void setSarvasadharanGoshwaraDarRupaye(String sarvasadharanGoshwaraDarRupaye) {
			this.sarvasadharanGoshwaraDarRupaye = sarvasadharanGoshwaraDarRupaye;
		}
		public String getSarvasadharanGoshwaraPratteki() {
			return sarvasadharanGoshwaraPratteki;
		}
		public void setSarvasadharanGoshwaraPratteki(String sarvasadharanGoshwaraPratteki) {
			this.sarvasadharanGoshwaraPratteki = sarvasadharanGoshwaraPratteki;
		}
		public String getSarvasadharanGoshwaraRakkamDashanshat() {
			return sarvasadharanGoshwaraRakkamDashanshat;
		}
		public void setSarvasadharanGoshwaraRakkamDashanshat(String sarvasadharanGoshwaraRakkamDashanshat) {
			this.sarvasadharanGoshwaraRakkamDashanshat = sarvasadharanGoshwaraRakkamDashanshat;
		}
		public String getMojmapAndajpatraKramank() {
			return mojmapAndajpatraKramank;
		}
		public void setMojmapAndajpatraKramank(String mojmapAndajpatraKramank) {
			this.mojmapAndajpatraKramank = mojmapAndajpatraKramank;
		}
		public String getMojmapAndajpatraLaambi() {
			return mojmapAndajpatraLaambi;
		}
		public void setMojmapAndajpatraLaambi(String mojmapAndajpatraLaambi) {
			this.mojmapAndajpatraLaambi = mojmapAndajpatraLaambi;
		}
		public String getMojmapAndajpatraRundi() {
			return mojmapAndajpatraRundi;
		}
		public void setMojmapAndajpatraRundi(String mojmapAndajpatraRundi) {
			this.mojmapAndajpatraRundi = mojmapAndajpatraRundi;
		}
		public String getMojmapAndajpatraKholi() {
			return mojmapAndajpatraKholi;
		}
		public void setMojmapAndajpatraKholi(String mojmapAndajpatraKholi) {
			this.mojmapAndajpatraKholi = mojmapAndajpatraKholi;
		}
		public String getMojmapAndajpatraParimanDashanshat() {
			return mojmapAndajpatraParimanDashanshat;
		}
		public void setMojmapAndajpatraParimanDashanshat(String mojmapAndajpatraParimanDashanshat) {
			this.mojmapAndajpatraParimanDashanshat = mojmapAndajpatraParimanDashanshat;
		}
		public String getEkun() {
			return ekun;
		}
		public void setEkun(String ekun) {
			this.ekun = ekun;
		}
		public String getYear() {
			return year;
		}
		public void setYear(String year) {
			this.year = year;
		}

	  

	}

