package eGramPanchayat.dto;

import java.time.LocalDateTime;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public class Namuna28MagasvargiyansathiFiftyTakkeKharchacheMasikVivaranDTO {

	private Long id;

	// @Pattern(regexp = "^[0-9 ]+$", message = "Employee ID can not contains
	// special characters.")
	private String employeeId;

	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Employee Name can not
	// contains special characters.")
	private String employeeName;

	// @Pattern(regexp = "^[0-9]*$", message = "Grampanchayat id can not contains
	// special characters.")
	private String gramPanchayatId;

	// @Pattern(regexp = "^[a-zA-Z\\s]+$", message = "Grampanchayat name can not
	// contains special characters.")
	private String gramPanchayatName;

	@Pattern(regexp = "^[a-zA-Z\\u0900-\\u097F\\p{P}\\p{S} ]*$", message = "sanMadhemagasvargiyansathiKeleliTartud contain invalid character.")
	@NotNull(message = "sanMadhemagasvargiyansathiKeleliTartud cannot be null.")
	@NotBlank(message = "sanMadhemagasvargiyansathiKeleliTartud cannot be empty.")
	private String sanMadhemagasvargiyansathiKeleliTartud;

	@Pattern(regexp = "^[\u0966-\u096F0-9 .-]*$", message = "san contain invalid character.")
	@NotNull(message = "san cannot be null.")
	@NotBlank(message = "san cannot be empty.")
	private String san;

	@Pattern(regexp = "^[\u0966-\u096F0-9 .]*$", message = "chaluMahinyatPraptaJhaleleUtpanna contain invalid character.")
	@NotNull(message = "chaluMahinyatPraptaJhaleleUtpanna cannot be null.")
	@NotBlank(message = "chaluMahinyatPraptaJhaleleUtpanna cannot be empty.")
	private String chaluMahinyatPraptaJhaleleUtpanna;

	@NotNull(message = "fiftyTakkeKharchaKarychiRakkam cannot be null.")
	@NotBlank(message = "fiftyTakkeKharchaKarychiRakkam cannot be empty.")
	private String fiftyTakkeKharchaKarychiRakkam;

	@Pattern(regexp = "^[a-zA-Z\\u0900-\\u097F\\p{P}\\p{S} ]*$", message = "kharchachyaBabiYojanavar contain invalid character.")
	@NotNull(message = "kharchachyaBabiYojanavar cannot be null.")
	@NotBlank(message = "kharchachyaBabiYojanavar cannot be empty.")
	private String kharchachyaBabiYojanavar;

	@Pattern(regexp = "^[\u0966-\u096F0-9 .]*$", message = "magilMahinayatJhalelaKharcha contain invalid character.")
	@NotNull(message = "magilMahinayatJhalelaKharcha cannot be null.")
	@NotBlank(message = "magilMahinayatJhalelaKharcha cannot be empty.")
	private String magilMahinayatJhalelaKharcha;

	@Pattern(regexp = "^[\u0966-\u096F0-9 .]*$", message = "chaluMahinyatJhalelaKharcha contain invalid character.")
	@NotNull(message = "chaluMahinyatJhalelaKharcha cannot be null.")
	@NotBlank(message = "chaluMahinyatJhalelaKharcha cannot be empty.")
	private String chaluMahinyatJhalelaKharcha;

	@NotNull(message = "ekunKharch cannot be null.")
	@NotBlank(message = "ekunKharch cannot be empty.")
	private String ekunKharch;

	@Pattern(regexp = "^[\u0966-\u096F0-9 .%-]*$", message = "kharchachiTakkevari contain invalid character.")
	@NotNull(message = "kharchachiTakkevari cannot be null.")
	@NotBlank(message = "kharchachiTakkevari cannot be empty.")
	private String kharchachiTakkevari;

	@NotNull(message = "year cannot be null.")
	@NotBlank(message = "year cannot be empty.")
	private String year;

	@Pattern(regexp = "^[a-zA-Z\\u0900-\\u097F\\p{P}\\p{S} ]*$", message = "shera contain the @ character.")
	@NotNull(message = "shera cannot be null.")
	@NotBlank(message = "shera cannot be empty.")
	private String shera;

	@NotNull(message = "month cannot be null.")
	@NotBlank(message = "month cannot be empty.")
	private String month;

	private String dinank;
	// @Pattern(regexp = "^[a-zA-Z0-9\\s]+$",message = "Remark can not contains
	// special characters.")
	// private String remark;

	private LocalDateTime createdDate;
	private LocalDateTime updatedDate;

	// Getters and Setters

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getGramPanchayatId() {
		return gramPanchayatId;
	}

	public void setGramPanchayatId(String gramPanchayatId) {
		this.gramPanchayatId = gramPanchayatId;
	}

	public String getGramPanchayatName() {
		return gramPanchayatName;
	}

	public void setGramPanchayatName(String gramPanchayatName) {
		this.gramPanchayatName = gramPanchayatName;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getSanMadhemagasvargiyansathiKeleliTartud() {
		return sanMadhemagasvargiyansathiKeleliTartud;
	}

	public void setSanMadhemagasvargiyansathiKeleliTartud(String sanMadhemagasvargiyansathiKeleliTartud) {
		this.sanMadhemagasvargiyansathiKeleliTartud = sanMadhemagasvargiyansathiKeleliTartud;
	}

	public String getChaluMahinyatPraptaJhaleleUtpanna() {
		return chaluMahinyatPraptaJhaleleUtpanna;
	}

	public void setChaluMahinyatPraptaJhaleleUtpanna(String chaluMahinyatPraptaJhaleleUtpanna) {
		this.chaluMahinyatPraptaJhaleleUtpanna = chaluMahinyatPraptaJhaleleUtpanna;
	}

	public String getFiftyTakkeKharchaKarychiRakkam() {
		return fiftyTakkeKharchaKarychiRakkam;
	}

	public void setFiftyTakkeKharchaKarychiRakkam(String fiftyTakkeKharchaKarychiRakkam) {
		this.fiftyTakkeKharchaKarychiRakkam = fiftyTakkeKharchaKarychiRakkam;
	}

	public String getKharchachyaBabiYojanavar() {
		return kharchachyaBabiYojanavar;
	}

	public void setKharchachyaBabiYojanavar(String kharchachyaBabiYojanavar) {
		this.kharchachyaBabiYojanavar = kharchachyaBabiYojanavar;
	}

	public String getMagilMahinayatJhalelaKharcha() {
		return magilMahinayatJhalelaKharcha;
	}

	public void setMagilMahinayatJhalelaKharcha(String magilMahinayatJhalelaKharcha) {
		this.magilMahinayatJhalelaKharcha = magilMahinayatJhalelaKharcha;
	}

	public String getChaluMahinyatJhalelaKharcha() {
		return chaluMahinyatJhalelaKharcha;
	}

	public void setChaluMahinyatJhalelaKharcha(String chaluMahinyatJhalelaKharcha) {
		this.chaluMahinyatJhalelaKharcha = chaluMahinyatJhalelaKharcha;
	}

	public String getEkunKharch() {
		return ekunKharch;
	}

	public void setEkunKharch(String ekunKharch) {
		this.ekunKharch = ekunKharch;
	}

	public String getKharchachiTakkevari() {
		return kharchachiTakkevari;
	}

	public void setKharchachiTakkevari(String kharchachiTakkevari) {
		this.kharchachiTakkevari = kharchachiTakkevari;
	}

	public String getShera() {
		return shera;
	}

	public void setShera(String shera) {
		this.shera = shera;
	}

	public String getSan() {
		return san;
	}

	public void setSan(String san) {
		this.san = san;
	}

	public String getDinank() {
		return dinank;
	}

	public void setDinank(String dinank) {
		this.dinank = dinank;
	}

}
