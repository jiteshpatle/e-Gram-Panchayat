package eGramPanchayat.dto;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;

public class Namuna16_DeadStockDTO {

    private long id;
    private String employeeId;
    private String employeeName;
    private String grampanchayatId;
    private String grampanchayatName;
    private String shera;
    private String vastucheVarnan;
    private String kharedibaddalPradhikar;
    private String kharedichiTarikh;
    private String sankhyaKinvaPraman;
    private Double kimmat;
    private String antimVilhevatsathiSankhyaKinvaPariman;
    private String vilhevaticheSwarup;
    private String pradhikarPatraKinvaPramanak;
    private String vasulKeleliRakkam;
    private String vasulRakkamKoshagaratBharnyachiTarikh;
    private String sathyatilShillak;
    private String date;
    private String year;
    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;
    
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getGrampanchayatId() {
		return grampanchayatId;
	}
	public void setGrampanchayatId(String grampanchayatId) {
		this.grampanchayatId = grampanchayatId;
	}
	public String getGrampanchayatName() {
		return grampanchayatName;
	}
	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}
	public String getShera() {
		return shera;
	}
	public void setShera(String shera) {
		this.shera = shera;
	}
	public String getVastucheVarnan() {
		return vastucheVarnan;
	}
	public void setVastucheVarnan(String vastucheVarnan) {
		this.vastucheVarnan = vastucheVarnan;
	}
	public String getKharedibaddalPradhikar() {
		return kharedibaddalPradhikar;
	}
	public void setKharedibaddalPradhikar(String kharedibaddalPradhikar) {
		this.kharedibaddalPradhikar = kharedibaddalPradhikar;
	}
	public String getKharedichiTarikh() {
		return kharedichiTarikh;
	}
	public void setKharedichiTarikh(String kharedichiTarikh) {
		this.kharedichiTarikh = kharedichiTarikh;
	}
	public String getSankhyaKinvaPraman() {
		return sankhyaKinvaPraman;
	}
	public void setSankhyaKinvaPraman(String sankhyaKinvaPraman) {
		this.sankhyaKinvaPraman = sankhyaKinvaPraman;
	}
	public Double getKimmat() {
		return kimmat;
	}
	public void setKimmat(Double kimmat) {
		this.kimmat = kimmat;
	}
	public String getAntimVilhevatsathiSankhyaKinvaPariman() {
		return antimVilhevatsathiSankhyaKinvaPariman;
	}
	public void setAntimVilhevatsathiSankhyaKinvaPariman(String antimVilhevatsathiSankhyaKinvaPariman) {
		this.antimVilhevatsathiSankhyaKinvaPariman = antimVilhevatsathiSankhyaKinvaPariman;
	}
	public String getVilhevaticheSwarup() {
		return vilhevaticheSwarup;
	}
	public void setVilhevaticheSwarup(String vilhevaticheSwarup) {
		this.vilhevaticheSwarup = vilhevaticheSwarup;
	}
	public String getPradhikarPatraKinvaPramanak() {
		return pradhikarPatraKinvaPramanak;
	}
	public void setPradhikarPatraKinvaPramanak(String pradhikarPatraKinvaPramanak) {
		this.pradhikarPatraKinvaPramanak = pradhikarPatraKinvaPramanak;
	}
	public String getVasulKeleliRakkam() {
		return vasulKeleliRakkam;
	}
	public void setVasulKeleliRakkam(String vasulKeleliRakkam) {
		this.vasulKeleliRakkam = vasulKeleliRakkam;
	}
	public String getVasulRakkamKoshagaratBharnyachiTarikh() {
		return vasulRakkamKoshagaratBharnyachiTarikh;
	}
	public void setVasulRakkamKoshagaratBharnyachiTarikh(String vasulRakkamKoshagaratBharnyachiTarikh) {
		this.vasulRakkamKoshagaratBharnyachiTarikh = vasulRakkamKoshagaratBharnyachiTarikh;
	}
	public String getSathyatilShillak() {
		return sathyatilShillak;
	}
	public void setSathyatilShillak(String sathyatilShillak) {
		this.sathyatilShillak = sathyatilShillak;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public LocalDateTime getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}
    
}
