package eGramPanchayat.dto;

import java.sql.Timestamp;

public class KarmachariVargikaranWetanShreniNondvahi_13_Dto {
    
    private Long id;
    // private Integer serialNo;
    private String employeeId; // Employee ID
    private String employeeName; // Employee name
    private String grampanchayatId; // Grampanchayat ID
    private String grampanchayatName; // Grampanchayat name
    private String padnaam;
    private Integer padanchiSankhya;
    private String manjurPadAdeshKramank;
    private String manjurPadAdeshDinank;
    private String purnakalikAnshkalik;
    private String manjurWetanShreni;
    private String karmacharyacheNaav;
    private String niyuktiDinank;
    private Timestamp createdDate;
    private Timestamp updatedDate;
    private String year;
    private String dinank;
    private String remark;

    // Getters and Setters
    
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    // public Integer getSerialNo() {
    //     return serialNo;
    // }

    // public void setSerialno(Integer serialNo) {
    //     this.serialNo = serialNo;
    // }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getGrampanchayatId() {
        return grampanchayatId;
    }

    public void setGrampanchayatId(String grampanchayatId) {
        this.grampanchayatId = grampanchayatId;
    }

    public String getGrampanchayatName() {
        return grampanchayatName;
    }

    public void setGrampanchayatName(String grampanchayatName) {
        this.grampanchayatName = grampanchayatName;
    }

    public String getPadnaam() {
        return padnaam;
    }

    public void setPadnaam(String padnaam) {
        this.padnaam = padnaam;
    }

    public Integer getPadanchiSankhya() {
        return padanchiSankhya;
    }

    public void setPadanchiSankhya(Integer padanchiSankhya) {
        this.padanchiSankhya = padanchiSankhya;
    }

   

    // public void setSerialNo(Integer serialNo) {
	// 	this.serialNo = serialNo;
	// }

	public String getPurnakalikAnshkalik() {
        return purnakalikAnshkalik;
    }

    public void setPurnakalikAnshkalik(String purnakalikAnshkalik) {
        this.purnakalikAnshkalik = purnakalikAnshkalik;
    }

    public String getManjurWetanShreni() {
        return manjurWetanShreni;
    }

    public void setManjurWetanShreni(String manjurWetanShreni) {
        this.manjurWetanShreni = manjurWetanShreni;
    }

    public String getKarmacharyacheNaav() {
        return karmacharyacheNaav;
    }

    public void setKarmacharyacheNaav(String karmacharyacheNaav) {
        this.karmacharyacheNaav = karmacharyacheNaav;
    }

    public String getNiyuktiDinank() {
        return niyuktiDinank;
    }

    public void setNiyuktiDinank(String niyuktiDinank) {
        this.niyuktiDinank = niyuktiDinank;
    }

    public Timestamp getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate) {
        this.createdDate = createdDate;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

	public String getManjurPadAdeshKramank() {
		return manjurPadAdeshKramank;
	}

	public void setManjurPadAdeshKramank(String manjurPadAdeshKramank) {
		this.manjurPadAdeshKramank = manjurPadAdeshKramank;
	}

	public String getManjurPadAdeshDinank() {
		return manjurPadAdeshDinank;
	}

	public void setManjurPadAdeshDinank(String manjurPadAdeshDinank) {
		this.manjurPadAdeshDinank = manjurPadAdeshDinank;
	}

    public String getDinank() {
        return dinank;
    }

    public void setDinank(String dinank) {
        this.dinank = dinank;
    }
    
}
