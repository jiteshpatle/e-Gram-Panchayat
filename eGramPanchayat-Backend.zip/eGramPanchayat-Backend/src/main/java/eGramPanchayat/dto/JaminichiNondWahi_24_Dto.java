package eGramPanchayat.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class JaminichiNondWahi_24_Dto
 {
    
    private Long id;
    private String employeeId;
    private String employeeName;
    private String grampanchayatId;
    private String grampanchayatName;
    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;
    private String year;
    
    // Additional Fields
    private String anukramank;
    private LocalDate hastantaritKharidiKinwaSampaditKelyachiTarikh;
    private String konatyaKarnasaathi;
    private String konakadun;
    private String kararnamaNiwadaNirdeshank;
    private String jaminicheKshetraphal;
    private String bhumapanKramankEtyadi;
    private String aakarni;
    private String jaminichyaSeema;
    private String jaminisahKharediSampadanEmarati;
    private String jaminichiWaEmartichiWilhewat;
    private String vikriPaasunMilaleliRakkam;
    private String pramanakachaKramankWaDinank;
    private String malmattechiWilhewatPanchayatichaTharav;
    private String malmattechiWilhewatKalam55;
    private String shera;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getGrampanchayatId() {
        return grampanchayatId;
    }

    public void setGrampanchayatId(String grampanchayatId) {
        this.grampanchayatId = grampanchayatId;
    }

    public String getGrampanchayatName() {
        return grampanchayatName;
    }

    public void setGrampanchayatName(String grampanchayatName) {
        this.grampanchayatName = grampanchayatName;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime localDateTime) {
        this.createdDate = localDateTime;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime localDateTime) {
        this.updatedDate = localDateTime;
    }

    public String getAnukramank() {
        return anukramank;
    }

    public void setAnukramank(String anukramank) {
        this.anukramank = anukramank;
    }

    public LocalDate getHastantaritKharidiKinwaSampaditKelyachiTarikh() {
        return hastantaritKharidiKinwaSampaditKelyachiTarikh;
    }

    public void setHastantaritKharidiKinwaSampaditKelyachiTarikh(LocalDate hastantaritKharidiKinwaSampaditKelyachiTarikh) {
        this.hastantaritKharidiKinwaSampaditKelyachiTarikh = hastantaritKharidiKinwaSampaditKelyachiTarikh;
    }

    public String getKonatyaKarnasaathi() {
        return konatyaKarnasaathi;
    }

    public void setKonatyaKarnasaathi(String konatyaKarnasaathi) {
        this.konatyaKarnasaathi = konatyaKarnasaathi;
    }

    public String getKonakadun() {
        return konakadun;
    }

    public void setKonakadun(String konakadun) {
        this.konakadun = konakadun;
    }

    public String getKararnamaNiwadaNirdeshank() {
        return kararnamaNiwadaNirdeshank;
    }

    public void setKararnamaNiwadaNirdeshank(String kararnamaNiwadaNirdeshank) {
        this.kararnamaNiwadaNirdeshank = kararnamaNiwadaNirdeshank;
    }

    public String getJaminicheKshetraphal() {
        return jaminicheKshetraphal;
    }

    public void setJaminicheKshetraphal(String jaminicheKshetraphal) {
        this.jaminicheKshetraphal = jaminicheKshetraphal;
    }

    public String getBhumapanKramankEtyadi() {
        return bhumapanKramankEtyadi;
    }

    public void setBhumapanKramankEtyadi(String bhumapanKramankEtyadi) {
        this.bhumapanKramankEtyadi = bhumapanKramankEtyadi;
    }

    public String getAakarni() {
        return aakarni;
    }

    public void setAakarni(String aakarni) {
        this.aakarni = aakarni;
    }

    public String getJaminichyaSeema() {
        return jaminichyaSeema;
    }

    public void setJaminichyaSeema(String jaminichyaSeema) {
        this.jaminichyaSeema = jaminichyaSeema;
    }

    public String getJaminisahKharediSampadanEmarati() {
        return jaminisahKharediSampadanEmarati;
    }

    public void setJaminisahKharediSampadanEmarati(String jaminisahKharediSampadanEmarati) {
        this.jaminisahKharediSampadanEmarati = jaminisahKharediSampadanEmarati;
    }

    public String getJaminichiWaEmartichiWilhewat() {
        return jaminichiWaEmartichiWilhewat;
    }

    public void setJaminichiWaEmartichiWilhewat(String jaminichiWaEmartichiWilhewat) {
        this.jaminichiWaEmartichiWilhewat = jaminichiWaEmartichiWilhewat;
    }

    public String getVikriPaasunMilaleliRakkam() {
        return vikriPaasunMilaleliRakkam;
    }

    public void setVikriPaasunMilaleliRakkam(String vikriPaasunMilaleliRakkam) {
        this.vikriPaasunMilaleliRakkam = vikriPaasunMilaleliRakkam;
    }

    public String getPramanakachaKramankWaDinank() {
        return pramanakachaKramankWaDinank;
    }

    public void setPramanakachaKramankWaDinank(String pramanakachaKramankWaDinank) {
        this.pramanakachaKramankWaDinank = pramanakachaKramankWaDinank;
    }

    public String getMalmattechiWilhewatPanchayatichaTharav() {
        return malmattechiWilhewatPanchayatichaTharav;
    }

    public void setMalmattechiWilhewatPanchayatichaTharav(String malmattechiWilhewatPanchayatichaTharav) {
        this.malmattechiWilhewatPanchayatichaTharav = malmattechiWilhewatPanchayatichaTharav;
    }

    public String getMalmattechiWilhewatKalam55() {
        return malmattechiWilhewatKalam55;
    }

    public void setMalmattechiWilhewatKalam55(String malmattechiWilhewatKalam55) {
        this.malmattechiWilhewatKalam55 = malmattechiWilhewatKalam55;
    }

    public String getShera() {
        return shera;
    }

    public void setShera(String shera) {
        this.shera = shera;
    }
}
