package eGramPanchayat.dto;

import java.time.LocalDateTime;

public class AakasmikKharchachePramanak_12_Dto {

    // Common Fields
    private Long id;
    private String employeeId;
    private String employeeName;
    private String grampanchayatId;
    private String grampanchayatName;
    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;

    // New Fields
    private String deyakKramank;
    private String pavtiLihunDenar;
    private String kamacheKharediPavtiPramaneInNumbers;
    private String kamacheKharediPavtiPramaneAkshari;
    private String matraRokhCheckNo;
    private String nagKinwaWajan;
    private String dar;
    private String unit;
    private String rakkamRupaye;
    private String watnichiRakkamRupaye;
    private String purvichaKharchRupaye;
    private String dewakatDarshawilelaKharch;
    private String ekunBerij2Plus2Rupaye;
    private String uplabdhShillak;
    private String tharavKramank;
    private String dewakamadheDarshavileliRakkam;
    private String maganiPurvichePurnRupayeInNumbers;
    private String maganiPurvichePurnRupayeAkshari;
    private String pramanakKramank;
    private String rojwahitilPrusthKramank;
    private String year;
    private String remark;
    
    //
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getGrampanchayatId() {
		return grampanchayatId;
	}
	public void setGrampanchayatId(String grampanchayatId) {
		this.grampanchayatId = grampanchayatId;
	}
	public String getGrampanchayatName() {
		return grampanchayatName;
	}
	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}
	public String getDeyakKramank() {
		return deyakKramank;
	}
	public void setDeyakKramank(String deyakKramank) {
		this.deyakKramank = deyakKramank;
	}
	public String getPavtiLihunDenar() {
		return pavtiLihunDenar;
	}
	public void setPavtiLihunDenar(String pavtiLihunDenar) {
		this.pavtiLihunDenar = pavtiLihunDenar;
	}
	public String getKamacheKharediPavtiPramaneInNumbers() {
		return kamacheKharediPavtiPramaneInNumbers;
	}
	public void setKamacheKharediPavtiPramaneInNumbers(String kamacheKharediPavtiPramaneInNumbers) {
		this.kamacheKharediPavtiPramaneInNumbers = kamacheKharediPavtiPramaneInNumbers;
	}
	public String getKamacheKharediPavtiPramaneAkshari() {
		return kamacheKharediPavtiPramaneAkshari;
	}
	public void setKamacheKharediPavtiPramaneAkshari(String kamacheKharediPavtiPramaneAkshari) {
		this.kamacheKharediPavtiPramaneAkshari = kamacheKharediPavtiPramaneAkshari;
	}
	public String getMatraRokhCheckNo() {
		return matraRokhCheckNo;
	}
	public void setMatraRokhCheckNo(String matraRokhCheckNo) {
		this.matraRokhCheckNo = matraRokhCheckNo;
	}
	public String getNagKinwaWajan() {
		return nagKinwaWajan;
	}
	public void setNagKinwaWajan(String nagKinwaWajan) {
		this.nagKinwaWajan = nagKinwaWajan;
	}
	public String getDar() {
		return dar;
	}
	public void setDar(String dar) {
		this.dar = dar;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getRakkamRupaye() {
		return rakkamRupaye;
	}
	public void setRakkamRupaye(String rakkamRupaye) {
		this.rakkamRupaye = rakkamRupaye;
	}
	public String getWatnichiRakkamRupaye() {
		return watnichiRakkamRupaye;
	}
	public void setWatnichiRakkamRupaye(String watnichiRakkamRupaye) {
		this.watnichiRakkamRupaye = watnichiRakkamRupaye;
	}
	public String getPurvichaKharchRupaye() {
		return purvichaKharchRupaye;
	}
	public void setPurvichaKharchRupaye(String purvichaKharchRupaye) {
		this.purvichaKharchRupaye = purvichaKharchRupaye;
	}
	public String getDewakatDarshawilelaKharch() {
		return dewakatDarshawilelaKharch;
	}
	public void setDewakatDarshawilelaKharch(String dewakatDarshawilelaKharch) {
		this.dewakatDarshawilelaKharch = dewakatDarshawilelaKharch;
	}
	public String getEkunBerij2Plus2Rupaye() {
		return ekunBerij2Plus2Rupaye;
	}
	public void setEkunBerij2Plus2Rupaye(String ekunBerij2Plus2Rupaye) {
		this.ekunBerij2Plus2Rupaye = ekunBerij2Plus2Rupaye;
	}
	public String getUplabdhShillak() {
		return uplabdhShillak;
	}
	public void setUplabdhShillak(String uplabdhShillak) {
		this.uplabdhShillak = uplabdhShillak;
	}
	public String getTharavKramank() {
		return tharavKramank;
	}
	public void setTharavKramank(String tharavKramank) {
		this.tharavKramank = tharavKramank;
	}
	public String getDewakamadheDarshavileliRakkam() {
		return dewakamadheDarshavileliRakkam;
	}
	public void setDewakamadheDarshavileliRakkam(String dewakamadheDarshavileliRakkam) {
		this.dewakamadheDarshavileliRakkam = dewakamadheDarshavileliRakkam;
	}
	public String getMaganiPurvichePurnRupayeInNumbers() {
		return maganiPurvichePurnRupayeInNumbers;
	}
	public void setMaganiPurvichePurnRupayeInNumbers(String maganiPurvichePurnRupayeInNumbers) {
		this.maganiPurvichePurnRupayeInNumbers = maganiPurvichePurnRupayeInNumbers;
	}
	public String getMaganiPurvichePurnRupayeAkshari() {
		return maganiPurvichePurnRupayeAkshari;
	}
	public void setMaganiPurvichePurnRupayeAkshari(String maganiPurvichePurnRupayeAkshari) {
		this.maganiPurvichePurnRupayeAkshari = maganiPurvichePurnRupayeAkshari;
	}
	public String getPramanakKramank() {
		return pramanakKramank;
	}
	public void setPramanakKramank(String pramanakKramank) {
		this.pramanakKramank = pramanakKramank;
	}
	public String getRojwahitilPrusthKramank() {
		return rojwahitilPrusthKramank;
	}
	public void setRojwahitilPrusthKramank(String rojwahitilPrusthKramank) {
		this.rojwahitilPrusthKramank = rojwahitilPrusthKramank;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
    // Getters and Setters
	public LocalDateTime getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}
}
