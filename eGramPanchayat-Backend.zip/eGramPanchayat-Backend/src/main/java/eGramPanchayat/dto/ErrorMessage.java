package eGramPanchayat.dto;

public class ErrorMessage {
    private String description;

    public ErrorMessage(String description) {
        this.description = description;
    }

    // Getter and Setter
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
