package eGramPanchayat.dto;

import java.time.LocalDateTime;

public class MojmaapWahi_21_Dto {

    // Common Fields
    private Long id;
    private String employeeId;
    private String employeeName;
    private String grampanchayatId;
    private String grampanchayatName;
    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;
    private String remark;
    private String year;

    // MojmaapWahi Fields
    private String kamachePratyakshaMojmap;
    private String kamkarnayaAgencyAbhikanacheNaaw;
    private String kamacheWarnan;
    private String mojmap;
    private String kamacheWarnanKamacheUpashirshVaKshetracheAdhikari;
    private String mojmapachaTapshilPariman;
    private String mojmapachaTapshilLaambi;
    private String mojmapachaTapshilRundi;
    private String mojmapachaTapshilKholiUnchi;
    private String mojmapachaTapshilEkun;
    private String ekunParimanMaapPurvicheHajeriPramaneWarnanKarave;
    private String ekunMojmapachaTapshilEkunVaEkunParimanMaap;
    private String dar;
    private String rakkam;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getGrampanchayatId() {
        return grampanchayatId;
    }

    public void setGrampanchayatId(String grampanchayatId) {
        this.grampanchayatId = grampanchayatId;
    }

    public String getGrampanchayatName() {
        return grampanchayatName;
    }

    public void setGrampanchayatName(String grampanchayatName) {
        this.grampanchayatName = grampanchayatName;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime localDateTime) {
        this.createdDate = localDateTime;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime localDateTime) {
        this.updatedDate = localDateTime;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getKamachePratyakshaMojmap() {
        return kamachePratyakshaMojmap;
    }

    public void setKamachePratyakshaMojmap(String kamachePratyakshaMojmap) {
        this.kamachePratyakshaMojmap = kamachePratyakshaMojmap;
    }

    public String getKamkarnayaAgencyAbhikanacheNaaw() {
        return kamkarnayaAgencyAbhikanacheNaaw;
    }

    public void setKamkarnayaAgencyAbhikanacheNaaw(String kamkarnayaAgencyAbhikanacheNaaw) {
        this.kamkarnayaAgencyAbhikanacheNaaw = kamkarnayaAgencyAbhikanacheNaaw;
    }

    public String getKamacheWarnan() {
        return kamacheWarnan;
    }

    public void setKamacheWarnan(String kamacheWarnan) {
        this.kamacheWarnan = kamacheWarnan;
    }

    public String getMojmap() {
        return mojmap;
    }

    public void setMojmap(String mojmap) {
        this.mojmap = mojmap;
    }

    

	public String getKamacheWarnanKamacheUpashirshVaKshetracheAdhikari() {
		return kamacheWarnanKamacheUpashirshVaKshetracheAdhikari;
	}

	public void setKamacheWarnanKamacheUpashirshVaKshetracheAdhikari(
			String kamacheWarnanKamacheUpashirshVaKshetracheAdhikari) {
		this.kamacheWarnanKamacheUpashirshVaKshetracheAdhikari = kamacheWarnanKamacheUpashirshVaKshetracheAdhikari;
	}

	public String getMojmapachaTapshilPariman() {
        return mojmapachaTapshilPariman;
    }

    public void setMojmapachaTapshilPariman(String mojmapachaTapshilPariman) {
        this.mojmapachaTapshilPariman = mojmapachaTapshilPariman;
    }

    public String getMojmapachaTapshilLaambi() {
        return mojmapachaTapshilLaambi;
    }

    public void setMojmapachaTapshilLaambi(String mojmapachaTapshilLaambi) {
        this.mojmapachaTapshilLaambi = mojmapachaTapshilLaambi;
    }

    public String getMojmapachaTapshilRundi() {
        return mojmapachaTapshilRundi;
    }

    public void setMojmapachaTapshilRundi(String mojmapachaTapshilRundi) {
        this.mojmapachaTapshilRundi = mojmapachaTapshilRundi;
    }

    public String getMojmapachaTapshilKholiUnchi() {
        return mojmapachaTapshilKholiUnchi;
    }

    public void setMojmapachaTapshilKholiUnchi(String mojmapachaTapshilKholiUnchi) {
        this.mojmapachaTapshilKholiUnchi = mojmapachaTapshilKholiUnchi;
    }

    public String getMojmapachaTapshilEkun() {
        return mojmapachaTapshilEkun;
    }

    public void setMojmapachaTapshilEkun(String mojmapachaTapshilEkun) {
        this.mojmapachaTapshilEkun = mojmapachaTapshilEkun;
    }

    public String getEkunParimanMaapPurvicheHajeriPramaneWarnanKarave() {
        return ekunParimanMaapPurvicheHajeriPramaneWarnanKarave;
    }

    public void setEkunParimanMaapPurvicheHajeriPramaneWarnanKarave(String ekunParimanMaapPurvicheHajeriPramaneWarnanKarave) {
        this.ekunParimanMaapPurvicheHajeriPramaneWarnanKarave = ekunParimanMaapPurvicheHajeriPramaneWarnanKarave;
    }

    public String getEkunMojmapachaTapshilEkunVaEkunParimanMaap() {
        return ekunMojmapachaTapshilEkunVaEkunParimanMaap;
    }

    public void setEkunMojmapachaTapshilEkunVaEkunParimanMaap(String ekunMojmapachaTapshilEkunVaEkunParimanMaap) {
        this.ekunMojmapachaTapshilEkunVaEkunParimanMaap = ekunMojmapachaTapshilEkunVaEkunParimanMaap;
    }

    public String getDar() {
        return dar;
    }

    public void setDar(String dar) {
        this.dar = dar;
    }

    public String getRakkam() {
        return rakkam;
    }

    public void setRakkam(String rakkam) {
        this.rakkam = rakkam;
    }
}
