package eGramPanchayat.dto;

public class DynamicFieldDTO {

    private String tapshil; // Description or details
    private String magilBaki; // Previous balance
    private String chaluBaki; // Current balance
    private String ekunRakkam; // Total amount

    private Long id; // Optional: Used for identifying existing records during update

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTapshil() {
        return tapshil;
    }

    public void setTapshil(String tapshil) {
        this.tapshil = tapshil;
    }

    public String getMagilBaki() {
        return magilBaki;
    }

    public void setMagilBaki(String magilBaki) {
        this.magilBaki = magilBaki;
    }

    public String getChaluBaki() {
        return chaluBaki;
    }

    public void setChaluBaki(String chaluBaki) {
        this.chaluBaki = chaluBaki;
    }

    public String getEkunRakkam() {
        return ekunRakkam;
    }

    public void setEkunRakkam(String ekunRakkam) {
        this.ekunRakkam = ekunRakkam;
    }

}
