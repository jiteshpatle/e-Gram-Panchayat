package eGramPanchayat.dto;


import java.time.LocalDateTime;



public class Namuna02PunarniyojanVaNiyatVatapDTO {

    private Long id;
    private String jamaRakmecheMukhyaShirshak;
    private String manjurArthsankalp;
    private String sudharitAndaz;
    private String sudharitAdhikVaja;
    private String kharchachePramukhShirsh;
    private String manjurRakkam;
    private String kharchachaSudharitAndaz;
    private String kharchachaAdhikVaja;
    private String shera;
    private Long employeeId;
    private String employeeName;
    private Long grampanchayatId;
    private String grampanchayatName;
    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;
    private String month;  // New field
    private String dnyapanRupees;  // New field
    private String year;

    // Getters and Setters for all fields

    public Long getId() {
        return id;
    }

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public void setId(Long id) {
        this.id = id;
    }

    public String getJamaRakmecheMukhyaShirshak() {
        return jamaRakmecheMukhyaShirshak;
    }

    public void setJamaRakmecheMukhyaShirshak(String jamaRakmecheMukhyaShirshak) {
        this.jamaRakmecheMukhyaShirshak = jamaRakmecheMukhyaShirshak;
    }

    public String getManjurArthsankalp() {
        return manjurArthsankalp;
    }

    public void setManjurArthsankalp(String manjurArthsankalp) {
        this.manjurArthsankalp = manjurArthsankalp;
    }

    public String getSudharitAndaz() {
        return sudharitAndaz;
    }

    public void setSudharitAndaz(String sudharitAndaz) {
        this.sudharitAndaz = sudharitAndaz;
    }

    public String getSudharitAdhikVaja() {
        return sudharitAdhikVaja;
    }

    public void setSudharitAdhikVaja(String sudharitAdhikVaja) {
        this.sudharitAdhikVaja = sudharitAdhikVaja;
    }

    public String getKharchachePramukhShirsh() {
        return kharchachePramukhShirsh;
    }

    public void setKharchachePramukhShirsh(String kharchachePramukhShirsh) {
        this.kharchachePramukhShirsh = kharchachePramukhShirsh;
    }

    public String getManjurRakkam() {
        return manjurRakkam;
    }

    public void setManjurRakkam(String manjurRakkam) {
        this.manjurRakkam = manjurRakkam;
    }

    public String getKharchachaSudharitAndaz() {
        return kharchachaSudharitAndaz;
    }

    public void setKharchachaSudharitAndaz(String kharchachaSudharitAndaz) {
        this.kharchachaSudharitAndaz = kharchachaSudharitAndaz;
    }

    public String getKharchachaAdhikVaja() {
        return kharchachaAdhikVaja;
    }

    public void setKharchachaAdhikVaja(String kharchachaAdhikVaja) {
        this.kharchachaAdhikVaja = kharchachaAdhikVaja;
    }

    public String getShera() {
        return shera;
    }

    public void setShera(String shera) {
        this.shera = shera;
    }

    public Long getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Long employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public Long getGrampanchayatId() {
        return grampanchayatId;
    }

    public void setGrampanchayatId(Long grampanchayatId) {
        this.grampanchayatId = grampanchayatId;
    }

    public String getGrampanchayatName() {
        return grampanchayatName;
    }

    public void setGrampanchayatName(String grampanchayatName) {
        this.grampanchayatName = grampanchayatName;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }



	public String getMonth() {
		return month;
	}



	public void setMonth(String month) {
		this.month = month;
	}



	public String getDnyapanRupees() {
		return dnyapanRupees;
	}



	public void setDnyapanRupees(String dnyapanRupees) {
		this.dnyapanRupees = dnyapanRupees;
	}
    
}
