package eGramPanchayat.dto;

public class Namuna18KirkolRokadVahiDto {
    private Long id;
    private String remark;
    private Long employeeId;
    private String employeeName;
    private Long grampanchayatId;
    private String grampanchayatName;
    private String jamaTarikh;
    private String dhanadeshKramank;
    private String konakadunPraptZala;
    private String jamaTapshil;
    private String jamaRakkam;
    private String agrim;
    private String jamaEkun;
    private String adhyakshari;
    private String kharchTarikh;
    private String kharchTapshil;
    private String konasRakkamDili;
    private String kharchRakkam;
    private String agrimatunKharch;
    private String kharchEkun;
    private String swakshari;
    private String prarambhiShillak;         
    private String prarambhiShillakJama;    
    private String prarambhiShillakKharch;
    private String prarambhiShillakEkun;    
    private String prarambhiShillakRokh;   
    private String aarambhiShillak;         
    private String aarambhiShillakJama;  
    private String aarambhiShillakEkun;     
    private String year;
    private String kharchYear;
    private String kharchShera;
    
    
    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Long getGrampanchayatId() {
		return grampanchayatId;
	}

	public void setGrampanchayatId(Long grampanchayatId) {
		this.grampanchayatId = grampanchayatId;
	}

	public String getGrampanchayatName() {
		return grampanchayatName;
	}

	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}

	public String getJamaTarikh() {
		return jamaTarikh;
	}

	public void setJamaTarikh(String jamaTarikh) {
		this.jamaTarikh = jamaTarikh;
	}

	public String getDhanadeshKramank() {
		return dhanadeshKramank;
	}

	public void setDhanadeshKramank(String dhanadeshKramank) {
		this.dhanadeshKramank = dhanadeshKramank;
	}

	public String getKonakadunPraptZala() {
		return konakadunPraptZala;
	}

	public void setKonakadunPraptZala(String konakadunPraptZala) {
		this.konakadunPraptZala = konakadunPraptZala;
	}

	public String getJamaTapshil() {
		return jamaTapshil;
	}

	public void setJamaTapshil(String jamaTapshil) {
		this.jamaTapshil = jamaTapshil;
	}

	public String getJamaRakkam() {
		return jamaRakkam;
	}

	public void setJamaRakkam(String jamaRakkam) {
		this.jamaRakkam = jamaRakkam;
	}

	public String getAgrim() {
		return agrim;
	}

	public void setAgrim(String agrim) {
		this.agrim = agrim;
	}

	public String getJamaEkun() {
		return jamaEkun;
	}

	public void setJamaEkun(String jamaEkun) {
		this.jamaEkun = jamaEkun;
	}

	public String getAdhyakshari() {
		return adhyakshari;
	}

	public void setAdhyakshari(String adhyakshari) {
		this.adhyakshari = adhyakshari;
	}

	public String getKharchTarikh() {
		return kharchTarikh;
	}

	public void setKharchTarikh(String kharchTarikh) {
		this.kharchTarikh = kharchTarikh;
	}

	public String getKharchTapshil() {
		return kharchTapshil;
	}

	public void setKharchTapshil(String kharchTapshil) {
		this.kharchTapshil = kharchTapshil;
	}

	public String getKonasRakkamDili() {
		return konasRakkamDili;
	}

	public void setKonasRakkamDili(String konasRakkamDili) {
		this.konasRakkamDili = konasRakkamDili;
	}

	public String getKharchRakkam() {
		return kharchRakkam;
	}

	public void setKharchRakkam(String kharchRakkam) {
		this.kharchRakkam = kharchRakkam;
	}

	public String getAgrimatunKharch() {
		return agrimatunKharch;
	}

	public void setAgrimatunKharch(String agrimatunKharch) {
		this.agrimatunKharch = agrimatunKharch;
	}

	public String getKharchEkun() {
		return kharchEkun;
	}

	public void setKharchEkun(String kharchEkun) {
		this.kharchEkun = kharchEkun;
	}

	public String getSwakshari() {
		return swakshari;
	}

	public void setSwakshari(String swakshari) {
		this.swakshari = swakshari;
	}

	// Getters and Setters for new fields
    public String getPrarambhiShillak() {
        return prarambhiShillak;
    }

    public void setPrarambhiShillak(String prarambhiShillak) {
        this.prarambhiShillak = prarambhiShillak;
    }

    public String getPrarambhiShillakJama() {
        return prarambhiShillakJama;
    }

    public void setPrarambhiShillakJama(String prarambhiShillakJama) {
        this.prarambhiShillakJama = prarambhiShillakJama;
    }

    public String getPrarambhiShillakKharch() {
        return prarambhiShillakKharch;
    }

    public void setPrarambhiShillakKharch(String prarambhiShillakKharch) {
        this.prarambhiShillakKharch = prarambhiShillakKharch;
    }

    public String getPrarambhiShillakEkun() {
        return prarambhiShillakEkun;
    }

    public void setPrarambhiShillakEkun(String prarambhiShillakEkun) {
        this.prarambhiShillakEkun = prarambhiShillakEkun;
    }

    public String getPrarambhiShillakRokh() {
        return prarambhiShillakRokh;
    }

    public void setPrarambhiShillakRokh(String prarambhiShillakRokh) {
        this.prarambhiShillakRokh = prarambhiShillakRokh;
    }

    public String getAarambhiShillak() {
        return aarambhiShillak;
    }

    public void setAarambhiShillak(String aarambhiShillak) {
        this.aarambhiShillak = aarambhiShillak;
    }

    public String getAarambhiShillakJama() {
        return aarambhiShillakJama;
    }

    public void setAarambhiShillakJama(String aarambhiShillakJama) {
        this.aarambhiShillakJama = aarambhiShillakJama;
    }

    public String getAarambhiShillakEkun() {
        return aarambhiShillakEkun;
    }

    public void setAarambhiShillakEkun(String aarambhiShillakEkun) {
        this.aarambhiShillakEkun = aarambhiShillakEkun;
    }

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getKharchYear() {
		return kharchYear;
	}

	public void setKharchYear(String kharchYear) {
		this.kharchYear = kharchYear;
	}

	public String getKharchShera() {
		return kharchShera;
	}

	public void setKharchShera(String kharchShera) {
		this.kharchShera = kharchShera;
	}
	
}
