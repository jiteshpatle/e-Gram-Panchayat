package eGramPanchayat.dto;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public class LekhaparikshanAaksheepanNamuna27DTO {

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	private Long id;

	// @Pattern(regexp = "^[^@]*$", message = "Anukramamka cannot contain the @
	// character.")
	// @NotNull(message = "Anukramamka cannot be null.")
	// @NotBlank(message = "Anukramamka cannot be empty.")
	// private String anukramamka;

	@NotNull(message = "Lekhaparikshan ahvalche vrsh cannot be null.")
	@NotBlank(message = "Lekhaparikshan ahvalche vrsh cannot be empty.")
	private String lekhaparikshanaAhvalcheVrsh;

	@Pattern(regexp = "^[\u0966-\u096F0-9 .]*$", message = "Paricheda samkhaya cannot contain the @ character.")
	@NotNull(message = "Paricheda samkhaya cannot be null.")
	@NotBlank(message = "Lekhapari KshanaAhvalatila Paricheda samkhaya cannot be empty.")
	private String lekhaparikshanaAhvalatilaParicchhedaSamkhaya;

	@Pattern(regexp = "^[\u0966-\u096F0-9 .]*$", message = "Grampanchayat pootarta kelelya cannot contain the @ character.")
	@NotNull(message = "Grampanchayat pootarta kelelya cannot be null.")
	@NotBlank(message = "Grampanchayat pootarta kelelya cannot be empty.")
	private String grampanchayattineeYaMahinyataPootartaKelelyaPariccchhedanchiSaikhaya;

	@Pattern(regexp = "^[\u0966-\u096F0-9 .]*$", message = "Panchayat samittine aakshepa cannot contain the @ character.")
	@NotNull(message = "Panchayat samittine aakshepa cannot be null.")
	@NotBlank(message = "Panchayat samittine aakshepa cannot be empty.")
	private String panchayatSamittineAakshepaadaraMaanyaKeleylyaaPootartachiSaikhaya;

	@Pattern(regexp = "^[\u0966-\u096F0-9 .]*$", message = "Aakshepanche sakhaya cannot contain the @ character.")
	@NotNull(message = "Aakshepanche sakhaya cannot be null.")
	@NotBlank(message = "Aakshepanche sakhaya cannot be empty.")
	private String lekhaparikshkaneChyaBabatitPootartaMaanyaKeliAaheTyaAaksheepaanchyaaSakhaya;

	@Pattern(regexp = "^[\u0966-\u096F0-9 .]*$", message = "Prlabit aakshepa cannot contain the @ character.")
	@NotNull(message = "Prlabit aakshepa cannot be null.")
	@NotBlank(message = "Prlabit aakshepa cannot be empty.")
	private String prlabitAsalellyaAakshepachiSakhaya;

	@Pattern(regexp = "^[a-zA-Z\\u0900-\\u097F\\p{P}\\p{S} ]*$", message = "Kaaryanvayan kaarana cannot contain the @ character.")
	@NotNull(message = "Kaaryanvayan kaarana cannot be null.")
	@NotBlank(message = "Kaaryanvayan kaarana cannot be empty.")
	private String pootartaNaKelelayabghlachiKaarana;

	@Pattern(regexp = "^[a-zA-Z\\u0900-\\u097F\\p{P}\\p{S} ]*$", message = "Shera cannot contain the @ character.")
	@NotNull(message = "Shera cannot be null.")
	@NotBlank(message = "Shera cannot be empty.")
	private String shera;

	// @Pattern(regexp = "^[a-zA-Z\\u0900-\\u097F ]*", message = "Employee Name
	// cannot contain the @ character.")
	// @NotNull(message = "Employee Name cannot be null.")
	// @NotBlank(message = "Employee Name cannot be empty.")
	private String employeeName;

	// @Pattern(regexp = "^[\u0966-\u096F0-9 .]*$", message = "Employee Name cannot
	// contain the @ character.")
	// @NotBlank(message = "Grampanchyat ID cannot be empty.")
	// @NotNull(message = "Grampanchyat ID cannot be null.")
	private String grampanchyatId;

	// @Pattern(regexp = "^[a-zA-Z\\u0900-\\u097F ]*", message = "Grampanchyat Name
	// cannot contain the @ character.")
	// @NotNull(message = "Grampanchyat Name cannot be null.")
	// @NotBlank(message = "Grampanchyat Name cannot be empty.")
	private String grampanchyatName;

	private LocalDateTime createDate;
	private LocalDateTime updatedDate;

	// @Pattern(regexp = "^[\u0966-\u096F0-9 . - ]*$", message = "Year must contain
	// only digits.")
	// @NotNull(message = "Year cannot be null.")
	// @NotBlank(message = "Year cannot be empty.")
	// private String year;

	// @Pattern(regexp = "^[\u0966-\u096F0-9 .]*$", message = "Year must contain
	// only digits.")
	// @NotNull(message = "Employee Id cannot be null.")
	// @NotBlank(message = "Employee Id cannot be empty.")
	private String employeeId;

	private String dinank;

	// public String getYear() {
	// return year;
	// }
	// public void setYear(String year) {
	// this.year = year;
	// }

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public LocalDateTime getCreateDate() {
		return createDate;
	}

	public void setCreateDate(LocalDateTime createDate) {
		this.createDate = createDate;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getGrampanchyatName() {
		return grampanchyatName;
	}

	public void setGrampanchyatName(String grampanchyatName) {
		this.grampanchyatName = grampanchyatName;
	}

	// public String getAnukramamka() {
	// return anukramamka;
	// }
	//
	// public void setAnukramamka(String anukramamka) {
	// this.anukramamka = anukramamka;
	// }

	public String getLekhaparikshanaAhvalatilaParicchhedaSamkhaya() {
		return lekhaparikshanaAhvalatilaParicchhedaSamkhaya;
	}

	public void setLekhaparikshanaAhvalatilaParicchhedaSamkhaya(String lekhaparikshanaAhvalatilaParicchhedaSamkhaya) {
		this.lekhaparikshanaAhvalatilaParicchhedaSamkhaya = lekhaparikshanaAhvalatilaParicchhedaSamkhaya;
	}

	public String getGrampanchayattineeYaMahinyataPootartaKelelyaPariccchhedanchiSaikhaya() {
		return grampanchayattineeYaMahinyataPootartaKelelyaPariccchhedanchiSaikhaya;
	}

	public void setGrampanchayattineeYaMahinyataPootartaKelelyaPariccchhedanchiSaikhaya(
			String grampanchayattineeYaMahinyataPootartaKelelyaPariccchhedanchiSaikhaya) {
		this.grampanchayattineeYaMahinyataPootartaKelelyaPariccchhedanchiSaikhaya = grampanchayattineeYaMahinyataPootartaKelelyaPariccchhedanchiSaikhaya;
	}

	public String getPanchayatSamittineAakshepaadaraMaanyaKeleylyaaPootartachiSaikhaya() {
		return panchayatSamittineAakshepaadaraMaanyaKeleylyaaPootartachiSaikhaya;
	}

	public void setPanchayatSamittineAakshepaadaraMaanyaKeleylyaaPootartachiSaikhaya(
			String panchayatSamittineAakshepaadaraMaanyaKeleylyaaPootartachiSaikhaya) {
		this.panchayatSamittineAakshepaadaraMaanyaKeleylyaaPootartachiSaikhaya = panchayatSamittineAakshepaadaraMaanyaKeleylyaaPootartachiSaikhaya;
	}

	public String getLekhaparikshkaneChyaBabatitPootartaMaanyaKeliAaheTyaAaksheepaanchyaaSakhaya() {
		return lekhaparikshkaneChyaBabatitPootartaMaanyaKeliAaheTyaAaksheepaanchyaaSakhaya;
	}

	public void setLekhaparikshkaneChyaBabatitPootartaMaanyaKeliAaheTyaAaksheepaanchyaaSakhaya(
			String lekhaparikshkaneChyaBabatitPootartaMaanyaKeliAaheTyaAaksheepaanchyaaSakhaya) {
		this.lekhaparikshkaneChyaBabatitPootartaMaanyaKeliAaheTyaAaksheepaanchyaaSakhaya = lekhaparikshkaneChyaBabatitPootartaMaanyaKeliAaheTyaAaksheepaanchyaaSakhaya;
	}

	public String getPrlabitAsalellyaAakshepachiSakhaya() {
		return prlabitAsalellyaAakshepachiSakhaya;
	}

	public void setPrlabitAsalellyaAakshepachiSakhaya(String prlabitAsalellyaAakshepachiSakhaya) {
		this.prlabitAsalellyaAakshepachiSakhaya = prlabitAsalellyaAakshepachiSakhaya;
	}

	public String getPootartaNaKelelayabghlachiKaarana() {
		return pootartaNaKelelayabghlachiKaarana;
	}

	public void setPootartaNaKelelayabghlachiKaarana(String pootartaNaKelelayabghlachiKaarana) {
		this.pootartaNaKelelayabghlachiKaarana = pootartaNaKelelayabghlachiKaarana;
	}

	public String getShera() {
		return shera;
	}

	public void setShera(String shera) {
		this.shera = shera;
	}

	public String getGrampanchyatId() {
		return grampanchyatId;
	}

	public void setGrampanchyatId(String grampanchyatId) {
		this.grampanchyatId = grampanchyatId;
	}

	public String getLekhaparikshanaAhvalcheVrsh() {
		return lekhaparikshanaAhvalcheVrsh;
	}

	public void setLekhaparikshanaAhvalcheVrsh(
			@NotNull String lekhaparikshanaAhvalcheVrsh) {
		this.lekhaparikshanaAhvalcheVrsh = lekhaparikshanaAhvalcheVrsh;
	}

	public String getDinank() {
		return dinank;
	}

	public void setDinank(String dinank) {
		this.dinank = dinank;
	}


	
}