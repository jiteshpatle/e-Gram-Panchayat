package eGramPanchayat.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import java.util.Date;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

public class GuntonukNamuna25Dto {

	private Long id;
	// @NotNull(message = "Guntonukici Tarikha cannot be null.")
	private Date guntonukiciTarikha;

	// @NotNull(message = "Guntonukici Tapisila cannot be null.")
	// @NotBlank(message = "Guntonukici Tapisila cannot be empty.")
	// @Pattern(regexp = "^[^@]*$", message = "Guntonukici Tapisila cannot contain
	// the @ character.")
	private String guntonukiciTapisila;

	// @NotNull(message = "Guntonukichi Rakam Darsani Mulya cannot be null.")
	// @NotBlank(message = "Guntonukichi Rakam Darsani Mulya cannot be empty.")
	// @Pattern(regexp = "^[^@]*$", message = "Guntonukichi Rakam Darsani Mulya
	// cannot contain the @ character.")
	private String guntonukichiRakamDarsaniMulya;

	// @NotNull(message = "Guntonukichi Rakam Kharēdī Kimata cannot be null.")
	// @NotBlank(message = "Guntonukichi Rakam Kharēdī Kimata cannot be empty.")
	/// @Pattern(regexp = "^[^@]*$", message = "Guntonukichi Rakam Kharēdī Kimata
	// cannot contain the @ character.")
	private String guntonukichiRakamKharēdīKimata;

	@NotNull(message = "Pranit Honachi Tarkhi cannot be null.")
	private Date pranitHonachiTarkhi;

	// @NotNull(message = "Nival Dya Rakam cannot be null.")
	// @NotBlank(message = "Nival Dya Rakam cannot be empty.")
	@Pattern(regexp = "^[^@]*$", message = "Nival Dya Rakam cannot contain the @ character.")
	private String nivalDyaRakam;

	@NotNull(message = "Uparichit Vachanchi Tarkhi cannot be null.")
	private Date uparichitVachanchiTarakhi;

	// @NotNull(message = "Badlicha Padrothricha Dinaka cannot be null.")
	// @NotBlank(message = "Badlicha Padrothricha Dinaka cannot be empty.")
	// @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-dd-MM")
	// @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "Date must be in the
	// format yyyy-MM-dd")
	private String badlichaPadrothrichaDinaka;

	// @NotNull(message = "Dainik Rokad Bahithil Jama Rakam cannot be null.")
	// @NotBlank(message = "Dainik Rokad Bahithil Jama Rakam cannot be empty.")
	// @Pattern(regexp = "^[^@]*$", message = "Dainik Rokad Bahithil Jama Rakam
	// cannot contain the @ character.")
	private String dainikRokadBahithilJamaRakam;

	// @NotNull(message = "Prakritischi Tapasni cannot be null.")
	// @NotBlank(message = "Prakritischi Tapasni cannot be empty.")
	// @Pattern(regexp = "^[^@]*$", message = "Prakritischi Tapasni cannot contain
	// the @ character.")
	private String prakritischiTapasni;

	// @NotNull(message = "Create Date cannot be null.")
	@CreationTimestamp
	private Date createDate;

	// @NotNull(message = "Updated Date cannot be null.")
	@UpdateTimestamp
	private Date updatedDate;

	// @NotNull(message = "Employee ID cannot be null.")
	private String employeeId;

	// @NotNull(message = "Employee Name cannot be null.")
	// @NotBlank(message = "Employee Name cannot be empty.")
	@Pattern(regexp = "^[^@]*$", message = "Employee Name cannot contain the @ character.")
	private String employeeName;

	// @NotNull(message = "Grampanchyat ID cannot be null.")
	private String grampanchyatId;

	// @NotNull(message = "Grampanchyat Name cannot be null.")
	// @NotBlank(message = "Grampanchyat Name cannot be empty.")
	@Pattern(regexp = "^[^@]*$", message = "Grampanchyat Name cannot contain the @ character.")
	private String grampanchyatName;

	// @NotNull(message = "Remark cannot be null.")
	// @NotBlank(message = "Remark cannot be empty.")
	@Pattern(regexp = "^[^@]*$", message = "Remark cannot contain the @ character.")
	private String remark;

	private String dinank;

	// private String month;

	// public String getMonth() {
	// return month;
	// }

	// public void setMonth(String month) {
	// this.month = month;
	// }

	@NotNull(message = "Year cannot be null.")
	// @NotBlank(message = "Year cannot be empty.")
	@Pattern(regexp = "^[0-9]+$", message = "Field must contain only digits.")
	private String Year;

	public String getYear() {
		return Year;
	}

	public void setYear(String year) {
		Year = year;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getGuntonukiciTarikha() {
		return guntonukiciTarikha;
	}

	public void setGuntonukiciTarikha(Date guntonukiciTarikha) {
		this.guntonukiciTarikha = guntonukiciTarikha;
	}

	public String getGuntonukiciTapisila() {
		return guntonukiciTapisila;
	}

	public void setGuntonukiciTapisila(String guntonukiciTapisila) {
		this.guntonukiciTapisila = guntonukiciTapisila;
	}

	public String getGuntonukichiRakamDarsaniMulya() {
		return guntonukichiRakamDarsaniMulya;
	}

	public void setGuntonukichiRakamDarsaniMulya(String guntonukichiRakamDarsaniMulya) {
		this.guntonukichiRakamDarsaniMulya = guntonukichiRakamDarsaniMulya;
	}

	public String getGuntonukichiRakamKharēdīKimata() {
		return guntonukichiRakamKharēdīKimata;
	}

	public void setGuntonukichiRakamKharēdīKimata(String guntonukichiRakamKharēdīKimata) {
		this.guntonukichiRakamKharēdīKimata = guntonukichiRakamKharēdīKimata;
	}

	public Date getPranitHonachiTarkhi() {
		return pranitHonachiTarkhi;
	}

	public void setPranitHonachiTarkhi(Date pranitHonachiTarkhi) {
		this.pranitHonachiTarkhi = pranitHonachiTarkhi;
	}

	public String getNivalDyaRakam() {
		return nivalDyaRakam;
	}

	public void setNivalDyaRakam(String nivalDyaRakam) {
		this.nivalDyaRakam = nivalDyaRakam;
	}

	public Date getUparichitVachanchiTarakhi() {
		return uparichitVachanchiTarakhi;
	}

	public void setUparichitVachanchiTarakhi(Date uparichitVachanchiTarakhi) {
		this.uparichitVachanchiTarakhi = uparichitVachanchiTarakhi;
	}

	public String getBadlichaPadrothrichaDinaka() {
		return badlichaPadrothrichaDinaka;
	}

	public void setBadlichaPadrothrichaDinaka(String badlichaPadrothrichaDinaka) {
		this.badlichaPadrothrichaDinaka = badlichaPadrothrichaDinaka;
	}

	public String getDainikRokadBahithilJamaRakam() {
		return dainikRokadBahithilJamaRakam;
	}

	public void setDainikRokadBahithilJamaRakam(String dainikRokadBahithilJamaRakam) {
		this.dainikRokadBahithilJamaRakam = dainikRokadBahithilJamaRakam;
	}

	public String getPrakritischiTapasni() {
		return prakritischiTapasni;
	}

	public void setPrakritischiTapasni(String prakritischiTapasni) {
		this.prakritischiTapasni = prakritischiTapasni;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getGrampanchyatName() {
		return grampanchyatName;
	}

	public void setGrampanchyatName(String grampanchyatName) {
		this.grampanchyatName = grampanchyatName;
	}

	public String getDinank() {
		return dinank;
	}

	public void setDinank(String dinank) {
		this.dinank = dinank;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getGrampanchyatId() {
		return grampanchyatId;
	}

	public void setGrampanchyatId(String grampanchyatId) {
		this.grampanchyatId = grampanchyatId;
	}

	

	// Getters and Setters...
}
