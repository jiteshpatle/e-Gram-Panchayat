package eGramPanchayat.dto;



import java.time.LocalDateTime;
import java.util.Map;

public class Namuna19KamavarAslelyaVyaktinchaHajeripatDto {
    private Long id;
    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;
    private String remark;
    private Long employeeId;
    private String employeeName;
    private Long grampanchayatId;
    private String grampanchayatName;
    private String sampurnaNaav;
    private String gaon;
    private String hudda;
    private String dar;
    private String ekun;
    private String dileliRakkam;
    private String year;
    private String yeneAsleliShillakRakkam;
    private String paiseDenaryaAdhikaryaneKaravayachiTaNishaA;
    private Map<String, String> attendanceData;  // This will store day-wise statuses
	
    
    public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public LocalDateTime getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public Long getGrampanchayatId() {
		return grampanchayatId;
	}
	public void setGrampanchayatId(Long grampanchayatId) {
		this.grampanchayatId = grampanchayatId;
	}
	public String getGrampanchayatName() {
		return grampanchayatName;
	}
	public void setGrampanchayatName(String grampanchayatName) {
		this.grampanchayatName = grampanchayatName;
	}
	public String getSampurnaNaav() {
		return sampurnaNaav;
	}
	public void setSampurnaNaav(String sampurnaNaav) {
		this.sampurnaNaav = sampurnaNaav;
	}
	public String getGaon() {
		return gaon;
	}
	public void setGaon(String gaon) {
		this.gaon = gaon;
	}
	public String getHudda() {
		return hudda;
	}
	public void setHudda(String hudda) {
		this.hudda = hudda;
	}
	public String getDar() {
		return dar;
	}
	public void setDar(String dar) {
		this.dar = dar;
	}
	public String getEkun() {
		return ekun;
	}
	public void setEkun(String ekun) {
		this.ekun = ekun;
	}
	public String getDileliRakkam() {
		return dileliRakkam;
	}
	public void setDileliRakkam(String dileliRakkam) {
		this.dileliRakkam = dileliRakkam;
	}
	public String getYeneAsleliShillakRakkam() {
		return yeneAsleliShillakRakkam;
	}
	public void setYeneAsleliShillakRakkam(String yeneAsleliShillakRakkam) {
		this.yeneAsleliShillakRakkam = yeneAsleliShillakRakkam;
	}
	public String getPaiseDenaryaAdhikaryaneKaravayachiTaNishaA() {
		return paiseDenaryaAdhikaryaneKaravayachiTaNishaA;
	}
	public void setPaiseDenaryaAdhikaryaneKaravayachiTaNishaA(String paiseDenaryaAdhikaryaneKaravayachiTaNishaA) {
		this.paiseDenaryaAdhikaryaneKaravayachiTaNishaA = paiseDenaryaAdhikaryaneKaravayachiTaNishaA;
	}
	public Map<String, String> getAttendanceData() {
		return attendanceData;
	}
	public void setAttendanceData(Map<String, String> attendanceData) {
		this.attendanceData = attendanceData;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}

}
